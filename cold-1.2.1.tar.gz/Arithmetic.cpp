/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//#include <iostream>
//using namespace std;

//#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

//#include "Miscellaneous.h"

//routine for parsing arithmetic expressions.


class ldstackelt{//stack of long doubles
  long double val;
  ldstackelt *next;
  friend class ldstack;
  ldstackelt(long double v,ldstackelt *n=NULL){next=n;val=v;};
};


class ldstack{//stack of long doubles
  int size;
  ldstackelt *top;
public:
  ldstack(){size=0;top=NULL;};
  long double pop(){if(size<=0){throw 0;};size--;ldstackelt *dl=top;top=top->next;long double ans=dl->val;delete dl;return ans;};
  void push(long double v){size++;ldstackelt *nt=new ldstackelt(v,top);top=nt;};
  void dump(char *&out){if(size>0){int sz=size;long double *temp=new long double[size];for(;size>0;*(temp+size-1)=this->pop());for(int i=0;i<sz;i++){sprintf(out,"%Lg ",*(temp+i));out+=strlen(out);};delete[] temp;};};
};

#define PLUS 1
#define MINUS 2
#define TIMES 3
#define DIV 4

int getop(const char *&s){
  switch(*(s++)){
  case '+':
    return PLUS;
  case '-':
    return MINUS;
  case '*':
    return TIMES;
  case '/':
    return DIV;
  };
  return 0;
};

char *parseexp(const char *exp){
  char *ans=new char[strlen(exp)*3+2];
  const char *starttok=exp;
  char *pos=ans;
  
  ldstack st;

  while(*starttok){
    if(isdigit(*starttok)||*starttok=='.'||*starttok=='-'){
      long double l=strtod(starttok,(char **)&starttok);
      for(;*starttok==' '||*starttok=='\t'||*starttok=='\r';starttok++);
      st.push(l);
    }else{
      const char* scan=starttok;
      //check for operations
      int op=getop(scan);
      switch(op){
      case 0:
	st.dump(pos);
	scan=starttok;
	for(;*scan&&*scan!=' '&&*scan!='\t'&&*scan!='\r';scan++){
	  *(pos++)=*scan;
	};
	for(;*scan==' '||*scan=='\t'||*scan=='\r';){
	  *(pos++)=*(scan++);
	};
	break;
      case PLUS:
	{
	  long double a=st.pop();
	  long double b=st.pop();
	  st.push(a+b);
	  break;
	}
      case MINUS:
	{
	  long double a=st.pop();
	  long double b=st.pop();
	  st.push(b-a);
	  break;
	}
      case TIMES:
	{
	  long double a=st.pop();
	  long double b=st.pop();
	  st.push(a*b);
	  break;
	}
      case DIV:
	{
	  long double a=st.pop();
	  long double b=st.pop();
	  st.push(b/a);
	  break;
	}
      };
      for(;*scan==' '||*scan=='\t'||*scan=='\r';scan++);
      starttok=scan;
    };
  };
  st.dump(pos);
  *pos='\0';
  return ans;
};

/*int main(int argc,char *argv[]){
  if(argc>1){
    cout<<parseexp(argv[1])<<"\n";
  };    
  };*/
