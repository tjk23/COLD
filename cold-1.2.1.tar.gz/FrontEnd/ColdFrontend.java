/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

import java.io.*;
import javax.swing.table.*;
import java.lang.*;
//import java.io.file.*;
//import java.nio.file.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.prefs.*;

class HandleError implements Runnable{   
    Process pr;
    BufferedReader input;
    JTextArea output; 
    public HandleError(Process p,BufferedReader i,JTextArea o){
	pr=p;
	input=i;
	output=o;
    }
    public void run(){
	try{
	    String line=null;
	    while((line=input.readLine()) != null) {
		System.out.println(line);
		//		output.setRows(output.getRows()+1);
		/*		if(line.length()>output.getColumns()){
		    output.setColumns(line.length());
		};
		output.append(line);
		output.append("\n");
		output.revalidate();*/
	    }
	}catch(Exception e){
	    if(!e.toString().contains("Stream closed")){
		System.out.println(e.toString());
	    };
	}
    }
}


class HandleOutput implements Runnable{   
    Process pr;
    BufferedReader input;
    JTextArea output; 
    ProgressMonitor pm;
    float progress;
    int stp;
    public HandleOutput(Process p,BufferedReader i,JTextArea o,ProgressMonitor pro){
	pr=p;
	input=i;
	output=o;
	pm=pro;
    }
    public void run(){
	try{
	    String line=null;
	    while((line=input.readLine()) != null) {
		output.setRows(output.getRows()+1);
		if(line.length()>output.getColumns()){
		    output.setColumns(line.length());
		};
		output.append(line);
		output.append("\n");
		output.revalidate();
		updateState(line);
		if(pm.isCanceled()){
		    pr.destroy();
		    ColdFrontend.current.endProcess();
		};
	    }
	    input.close();
	    ColdFrontend.current.endProcess();
	}catch(Exception e){
	    if(!e.toString().contains("Stream closed")){
		System.out.println(e.toString());
	    };
	}
    }
    void updateState(String line){
	if(line.contains("Started step")){
	    stp=Integer.valueOf(line.substring(line.lastIndexOf("number")+7,line.lastIndexOf('.')));
	    pm.setNote(line);
	};
	if(line.contains("Expected improvement")){
	    double ei=Float.valueOf(line.substring(line.lastIndexOf("=")+1));
	    double expStepsToComplete=-20/(Math.log(Math.abs(ei))-2);
	    if(expStepsToComplete<0){
		expStepsToComplete=100;
	    };
	    if(ei<1e-10){
		expStepsToComplete=0;
	    };
	    //	    pm.setNote("Estimated steps to completion: "+expStepsToComplete);
	    pm.setProgress((int)(stp*pm.getMaximum()/(expStepsToComplete+stp)));	    
	};
    }
}

class TestDerivsAction extends AbstractAction{
    public TestDerivsAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
    }
    public void actionPerformed(ActionEvent e){
	double epsilon=Float.valueOf((String)JOptionPane.showInputDialog("Epsilon","1e-6"));
	ColdFrontend.current.run.addarg("--testderivs",null);
	ColdFrontend.current.run.addarg("-e",""+epsilon);
	ColdFrontend.current.run.actionPerformed(null);
    }    
};

class CodonFreqAction extends AbstractAction{
    String freq;
    public CodonFreqAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	freq=name;
    }
    public CodonFreqAction(String name,String desc,int mnemonic,String cf){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	freq=cf;
    }
    public void actionPerformed(ActionEvent e){
	if(freq==null){
	    ColdFrontend.current.run.removeargwithval("--empirical");
	}else{
	    ColdFrontend.current.run.addarg("--empirical",freq);
	};
    }    
};

class InitParsAction extends AbstractAction{
    //Doesn't yet work for mixed models.
    JFrame window;
    JTextField[] value;
    JButton OK;
    JButton Cancel;
    public InitParsAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
    }
    void setupWindow(){
	window=new JFrame("Set initial parameter values");
	int n=ColdFrontend.current.ps.getNum();
	value=new JTextField[n];

	JPanel panel=new JPanel(new GridBagLayout());	
 	GridBagConstraints c = new GridBagConstraints();
 	c.fill = GridBagConstraints.HORIZONTAL;
	//	MenuElement[] me=ColdFrontend.current.parmenu.getSubElements();
	for(int i=0;i<n;i++){
	    c.gridx=0;
	    c.gridy=i;
	    String parname=ColdFrontend.current.ps.getLabel(i);
	    panel.add(new JLabel(parname),c);
	    c.gridx=1;
	    c.gridy=i;
	    value[i]=new JTextField("0");
	    panel.add(value[i],c);
	};
	OK=new JButton("OK");
	OK.addActionListener(this);
	c.gridx=0;
	c.gridy=n;
	panel.add(OK,c);
	Cancel=new JButton("Cancel");
	Cancel.addActionListener(this);
	c.gridx=1;
	c.gridy=n;
	panel.add(Cancel,c);
	window.getContentPane().add(panel,BorderLayout.CENTER);
    }
    public void actionPerformed(ActionEvent e){
	if(e.getSource()==OK){
	    String list="";
	    for(int i=0;i<value.length;i++){
		list+=Float.valueOf(value[i].getText());
		if(i<value.length-1){
		    list+=",";
		};
	    };
	    ColdFrontend.current.run.addarg("--initpars",list);
	    window.setVisible(false);
	}else if(e.getSource()==Cancel){
	    //window.unpack();
	    //	    System.out.printl
	    window.setVisible(false);
	}else{
	    this.setupWindow();
	    window.pack();
	    window.setVisible(true);
	}
    }    
};

class RunSimulateAction extends AbstractAction{
    JFrame window;
    JTextField number;
    JTextField length;
    JTextField seed;
    JButton OK;
    JButton Cancel;
    public RunSimulateAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);

	window=new JFrame("Simulate");
	number=new JTextField("1");
	length=new JTextField("300");
	seed=new JTextField("12345");

	JPanel panel=new JPanel(new GridBagLayout());	
 	GridBagConstraints c = new GridBagConstraints();
 	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx=0;
	c.gridy=0;
	panel.add(new JLabel("number of simulations"),c);
	c.gridx=1;
	c.gridy=0;
	panel.add(number,c);
	c.gridx=0;
	c.gridy=1;
	panel.add(new JLabel("sequence length"),c);
	c.gridx=1;
	c.gridy=1;
	panel.add(length,c);
	c.gridx=0;
	c.gridy=2;
	panel.add(new JLabel("random number generator seed"),c);
	c.gridx=1;
	c.gridy=2;
	panel.add(seed,c);
	OK=new JButton("OK");
	OK.addActionListener(this);
	c.gridx=0;
	c.gridy=3;
	panel.add(OK,c);
	Cancel=new JButton("Cancel");
	Cancel.addActionListener(this);
	c.gridx=1;
	c.gridy=3;
	panel.add(Cancel,c);
	window.getContentPane().add(panel,BorderLayout.CENTER);
    }
    public void actionPerformed(ActionEvent e){
	if(e.getSource()==OK){
	    int len=Integer.valueOf(length.getText());
	    if(len%3!=0){
		JOptionPane.showMessageDialog(window,"Sequence length must be a multiple of 3!");
	    }else if(len<=0){
		JOptionPane.showMessageDialog(window,"Sequence length must be positive!");
	    }else{
		int num=Integer.valueOf(number.getText());
		if(num<=0){
		    JOptionPane.showMessageDialog(window,"number of sequences must be positive!");
		}else{
		    int s=Integer.valueOf(seed.getText());
		    ColdFrontend.current.run.addarg("--simulate",num+","+len+":"+s);
		    ColdFrontend.current.run.actionPerformed(null);
		    ColdFrontend.current.run.removeargwithval("--simulate");
		    window.setVisible(false);
		}
	    };
	}else if(e.getSource()==Cancel){
	    //window.unpack();
	    //	    System.out.printl
	    window.setVisible(false);
	}else{
	    window.pack();
	    window.setVisible(true);
	}
    }    
};

class StopAction extends AbstractAction{
    public StopAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
    }    
    public void actionPerformed(ActionEvent e){
	ColdFrontend.current.endProgram.windowClosing(null);
    };
};

class SetBackupAction extends AbstractAction{
    JFrame window;
    JTextField statefile;
    JTextField recover;
    JCheckBox autobackup;
    JCheckBox rec;
    JButton OK;
    JButton Cancel;
    JLabel lab;
    public SetBackupAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);

	window=new JFrame("Backup options");
	statefile=new JTextField("statefile");
	recover=new JTextField("");
	autobackup=new JCheckBox("Automatic backups",true);
	rec=new JCheckBox("Resume previous run",false);
	rec.addActionListener(this);
	recover.setEnabled(false);
	JPanel panel=new JPanel(new GridBagLayout());	
 	GridBagConstraints c = new GridBagConstraints();
 	c.fill = GridBagConstraints.HORIZONTAL;
	c.gridx=0;
	c.gridy=0;
	panel.add(new JLabel("Filename for backups"),c);
	c.gridx=1;
	c.gridy=0;
	panel.add(statefile,c);
	c.gridx=0;
	c.gridy=1;
	panel.add(autobackup,c);
	c.gridx=0;
	c.gridy=2;
	c.gridwidth=2;
	panel.add(new JSeparator(),c);
	c.gridx=0;
	c.gridy=3;
	panel.add(rec,c);
	c.gridwidth=1;
	c.gridx=0;
	c.gridy=4;
	lab=new JLabel("From File:");
	lab.setEnabled(false);
	panel.add(lab,c);
	c.gridx=1;
	c.gridy=4;
	panel.add(recover,c);
	OK=new JButton("OK");
	OK.addActionListener(this);
	c.gridx=0;
	c.gridy=5;
	panel.add(OK,c);
	Cancel=new JButton("Cancel");
	Cancel.addActionListener(this);
	c.gridx=1;
	c.gridy=5;
	panel.add(Cancel,c);
	window.getContentPane().add(panel,BorderLayout.CENTER);
    }
    public void actionPerformed(ActionEvent e){
	if(e.getSource()==OK){	    
	    if(statefile.getText().equals("")){
		JOptionPane.showMessageDialog(window,"Recovery file must be specified");		    
		return;
	    };
	    ColdFrontend.current.run.addarg("--state",statefile.getText());
	    if(autobackup.isSelected()){
		ColdFrontend.current.run.removeflag("--noautobackup");
	    }else{
		ColdFrontend.current.run.addarg("--noautobackup",null);
	    };
	    if(rec.isSelected()){
		if(recover.getText().equals("")){
		    JOptionPane.showMessageDialog(window,"Recovery file must be specified");		    
		    return;
		};
		ColdFrontend.current.run.addarg("--recover",recover.getText());
	    };
	    window.setVisible(false);
	}else if(e.getSource()==Cancel){
	    //window.unpack();
	    //	    System.out.printl
	    window.setVisible(false);
	}else if(e.getSource()==rec){
	    //window.unpack();
	    //	    System.out.printl
	    lab.setEnabled(rec.isEnabled());
	    recover.setEnabled(rec.isEnabled());
	}else{
	    window.pack();
	    window.setVisible(true);
	}
    }    
};

class RunColdAction extends AbstractAction{
    String args[];
    JTextArea output;
    String coldcommand;
    public RunColdAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	coldcommand=ColdFrontend.current.pref.get("PACKAGENAME","cold");
    }
    public RunColdAction(String name,String desc,int mnemonic,String a[]){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	args=a;
	coldcommand=ColdFrontend.current.pref.get("PACKAGENAME","cold");
    }
    public RunColdAction(String name,String desc,int mnemonic,JTextArea o){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	output=o;
	coldcommand=ColdFrontend.current.pref.get("PACKAGENAME","cold");
	//	output.setPreferredSize(new Dimension(500,500));
    }
    public void addarg(String option,String value){
	if(args==null){
	    if(value==null){
		args=new String[1];
		args[0]=option;
	    }else{
		args=new String[2];
		args[0]=option;
		args[1]=value;
	    };
	}else{
	    for(int i=0;i<args.length-1;i++){
		if(args[i]==option){
		    args[i+1]=value;
		    return;
		};
	    };
	    //No match
	    String temp[]=args;
	    if(value==null){
		args=new String[temp.length+1];
	    }else{
		args=new String[temp.length+2];
	    };
	    for(int i=0;i<temp.length;i++){
		args[i]=temp[i];
	    };
	    args[temp.length]=option;
	    if(value!=null){
		args[temp.length+1]=value;
	    };
	};
    }
    public void removeargwithval(String option){
	if(args!=null){
	    for(int i=0;i<args.length-1;i++){
		if(args[i]==option){
		    String temp[]=args;
		    args=new String[temp.length-2];
		    for(int j=0;j<i;j++){
			args[j]=temp[j];
		    };
		    for(int j=i;j<args.length;j++){
			args[j]=temp[j+2];
		    };
		};
	    };
	    //No match
	};
    }

    public void removeflag(String option){
	if(args!=null){
	    for(int i=0;i<args.length-1;i++){
		if(args[i]==option){
		    String temp[]=args;
		    args=new String[temp.length-1];
		    for(int j=0;j<i;j++){
			args[j]=temp[j];
		    };
		    for(int j=i;j<args.length;j++){
			args[j]=temp[j+1];
		    };
		};
	    };
	    //No match
	};
    }

    public void actionPerformed(ActionEvent e){
	try{	    
	    int argc;
	    if(args==null){
		argc=0;
	    }else{
		argc=args.length;
	    };
	    //	    System.out.println("Got Here!");
	    String allargs=coldcommand+" --unbufferedstdout";
	    for(int i=0;i<argc;i++){
		allargs+=" ";
		allargs+=args[i];
	    };
	    String line="Executing command: \""+allargs+"\" ...";
	    output.setRows(output.getRows()+1);
	    if(line.length()>output.getColumns()){
		output.setColumns(line.length());
	    };
	    output.append(line);
	    output.append("\n");
	    output.revalidate();

	    Runtime rt= Runtime.getRuntime();
	    Process pr=rt.exec(allargs);
	    ColdFrontend.current.endProgram.addProcess(pr);
	    ColdFrontend.current.addProcess();
	    /*	    ProgressMonitorInputStream pm=new ProgressMonitorInputStream(ColdFrontend.current.mainWindow,"Executing cold ...",pr.getInputStream());
	    pm.getProgressMonitor().setMinimum(-1);
	    pm.getProgressMonitor().setMaximum(30000);
	    pm.getProgressMonitor().setMillisToDecideToPopup(1);*/

	    ProgressMonitor pm=new ProgressMonitor(ColdFrontend.current.mainWindow,"Executing cold ...","",0,100);
	    pm.setMinimum(0);
	    pm.setMaximum(30000);
	    pm.setMillisToDecideToPopup(1);
	    BufferedReader error=new BufferedReader (new InputStreamReader(pr.getErrorStream()));
	   
	    BufferedReader input=new BufferedReader (new InputStreamReader(pr.getInputStream()),100);
	    new Thread(new HandleOutput(pr,input,output,pm)).start();
	    new Thread(new HandleError(pr,error,output)).start();
 
	    /*	    int exitVal = pr.waitFor();
	    if(exitVal!=0){
		output.append("Program terminated with error code "+exitVal);
		};*/
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class RunUtilAction extends AbstractAction{
    String args;
    //
    JTextArea output;
    String command;
    String argnames[];
    int numargs;

    JFrame window;
    JTextField[] arguments;
    JButton OK;
    JButton Cancel;
    public RunUtilAction(String name,String desc,int mnemonic,String comm,String a){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	args=a;
	command=ColdFrontend.current.pref.get("UTIL"+comm,comm.toLowerCase());
	this.prepareWindow();
    }
    public RunUtilAction(String name,String desc,int mnemonic,String comm,JTextArea o,String a){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	output=o;
	command=ColdFrontend.current.pref.get("UTIL"+comm,comm.toLowerCase());
	args=a;
	this.prepareWindow();
	//	output.setPreferredSize(new Dimension(500,500));
    }
    public RunUtilAction(String name,String desc,int mnemonic,String comm,JTextArea o,String a,String[] an){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	output=o;
	command=ColdFrontend.current.pref.get("UTIL"+comm,comm.toLowerCase());
	args=a;
	argnames=an;
	this.prepareWindow();
	//	output.setPreferredSize(new Dimension(500,500));
    }
    void prepareWindow(){
	window=new JFrame(command);
	int minarg=0;

	for(int i=0;i<args.length();i++){
	    char x=args.charAt(i);
	    switch(x){
	    case 's':
	    case 'f':
		minarg++;
		break;
	    case '?':
		minarg--;
	    };
	};
	numargs=minarg;

	if(minarg>0){
	    arguments=new JTextField[minarg];
	    for(int i=0;i<minarg;i++){
		arguments[i]=new JTextField("");
	    };
	};
	JPanel panel=new JPanel(new GridBagLayout());	
 	GridBagConstraints c = new GridBagConstraints();
 	c.fill = GridBagConstraints.HORIZONTAL;
	for(int i=0;i<minarg;i++){
	    c.gridx=0;
	    c.gridy=i;
	    if(argnames!=null&&argnames.length>i){
		panel.add(new JLabel(argnames[i]),c);
	    }else{
		panel.add(new JLabel("argument "+i),c);
	    };
	    c.gridx=1;
	    c.gridy=i;
	    panel.add(arguments[i],c);
	};
	OK=new JButton("OK");
	OK.addActionListener(this);
	c.gridx=0;
	c.gridy=minarg;
	panel.add(OK,c);
	Cancel=new JButton("Cancel");
	Cancel.addActionListener(this);
	c.gridx=1;
	c.gridy=minarg;
	panel.add(Cancel,c);
	window.getContentPane().add(panel,BorderLayout.CENTER);
    }
    public String getArgs(){
	String answer="";
	for(int i=0;i<numargs;i++){
	    answer+=arguments[i].getText()+" ";
	};
	return answer;
    }
    public void actionPerformed(ActionEvent e){
	if(e.getSource()==OK){
	    try{	    
		String allargs=command+" "+this.getArgs();//Will fix this later.
		System.out.println(allargs);
		Runtime rt= Runtime.getRuntime();
		Process pr=rt.exec(allargs);
		BufferedReader input=new BufferedReader (new InputStreamReader(pr.getInputStream()));
		String line=null;
		while((line=input.readLine()) != null) {
		    output.setRows(output.getRows()+1);
		    if(line.length()>output.getColumns()){
			output.setColumns(line.length());
		    };
		    output.append(line);
		    output.append("\n");
		    output.revalidate();
		}
		
		int exitVal = pr.waitFor();
		if(exitVal!=0){
		    output.append("Program terminated with error code "+exitVal);
		};
	    }catch(Exception ex){
		System.out.println(ex.toString());
	    }finally{
		window.setVisible(false);
	    };
	}else if(e.getSource()==Cancel){
	    //window.unpack();
	    //	    System.out.printl
	    window.setVisible(false);
	}else{
	    window.pack();
	    window.setVisible(true);
	}
    }
}




class SetValueAction extends AbstractAction{
    String option;
    String nm;
    public SetValueAction(String name,String desc,int mnemonic,String o){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	option=o;
	nm=name;
    }
    public SetValueAction(String name,String desc,int mnemonic,String o,String text){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	option=o;
	nm=text;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    String value=(String)JOptionPane.showInputDialog(nm+"=","Set value");
	    ColdFrontend.current.run.addarg(option,value);
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class FlagAction extends AbstractAction{
    String flag;
    boolean selected;
    public FlagAction(String name,String desc,int mnemonic,String f,boolean s){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	flag=f;
	selected=s;
    }
    public FlagAction(String name,String desc,int mnemonic,String f){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	flag=f;
	selected=false;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    if(selected){
		ColdFrontend.current.run.removeflag(flag);
		selected=false;
	    }else{
		ColdFrontend.current.run.addarg(flag,"");
		selected=true;
	    };
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class ParSelect{
    String infile;
    boolean selected[];
    RunColdAction rc;
    ParSelect(String f,int n){
	infile=f;
	selected=new boolean[n];
	for(int i=0;i<n;i++){
	    selected[i]=true;
	};
	rc=ColdFrontend.current.run;
    };
    ParSelect(String f){
	infile=f;
	rc=ColdFrontend.current.run;
    }
    ParSelect(){
	rc=ColdFrontend.current.run;
    }
    int getNum(){
	int ans=0;
	for(int i=0;i<selected.length;i++){
	    if(selected[i]){
		ans++;
	    };
	};
	return ans;
    }
    String getLabel(int n){
	int j=0;
	for(int i=0;i<selected.length;i++){
	    if(selected[i]){
		j++;
		if(j==n){
		    return ((JCheckBoxMenuItem)ColdFrontend.current.parmenu.getItem(j)).getText();
		};
	    };
	};
	return null;	
    };
    void setNum(int n){
	selected=new boolean[n];
	for(int i=0;i<n;i++){
	    selected[i]=true;
	};
    }
    void setValue(String f){
	infile=f;
    }
    void toggle(int n){
	selected[n]=!selected[n];
	String sel=null;
	for(int i=1;i<selected.length;i++){
	    if(selected[i]){
		if(sel==null){
		    sel="";
		}else{
		    sel+=",";
		};
		sel+=i;
	    };
	};
	rc.addarg("--parameterselection",sel);
    }
}

class ChooseParAction extends AbstractAction{
    ParSelect p;
    int number;
    JMenu men;
    public ChooseParAction(String name,String desc,int mnemonic,ParSelect ps,int n,JMenu m){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	p=ps;
	number=n;
	men=m;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    p.toggle(number);
	    men.setPopupMenuVisible(true);
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class SelectValueAction extends AbstractAction{
    String option;
    String value;
    public SelectValueAction(String name,String desc,int mnemonic,String op,String v){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	value=v;
	option=op;
    }
    public void actionPerformed(ActionEvent e){
	try{	 
	    if(value!=""){   
		ColdFrontend.current.run.addarg(option,value);
	    }else{
		ColdFrontend.current.run.removeargwithval(option);
	    };		
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}


class SelectParsimonyAction extends AbstractAction{
    String value;
    public SelectParsimonyAction(){
    }
    public SelectParsimonyAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	value=name;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    ColdFrontend.current.run.addarg("--parsimony",value);
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class RemoveModelAction extends AbstractAction{
    public RemoveModelAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    ColdFrontend.current.run.removeargwithval("--modelfile");
	    ColdFrontend.current.run.removeargwithval("--model");
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class ChooseModelAction extends AbstractAction{
    String modname;
    String infile;
    int pars;
    public ChooseModelAction(String name,String desc,int mnemonic,String filename,int num){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	modname=name;
	infile=filename;
	pars=num;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    ColdFrontend.current.run.addarg("--modelfile",infile);
	    ColdFrontend.current.run.addarg("--model",modname);
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class ChooseCodeAction extends AbstractAction{
    String codename;
    String infile;
    public ChooseCodeAction(String name,String desc,int mnemonic,String filename){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	codename=name;
	infile=filename;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    ColdFrontend.current.run.addarg("--codesfile",infile);
	    ColdFrontend.current.run.addarg("--code",codename);
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class ModelLookupAction extends AbstractAction{
    JMenu modelmenu;
    ButtonGroup bg;
    public ModelLookupAction(String name,String desc,int mnemonic,JMenu mm,ButtonGroup b){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	modelmenu=mm;
	bg=b;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    String value="test";
	    ColdFrontend.fc.setApproveButtonText("Select");
	    ColdFrontend.fc.setDialogTitle("Select Model File");
	    int decision=ColdFrontend.fc.showOpenDialog(ColdFrontend.current.mainWindow);
	    if(decision==JFileChooser.APPROVE_OPTION){
		File file=ColdFrontend.fc.getSelectedFile();
		if(file.isDirectory()){
		    //		fc.setDirectory(file);
		}else{
		    value=file.getAbsolutePath();
		    BufferedReader read=new BufferedReader(new FileReader(file));
		    String line=null;
		    int inmodel=0;
		    while((line=read.readLine())!=null){
			if(inmodel==0){
			    int li=line.lastIndexOf('{');
			    if(li!=-1){
				String modname=line.substring(0,li);
				li=modname.lastIndexOf('(');
				int numpars=0;
				if(li!=-1){
				    String params=modname.substring(modname.indexOf('(')+1,modname.lastIndexOf(')'));
				    numpars++;
				    for(int ic=params.lastIndexOf(',');ic!=-1;ic=params.lastIndexOf(',')){
					params=params.substring(0,ic);
					numpars++;
				    };
				};
				JRadioButtonMenuItem mIt=new JRadioButtonMenuItem(modname,false);
				mIt.setAction(new ChooseModelAction(modname,"",0,value,numpars));
				modelmenu.add(mIt);
				bg.add(mIt);		    
			    };
			}else{
			    if(line.lastIndexOf('}')!=-1){
				inmodel=0;
			    };
			};
		    };
		};
	    }
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class CodeLookupAction extends AbstractAction{
    JMenu modelmenu;
    ButtonGroup bg;
    public CodeLookupAction(String name,String desc,int mnemonic,JMenu mm,ButtonGroup b){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	modelmenu=mm;
	bg=b;
    }
    public void actionPerformed(ActionEvent e){
	try{	    
	    String value="test";
	    ColdFrontend.fc.setApproveButtonText("Select");
	    ColdFrontend.fc.setDialogTitle("Select Model File");
	    int decision=ColdFrontend.fc.showOpenDialog(ColdFrontend.current.mainWindow);
	    if(decision==JFileChooser.APPROVE_OPTION){
		File file=ColdFrontend.fc.getSelectedFile();
		if(file.isDirectory()){
		    //		fc.setDirectory(file);
		}else{
		    value=file.getAbsolutePath();
		    BufferedReader read=new BufferedReader(new FileReader(file));
		    String line=null;
		    while((line=read.readLine())!=null){
			int li=line.indexOf(' ');
			if(li!=-1){
			    String codename=line.substring(0,li);
			    JRadioButtonMenuItem mIt=new JRadioButtonMenuItem(codename,false);
			    mIt.setAction(new ChooseCodeAction(codename,"",0,value));
			    modelmenu.add(mIt);
			    bg.add(mIt);		    
			};
		    };
		};
	    }
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class SetFileAction extends AbstractAction{
    //    String args[];
    String option;
    String title;
    String type;
    public SetFileAction(String name,String desc,int mnemonic){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	title="file";
	type=null;
    }
    public SetFileAction(String name,String desc,int mnemonic,String op){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	option=op;
	title="file";
	type=null;
    }
    public SetFileAction(String name,String desc,int mnemonic,String op,String tit){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	option=op;
	title=tit;
	type=null;
    }
    public SetFileAction(String name,String desc,int mnemonic,String op,String tit,String ty){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	option=op;
	title=tit;
	type=ty;
    }
    /*    public RunColdAction(String name,String desc,int mnemonic,String a[]){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	args=a;
	}*/
    public void actionPerformed(ActionEvent e){
	try{
	    String value="test";
	    //	    JFileChooser fc=new JFileChooser();
	    ColdFrontend.fc.setApproveButtonText("Select");
	    ColdFrontend.fc.setDialogTitle("Select " +title);
	    int decision=ColdFrontend.fc.showOpenDialog(ColdFrontend.current.mainWindow);
	    if(decision==JFileChooser.APPROVE_OPTION){
		File file=ColdFrontend.fc.getSelectedFile();
		if(file.isDirectory()){
		    //		fc.setDirectory(file);
		}else{
		    value=file.getAbsolutePath();
		    ColdFrontend.current.run.addarg(option,value);
		    if(type!=null){			
			ColdFrontend.current.setFile(type,value);
		    };
		};
	    }
	}catch(Exception ex){
	    System.out.println(ex.toString());
	};
    }
}

class SetMixtureAction extends AbstractAction{
    ParSelect p;
    public SetMixtureAction(String name,String desc,int mnemonic,ParSelect ps){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	p=ps;
    }
    public void actionPerformed(ActionEvent e){
	try{
	    MixtureSelector sel=new MixtureSelector(1,p);
	}catch(Exception ex){
	    System.out.println(ex.toString());
	    StackTraceElement stk[]=ex.getStackTrace();
	    for(int i=0;i<stk.length;i++){
		System.out.println(stk[i].getFileName()+":"+stk[i].getLineNumber()+"  "+stk[i].getMethodName());
	    };
	};
    }
}

class MixtureTableModel extends DefaultTableModel{
    MixtureSelector sel;
    MixtureTableModel(){
	super();
    }
    MixtureTableModel(int r,int c,MixtureSelector s){
	super(r,c+1);
	sel=s;
    }
    /*    void setms(){
	System.out.println("Got Here.");
	sel=s;
	}*/
    public String getColumnName(int col){
	return "";
    };
    public int getColumnCount(){
	if(sel==null){
	    return 2;
	};
	return sel.num+1;
    };
    public int getRowCount(){
	if(sel==null){
	    return 1;
	};
	return sel.ps.getNum();
    }
    public Object getValueAt(int row,int col){
	if(sel==null){
	    return 1;
	};
	if(col==0){
	    return row;//Improve this to give parameter names.
	}else{
	    return sel.cl[row][col-1];
	}
    }
    public boolean isCellEditable(int row,int col){
	return col>0;
    }
    public void setValueAt(Object value,int row,int col){
	if(sel==null){
	    return;
	};
	sel.cl[row][col-1]=Integer.valueOf((String)value);
	fireTableCellUpdated(row,col);
    }
}


class MixtureSelectedAction extends AbstractAction{
    RunColdAction rc;
    MixtureSelector ms;
    MixtureSelectedAction(String name,String desc,int mnemonic,MixtureSelector m){
	putValue(NAME,name);
	putValue(SHORT_DESCRIPTION,desc);
	putValue(MNEMONIC_KEY,mnemonic);
	ms=m;
	rc=ColdFrontend.current.run;
    }
    public void actionPerformed(ActionEvent e){
	rc.addarg("--mixstring",ms.getMixString());
	ms.window.dispose();
    }
}

class MixtureSelector implements ActionListener,TableModelListener {
    JFrame window;
    int num;
    ParSelect ps;
    JTable tab;
    int cl[][];
    JTextField number;
    JButton OK;
    public MixtureSelector(int n,ParSelect p){
	ps=p;
	num=n;
	int pn=ps.getNum();
	cl=new int[pn][num];
	for(int i=0;i<num;i++){
	    for(int j=0;j<pn;j++){
		cl[j][i]=i*pn+j;
	    };
	};

	window=new JFrame("Select Mixture");
	//	mainWindow.addWindowListener(endProgram);
	JPanel panel=new JPanel(new GridBagLayout());	
 	GridBagConstraints c = new GridBagConstraints();
	// 	c.gridwidth=5;
	// 	c.gridheight=20;//maxJumps;
	c.insets=new Insets(0,0,0,0);
	JLabel lab=new JLabel("Number of classes:");
	panel.add(lab,c);
	c.gridx=1;
	number=new JTextField(String.valueOf(num),3);
	number.addActionListener(this);
	panel.add(number,c);
	c.gridy=1;
	c.gridx=0;
	c.gridwidth=2;
	MixtureTableModel mtm=new MixtureTableModel(pn,num,this);
	tab=new JTable(mtm);
	tab.getModel().addTableModelListener(this);
	panel.add(tab,c);
	OK=new JButton("OK");
	c.gridy=2;
	panel.add(OK,c);
	OK.setAction(new MixtureSelectedAction("OK","Accept the current mixture",0,this));
	window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	window.getContentPane().add(panel,BorderLayout.CENTER);
	window.pack();
	window.setVisible(true);
    }

    public String getMixString(){
	int pn=ps.getNum();
	for(int i=0;i<num*pn;i++){
	    int rows[]=null;
	    int cols[]=null;
	    for(int j=0;j<num;j++){
		for(int k=0;k<pn;k++){
		    if(cl[j][k]==i){
			if(rows==null){
			    rows=new int[1];
			    rows[0]=k;
			    cols=new int[1];
			    cols[0]=j;
			}else{
			    int l=0;
			    for(;l<rows.length&&rows[l]!=k;l++);			       
			    if(l==rows.length){
				int tmp[]=new int[rows.length+1];
				for(l=0;l<rows.length;l++){
				    tmp[l]=rows[l];
				};
				tmp[rows.length]=k;
				rows=tmp;
			    };
			    l=0;
			    for(;l<cols.length&&cols[l]!=j;l++);
			    if(l==cols.length){
				int tmp[]=new int[rows.length+1];
				for(l=0;l<cols.length;l++){
				    tmp[l]=cols[l];
				};
				tmp[cols.length]=j;
				cols=tmp;
			    };
			};
		    };
		};
	    };
	};
	return "."; //Need to write this
    }
    public void tableChanged(TableModelEvent e){
	int row=e.getFirstRow();
	int col=e.getColumn();
	if(e.getType()==TableModelEvent.UPDATE&&row!=e.HEADER_ROW){
	    TableModel model=(TableModel) e.getSource();
	    int data=(Integer)model.getValueAt(row,col);
	}else{

	}
    }
    public void actionPerformed(ActionEvent e){
	int n=Integer.valueOf(number.getText());
	if(n>0&&n!=num){
	    int pn=ps.getNum();
	    int temp[][]=new int[pn][n];
	    if(n>num){
		int last=0;
		for(int i=0;i<num;i++){
		    for(int j=0;j<pn;j++){
			temp[j][i]=cl[j][i];
			if(temp[j][i]>last){
			    last=temp[j][i];
			};
		    };
		};
		for(int i=num;i<n;i++){
		    for(int j=0;j<pn;j++){
			temp[j][i]=++last;
		    };
		};
	    }else{
		for(int i=0;i<n;i++){
		    for(int j=0;j<pn;j++){
			temp[j][i]=i*pn+j;
		    };
		};
	    }
	    num=n;
	    cl=temp;
	    ((MixtureTableModel)tab.getModel()).setColumnCount(num);
	    tab.setModel(tab.getModel());
	};
    }
}

public class ColdFrontend{
    int numprocs;
    static boolean debugging=true;

    static Preferences pref=Preferences.userNodeForPackage(ColdFrontend.class);;

    JFrame mainWindow;
    static JFileChooser fc=new JFileChooser();

    JTextField command;
    JLabel info;
    //    JLabel value;
    JPanel panel;
    JRadioButtonMenuItem[] direction;

    JMenu modelmenu;
    JMenu codemenu;
    JMenu parmenu;
    ButtonGroup bg;
    ButtonGroup bgcd;
    ButtonGroup bgpar;

    RunColdAction run;
    Action setTree;
    Action setData;
    Action setModel;
    Action setOpts;


    JMenuItem Run;
    JMenuItem SetTree;
    JMenuItem SetData;
    JMenuItem SetModel;


    JTextArea output;

    //    BufferedReader readsettings;

    JButton testButton;

    JLabel[] showJumps;

    Thread mainThread;
    ParSelect ps;

    StopAction stop;
    RunCold runner;

    WindowCloser endProgram;

    static ColdFrontend current;

    public void addProcess(){
	if(numprocs==0){
	    stop.setEnabled(true);
	};
	numprocs++;
    }
    public void endProcess(){
	numprocs--;
	if(numprocs==0){
	    stop.setEnabled(false);
	};
    }

    void setFile(String filetype,String filename){
	try{
	    if(filetype.equals("param")){
		File parfile=new File(filename);
		String value=parfile.getAbsolutePath();
		ps.setValue(value);
		BufferedReader read=new BufferedReader(new FileReader(parfile));
		String line=null;
		int num=0;
		parmenu.removeAll();
		while((line=read.readLine())!=null){
		    int li=line.indexOf(':');
		    if(li!=-1){
			num++;
			String parname=line.substring(0,li);
			JCheckBoxMenuItem mIt=new JCheckBoxMenuItem(parname,true);
			mIt.setAction(new ChooseParAction(parname,"",0,ps,num,parmenu));
			if(parname.equals("scale")){
			    mIt.setEnabled(false);
			};
			parmenu.add(mIt);
		    };
		};
		ps.setNum(num);
	    };
	}catch(Exception e){
	    System.out.println(e.toString());
	    StackTraceElement stk[]=e.getStackTrace();
	    for(int i=0;i<stk.length;i++){
		System.out.println(stk[i].getFileName()+":"+stk[i].getLineNumber()+"  "+stk[i].getMethodName());
	    };
	};
    }

    static void configure(File lstmk){
	try{
	    BufferedReader read=new BufferedReader(new FileReader(lstmk));
	    String line=null;
	    while((line=read.readLine()) != null) {
		String mkfilename=line.substring(0,line.indexOf('='));
		String value=line.substring(line.indexOf('=')+1);
		pref.put(mkfilename,value);
		System.out.println(line);
	    }
	}catch(Exception e){
	    System.out.println(e.toString());
	}	
    }

    void openDefaultFiles(){
	try{
	    File modelfile=new File(pref.get("mainsearchdir","")+"/Models/"+pref.get("DEFAULTMODELFILE","models"));
	    String value=modelfile.getAbsolutePath();
	    BufferedReader read=new BufferedReader(new FileReader(modelfile));
	    String line=null;
	    int inmodel=0;
	    while((line=read.readLine())!=null){
		if(inmodel==0){
		    int li=line.lastIndexOf('{');
		    if(li!=-1){
			String modname=line.substring(0,li);
			li=modname.lastIndexOf('(');
			int numpars=0;
			if(li!=-1){
			    String params=modname.substring(modname.indexOf('(')+1,modname.lastIndexOf(')'));
			    numpars++;
			    for(int ic=params.lastIndexOf(',');ic!=-1;ic=params.lastIndexOf(',')){
				params=params.substring(0,ic);
				numpars++;
			    };
			};
			JRadioButtonMenuItem mIt=new JRadioButtonMenuItem(modname,false);
			mIt.setAction(new ChooseModelAction(modname,"",0,value,numpars));
			modelmenu.add(mIt);
			bg.add(mIt);		    
		    };
		}else{
		    if(line.lastIndexOf('}')!=-1){
			inmodel=0;
		    };
		};
	    };
	    File codefile=new File(pref.get("mainsearchdir","")+"/"+pref.get("DEFAULTCODEFILE","geneticcodes"));
	    value=codefile.getAbsolutePath();
	    read=new BufferedReader(new FileReader(codefile));
	    line=null;
	    while((line=read.readLine())!=null){
		int li=line.indexOf(' ');
		if(li!=-1){
		    String codename=line.substring(0,li);
		    JRadioButtonMenuItem mIt=new JRadioButtonMenuItem(codename,false);
		    mIt.setAction(new ChooseCodeAction(codename,"",0,value));
		    codemenu.add(mIt);
		    bgcd.add(mIt);		    
		};
	    };
	    File parfile=new File(pref.get("mainsearchdir","")+"/Models/"+pref.get("DEFAULTPARAMS","parametermatrices"));
	    value=parfile.getAbsolutePath();
	    ps.setValue(value);
	    read=new BufferedReader(new FileReader(parfile));
	    line=null;
	    int num=0;
	    while((line=read.readLine())!=null){
		int li=line.indexOf(':');
		if(li!=-1){
		    num++;
		    String parname=line.substring(0,li);
		    JCheckBoxMenuItem mIt=new JCheckBoxMenuItem(parname,true);
		    mIt.setAction(new ChooseParAction(parname,"",0,ps,num,parmenu));
		    if(parname.equals("scale")){
			mIt.setEnabled(false);
		    };
		    parmenu.add(mIt);
		};
	    };
	    ps.setNum(num);
	}catch(Exception e){
	    System.out.println(e.toString());
	}
    }

    public static void createGUI(){
	JFrame.setDefaultLookAndFeelDecorated(true);
	ColdFrontend wind=new ColdFrontend();
	wind.runner=new RunCold();//game.players[0],game.players[1],game);
	//	wind.loadSettings();
	wind.mainThread=new Thread(wind.runner);
	wind.mainThread.start();
    }

    public static void main(String[] args){
	for(int i=0;args!=null&&i<args.length;i++){
	    if(args[i].equals("--configure")){
		System.out.println("Configuring cold frontend.");
		if(i+1<args.length){

		}else{
		    ColdFrontend.configure(new File("LastMake"));
		}
		return;
	    }
	}
	javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createGUI();
            }
        });
	return;      
    }

    public ColdFrontend(){
	numprocs=0;
	current=this;	
	endProgram=new WindowCloser();


	output=new JTextArea();
	JScrollPane scroll=new JScrollPane(output);
	scroll.setPreferredSize(new Dimension(500,500));
	//	loadSettings();

	command=new JTextField(50);

	
	//	help=new HelpAction("Show help","displays help file.",0);

	mainWindow=new JFrame("COLD - version "+pref.get("VERSION","(unknown)"));
	setData=new SetFileAction("Set Data","Sets the data file",0,"-d","data");
	run=new RunColdAction("Run","Runs Cold with current settings.",0,output);

	ps=new ParSelect();
	this.setUpMenus();
	this.openDefaultFiles();
	mainWindow.addWindowListener(endProgram);

	
	//	info=new JLabel("\t\t\n\n\n\n\t");

	panel=new JPanel(new GridBagLayout());	
 	GridBagConstraints c = new GridBagConstraints();
 	c.fill = GridBagConstraints.HORIZONTAL;
 	c.gridwidth=5;
 	c.gridheight=20;//maxJumps;
	c.gridx = 0;
 	c.gridy = 0;
	// 	panel.add(board.display,c);
	c.gridx=5;
	c.gridheight=1;
	//	for(int i=0;i<maxJumps;i++){
	//	    c.gridy=i;
	    //	    panel.add(showJumps[i],c);
	//	}
	c.gridwidth=1;
	c.gridx=0;
	//	c.gridy=maxJumps;
	//	panel.add(move,c);
	c.gridx=1;
	c.gridx=2;
	c.insets=new Insets(0,0,0,0);
	//	panel.add(info,c);
	c.gridx=0;
	c.gridx=0;
	panel.add(scroll,c);

	//panel.add(value,c);



	mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	mainWindow.getContentPane().add(panel,BorderLayout.CENTER);
	mainWindow.pack();
	mainWindow.setVisible(true);
    }

    public void setUpMenus(){
	JMenuBar menuBar=new JMenuBar();
	JMenu submenu;

//DATA MENU ----------------------------------------------------------

	JMenu menu=new JMenu("Data");
	menu.setMnemonic(KeyEvent.VK_D);
	menu.getAccessibleContext().setAccessibleDescription("Data Options");

	JMenuItem menuItem=new JMenuItem("Set Data",KeyEvent.VK_D);
	menuItem.setAction(setData);
	menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,ActionEvent.CTRL_MASK));
	menu.add(menuItem);

	codemenu=new JMenu("Set Code");
	codemenu.setMnemonic(KeyEvent.VK_C);
	//	menuItem.setAction(new SetFileAction("Set Code","Sets the Genetic Code",KeyEvent.VK_C));
	menu.add(codemenu);
	bgcd=new ButtonGroup();

	menuItem=new JMenuItem("Code File",0);
	menuItem.setAction(new CodeLookupAction("Open Code File","Opens a new code file",0,codemenu,bgcd));
	menu.add(menuItem);

	menuItem=new JMenuItem("Set Tree",KeyEvent.VK_T);
	menuItem.setAction(new SetFileAction("Set Tree","Sets the tree file",KeyEvent.VK_T,"-t","tree"));
	menu.add(menuItem);

	menuBar.add(menu);



	menuBar.add(menu);

//RUN MENU ----------------------------------------------------------

	menu=new JMenu("Run");
	menu.setMnemonic(KeyEvent.VK_R);
	menu.getAccessibleContext().setAccessibleDescription("Run Cold");

	menuItem=new JMenuItem("run",KeyEvent.VK_R);
	menuItem.setAction(run);
	menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
	menu.add(menuItem);

	stop=new StopAction("Stop","Cancels all running instances",KeyEvent.VK_X);	
	stop.setEnabled(false);
	menuItem=new JMenuItem("Backups",KeyEvent.VK_B);
	menuItem.setAction(stop);
	menu.add(menuItem);

	menuItem=new JMenuItem("Simulate",KeyEvent.VK_S);
	menuItem.setAction(new RunSimulateAction("Simulate","Runs a simulation for the current model",KeyEvent.VK_S));
	menu.add(menuItem);

	menuItem=new JMenuItem("Iteration Limit",KeyEvent.VK_I);
	menuItem.setAction(new SetValueAction("Iteration limit","Sets the iteration limit",KeyEvent.VK_I,"-n"));
	menu.add(menuItem);

	JCheckBoxMenuItem flag=new JCheckBoxMenuItem(new FlagAction("Variable Selection","Performs automatic variable selection",KeyEvent.VK_V,"--variableselection",false));
	menu.add(flag);

	menuItem=new JMenuItem("Backups",KeyEvent.VK_B);
	menuItem.setAction(new SetBackupAction("Backups","Options controlling backup of data during optimisation",KeyEvent.VK_B));
	menu.add(menuItem);


	menuBar.add(menu);

//MODEL MENU ----------------------------------------------------------

	menu=new JMenu("Model");
	menu.setMnemonic(KeyEvent.VK_M);
	menu.getAccessibleContext().setAccessibleDescription("Model options");
	bg=new ButtonGroup();

	JRadioButtonMenuItem mIt=new JRadioButtonMenuItem("none",true);
	mIt.setAction(new RemoveModelAction("none","",0));
	modelmenu=new JMenu("Model");
	modelmenu.add(mIt);
	bg.add(mIt);

	//	menuItem=new JMenuItem("Model",KeyEvent.VK_T);
	//	menuItem.setAction(new SetFileAction("Set Code","Sets the Genetic Code",0));
	menu.add(modelmenu);



	menuItem=new JMenuItem("Model File",KeyEvent.VK_M);
	menuItem.setAction(new ModelLookupAction("Open Model File","Opens a new model file",0,modelmenu,bg));
	menu.add(menuItem);

	menuItem=new JMenuItem("Mask file",KeyEvent.VK_K);
	menuItem.setAction(new SetFileAction("Set mask file","Sets the mask file",0,"--maskfile","Mask"));
	menu.add(menuItem);

	menuItem=new JMenuItem("Parameter File",KeyEvent.VK_P);
	menuItem.setAction(new SetFileAction("Parameter File","Sets the parameter file",0,"-p","Parameters","param"));
	menu.add(menuItem);

	parmenu=new JMenu("Select Parameters");
	parmenu.setMnemonic(KeyEvent.VK_S);
	//	bgpar=new ButtonGroup();
	//	menuItem.setAction(new SetFileAction("Select Parameters","Chooses which parameters to include",0,"--p","Parameters"));
	menu.add(parmenu);

	menuItem=new JMenuItem("Select Mask",0);
	menuItem.setAction(new SetValueAction("Select Mask","Chooses which mask to use",0,"--mask"));
	menu.add(menuItem);

	menuItem=new JMenuItem("Mixture",KeyEvent.VK_X);
	menuItem.setAction(new SetMixtureAction("Mixture","Specifies the details for a mixed model",0,ps));
	menu.add(menuItem);

	submenu=new JMenu("Codon Frequencies");
	submenu.setMnemonic(KeyEvent.VK_C);
	bg=new ButtonGroup();

	menu.add(submenu);

	JRadioButtonMenuItem rbmenuItem=new JRadioButtonMenuItem("ECM",true);
	rbmenuItem.setAction(new CodonFreqAction("ECM","",0,null));
	submenu.add(rbmenuItem);
	bg.add(rbmenuItem);

	rbmenuItem=new JRadioButtonMenuItem("Fequal",true);
	rbmenuItem.setAction(new CodonFreqAction("Fequal","",0));
	submenu.add(rbmenuItem);
	bg.add(rbmenuItem);

	rbmenuItem=new JRadioButtonMenuItem("F1x4",false);
	rbmenuItem.setAction(new CodonFreqAction("F1x4","",0));
	submenu.add(rbmenuItem);
	bg.add(rbmenuItem);

	rbmenuItem=new JRadioButtonMenuItem("F3x4",false);
	rbmenuItem.setAction(new CodonFreqAction("F3x4","",0));
	submenu.add(rbmenuItem);
	bg.add(rbmenuItem);

	rbmenuItem=new JRadioButtonMenuItem("F61",true);
	rbmenuItem.setAction(new CodonFreqAction("F61","",0));
	submenu.add(rbmenuItem);
	bg.add(rbmenuItem);

	menuItem=new JMenuItem("From file",0);
	menuItem.setAction(new SetFileAction("From file","Sets the codon frequencies from a file.",0,"--freqs","codon frequencies"));
	submenu.add(menuItem);

	//	menuItem=new JMenuItem("Codon Probabilities",KeyEvent.VK_E);
	//	menuItem.setAction(new SetValueAction("Select Codon Probabilities","Chooses how codon probabilities are estimated",0,"--empirical","Codon Probabilities"));

	/*
	submenu=new JMenu("Codon Probabilities");
	submenu.setMnemonic(KeyEvent.VK_P);
	JRadioButtonMenuItem rmenuItem[]=new JRadioButtonMenuItem[4];
       
	rmenuItem[0]=new JRadioButtonMenuItem("None",true);
	rmenuItem[0].setAction(new SelectParsimonyAction("NONE","",0));
	submenu.add(rmenuItem[0]);

	rmenuItem[1]=new JRadioButtonMenuItem("parameters",false);
	rmenuItem[1].setAction(new SelectParsimonyAction("PARAMETERS","",0));
	submenu.add(rmenuItem[1]);

	rmenuItem[2]=new JRadioButtonMenuItem("Branch lengths",false);
	rmenuItem[2].setAction(new SelectParsimonyAction("BRANCHLENGTHS","",0));
	submenu.add(rmenuItem[2]);

	rmenuItem[3]=new JRadioButtonMenuItem("Both",false);
	rmenuItem[3].setAction(new SelectParsimonyAction("BOTH","",0));
	submenu.add(rmenuItem[3]);


	menu.add(submenu);
	*/
	menuBar.add(menu);

//START MENU ----------------------------------------------------------

	menu=new JMenu("Start");
	menu.setMnemonic(KeyEvent.VK_S);
	menu.getAccessibleContext().setAccessibleDescription("Starting Options");

	menuItem=new JMenuItem("Initial Parameters",KeyEvent.VK_I);
	menuItem.setAction(new InitParsAction("Set initial parameters","Sets initial parameter values",KeyEvent.VK_I));
	menu.add(menuItem);//Need to improve this!!!


	menuItem=new JMenuItem("Load Settings",KeyEvent.VK_S);
	menuItem.setAction(new SetFileAction("Load Settings","Loads previously saved settings",0,"--variables","Settings"));
	menu.add(menuItem);

	submenu=new JMenu("Parsimony");
	submenu.setMnemonic(KeyEvent.VK_P);
	JRadioButtonMenuItem rmenuItem[]=new JRadioButtonMenuItem[4];
       
	rmenuItem[0]=new JRadioButtonMenuItem("None",true);
	rmenuItem[0].setAction(new SelectParsimonyAction("NONE","",0));
	submenu.add(rmenuItem[0]);

	rmenuItem[1]=new JRadioButtonMenuItem("parameters",false);
	rmenuItem[1].setAction(new SelectParsimonyAction("PARAMETERS","",0));
	submenu.add(rmenuItem[1]);

	rmenuItem[2]=new JRadioButtonMenuItem("Branch lengths",false);
	rmenuItem[2].setAction(new SelectParsimonyAction("BRANCHLENGTHS","",0));
	submenu.add(rmenuItem[2]);

	rmenuItem[3]=new JRadioButtonMenuItem("Both",false);
	rmenuItem[3].setAction(new SelectParsimonyAction("BOTH","",0));
	submenu.add(rmenuItem[3]);

	ButtonGroup group=new ButtonGroup();
	group.add(rmenuItem[0]);
	group.add(rmenuItem[1]);
	group.add(rmenuItem[2]);
	group.add(rmenuItem[3]);

	menu.add(submenu);

	menuBar.add(menu);

//OUTPUT MENU ----------------------------------------------------------

	menu=new JMenu("Output");
	menu.setMnemonic(KeyEvent.VK_O);
	menu.getAccessibleContext().setAccessibleDescription("Output options");

	menuItem=new JMenuItem("Output to File",KeyEvent.VK_F);
	menuItem.setAction(new SetFileAction("Output file","Choose the filename for saved output",0,"--output","Output"));
	menu.add(menuItem);
	menu.addSeparator();

	flag=new JCheckBoxMenuItem(new FlagAction("Site Likelihoods","Include site likelihoods in output.",KeyEvent.VK_S,"--printsitelikes"));

	menu.add(flag);

	flag=new JCheckBoxMenuItem(new FlagAction("t-statistics","Include t-statistics in output.",KeyEvent.VK_T,"--tstats"));

	menu.add(flag);

	flag=new JCheckBoxMenuItem(new FlagAction("Observed information","Include the observed information matrix in output.",KeyEvent.VK_O,"--printsitelikes"));

	menu.add(flag);

	flag=new JCheckBoxMenuItem(new FlagAction("Standard deviation","Output standard deviations of branch lengths.",KeyEvent.VK_D,"--printsitelikes"));

	menu.add(flag);

	menuBar.add(menu);

//DEBUG MENU ----------------------------------------------------------

	menu=new JMenu("Debug");
	menu.setMnemonic(KeyEvent.VK_G);
	menu.getAccessibleContext().setAccessibleDescription("Debugging options");
	submenu=new JMenu("Interactivity level");
	submenu.setMnemonic(KeyEvent.VK_I);
	//	menuItem.setAction(new SetFileAction("Set Code","Sets the Genetic Code",0));
	menu.add(submenu);

	rmenuItem[0]=new JRadioButtonMenuItem("log file",false);
	rmenuItem[0].setAction(new SelectValueAction("log file","",0,"-i","-1"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("away",false);
	rmenuItem[0].setAction(new SelectValueAction("away","",0,"-i","0"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("vital",false);
	rmenuItem[0].setAction(new SelectValueAction("vital","",0,"-i","1"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("normal",true);
	rmenuItem[0].setAction(new SelectValueAction("normal","",0,"-i","2"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("fussy",false);
	rmenuItem[0].setAction(new SelectValueAction("fussy","",0,"-i","3"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("start",false);
	rmenuItem[0].setAction(new SelectValueAction("start","",0,"-i","32"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("start then check",true);
	rmenuItem[0].setAction(new SelectValueAction("start then check","",0,"-i","33"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);


	submenu=new JMenu("Debug level");
	submenu.setMnemonic(KeyEvent.VK_D);
	bg=new ButtonGroup();
	//	menuItem.setAction(new SetFileAction("Set Code","Sets the Genetic Code",0));
	menu.add(submenu);


	rmenuItem[0]=new JRadioButtonMenuItem("silent",false);
	rmenuItem[0].setAction(new SelectValueAction("silent","",0,"-D","-1"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("normal",true);
	rmenuItem[0].setAction(new SelectValueAction("normal","",0,"-D","0"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("basic",false);
	rmenuItem[0].setAction(new SelectValueAction("basic","",0,"-D","1"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	rmenuItem[0]=new JRadioButtonMenuItem("full",false);
	rmenuItem[0].setAction(new SelectValueAction("full","",0,"-D","2"));
	submenu.add(rmenuItem[0]);
	bg.add(rmenuItem[0]);

	menuBar.add(menu);

//TECHNICAL MENU ----------------------------------------------------------

	menu=new JMenu("Technical");
	menu.setMnemonic(KeyEvent.VK_T);
	menu.getAccessibleContext().setAccessibleDescription("Technical options");
	menuItem=new JMenuItem("Number of threads",KeyEvent.VK_T);
	menuItem.setAction(new SetValueAction("Number of threads","Sets the number of threads",KeyEvent.VK_T,"-T"));
	menu.add(menuItem);

	menuItem=new JMenuItem("Test Derivatives",KeyEvent.VK_D);
	menuItem.setAction(new TestDerivsAction("Test Derivativs","Tests the calculated derivatives",KeyEvent.VK_D));
	menu.add(menuItem);

	menuBar.add(menu);

//UTILITIES MENU ----------------------------------------------

	menu=new JMenu("Utilities");
	menu.setMnemonic(KeyEvent.VK_U);
	menu.getAccessibleContext().setAccessibleDescription("Utility programs");

	String[] temp= {"name","Amino Acids","Codes file","Parameter file"};


	menuItem=new JMenuItem("Add code",KeyEvent.VK_C);
	menuItem.setAction(new RunUtilAction("Add code","Add a new genetic code",KeyEvent.VK_C,"ADDCODE",output,"ssf+",temp));
	menu.add(menuItem);

	String[] temp2= {"Codon file","Input matrix file","Output matrix file"};

	menuItem=new JMenuItem("Reorder matrix",KeyEvent.VK_R);
	menuItem.setAction(new RunUtilAction("Reorder matrix","Convert matrices from different codon order",KeyEvent.VK_R,"REORDERMATNAME",output,"fff",temp2));
	menu.add(menuItem);

	String[] temp3= {"Sequence file","Selection","Output file"};

	menuItem=new JMenuItem("Strip ambiguous sites",KeyEvent.VK_A);
	menuItem.setAction(new RunUtilAction("Strip ambiguous sites","Strip ambiguous sites and alignment gaps from a data file",KeyEvent.VK_A,"STRIPAMBNAME",output,"fs?f?",temp3));
	menu.add(menuItem);

	String[] temp4= {"Matrix file","Selection","Subtracted selection"};

	menuItem=new JMenuItem("Sum matrices",KeyEvent.VK_S);
	menuItem.setAction(new RunUtilAction("Sum matrices","Create new matrices by summing existing matrices",KeyEvent.VK_S,"SUMMATNAME",output,"fss?",temp4));
	menu.add(menuItem);

	String[] temp5= {"Input matrix file","Output matrix file"};

	menuItem=new JMenuItem("Matrices from columns",KeyEvent.VK_M);
	menuItem.setAction(new RunUtilAction("Matrices from columns","Read matrices from column vectors of entries",KeyEvent.VK_M,"SETUPNAME",output,"ff",temp5));
	menu.add(menuItem);


	menuBar.add(menu);


	mainWindow.setJMenuBar(menuBar);
    }
}


class WindowCloser implements WindowListener{
    ColdFrontend boss;
    int numProcesses;
    Process procs[];

    void addProcess(Process pr){
	Process pr2[]=new Process[numProcesses+1];
	for(int i=0;i<numProcesses;i++){
	    pr2[i]=procs[i];
	};
	pr2[numProcesses]=pr;
	procs=pr2;
	numProcesses++;
    };
    public void windowClosing(WindowEvent e){
	for(int i=0;i<numProcesses;i++){
	    procs[i].destroy();
	};
	boss.numprocs=0;
	boss.stop.setEnabled(false);
    }
    public void windowOpened(WindowEvent e){
    }
    public void windowClosed(WindowEvent e){
    }
    public void windowIconified(WindowEvent e){
    }
    public void windowDeiconified(WindowEvent e){
    }
    public void windowActivated(WindowEvent e){
    }
    public void windowDeactivated(WindowEvent e){
    }
    public WindowCloser(){
	boss=ColdFrontend.current;
	numProcesses=0;
    }
}


class RunCold implements Runnable{
    Thread interrupter;
    public RunCold(){
	super();
    }
    public void setInterrupter(Thread t){
	interrupter=t;
    }
    public void run(){
	while(true){
	}
    }
}

