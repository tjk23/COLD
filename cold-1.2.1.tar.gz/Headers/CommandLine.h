/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//Code for dealing with command-line options
#ifndef COMMANDLINE_H
#define COMMANDLINE_H 1
#include <iosfwd>

//Functions to use as function pointers

void noprnt(std::ostream &o,void *address);

void prntstr(std::ostream &o,void *address);

void prntint(std::ostream &o,void *address);

void prntld(std::ostream &o,void *address);

void prntdbl(std::ostream &o,void *address);

void prntflt(std::ostream &o,void *address);

int chooseifstreams(char *basename,int n,...);

int setifstream(const char *val,void *address);

int setifstreamthrow(const char *val,void *address);

int setstr(const char *val,void *address);

int setint(const char *val,void *address);

int setflt(const char *val,void *address);

int setdbl(const char *val,void *address);

int setld(const char *val,void *address);

int setflag(const char *val,void *address);

void delstr(void *address);

void delint(void *address);

void delld(void *address);

void delflt(void *address);

void deldbl(void *address);

void *makevar(char *type);

// ---------------------------------------------------------------------------

class variable{//Used for storing system variables
public:
  char *name;
  char *tag;//commandline option tag
  void *value;
  int (*setv)(const char *val,void *address);
  void (*delv)(void *address);
  void (*prnt)(std::ostream& o,void *address);
  int setval(const char *val){if(value==NULL){return 0;}else{return (*setv)(val,value);};};
  variable(const char *n, const char *t,void* address,int (*set)(const char *val,void *address),void (*print)(std::ostream& o,void *address),void (*del)(void *add));
  ~variable(){if(delv!=NULL){delv(value);};delete[] name; delete[] tag;};
};

class varlist{//linked list of variables.
  variable *x;
  varlist *next;
  void checkvars();
public:
  varlist(){x=NULL;next=NULL;};
  void *seekval(const char *vname);
  variable *seektag(const char *tg);
  void setvals(int argc,char *argv[]);
  void addvar(const char *name,const char *tag,void *address,int (*setv)(const char *val,void *address),const char *init,void (*prnt)(std::ostream& o,void *address),void (*delv)(void *add)=NULL);
  void remove(){if(next!=NULL){next->remove();delete next;};if(x!=NULL){delete x;};};
  //  ~varlist(){this->remove();};
  void addvars(std::ifstream& in);
  void setupvars();
  friend std::ostream &operator <<(std::ostream &o,varlist &v);
};

void removevarlist();

extern varlist vars;

void checkvars();//Checks that the options given are valid.

int inputcheck();//Checks for external inputs to cold.

int envgetopts();//Reads new options from environment variables.

void setupdatecommandline(void (*rrcl)());

#endif
