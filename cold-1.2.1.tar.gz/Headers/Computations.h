/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include<iosfwd>
#include<stdlib.h>

class intcomp{//A computation to produce an integer
  const int *ans;
  const int *(*getval)();
public:
  intcomp(const int *(*gv)()){ans=NULL;getval=gv;};
  intcomp(const long double *(*gv)());
  intcomp(void (*gv)(std::ostream& out));
  int lookup(int i);
};


class ldcomp{//A computation to produce a long double
  const long double *ans;
  const long double *(*getval)();
public:
  ldcomp(const long double *(*gv)());//{ans=NULL;getval=gv;cout<<"\n"<<ans<<*(*getval)();};
  ldcomp(const int *(*gv)());
  ldcomp(void (*gv)(std::ostream& out));
  ldcomp(const long double *a);
  long double lookup(int i);
};


class strcomp{//A computation to produce a string
  void (*getval)(std::ostream&);
public:
  strcomp(void (*gv)(std::ostream &)){getval=gv;};
  strcomp(const int *(*gv)());
  strcomp(const long double *(*gv)());
  void lookup(std::ostream &out);
};
