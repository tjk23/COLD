/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* These can be changed to affect the running of the program.  It
would probably be better to allow changes to be made at
runtime. Perhaps I'll implement this feature later. */

#ifndef MACROFILE
#define MACROFILE 1

//#include <pthread.h>

#define NumCodons 4         //Unlikely to change.
#define NumCodonsSq 16         //Unlikely to change.
static const int CodonLength=1;         //Unlikely to change.
#define NUMPARS 4         //The number of parameters on which the Q matrix is based. Need to allow this to vary dynamically.
#define HESSIAN 1 //Remove this line to disable hessian calculation.
#define DBLSPACE 0   //Controls display of matrices


//These control the thresholds at which numbers are assumed to be zero
#define NONZERO(a) ((a)>1e-10||(a)<-1e-10)  
#define ZERO(a) ((a)<1e-10&&(a)>-1e-10)
#define ZEROWEAK(a) ((a)<1e-5&&(a)>-1e-5)
#define NONZEROST(a) ((a)>1e-17||(a)<-1e-17)
#define ZEROST(a) ((a)<1e-17&&(a)>-1e-17)
#define ZEROSQ(a) ((a)<1e-20&&(a)>-1e-20)
#define NONZEROSQ(a) ((a)>1e-20||(a)<-1e-20)
#define ZEROSTSQ(a) ((a)<1e-34&&(a)>-1e-34)
#define NONZEROSTSQ(a) ((a)>1e-34||(a)<-1e-34)
#define MATRIXPRINTTHRESHOLD 1e-10 
#define ZEROM(a) ((a)<MATRIXPRINTTHRESHOLD &&(a)>-MATRIXPRINTTHRESHOLD)

#define PI 3.14159265358979323846264    //Unlikely to change

//Options for optimisation
#define MAXIMISE 1
#define MINIMISE 0
#define OTHEROP(a) (1-a)
#define SCALEMAX 10
#define SCALEMIN 10

#define MAKESTRING(a) MKSTR(a)
#define MKSTR(a) #a

#define TSTAT10 1.282
#define TSTAT5 1.645
#define TSTAT25 1.960
#define TSTAT1 2.326
#define TSTAT05 2.576
#define TSTAT01 3.090

#include "configvars.h"

#endif
