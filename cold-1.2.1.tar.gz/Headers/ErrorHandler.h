/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* 

   Routines for dealing with errors. The global variables in this file allow control over how errors, information and warnings are handled. For example, should warnings give a prompt for the user to confirm.

*/
#ifndef ERROR_HANDLER
#define ERROR_HANDLER 1

#include<stddef.h>
#include<iosfwd>

//int interactivity=0; 
// Indicates whether the user should be prompted for confirmations.

//int debug=0;
// Indicates whether debugging information should be output with error
// messages.

// Indicates whether the user should be prompted for confirmations.
/*

  0  - Away, no interactivity. Messages displayed on screen.  

  -1 - No interactivity. Messages sent to log file if it exists. Otherwise no
       messages.

  1  - Only prompt for vital messages.

  2  - Prompt for messages where appropriate.

  3  - Prompt for all messages

 */

#define AWAY 0
#define LOGFILE -1
#define VITAL 1
#define PRESENT 2
#define ALL 3
#define START 32
#define STARTCHECK 33

#define MAXINTERACT 3


// Indicates whether debugging information should be output with error
// messages.

/*

  0  - No debugging information.

  1  - Basic debugging information.

  2  - Full debugging information.

*/

#define NODEBUG 0
#define BASICDEBUG 1
#define FULLDEBUG 2


void printContext(int i=0);

void setContext(void (*pc)(void *),void *c);

void setContext(void *c);

inline int msgcode(int debug,int import){
  return debug*32+MAXINTERACT-import;
};//This should be the usual way to call th menu functions.


class menuitem{
  char *text;
  void (*perform)(void *params);
public:
  menuitem(){text=NULL;perform=NULL;};
  menuitem(const char *t,void (*p)(void *));
  menuitem(const menuitem& m);
  void choose(void *pars){(*perform)(pars);};
  friend std::ostream& operator<<(std::ostream& out,menuitem m);
  void operator =(const menuitem& m);
  int enabled(){return text!=NULL;}
  ~menuitem(){delete[] text;};
};

extern menuitem stop;
extern menuitem openfile;

class menu{
  int n;
  menuitem *options;
  void *pars;
public:
  menu(int num,menuitem *o,void *p=NULL){n=num;options=new menuitem[num];for(int i=0;i<num;i++){*(options+i)=*(o+i);};pars=p;};
  menu(int num,menuitem& first,menuitem& second,...);
  menu(const menu& base,int num=0);
  void setpars(void *p){pars=p;};
  void set(int i,menuitem &m){if(i<0||i>=n){throw n;};*(options+i)=m;};
  void display();//displays the menu and accepts the choice.
  int displayno(const char* message="Continue.");
  ~menu();
  //displays the menu with an additional choice to do nothing.
};

extern menu stopstart;
extern menu filemenu;

void setinteractive(int i);
void interactivestarted();
void setdebug(int i);
void setlogfile(std::ofstream& out);
void setlogfile(const char *name);

int info(const char *message,int type=0,menu *choices=NULL);//information for the user.

int warning(const char *message,int type=0,menu *choices=NULL);
//warning about unusual, probably wrong behaviour, but theoretically
//OK.

int recoverableError(const char *message,int type=0,menu *choices=NULL);
//an error that could be recovered from with user input.

void fatalError(const char *message,int type=0,menu *choices=NULL);
//an error that can't be recovered from. Possibly some damage
//limitation can be achieved, and some debugging can be performed
//interactively.

#endif
