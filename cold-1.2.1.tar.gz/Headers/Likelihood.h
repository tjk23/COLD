/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Routines for calculating likelihoods along a branch */

#ifndef LIKELIHOOD_H
#define LIKELIHOOD_H

// Newer versions using pre-calculated exponentials
//Inline functions

long double inline getcoeffold(const long double *d,long double t,int i, int j,const long double *ex){
  if(ZEROST(*(d+i)-*(d+j))){
    return t*(*(ex+i));
  }else{ 
    return (*(ex+i)-*(ex+j))/((*(d+i))-(*(d+j)));
  };
};

long double inline getcoeff(const long double *D,long double t,int i, int j,const long double *ex){
  return (*(ex+i)-*(ex+j))*(*(D+i*NumCodons+j));
};

long double inline getcoeff2(const long double *d,long double t,int i, int j,const long double *ex){
  return((ZEROST(*(d+i)-*(d+j)))?(*(d+i)*t+1)*(*(ex+i)):(*(d+i)*(*(ex+i))-*(d+j)*(*(ex+j)))/(*(d+i)-*(d+j)));
};//This is the derivative of getcoeff wrt t.

long double inline getcoeff2(const long double *d,const long double *A,long double t,int i, int j,const long double *ex){
  return (*(d+i)*(*(ex+i))-*(d+j)*(*(ex+j)))*(*(A+i*NumCodons+j));
};//This is the derivative of getcoeff wrt t.

long double inline getcoeffold(const long double *d,long double t,int i, int j,int k,const long double *ex){
  if(ZEROST(*(d+i)-*(d+j))){
    if(ZEROST(*(d+i)-*(d+k))){
      return(t*t*(*(ex+i))/2);
    }else{
      return((((*(d+i)-*(d+k))*t-1)*(*(ex+i))+*(ex+k))/((*(d+i)-*(d+k))*(*(d+i)-*(d+k))));
    };
  }else if(ZEROST(*(d+i)-*(d+k))){
    return((((*(d+i)-*(d+j))*t-1)*(*(ex+i))+*(ex+j))/((*(d+i)-*(d+j))*(*(d+i)-*(d+j))));
  }else if(ZEROST(*(d+j)-*(d+k))){
    return((((*(d+j)-*(d+i))*t-1)*(*(ex+j))+*(ex+i))/((*(d+i)-*(d+j))*(*(d+i)-*(d+j))));
  }else{//all different
    return(*(ex+i)/((*(d+i)-*(d+j))*(*(d+i)-*(d+k)))+*(ex+j)/((*(d+j)-*(d+i))*(*(d+j)-*(d+k)))+*(ex+k)/((*(d+k)-*(d+j))*(*(d+k)-*(d+i))));
  };
};

long double inline getcoeff(const long double *A,long double t,int i, int j,int k,const long double *ex){
  return *(ex+i)*(*(A+i*NumCodons+j))*(*(A+i*NumCodons+k))+*(ex+j)*(*(A+i*NumCodons+j))*(*(A+k*NumCodons+j))+*(ex+k)*(*(A+i*NumCodons+k))*(*(A+k*NumCodons+j));
  /*  if(ZEROST(*(d+i)-*(d+j))){
    if(ZEROST(*(d+i)-*(d+k))){
      return(t*t*(*(ex+i))/2);
    }else{
      return((((*(d+i)-*(d+k))*t-1)*(*(ex+i))+*(ex+k))/((*(d+i)-*(d+k))*(*(d+i)-*(d+k))));
    };
  }else if(ZEROST(*(d+i)-*(d+k))){
    return((((*(d+i)-*(d+j))*t-1)*(*(ex+i))+*(ex+j))/((*(d+i)-*(d+j))*(*(d+i)-*(d+j))));
  }else if(ZEROST(*(d+j)-*(d+k))){
    return((((*(d+j)-*(d+i))*t-1)*(*(ex+j))+*(ex+i))/((*(d+i)-*(d+j))*(*(d+i)-*(d+j))));
  }else{//all different
    return(*(ex+i)/((*(d+i)-*(d+j))*(*(d+i)-*(d+k)))+*(ex+j)/((*(d+j)-*(d+i))*(*(d+j)-*(d+k)))+*(ex+k)/((*(d+k)-*(d+j))*(*(d+k)-*(d+i))));
    };*/
};


//Functions

void Likelihood(const Factmatrix &Q,long double *in,long double *out,long double length,const long double* ex);

long double dlikeq(const Factmatrix& f,long double *top,long double *bot,long double len,const params& p,int k,const Realmatrix &m,const long double* ex);

long double dliket(const Factmatrix& f,long double *top,long double *bot,long double len,const params& p,const long double *ex);

void dlikeql(const Factmatrix& f,long double *in,long double *out,long double len,const params& p,int k,const long double *ex);

void dliketl(const Factmatrix& f,long double *in,long double *out,long double len, const params& p,const long double *ex);

long double d2liket(const Factmatrix& f,long double *top,long double *bot,long double len, const params& p,const long double *ex);

long double d2liketq(const Factmatrix& f,long double *top,long double *bot,long double len, const params& p, int k,const long double *ex);

//Newer versions allow passing a precalculated action on top.

long double inline dlikeqact(const Factmatrix& f,const long double *top,long double *bot,long double len,const params& p,int k,const Realmatrix &m,const long double* ex){
  //For computing the likelihood, not for compiling likelihood lists.
  long double *b2=new long double[NumCodons];
  f.gammainv.act(bot,b2);
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    long double w=0;
    for(int j=0;j<NumCodons;j++){
      long double coeff=getcoeff(f.A,len,i,j,ex);
      w+=*(m.entries+i*NumCodons+j)*(*(b2+j))*coeff;
    };
    ans+=*(top+i)*w;
  };
  for(int i=0;i<NumCodons;i++){
    ans+=*(top+i)*(*(b2+i))*(*(m.entries+i*(NumCodons+1)))*len*(*(ex+i));
  };
  delete[] b2;
  return ans;
};


long double inline dlikeqact2(const Factmatrix& f,const long double *top,long double *bot,long double len,const params& p,const Realmatrix &m,const long double* ex){
  //For computing the likelihood, not for compiling likelihood lists.
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    long double w=0;
    for(int j=0;j<NumCodons;j++){
      long double coeff=getcoeff(f.A,len,i,j,ex);
      w+=*(m.entries+i*NumCodons+j)*(*(bot+j))*coeff;
    };
    ans+=*(top+i)*w;
  };
  for(int i=0;i<NumCodons;i++){
    ans+=*(top+i)*(*(bot+i))*(*(m.entries+i*(NumCodons+1)))*len*(*(ex+i));
  };
  return ans;
};

long double inline dlikeqact2(const long double *top,long double *bot,const Realmatrix &m,const long double *coeff){
  //For computing the likelihood, not for compiling likelihood lists.
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    long double w=0;
    for(int j=0;j<NumCodons;j++){
      w+=*(m.entries+i*NumCodons+j)*(*(bot+j))*(*(coeff+i*NumCodons+j));
    };
    ans+=*(top+i)*w;
  };
  return ans;
};

void inline PreLikelihoodact(const Factmatrix &Q,long double *in,long double *out,const long double* ex){
  //For compiling likelihood lists. Parameter "length" is now unnecessary.
  for(int k=0;k<NumCodons;k++){
    *(out+k)=*(in+k)*(*(ex+k));
  };
};

void inline Likelihoodact(const Factmatrix &Q,long double *in,long double *out,long double length,const long double* ex){
  //For compiling likelihood lists. Parameter "length" is now unnecessary.
  long double *temp=new long double[NumCodons];
  for(int k=0;k<NumCodons;k++){
    *(temp+k)=*(in+k)*(*(ex+k));
  };
  Q.gamma.act(temp,out);
  delete[] temp;
};

void inline LikelihoodMultiact(const Factmatrix &Q,int n,long double *in,long double *out,long double length,const long double* ex){
  //For compiling likelihood lists. Parameter "length" is now unnecessary.
  long double *temp=new long double[NumCodons*n];
  for(int j=0;j<n;j++){
    for(int k=0;k<NumCodons;k++){
      *(temp+j*NumCodons+k)=*(in+j*NumCodons+k)*(*(ex+NumCodons+k));
    };
  };
  Q.gamma.MultiActLin(n,temp,out);
  delete[] temp;
};

void inline Likelihoodact(const Factmatrix &Q,long double *in,long double *out,const long double* ex){
  //For compiling likelihood lists. 
  long double *temp=new long double[NumCodons];
  for(int k=0;k<NumCodons;k++){
    *(temp+k)=*(in+k)*(*(ex+k));
  };
  Q.gamma.act(temp,out);
  delete[] temp;
};


long double inline Likelihoodactval(const Factmatrix &Q,long double *top,long double *bot,long double length,const long double* ex){
  long double *temp=new long double[NumCodons];
  Q.gammainv.act(bot,temp);
  long double ans=0;
  for(int k=0;k<NumCodons;k++){
    ans+=*(temp+k)*(*(ex+k))*(*(top+k));
  };
  delete[] temp;
  return ans;
};

long double inline dliketact(const Factmatrix& f,long double *top,long double *bot,long double len,const params& p,const long double *ex){
  long double *b2=new long double[NumCodons];
  f.gammainv.act(bot,b2);
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    ans+=*(b2+i)*(*(top+i))*(*(ex+i))*(*(f.D.entries+i));
  };
  delete[] b2;
  return ans;
};

long double inline dliketact2(const Factmatrix& f,long double *top,long double *bot,long double len,const params& p,const long double *ex){
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    ans+=*(bot+i)*(*(top+i))*(*(ex+i))*(*(f.D.entries+i));
  };
  return ans;
};

void inline dlikeqlact(const Factmatrix& f,long double *in,long double *out,long double len,const params& p,int k,const long double *ex){
  //For compiling likelihood lists.
  long double *b2=new long double[NumCodons];
  const Realmatrix& m=p.dD(k);
  for(int i=0;i<NumCodons;i++){
    *(b2+i)=0;
    for(int j=0;j<NumCodons;j++){
      long double coeff=getcoeff(f.A,len,i,j,ex);      
      *(b2+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*coeff;
    };
  };
  for(int i=0;i<NumCodons;i++){
    *(b2+i)+=*(in+i)*(*(m.entries+i*(NumCodons+1)))*len*(*(ex+i));
  };
  f.gamma.act(b2,out);
  delete[] b2;
};

void inline dlikeqlact(const Factmatrix& f,long double *in,long double *out,long double len,const params& p,const Realmatrix& m,const long double *ex){
  //For compiling likelihood lists.
  long double *b2=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(b2+i)=0;
    for(int j=0;j<NumCodons;j++){
      long double coeff=getcoeff(f.A,len,i,j,ex);
      //      cout<<"coeff="<<coeff<<"\n";
      *(b2+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*coeff;
    };
  };
  for(int i=0;i<NumCodons;i++){
    *(b2+i)+=*(in+i)*(*(m.entries+i*(NumCodons+1)))*len*(*(ex+i));
  };
  f.gamma.act(b2,out);
  delete[] b2;
};


void inline dlikeqlact(const Factmatrix& f,const long double *in,long double *out,const Realmatrix& m,const long double *coeffs){
  //For compiling likelihood lists.
  long double *b2=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(b2+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(b2+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*(*(coeffs+i*NumCodons+j));
    };
  };
  f.gamma.act(b2,out);
  delete[] b2;
};

void inline Predlikeqlactsv(const Factmatrix& f,const long double *in,long double *out,const Realmatrix& m,const long double *coeffs,long double *T){
  //For compiling likelihood lists.
  for(int i=0;i<NumCodons;i++){
    *(out+i)=0;
    *(T+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(out+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*(*(coeffs+i*NumCodons+j));
      *(T+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*(*(f.A+j*NumCodons+i));
    };
  };
};

void inline dlikeqlactsv(const Factmatrix& f,const long double *in,long double *out,const Realmatrix& m,const long double *coeffs,long double *T){
  //For compiling likelihood lists.
  long double *b2=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(b2+i)=0;
    *(T+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(b2+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*(*(coeffs+i*NumCodons+j));
      *(T+i)+=*(m.entries+i*NumCodons+j)*(*(in+j))*(*(f.A+j*NumCodons+i));
    };
  };
  f.gamma.act(b2,out);
  delete[] b2;
};

void inline dlikeqlactdown(const Factmatrix& f,const long double *in,long double *out,const Realmatrix& m,const long double *coeffs){
  //For compiling likelihood lists.
  for(int i=0;i<NumCodons;i++){
    *(out+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(out+i)+=*(m.entries+j*NumCodons+i)*(*(in+j))*(*(coeffs+j*NumCodons+i));
    };
  };
};

void inline dlikeqlactdownsv(const Factmatrix& f,const long double *in,long double *out,const Realmatrix& m,const long double *coeffs,long double *T){
  //For compiling likelihood lists.
  for(int i=0;i<NumCodons;i++){
    *(out+i)=0;
    *(T+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(out+i)+=*(m.entries+j*NumCodons+i)*(*(in+j))*(*(coeffs+j*NumCodons+i));
      *(T+i)+=*(m.entries+j*NumCodons+i)*(*(in+j))*(*(f.A+j*NumCodons+i));
    };
  };
};


void inline calcT(const Factmatrix& f,const long double *in,const Realmatrix& m,const long double *coeffs,long double *T){
  //For compiling likelihood lists.
  for(int i=0;i<NumCodons;i++){
    *(T+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(T+i)+=*(m.entries+j*NumCodons+i)*(*(in+j))*(*(f.A+j*NumCodons+i));
    };
  };
};


void inline dliketlact(const Factmatrix& f,long double *in,long double *out,long double len, const params& p,const long double *ex){
  //Used for computing likelihood lists.
  long double *b2=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(b2+i)=(*(in+i))*(*(f.D.entries+i))*(*(ex+i));
  };
  f.gamma.act(b2,out);
  delete[] b2;
};

long double inline d2liketact(const Factmatrix& f,long double *top,long double *bot,long double len, const params& p,const long double *ex){
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    ans+=*(bot+i)*(*(top+i))*(*(f.D.entries+i))*(*(f.D.entries+i))*(*(ex+i));
  };
  return ans;
};

long double inline d2liketqact(const Factmatrix& f,long double *top,long double *bot,long double len, const params& p, int k,const long double *ex){
  const Realmatrix& m=p.dD(k);
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    long double w=0;
    for(int j=0;j<NumCodons;j++){
      long double coeff=getcoeff2(f.D.entries,f.A,len,i,j,ex);
      w+=*(m.entries+i*NumCodons+j)*(*(bot+j))*coeff;
    };
    ans+=*(top+i)*w;
  };
  for(int i=0;i<NumCodons;i++){
    ans+=*(top+i)*(*(m.entries+i*(NumCodons+1)))*(*(bot+i))*(*(f.D.entries+i)*len+1)*(*(ex+i));
  };
  return ans;
};

long double inline d2liketqact(const Factmatrix& f,long double *top,long double *bot,long double len, const params& p, const Realmatrix &m,const long double *ex){
  //Useful when calculating directional derivatives.
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    long double w=0;
    for(int j=0;j<NumCodons;j++){
      long double coeff=getcoeff2(f.D.entries,f.A,len,i,j,ex);
      w+=*(m.entries+i*NumCodons+j)*(*(bot+j))*coeff;
    };
    ans+=*(top+i)*w;
  };
  for(int i=0;i<NumCodons;i++){
    ans+=*(top+i)*(*(m.entries+i*(NumCodons+1)))*(*(bot+i))*(*(f.D.entries+i)*len+1)*(*(ex+i));
  };
  return ans;
};

#endif
