/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Classes and Routines for matrix manipulation */
#ifndef REALMATRIX_H
#define REALMATRIX_H 1

#include <iosfwd>
#include "Macros.h" 
#ifdef COMPLEX_NUMBERS
//#include "NewAlgebra.cpp"
#endif

class Diagmatrix{
public:
  int sz;
  long double *entries; //Possibly should enable complex as well.
  Diagmatrix(){entries=NULL;};
  Diagmatrix(int n){sz=n;entries=new long double[n];};
  Diagmatrix(const Diagmatrix& D){sz=D.sz;entries=new long double[sz];for(int i=0;i<sz;i++){*(entries+i)=*(D.entries+i);};};
  void operator =(const Diagmatrix& D){if(entries!=NULL){delete[] entries;};sz=D.sz;entries=new long double[sz];for(int i=0;i<sz;i++){*(entries+i)=*(D.entries+i);};};
  ~Diagmatrix(){if(entries!=NULL){delete[] entries;};};
  Diagmatrix(long double *ev){entries=ev;};//Assumes ev no longer needed.
  void assign(long double *ev,int s){if(entries!=NULL){delete[] entries;};sz=s;entries=new long double[s];for(int i=0;i<s;i++){*(entries+i)=*(ev+i);};};
  friend std::ostream &operator <<(std::ostream &o,const Diagmatrix &D);
};

class Factmatrix;

class RealmatrixT;//temporary realmatrix, used to reduce needless copying.

class Realmatrix{
  void applyHouseholder(long double *v);
  void applyHouseholder(long double *v,int n);
  RealmatrixT applyHouseholderto(long double *v) const;
  RealmatrixT tridiagonalisesymmetric(long double *output) const;
public:
  int sz;    //size of square matrix
  long double *entries;   
  ~Realmatrix(){if(entries!=NULL){delete[] entries;};};
  Realmatrix();
  Realmatrix(int s);
  Realmatrix(char *s);
  Realmatrix(std::ifstream& s);
  Realmatrix(std::istream& s);
  Realmatrix(long double *a);
  Realmatrix(int s,const long double *a);
  Realmatrix(const Realmatrix &R);
  Realmatrix(RealmatrixT R);
  void operator =(const Realmatrix &R);
  void operator =(RealmatrixT R);
  void assign(std::ifstream& s);
  void save(std::ofstream& s) const;
  void copy(long double *T) const;

  void premult(long double *ent);
  void mult(long double *ent);
  void mult(const Realmatrix &X);
  void act(const long double *vect,long double *ans) const;
  void TranspAct(const long double *vect,long double *ans) const;
  void MultiAct(int n,const long double *const *vect,long double *ans) const;
  void MultiActLin(int n,const long double *vect,long double *ans) const;
  void MultiTranspAct(int n,const long double *const *vect,long double *ans) const;
  void MultiTranspActProd(int n,const long double *const *vect,const long double *prod,long double *ans) const;
  long double actNorm(long double *vect,long double *ans) const;
  void minus(Realmatrix T);
  void subtractid(long double l);
  void divide(long double l);

  void display() const;
  friend std::ostream &operator <<(std::ostream &o,const Realmatrix &R);

  RealmatrixT transpose() const;
  RealmatrixT inverse() const;
  RealmatrixT transinverse() const;
  RealmatrixT diagonalisesymmetric(long double *ev) const;

  void diagnosesymm() const;
  void testdiagfact(long double *v) const;

  void swaprows(int i,int j);
  void resortrows(const int *p);
  void resortcols(const int *p);
  RealmatrixT getresistance();

#ifdef COMPLEX_NUMBERS
  void copy(complex *T) const;
  void act(complex *vect,complex *ans) const;
#endif
};

class RealmatrixT{//temporary realmatrix, used to reduce needless copying.
  //  RealmatrixT(const RealmatrixT& R);
public:
  int sz;
  long double *ent;

  RealmatrixT(Realmatrix& R){ent=R.entries;sz=R.sz;R.sz=0;R.entries=NULL;};
  RealmatrixT(int s,long double* en){ent=en;sz=s;};//new long double[s*s];for(int i=0;i<s*s;i++){*(ent+i)=*(en+i);};
  RealmatrixT(int s){ent=new long double[s*s];sz=s;};
  RealmatrixT(std::ifstream& in);
  //  RealmatrixT(Realmatrix R){ent=R.entries;sz=R.sz;};
};

class Factmatrix{
  //Factorisation of a matrix into diagonalised form (if possible)
  //M=gamma.D.gammainv  
public:
  int sz;
  Realmatrix gamma;
  Realmatrix gammainv;
  Diagmatrix D;
  long double* A;
  void setA(){if(A!=NULL){delete[]A;};A=new long double[sz*sz];for(int i=0;i<sz;i++){for(int j=0;j<sz;j++){if(ZEROST(*(D.entries+i)-*(D.entries+j))){*(A+i*NumCodons+j)=0;}else{*(A+i*NumCodons+j)=1/(*(D.entries+i)-*(D.entries+j));};};};};
  Factmatrix(RealmatrixT Q,Diagmatrix &EV,RealmatrixT R){gamma=Q;gammainv=R;D=EV;A=NULL;};
 Factmatrix():gamma(0),gammainv(0){A=NULL;};
  Factmatrix(int n){sz=n;gamma=RealmatrixT(n);gammainv=RealmatrixT(n);D=Diagmatrix(n);A=NULL;};
  Factmatrix(const Factmatrix& f);
  //  void remove(){delete[] D.entries;};
  void operator=(const Factmatrix& f);
  void display() const;
  //  Realmatrix compose();
  void assign(std::ifstream& s);
  void save(std::ofstream& s) const;
  void remove(){delete[] A;};
  friend std::ostream &operator <<(std::ostream &o,const Factmatrix &F);
};

void inline Realmatrix::act(const long double *vect,long double *ans) const {
  for(int i=0;i<sz;i++){
    long double acc=0;
    for(int j=0;j<sz;j++){
      acc+=*(vect+j)*(*(entries+i*sz+j));
    };
    *(ans+i)=acc;
  };
};

void dummyreadmatrix(std::istream& in);
//moves the steam position to the end of the matrix, but does not save
//the matrix.

RealmatrixT getsym(const Realmatrix& Q,long double *pi);

#endif
