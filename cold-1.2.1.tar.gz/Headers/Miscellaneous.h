/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Routines for various necessary functions */
#ifndef MISCELLANEOUS
#define MISCELLANEOUS 1

#include <iosfwd>

#include "MiscellaneousFuns.h"

class strlist{//linked list of strings;
public:
  char *str;
  strlist *next;
//public:
  strlist(){str=NULL;next=NULL;};
  strlist(const char *s);
  char *getstr(unsigned int n) const {if(n==0){return str;}else{if(next==NULL){return NULL;}else{return next->getstr(n-1);};};};
  void remove();
  void insert(const char *s);
  void insert(const char *s,unsigned int n);
  int search(const char *s,int n=0) const;
  friend std::ostream& operator <<(std::ostream& out,strlist s);
};

class numlist{//linked list of integers;
public:
  int n;
  numlist *next;
//public:
  numlist(){n=0;next=NULL;};
  numlist(int i){n=i;next=NULL;};
  void cutfirst(){if(next==NULL){n=0;}else{n=next->n;numlist *tmp=next->next; delete[] next; next=tmp;};}
  int getnum(unsigned int no) const {if(no==0){return n;}else{if(next==NULL){return -1;}else{return next->getnum(no-1);};};};
  void remove();
  void insert(int i);
  int search(int i,int c=0) const {if(n==i){return c;}else if(next==NULL){return -1;}else{return next->search(i,c+1);};};
  friend std::ostream& operator <<(std::ostream& out,numlist s);
};

class linklist{//linked list of data;
public:
  void *data;
  linklist *next;
//public:
  linklist(){data=NULL;next=NULL;};
  linklist(void *s){data=s;next=NULL;};
  void *getdata(unsigned int n) const {if(n==0){return data;}else{if(next==NULL){return NULL;}else{return next->getdata(n-1);};};};
  void remove(void (*de)(void *x));
  void insert(void *s);
  void insert(linklist &l);//Destroys l
  void insertcplst(const linklist &l);
  //  int search(*s,int n=0) const {if(strcmp(s,str)==0){return n;}else if(next==NULL){return -1;}else{return next->search(s,n+1);};};
  int del(unsigned int n,void (*de)(void *x));
  int delto(unsigned int n,void (*de)(void *x));
  void reverse(linklist *app=NULL,linklist *start=NULL,void *dat=NULL);
  void unlink();//removes the link structure, but keeps the data
		//(which is hopefully now pointed to by something
		//else).
  friend std::ostream& operator <<(std::ostream& out,linklist s);
};

class stackelt{
  void *data;
  stackelt *next;
public:
  stackelt(void *d,stackelt *ne=NULL){data=d;next=ne;};
  friend class stack;
  friend std::ostream& operator <<(std::ostream& out,stackelt s);
};

class stack{//stack;
  stackelt *top;
public:
  stack(){top=NULL;};
  void *pop(){if(top==NULL){return NULL;};void *ans=top->data;stackelt *nt=top->next;delete top;top=nt;return ans;};
  void push(void *elt){stackelt *x=new stackelt(elt,top);top=x;};
  friend std::ostream& operator <<(std::ostream& out,stack s);
};

class ldlist{//linked list of long doubles
public:
  unsigned int sz;
  long double *l;
  ldlist *next;
//public:
  ldlist(){l=NULL;next=NULL;sz=0;};
  ldlist(int n,long double *i){sz=n;l=new long double[n];for(int j=0;j<n;j++){*(l+j)=*(i+j);};next=NULL;};
  long double *getnum(unsigned int no) const {if(no<sz){return l+no;}else{if(next==NULL){return NULL;}else{return next->getnum(no-sz);};};};
  void remove();
  void insert(int n,long double *i);
  //  int search(int i,int c=0) const {if(n==i){return c;}else if(next==NULL){return -1;}else{return next->search(i,c+1);};};
  long unsigned int size(){if(next==NULL){return sz;}else{return sz+next->size();};};
  void extract(long double *d){for(unsigned int i=0;i<sz;i++){*(d+i)=*(l+i);};if(next!=NULL){next->extract(d+sz);};};
  friend std::ostream& operator <<(std::ostream& out,ldlist s);
};

//template <typename T> class linkedlist;

//template<typename T>
//ostream& operator <<(ostream& out,const linkedlist<T>& s);


template <typename T>
class linkedlist{//linked list
public:
  unsigned int sz;
  T *l;
  linkedlist *next;
//public:
  linkedlist(){l=NULL;next=NULL;sz=0;};
  linkedlist(int n,T *i){sz=n;l=new T[n];for(int j=0;j<n;j++){*(l+j)=*(i+j);};next=NULL;};
  T *getnum(unsigned int no) const {if(no<sz){return l+no;}else{if(next==NULL){return NULL;}else{return next->getnum(no-sz);};};};
  void remove();
  void insert(int n,T *i);
  void insert(linkedlist<T> ll);
  void insertcplist(linkedlist<T> ll);
  long unsigned int count(){if(next==NULL){return sz;}else{return sz+next->count();};};
  void extract(T *out){for(unsigned int i=0;i<sz;i++){*(out++)=*(l+i);};if(next!=NULL){next->extract(out);};};
  void clear(){if(sz>0){delete[] l;};if(next!=NULL){next->clear();delete[] next;};sz=0;next=NULL;l=NULL;};
  //  int search(int i,int c=0) const {if(n==i){return c;}else if(next==NULL){return -1;}else{return next->search(i,c+1);};};
  template <typename TT>
  friend std::ostream& operator <<(std::ostream& out,const linkedlist<TT> &s);
};

template<typename T>
std::ostream& operator <<(std::ostream& out,const linkedlist<T>& s){
  for(unsigned int i=0;i<s.sz;i++){
    out<<*(s.l+i)<<"\n";
  };
  if(s.next!=NULL){
    out<<*(s.next);
  };
  return out;
};

template<typename T>
void linkedlist<T>::insert(linkedlist<T> ll){
  long unsigned int c=ll.count();
  T *arr=new T[c];
  ll.extract(arr);
  this->insert(c,arr);
  delete[] arr;
};

template<typename T>
void linkedlist<T>::remove(){
  if(l!=NULL){
    delete[] l;
  };
  if(next!=NULL){
    next->remove();
    delete[] next;
  };
};

template<typename T>
void linkedlist<T>::insert(int n,T *i){
  if(n<=0){
    return;
  };
  if(l!=NULL){
    linkedlist<T> *ne=new linkedlist[1];
    ne->l=l;
    ne->next=next;
    ne->sz=sz;
    next=ne;
  }else{
    next=NULL;
  };
  sz=n;
  l=new T[n];
  for(int j=0;j<n;j++){
    *(l+j)=*(i+j);
  };
};

/*
template<typename T>
void linkedlist<T>::sort(){
  linkedlist<T> *start=this;
  linkedlist<T> *pos=next;
  linkedlist<T> *last=this;
  for(;pos!=NULL;){
    if(
  };
};
*/

#endif
