/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef MISCELLANEOUSFUNS_H
#define MISCELLANEOUSFUNS_H

char* readstring(std::istream &s,const char *term);

char* readnonemptystring(std::istream &s,const char *term);

char* readstring(std::istream &s,char &t,const char *term);

char* readstring(std::istream &s,const char *term,const char esc);

char* readmatchedstring(std::istream &s,char up,char down,char esc,const char *term);

void readline(const char* s, const char *fmt, ...);

void skipblanklines(std::istream &s);

int* selection(const char* s);

void sortlist(int *l);

int *partition(int n,const void *p,int (*relate)(int i,int j,const void *p));

#define ZEROPART(a) (((a)>-0.0000001) && ((a)<0.0000001))

int *partition(int n,const long double *p);

inline int tri(int a,int b){//For indexing triangular arrays.
  int x=(a>b)?a:b;
  int n=(a>b)?b:a;
  return(x*(x+1)/2+n);
};

inline int tri(int a,int b,int n){//For indexing triangular arrays backwards.
  int x=(a>b)?a:b;
  int y=(a>b)?b:a;
  return y*(2*n+1-y)/2+x-y;
};

#endif
