/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef MIXTREELIKELIHOOD_H
#define MIXTREELIKELIHOOD_H

#include "Tree.h"
#include "TreeLikelihood_base.h"

class Distribution;
class constraint;
class Realmatrix;
class RealmatrixT;
class params;

// Code needed for optimisation.

class Mixture{
  //determines which parameters are the same across all models 
  //and which parameters are constant.
  int num;
  int npars;
  int inpars;
  int *pars;// Negative values indicate a continuation of the previous
	    // parameter. List is terminated by 0.
  unsigned int numconstraints;
  constraint *cst;
  Distribution **dist;//List of distributions, (terminated with a NULL.?)
  int *dists;//List of distribution associated to each parameter. -1 represents no distribution.
  int *distpnum;//For quick reference, the first parameter number for each distribution.

  int getparptr(int i);
public:
  Mixture(){num=0;npars=0;pars=NULL;numconstraints=0;cst=NULL;dist=NULL;dists=NULL;distpnum=NULL;};
  Mixture(int n){num=n;npars=0;pars=NULL;numconstraints=0;cst=NULL;dist=NULL;dists=NULL;distpnum=NULL;};
  Mixture(const char *s,int n);
  Mixture(std::istream& s,int n);
  ~Mixture();
  int valid(){return pars!=NULL;};
  void Normalise(int offset=0);
  void insvars(int i);
  void setnum(int n){num=n;};
  void assign(const char *s);
  void assign(std::istream &s);
  friend class Mixtreelikelihood;
  void setpars(const long double *vals,long double *in);
  void sumpars(const long double *in,long double *out);
  void sumparsdecstep(const long double *in,long double *out,int firststep);
  void sumparstrisquare(const long double *dt,long double *to,int dim,int offset=0);
  void print();
  int getparno(int p){int *pr=pars;for(int i=0;i<p;i++){for(pr++;*pr<0;pr++);};return *pr;};

  //Dealing with distributions
  long double *applydistributions(const long double *vals,int scale=1);
  void seeddists(const long double *seeds,long double *out);
  void writedists(const long double *seeds,const long double *dpars,long double *out);
  void sumdistderivpars(const long double *vals,const long double* in,long double *out);
  void sumdistsecderparssq(const long double *vals,const long double* in,const long double* in2,long double *out,int dim);
  void showdistpars(std::ostream &out,const long double *x);
};

class Mixtreelikelihood : public treelk{
  tree T;
  unsigned int fixbl;
  int num;
  params *p;
  long double *prob;
  int varprobs;
  sequence *d;
  Factmatrix *f;
  long double *lastval;
  long double *vals;
  int *variablepars;//Makes a list of parameters allowed to vary.
  long double *distpars;
  int dir;
  Mixture m;
  int testlast(const long double *x);
  Mixtreelikelihood(const Mixtreelikelihood& T);//Disable copying
  inline void calculatevals(const long double *x);
public:
  Mixtreelikelihood(int mx,const char *tr,const Realmatrix& Q,std::ifstream& data);
  Mixtreelikelihood(int mx,const char *tr,std::ifstream& data);
  ~Mixtreelikelihood();
  void satisfyconstraints();
  void setpars(const Realmatrix& Q);
  void setpars(std::ifstream& I);
  void setpars(const char* c);
  void readpars(std::istream &in);
  void getx(long double *out);
  long double evaluate(const long double *x);
  long double *sitelikes(){return NULL/*T.Mixsitelikelihoods(f,d,p)*/;};
  long double *sitepostprobs();
  int numsites();
  void deriv(const long double *x,long double *out);
  void hessian(const long double *x,long double *out);
  /*  long double directionalDeriv(const long double *x,const long double *v);
      long double directionalSecDer(const long double *x,const long double *v);*/
  void approxHessian(const long double *x,long double *out){};//Need to implement this.
  void truehessian(const long double *x,long double *out){};
  void trueapproxHessian(const long double *x,long double *out){};
  /*  int LineSearch(long double *x,long double lastval,const long double *dir,int numpos);*/
  long double quickEvaluate(const long double *x);
  int edges(){return T.edges();};
  int posvals(){return fixbl?0:T.numed;};
  void constpars(){dim=T.edges();*variablepars=-1;};
  void printtree(std::ostream& out=std::cout){T.print(out);};
  void printdata(){T.printdata(std::cout,d);};
  void normalise();
  void normalisejustpars();
  void orthpars();
  void printall(std::ostream& out=std::cout,int *valpars=NULL);
  void parsimonybl();
  void parsimonypars();
  void empirical(int type=0);
  void setprob(long double *pr){for(int i=0;i<num-1;i++){*(prob+i)=*(pr+i);};};
  void setmix(const char*s);
  void setmix(std::ifstream& s);
  void setmixfile(const char* s,const char *const*pt=NULL);
  void setvarprobs(int i){dim+=i-varprobs;m.insvars(i-varprobs);varprobs=i;};
  void setfixedpars(long double *vls,int vlno);
  void setblfix();
  long double *tstats(const long double *x);
  void tstat(const long double *x,std::ostream& out);
  int* tstatsel(const long double *x,long double threshold=TSTAT5);
  void selectpars(int *sel);
  void undoselect(int *sel,int lastpars);
  void printtreedev(const Realmatrix &oi,std::ostream& out=std::cout);
  long double *truepars(int *valpars=NULL);
  RealmatrixT oi(const long double *x);
  unsigned int constraints();
  constraint* cst();
  long double* branchlen(){return T.branchlen();};
  long double* getmixprobs();
  void setequalprobs();
  void setzeropars();
  long double *posteriorprobs();
  long double *likelihoodDisplacement(int *params=NULL);
  long double *branchinfluences(int *params=NULL);
};

#endif
