/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef NEWTONRAPHSON
#define NEWTONRAPHSON
#include<stddef.h>

extern int useapproxhessian; //used by external functions to control hessian calculation.

class function{
public:
  int dim;
  virtual long double evaluate(const long double *x)=0;
  virtual void deriv(const long double *x,long double *out)=0;
  virtual void hessian(const long double *x,long double *out)=0;
};

class functionplus : virtual public function{//function with extra routines to speed up calculation.
public:
  virtual long double directionalDeriv(const long double *x,const long double *v)=0;
  virtual long double directionalSecDer(const long double *x,const long double *v)=0;
  virtual void approxHessian(const long double *x,long double *out)=0;
  virtual int LineSearch(long double *x,long double lastval,const long double *dir,int numpos)=0;
};

class onedfunction{
public:
  virtual long double evaluate(long double x)=0;
  virtual long double deriv(long double x)=0;
  virtual long double secder(long double x)=0;
};

inline long double min(long double a,long double b){
  return (a<b)?a:b;
};

inline long double max(long double a,long double b){
  return (a<b)?b:a;
};

long double testfunction(function& f,long double *x,long double eps,long double signif=0.00001);

long double testfunctionplus(functionplus& f,long double *x,long double *dir, long double eps);

void subsolve(const long double *M,const long double *v,long double *w,int dim,const int* omit);

void solve(const long double *M,long double *v,long double *w,int dim);

class constraint{
  int numterms;
  long double lt;
  int *varnum;
  long double *coeff;
public:
  constraint(){numterms=0;lt=0;varnum=NULL;coeff=NULL;};
  constraint(int nt,long double less,const int *vn,const long double *co){numterms=nt;lt=less;varnum=new int[nt];coeff=new long double[nt];for(int i=0;i<nt;i++){*(varnum+i)=*(vn+i);*(coeff+i)=*(co+i);};};
  constraint(const constraint & c){numterms=c.numterms;lt=c.lt;varnum=new int[numterms];coeff=new long double[numterms];for(int i=0;i<numterms;i++){*(varnum+i)=*(c.varnum+i);*(coeff+i)=*(c.coeff+i);};};
  ~constraint(){delete[] varnum;delete[] coeff;};
  void set(int nt,long double less,const int *vn,const long double *co){numterms=nt;lt=less;varnum=new int[nt];coeff=new long double[nt];for(int i=0;i<nt;i++){*(varnum+i)=*(vn+i);*(coeff+i)=*(co+i);};};
  void add(int i){for(int j=0;j<numterms;j++){*(varnum+j)+=i;};};
  long double slack(const long double *vals) const;
  char *prnt() const;
  void normalise(const long double *A){for(int i=0;i<numterms;i++){*(coeff+i)/=*(A+*(varnum+i));};};
  int correct(long double *vals) const;
  void operator=(const constraint &x){numterms=x.numterms;lt=x.lt;varnum=new int[numterms];coeff=new long double[numterms];for(int i=0;i<numterms;i++){*(varnum+i)=*(x.varnum+i);*(coeff+i)=*(x.coeff+i);};};
  friend long double *satisfyconstraints(int numposvals,int dim,const long double *max,const long double *hess,int numcon,const constraint *con);
  friend long double *optimiseQuadraticWithConstraints(const long double *hess,const long double *der,const long double *offset,const long double *pos,int dim,int numpos,int numcon,const constraint *cst);
};

long double *satisfyconstraints(int numposvals,int dim,const long double *max,const long double *hess,int numcon,const constraint *con);

int NewtonRaphson(function& f,long double *start,long unsigned steps,int op,int stv,int numposvals=0,int numconstraints=0,const constraint *cst=NULL,long double tolerance=1e-4,long double initpen=0);

int NewtonRaphsonExp(function& f,long double *start,long unsigned steps,int op,int numposvals=0);

int Gradient(function& f,long double *start,long unsigned steps,int op,int numposvals=0);

long double *maxima(onedfunction& f,long double lb, long double ub,int op);

long double *constrainedOptimum(int m,int n,long double **constraints,long double * vals,long double *start);

#endif
