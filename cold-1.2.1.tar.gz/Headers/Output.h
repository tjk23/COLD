/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

class OutputTemplate;
class treelk;

/*

Each line should be ended with the endrow character ;, or with a blank
line. Single new lines are ignored. "\t" inserts a tab character.

The output template works as follows: It simply copies characters from
input to output (with appropriate markup, using \ as an escape
character) until it encounters a special character <, >, {, or }. 

When it encounters >, it just cancels the last markup command (if one exists). 
When it encounters <, it reads a new markup command and adds it to the stack.

When it encounters {, it reads the placeholder, and makes the
necessary calculations. It then reads the formatting information and
outputs the value. If the formatting information consists of a cases
statement, it goes through the cases until it finds one that
matches. Then it resumes normal output until it reaches the end of
that case (indicated with | or }. If the end is indicated with |, it
then skips over the remainder of the file until it reaches the closing
} then resumes.


Tables are divided into rows, separated by the ; character.

Each row represents a set of rows - one for each data item.  That is,
some placeholders refer to a collection of data, and if such a
placeholder occurs in a table, one row is generated for every value of
that placeholder (or only the selected values if a selection is given.

Each placeholder has a type. The following types are currently possible:

int
enum
long double
string
int list
enum list
long double list
string list

There are different options for different types of placeholders.

For int/enum types, there is a cases option, which compares the value with the various cases and produces different output for each case.

For list types, there is a select option, which selects only certain elements from the list.

For long double types, there is a precision option, which controls the precision of the output.


 */



void outputtemplate(const OutputTemplate &tmplt,treelk *ff,long double *x,int *valpars=NULL);

void outputnoconverge(int numtimes,treelk *ff,long double *x,int argc,char* argv[],int *valpars=NULL);

void printconverge(treelk *ff,long double *x,int *valpars=NULL);

void outputconverge(treelk *ff,long double *x,int argc,char* argv[],int *valpars=NULL);
