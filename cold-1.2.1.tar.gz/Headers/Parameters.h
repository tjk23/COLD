/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Class and routines affecting parameters */


/*

The R matrix is given by R_ij=exp(sum_k(x_ijk b_k)), when i!=j.  Hence
the derivative is given by dR_ij/db_k=x_ijk R_ij, whenever i!=j, and
is constrained by the sum of each row being zero otherwise.

 */
#ifndef PARAMETERS
#define PARAMETERS 1
#define DEFAULTFILENAME "parametermatrices"
#include "Macros.h"
#include "Matrix.h"
#include <string.h>

void unsetupParams();
RealmatrixT orthonormalisemats(Realmatrix *X,int n);
RealmatrixT normalisemats(Realmatrix *X,int n);

class params{
  static char Filename[50];
  static long double X(int i,int j,int k);
  static int setupp;
  long double scale;
  Realmatrix C;  //matrix used to diagonalise R.

  static void setup(std::ifstream& in);//Should change this to istream later
  static void setup(const char *name);


  void calculate_derivs(const Factmatrix &f);
  void setR();
  friend void unsetupParams();


public:

  static Realmatrix *mask;//Used to allow restriction to models with
			  //at most one (or two) simultaneous
			  //nucleotide change. Null if no mask.

  static std::ifstream in;
  static Realmatrix *XX;
  static Realmatrix A; //Store the matrices in orthonormal form, then
		       //use matrix A to obtain the actual X matrices.

  long double *coeff;

  //Everything above here should be private.

  static int numpars;

  long double *pi;
  Realmatrix R;
  Realmatrix* derivs;

  void rescale(long double loga){*coeff-=loga;this->setR();};


  params();
  void operator=(const params& p);
  ~params();
  static void getmask(int n,std::ifstream& in);//Should change this to istream later  static void setup(const char *name);
  static void setFilename(const char* newname){strcpy(Filename,newname);};
  static void usematrix(const Realmatrix &Q);
  static void selectpars(const int *sel);
  static void undoselect(const int *sel,int num);
  long double getpars(const Realmatrix& Q);
  long double getparsFixedPi(const Realmatrix& Q);
  void regressionpars(const long double *temp);
  void readpars(std::istream& in);
  void readpi(std::istream& in);
  long double testpars(const Realmatrix& Q);
  Realmatrix Rmatrix() const;
  Factmatrix fmatrix();
  void setCoeff(const long double *cnew){for(int i=0;i<numpars;i++){coeff[i]=*(cnew+i);};this->setR();};
  void setTrueCoeff(const long double *cnew);
  const Realmatrix& dD(int k) const;
             //returns the derivative of the diagonal part of the
             //Qmatrix with respect to the kth parameter.
  RealmatrixT dR(int k) const;
  RealmatrixT d2R(int k,int l) const;
  const Realmatrix *Derivmats() const;
  const Realmatrix& d2D(int j,int k) const;
  long double normalise();//Normalises parameters, so that branch lengths correspond to expected number of changes.
  long double *truepars();// calculates the parameters wrt the
			  // original matrices, rather than the
			  // orthogonalised versions.
  void setpi(const long double *x){for(int i=0;i<NumCodons;i++){*(pi+i)=*(x+i);};};

  static void orthmats(){if(numpars>0){Realmatrix tmp=orthonormalisemats(XX,numpars);A.mult(tmp);};};//orthonormalises the matrices.
  long double dist(int *cf);//Measures the real distance between two different sets of parameters.
  void selcoeffs(const int *sel);
};

inline void params::operator=(const params& p){
  for(int i=0;i<NumCodons;i++){
    *(pi+i)=*(p.pi+i);
  };
  for(int i=0;i<numpars;i++){
    *(coeff+i)=*(p.coeff+i);
  };
  this->setR();
  long double *d=new long double[NumCodons];
  C=R.diagonalisesymmetric(d);
  delete[] d;
};

#endif
