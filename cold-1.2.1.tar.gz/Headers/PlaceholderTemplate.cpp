//#include<iostream>
//using namespace std;
//#include "ErrorHandler.h"
#include "Computations.h"

extern "C"{

#include "placeholders.h"
#include "placeholders2.h"
#include "placeholders3.h"

  int nplaceholders=NUMPLACEHOLDERS;
  const char **placeholderarray=placeholders;

}


#define MAKESTRING(a) MKSTR(a)
#define MKSTR(a) #a

void assignfuns(void** array,int (**dims)(int),const char *type){
#define FUNCTIONNAMEIND2(a) PLACEHOLDER##a
#define FUNCTIONNAMEIND(a) FUNCTIONNAMEIND2(a)
#define FUNCTIONNAME(a) FUNCTIONNAMEIND(a)
#define NUMLOOPS NUMPLACEHOLDERS
#define LOOPINCLUDEFILE "OutputFunctionassign.cpp"
#include "preprocessorloop.cpp"
};

extern "C"{
  void (*assignfunctions)(void** array,int (**dims)(int),const char *type)=assignfuns;
}
