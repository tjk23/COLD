/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Classes and routines for dealing with DNA sequences */

#ifndef SEQUENCE_H
#define SEQUENCE_H 1

#include <iosfwd>
//#include <iostream>
//#include <string.h>

#include "Macros.h"

int codon(char *seq);

char *displayCodon(int cod);

class sequence{
public:
  int length; //Maybe make these data private
  char *seq;  //But for the moment, this is fine.
  sequence(){length=0;seq=NULL;};
  sequence(char *s);
  ~sequence(){if(seq!=NULL){delete[] seq;};};
  void assign(char *s);
  void display() const;
  void copypos(int pos,char *target) const {for(int i=0;i<CodonLength;i++){*(target+i)=*(seq+pos*CodonLength+i);};};
  int getLength() const {return length;};
  void assign(std::ifstream &in);
  void assign(std::ifstream &in,int len);
  friend std::ostream& operator <<(std::ostream& out,const sequence& s);
};

char *comparepos(sequence *s,int pos,int numseq);

long double *emppi(sequence *data,int len,int type=0);

int setcode(const char *name,std::istream &in);

void makematrices(const char *name, const char *AA,const char *parameterfilebasename);

void makematrices(const char *name,std::ifstream &in,const char *parameterfilebasename);

#endif
