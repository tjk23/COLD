/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef SIGNALHANDLER_H
#define SIGNALHANDLER_H

#include "State.h"

#include <fstream>
//#include <signal.h>

//#define BACKTRACESIZE 20

class recoverState{
  //Used to recover a saved state, and resume program execution.
  std::ifstream read;
  int pos;
  char *type; //indicates the types of the data stored in the file.
public:
  char *command; //The command that was previously executed.
  char *retid; //identification string to indicate where program was up to
  int num(char t){int ans=0;for(char *p=type+pos;*p;p++){if(*p==t){ans++;};};return ans;};
  recoverState(char *filename);
  void load(int n,...);//used for resumption after process interruption.
  void load(int n,long unsigned int *max,void **address);//used for resumption after process interruption.
  void remove(){delete[] retid;delete[] type;read.close();};//For tidying up after finishing recovery
};

void endrecover();

extern recoverState* Recover;//If recovery is required, this will
				//store the necessary recovery
				//variable.

inline void endrecover(){Recover=NULL;};

void recover(char *filename);

void TerminatingSignalHandler(int sig,int sigtype);

int SetUpSignalHandlers(const void *variables=NULL);

#endif
