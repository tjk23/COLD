/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef STATE_H
#define STATE_H
#include <stddef.h>

void accessState();

void accessStateFinished();

class state{
  //Used for storing the important variables representing the
  //computations already performed. This way, the output can be
  //analysed to improve debugging. Also, the program can later be set
  //to resume from where it was up to.
  char *filename;
  //  int numdata; this is just strlen type.
  char *command;//The command used to execute the program
  const char *retid; //identification string to indicate where program was up to
  const void **data;
  char *type;
  long unsigned int *numitems;//Usually, this is a long unsigned int, telling how
		 //many items pointed to by data.
  int *no;
  int next;
public:
  state(const char* pos);
  state(const char* pos,const char *comm);
  void setfile(const char* name);
  void save();//used on termination to allow resumption
  int addvar(char ty,long unsigned int numitems,const void *add,const char *pos="Unspecified");//adds a new variable to the state.
  void remvar(int num,const char *pos=NULL,int nv=1);//adds a new variable to the state.
  void resizedata(int n,unsigned long int sz,const char *pos);//extends the amount of
      //data of interest.
  void clear(int k);//just keep one variable					
  void clear();//tidy up when information is processed.
  const char* getcommand(){return command;};
  ~state();
};

extern state* CurrentState; //This stores the current state of the program,
		     //so that if the program is interrupted, the
		     //signal handler can save the state
		     //appropriately.

void setstate(state *st);

#endif
