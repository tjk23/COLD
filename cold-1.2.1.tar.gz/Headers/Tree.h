/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef TREE_H
#define TREE_H 1

class precalc;
class mspace;

#include <iostream>
#include "Macros.h"

class Realmatrix;
class Factmatrix;
class params;
class sequence;

class tree{
#include "tree_private.h"
public:

  int numed;
  tree();
  tree(const tree& T);
  void operator=(tree T);
  tree(int l,const char *s);
  tree(const char *s);
  void remove();
  int findlabel(char *lab) const;


  int edges() const;
  int leaves() const;

  void substitutenames(std::ifstream& f,std::streampos& st);

  void printdata(std::ostream& out,sequence* d) const;
  long double *getlengths() const;
  long double *hessian(const Factmatrix& f,const sequence *data,const params& p);
  long double *approxHessian(const Factmatrix& f,const sequence *data,const params& p);
  long double *derivs(const Factmatrix& f,const sequence *data,const params& p);
  long double likelihood(const Factmatrix& f,const sequence *data,const params& p);
  long double fastlikelihood(const Factmatrix& f,const sequence *data,const params& p);
  long double *sitelikelihoods(const Factmatrix& f,const sequence *data,const params& p);
  long double *sitefirstders(const Factmatrix& f,const sequence *data,const params& p);

  void printspecies(std::ostream& out,int* no) const;

  //Routines for calculating directional derivatives.
  long double *directionalDerivs(const Factmatrix& f,const sequence *data,const params& p,const long double *dir);

  void parsimonybl(const Realmatrix &C,sequence *data);
  void parsimonybl(int num,const Realmatrix *C,const long double *probs,sequence *data);

  long double *hessian_threaded(const Factmatrix& f,const sequence *data,const params& p,const precalc &x,int st=-1);

  //Mixture Models
  long double *Mixhessian_threaded(const Factmatrix* f,const sequence *data,int num,const long double *prob,const params* p,const precalc *x,int st=-1);
  /*
    Output format of this function is a vector 

    first entry is log-likelihood

    next is derivative of likelihood with respect to branch lengths
    next is derivative of likelihood with respect to parameters
    next is derivative of likelihood with respect to probabilities
    
    next are second derivatives 
        d2l/didj where i<j in the order
	      branchlengths
	      parameters (one for each class)
	      probabilities


   */

  long double Mixlikelihood(const Factmatrix* f,const sequence *data,int num,const long double *prob,const params* p);
  long double *branchlen();//returns a list of branchlengths

  friend long double *recovercalchess(tree &t, const Factmatrix& f,const sequence *data,const params& p);
  friend long double *calchess(tree &t, const Factmatrix& f,const sequence *data,const params& p);
  friend long double *calchessandbi(tree &t, const Factmatrix& f,const sequence *data,const params& p);
  friend long double *Mixcalchess(tree &t, const Factmatrix* f,const sequence *data,int num,const long double *prob,const params* p);
  friend class treelikelihood;
  friend class Mixtreelikelihood;
  friend class simulationtree;

  //For calculating influence of branches.
  void getlnp(Realmatrix *&lp,const Factmatrix &f,const long double *&ex,const Realmatrix *DD) const;
  long double *branchInfluences(const Factmatrix& f,const sequence *data,const params& p,const precalc &x,int st);
  long double *hessian_threaded_With_branch_influences(const Factmatrix& f,const sequence *data,const params& p,const precalc &x,int st=-1);
};

sequence *getdata(std::ifstream& f,const tree& T);

void setnumthreads(int i);



inline tree::tree(){n=0;length=NULL;subtree=NULL;label=NULL;down=NULL;down2=NULL;down3=NULL;up=NULL;up2=NULL;up3=NULL;extra=NULL;extra2=NULL;extra3=NULL;};

inline tree::tree(const tree& T){n=T.n;length=T.length;subtree=T.subtree;label=T.label;up=T.up;up2=T.up2;up3=T.up3;down=T.down;down2=T.down2;down3=T.down3;extra=T.extra;extra2=T.extra2;extra3=T.extra3;};

inline void tree::operator =(tree T){n=T.n;length=T.length;subtree=T.subtree;label=T.label;up=T.up;up2=T.up2;up3=T.up3;down=T.down;down2=T.down2;down3=T.down3;extra=T.extra;extra2=T.extra2;extra3=T.extra3;};


inline long double *tree::getlengths() const{long double *ans=new long double[this->edges()];long double *a2=ans;this->getlengths(a2);return ans;};

inline int tree::edges() const {int l=n;for(int i=0;i<n;i++){l+=(subtree+i)->edges();};return l;};

inline int tree::leaves() const {if(n==0){return 1;}else{int l=0;for(int i=0;i<n;i++){l+=(subtree+i)->leaves();};return l;};};






#endif


