/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef TREELIKELIHOOD_H
#define TREELIKELIHOOD_H

#include "TreeLikelihood_base.h"
#include "Tree.h"
#include "Parameters.h"

class sequence;
class RealmatrixT;
#include "Optimisation.h"

// Code needed for optimisation.



class logbllike;
class logplike;

class treelikelihood : public treelk{
  tree T;
  unsigned int fixbl;
  params p;
  sequence *d;
  Factmatrix f;
  long double *lastval;
  long double *vals;
  int *variablepars;//Makes a list of parameters allowed to vary.
  int dir;
  int testlast(const long double *x);
  treelikelihood(const treelikelihood& T);//Disable copying
public:
  treelikelihood(const char *tr,const Realmatrix& Q,std::ifstream& data);
  treelikelihood(const char *tr,std::ifstream& data);
  void setpars(const Realmatrix& Q);
  void setpars(std::ifstream& I);
  void setpars(const char* c);
  ~treelikelihood();
  void readpars(std::istream &in){p.readpars(in);f=p.fmatrix();};
  void getx(long double *out){for(int i=0;i<dim-T.edges();i++){*(out+i+T.edges())=p.coeff[*(variablepars+i)];};T.putedgelengths(out);};
  long double evaluate(const long double *x);
  long double *sitelikes(){return T.sitelikelihoods(f,d,p);};
  int numsites();
  void deriv(const long double *x,long double *out);
  void testderiv(const long double *x);
  void hessian(const long double *x,long double *out);
  //  long double directionalDeriv(const long double *x,const long double *v);
  //  long double directionalSecDer(const long double *x,const long double *v);
  void approxHessian(const long double *x,long double *out);
  void truehessian(const long double *x,long double *out);
  void trueapproxHessian(const long double *x,long double *out);
  int LineSearch(long double *x,long double lastval,const long double *dir,int numpos);
  long double quickEvaluate(const long double *x);
  int edges(){return T.edges();};
  int posvals(){return fixbl?0:T.numed;};
  void constpars(){dim=T.edges();*variablepars=-1;};
  void printtree(std::ostream& out=std::cout){T.print(out);};
  void printtreedev(const Realmatrix &oi,std::ostream& out=std::cout);
  void printdata(){T.printdata(std::cout,d);};
  void normalise(){if(params::numpars>0){T.scale(p.normalise());};};
  void normalisejustpars(){if(params::numpars>0){p.normalise();};};
  void orthpars(){p.orthmats();};
  void printall(std::ostream& out=std::cout,int *valpars=NULL);
  void parsimonybl();
  void parsimonypars();
  void empirical(int type=0);
  void setfixedpars(long double *vls,int max);
  void setblfix();
  long double *tstats(const long double *x);
  void tstat(const long double *x,std::ostream& out);
  int* tstatsel(const long double *x,long double threshold=TSTAT5);
  void selectpars(int *sel);
  void undoselect(int *sel,int lastnum);
  long double *truepars(int *valpars=NULL){return p.truepars();};
  RealmatrixT oi(const long double *x);
  logbllike optbranchlength(int branch,int site1,int site2);
  logplike optpar(int par,int branch,int site1,int site2);
  unsigned int constraints(){return 0;};
  constraint* cst(){return NULL;};
  long double* branchlen(){return T.branchlen();};
  void setzeropars();
  long double *likelihoodDisplacement(int *params=NULL);
  long double *branchinfluences(int *params=NULL);
};

class logbllike : public onedfunction{
  int sites;
  long double *ev;
  long double *coeffs;
public:
  logbllike(int s=0){sites=s;ev=new long double[NumCodons];coeffs=new long double[NumCodons*sites];};
  void setsites(int s){sites=s;if(coeffs!=NULL){delete[] coeffs;};coeffs=new long double[NumCodons*sites];};
  void fillsite(int n,long double *v){for(int i=0;i<NumCodons;i++){*(coeffs+n*NumCodons+i)=*(v+i);};};//No safety checking!
  void setev(long double* e){for(int i=0;i<NumCodons;i++){*(ev+i)=*(e+i);};};
  long double evaluate(long double x);
  long double deriv(long double x);
  long double secder(long double x);
};

class logplike : public onedfunction{
  int sites;
  int pno;
  params *p;
  long double *coeffs;
  long double *y;
  long double len;
public:
  logplike(params *pa,int pn=0,int s=0){p=pa;sites=s;coeffs=new long double[NumCodons*sites*2];y=new long double[params::numpars];for(int i=0;i<params::numpars;i++){*(y+i)=p->coeff[i];};pno=pn;};
  //  logplike(params *pa,int s=0){p=pa;sites=s;coeffs=new long double[NumCodons*sites*2];y=new long double[params::numpars];for(int i=0;i<params::numpars;i++){*(y+i)=p->coeff[i];};};
  void setsites(int s){sites=s;if(coeffs!=NULL){delete[] coeffs;};coeffs=new long double[NumCodons*sites*2];};
  void fillsite(int n,long double *v,long double *w){for(int i=0;i<NumCodons;i++){*(coeffs+n*NumCodons*2+i)=*(v+i);*(coeffs+(n*2+1)*NumCodons+i)=*(w+i);};};//No safety checking!
  void setpar(params *pa){p=pa;};
  long double evaluate(long double x);
  long double deriv(long double x);
  long double secder(long double x);
  friend logplike treelikelihood::optpar(int par,int branch,int site1,int site2);
};


#endif

/*cout<<"Empirical frequencies:\n";for(int j=0;j<NumCodons;j++){cout<<*(epi+j)<<"\t";};cout<<"\n";*/ 
