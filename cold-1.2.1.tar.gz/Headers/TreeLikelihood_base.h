/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#ifndef TREELIKELIHOOD_BASE_H
#define TREELIKELIHOOD_BASE_H

#include <iosfwd>
#include <iostream>
class Realmatrix;
class RealmatrixT;
#include "Macros.h"
#include "Optimisation.h"

class treelk : virtual public function{//Interface for using tree likelihoods for normal and mixture models in same way.
 public:
  virtual ~treelk(){};
  virtual void setpars(const Realmatrix& Q)=0;
  virtual void setpars(std::ifstream& I)=0;
  virtual void setpars(const char* c)=0;
  virtual void readpars(std::istream &in)=0;
  virtual void getx(long double *out)=0;
  virtual long double evaluate(const long double *x)=0;
  virtual long double *sitelikes()=0;
  virtual int numsites()=0;
  virtual void deriv(const long double *x,long double *out)=0;
  virtual void hessian(const long double *x,long double *out)=0;
  virtual void approxHessian(const long double *x,long double *out)=0;
  virtual void truehessian(const long double *x,long double *out)=0;
  virtual void trueapproxHessian(const long double *x,long double *out)=0;
  virtual long double quickEvaluate(const long double *x)=0;
  virtual int edges()=0;
  virtual int posvals()=0;
  virtual void constpars()=0;
  virtual void printtree(std::ostream& out=std::cout)=0;
  virtual void printdata()=0;
  virtual void normalise()=0;
  virtual void normalisejustpars()=0;
  virtual void orthpars()=0;
  virtual void printall(std::ostream& out=std::cout,int *valpars=NULL)=0;
  virtual void parsimonybl()=0;
  virtual void parsimonypars()=0;
  virtual void empirical(int type=0)=0;
  virtual void setfixedpars(long double *vls,int max)=0;
  virtual void setblfix()=0;
  virtual long double *tstats(const long double *x)=0;
  virtual void tstat(const long double *x,std::ostream& out)=0;
  virtual int* tstatsel(const long double *x,long double threshold=TSTAT5)=0;
  virtual void selectpars(int *sel)=0;
  virtual void undoselect(int *sel,int lastpars)=0;
  virtual void printtreedev(const Realmatrix &oi,std::ostream& out=std::cout)=0;
  virtual long double *truepars(int *valpars=NULL)=0;
  virtual RealmatrixT oi(const long double *x)=0;
  virtual unsigned int constraints()=0;
  virtual constraint* cst()=0;
  virtual long double* branchlen()=0;
  virtual void setzeropars()=0;
  virtual long double *likelihoodDisplacement(int *params=NULL)=0;
  virtual long double *branchinfluences(int *params=NULL)=0;
};

void setcont(treelk *c);
#endif
