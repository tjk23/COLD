/*

This file is generated automatically by the script 'makefile'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/configvars.template'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#define NUMTHREADS 4
#define BUFFERSIZE 50
#define DEFAULTPARAMS parametermatrices
#define DEFAULTVARIABLES variables
#define DEFAULTMATRIX ECMq.txt
#define DEFAULTNUMTIMES 100
#define DEFAULTTREE testtrees
#define DEFAULTDATA testdata
#define DEFAULTMASKFILE masks
#define DEFAULTMODELFILE models
#define ROOTDIR /home/tjk23/cold
#define DEFAULTMARKUP markupcommands
#define DEFAULTOUTPUTTEMPLATE outputtemplate
#define DEFAULTCODEFILE geneticcodes
