/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makeheaders.sh'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.flags'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef FLAGS_H
#define FLAGS_H
const char *flag[]={
"-printsitelikes",
"-nomask",
"-usematrix",
"-justbl",
"-noautobackup",
"v ",
"q",
"-testderivs",
"-empiricalpi",
"-keepstate",
"-hessian",
"-approximatehessian",
"-tstats",
"-variableselect",
"-blstdev",
"-observedinformation",
"-equalprobs",
"-unbufferedstdout",
"-posteriorprobs",
"-converge",
"-usebranchlengths"};
#define NUMFLAG 21
#endif
