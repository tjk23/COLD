/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makeheaders.sh'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.markupcommands'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef MARKUPCOMMANDS_H
#define MARKUPCOMMANDS_H
const char *markupcommands[]={
"table 0",
"comment 1"};
#define NUMMARKUPCOMMANDS 2
#endif
