/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makemacrodefs'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.markupcommands'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef MARKUPCOMMANDS2_H
#define MARKUPCOMMANDS2_H
#define MARKUPCOMMANDS_TABLE 0
#define MARKUPCOMMANDS_COMMENT 1
#endif
