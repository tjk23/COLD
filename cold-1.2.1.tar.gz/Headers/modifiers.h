/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makeheaders.sh'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.modifiers'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef MODIFIERS_H
#define MODIFIERS_H
const char *modifiers[]={
"i precision",
"I selection ",
"s cases"};
#define NUMMODIFIERS 3
#endif
