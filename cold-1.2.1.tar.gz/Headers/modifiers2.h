/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makemacrodefs'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.modifiers'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef MODIFIERS2_H
#define MODIFIERS2_H
#define MODIFIERS_PRECISION 0
#define MODIFIERS_SELECTION 1
#define MODIFIERS_CASES 2
#endif
