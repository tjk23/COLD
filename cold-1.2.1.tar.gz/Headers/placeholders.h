/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makeheaders.sh'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.placeholders'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef PLACEHOLDERS_H
#define PLACEHOLDERS_H
const char *placeholders[]={
"d LL calculationdata::LL",
"I varsel calculationdata::varsel",
"e converge calculationdata::converge",
"I varnum calculationdata::varnum",
"I truevarnum calculationdata::truevarnum",
"D coeff calculationdata::coeff",
"D expcoeff calculationdata::expcoeff",
"D tstat calculationdata::tstat",
"I branchno calculationdata::branchno",
"I branchtop calculationdata::branchtop",
"I branchbot calculationdata::branchbot",
"D branchlen calculationdata::branchlen",
"D branchlenstd calculationdata::branchlenstd",
"s tree calculationdata::tree",
"s treestd calculationdata::treestd",
"I mixno calculationdata::mixno",
"I mixclass calculationdata::mixclass",
"D mixprob calculationdata::mixprob",
"I siteno calculationdata::siteno",
"D sitelike calculationdata::sitelike",
"D sitepostprob calculationdata::sitepostprob",
"s observedinformation calculationdata::observedinformation",
"s observedinformationinverse calculationdata::observedinformationinverse",
"D branchinfluence calculationdata::branchinf",
"s command calculationdata::command",
"D treelen calculationdata::treelen",
"s likelihooddisplacement calculationdata::likelihooddisplacement",
"s parameterinfluence calculationdata::parameterinfluence"};
#define NUMPLACEHOLDERS 28
#endif
