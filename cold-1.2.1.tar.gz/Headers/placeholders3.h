/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makefunctionnamemacros'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.placeholders'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef PLACEHOLDERS3_H
#define PLACEHOLDERS3_H
#define PLACEHOLDER0 calculationdata::LL
#define PLACEHOLDER1 calculationdata::varsel
#define PLACEHOLDER2 calculationdata::converge
#define PLACEHOLDER3 calculationdata::varnum
#define PLACEHOLDER4 calculationdata::truevarnum
#define PLACEHOLDER5 calculationdata::coeff
#define PLACEHOLDER6 calculationdata::expcoeff
#define PLACEHOLDER7 calculationdata::tstat
#define PLACEHOLDER8 calculationdata::branchno
#define PLACEHOLDER9 calculationdata::branchtop
#define PLACEHOLDER10 calculationdata::branchbot
#define PLACEHOLDER11 calculationdata::branchlen
#define PLACEHOLDER12 calculationdata::branchlenstd
#define PLACEHOLDER13 calculationdata::tree
#define PLACEHOLDER14 calculationdata::treestd
#define PLACEHOLDER15 calculationdata::mixno
#define PLACEHOLDER16 calculationdata::mixclass
#define PLACEHOLDER17 calculationdata::mixprob
#define PLACEHOLDER18 calculationdata::siteno
#define PLACEHOLDER19 calculationdata::sitelike
#define PLACEHOLDER20 calculationdata::sitepostprob
#define PLACEHOLDER21 calculationdata::observedinformation
#define PLACEHOLDER22 calculationdata::observedinformationinverse
#define PLACEHOLDER23 calculationdata::branchinf
#define PLACEHOLDER24 calculationdata::command
#define PLACEHOLDER25 calculationdata::treelen
#define PLACEHOLDER26 calculationdata::likelihooddisplacement
#define PLACEHOLDER27 calculationdata::parameterinfluence
#endif
