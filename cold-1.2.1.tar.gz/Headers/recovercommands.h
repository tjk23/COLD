/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makeheaders.sh'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.recovercommands'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef RECOVERCOMMANDS_H
#define RECOVERCOMMANDS_H
const char *recovercommand[]={
"-model",
"-modelfile",
"-numpars",
"-mask",
"-maskfile",
"-nomask",
"-parameterselection",
"-usematrix",
"-justbl",
"-mixture",
"-mixfile",
"-mixstring",
"-empirical",
"-equalprobs",
"-varprobs",
"-fixedprobs",
"-freqs",
"-setfixedpars",
"-treenumber",
"-variables",
"-path",
"-simulate",
"-variableselect",
"-code",
"-codesfile",
"-testderivs",
"e",
"t",
"d",
"o",
"f",
"p",
""};
#define NUMRECOVERCOMMAND 33
#endif
