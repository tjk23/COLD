/*

This file is generated automatically by the script '/home/tjk23/Hong/programs/Cold/Version1.2/Scripts/makeheaders.sh'
from the data file '/home/tjk23/Hong/programs/Cold/Version1.2/Headers/.recovercommandsunderride'. Please do not manually edit
this file, as changes may be automatically overwritten.

*/


#ifndef RECOVERCOMMANDSUNDERRIDE_H
#define RECOVERCOMMANDSUNDERRIDE_H
const char *recovercommandunderride[]={
"-output",
"-printsitelikes",
"-tstats",
"-observedinformation",
"-blstdev",
"-showeverysite",
"-unbufferedstdout",
"-posteriorprobs",
"P",
"b",
"T",
"i",
"D",
"q",
"v"};
#define NUMRECOVERCOMMANDUNDERRIDE 15
#endif
