/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//Private members and functions of class tree.

  void fillbranchlen(long double *&to);
  tree *clone(int n);
  void clone(tree *t);
  const long double** getdownlists() const;
  const long double** getuplists() const;
  void getdownlists(const long double** list) const;
  void getuplists(const long double** list) const;
  void getalldown3lists(long double* list) const;
  void getallup2lists(long double* list) const;
  void getdown3lists(long double* list) const;
  void getup2lists(long double* list) const;
  void setblzero();
  void parsimonyblsno(const Realmatrix &C,sequence *data,int m,long double inf);
  void parsimonyupdatebl(const Realmatrix& C,int i,long double );
  void makenonzerobranches(){for(int i=0;i<n;i++){if(ZEROST(*(length+i))){*(length+i)=1e-5;};(subtree+i)->makenonzerobranches();};};
  long double secder(int i,int j,const params& p,const Factmatrix& f,long double ul,const Realmatrix& M,const Realmatrix& N,const long double *&ex,const long double *&coeffs)const;
  long double sdsame(int i,int j,const Factmatrix& f, const params &p,const Realmatrix& M,const Realmatrix& N,const Realmatrix& O,const long double *mat,const long double *mat2,const long double *mat3,const long double *mat4,const int *part,const long double* upvals,const long double* downvals,const long double *ex,const long double *l,const long double *FIJ,const long double *coeffs,const long double *coeffs2,const long double *coeffs3,const long double *coeffs4,const long double *coeffs5,const long double *lsq,const long double *T,const long double *U)const throw();
  long double secderblp(int i,int j,const params& p,const Factmatrix& f,const long double* ex,const Realmatrix& R,long double ul,const long double *upvals,const long double *coeffs,int offset=0);
  long double secderbl(int i,int j,const params& p,const Factmatrix& f,const long double *ex,long double ul=0,int offset=0);
  void secderbl(int i,const params& p,const Factmatrix& f,const long double *ex,long double *&output,int edg,long double ul=0,int offset=0);
  //  void setextra(int ed);
  void liklistextrabl(const Factmatrix &f,int j,const params& p,int st,long double ul,const long double* ex);
  void liklistextrabl(const Factmatrix &f,const params& p,int st,long double ul,const long double *ex);
  void liklistextra(const Factmatrix& f,const params& p,const long double *ex,const long double *coeffs,const Realmatrix *dD,long double *T,long double *U);
              //builds the lists of extra likelihoods.
  void liklistextra(const Factmatrix& f,int i,const Realmatrix& M,const long double *ex,const long double *coeffs,long double *T,long double *U);
  void liklistextra(const Factmatrix& f,int i,const params& p,const long double *ex,long double len=0);
  void liklistextrabldir(const Factmatrix &f,const params& p,int st,long double ul,const long double* ex,const long double *dir);
  void liklistextradir(const Factmatrix& f,const params& p,const long double *ex,const Realmatrix &M, const long double *dir);
              //builds the lists of extra likelihoods.
  void liklistextradir(const Factmatrix& f,const Realmatrix& M,const params& p,const long double *ex,long double len=0);
  long double secderdir(const params& p,const Factmatrix& f,long double ul,const Realmatrix& M,const long double *&ex,const long double *coeffs)const;
  long double sdsamedir(const Factmatrix& f, const params &p,const Realmatrix& M,const Realmatrix& O,const long double *mat,const long double *mat2,const long double *mat3,const long double *mat4,const int *part,const long double* upvals,const long double* downvals,const long double *ex,const long double *l,const long double *FIJ)const throw();
  long double secderblpdir(const long double *dir,const params& p,const Factmatrix& f,const long double* ex,const Realmatrix& R,long double ul,const long double *coeffs,int offset=0);
  long double secderbldir(const long double *dir,const params& p,const Factmatrix& f,const long double *ex,long double ul=0,int offset=0);


  void sitehess(const Factmatrix& f,const sequence *data,const params& p,int i,long double *siteliks,const precalc &x,mspace &mem);

  void shiftbranchlength(int no,long double eps){for(int i=0;i<n;i++){if(no--==0){*(length+i)+=eps;return;}else if(no<(subtree+i)->edges()){(subtree+i)->shiftbranchlength(no,eps);return;}else{no-=(subtree+i)->edges();};};};

  long double *putedgelengths(long double *x){long double *ret=x;for(int i=0;i<n;i++){*ret=*(length+i);ret=(subtree+i)->putedgelengths(ret+1);};return ret;};

  void getlengths(long double*& out) const{for(int i=0;i<n;i++){*(out++)=*(length+i);(subtree+i)->getlengths(out);};};



  const long double *setedgelengths(const long double *x){const long double *ret=x;for(int i=0;i<n;i++){*(length+i)=*ret;ret=(subtree+i)->setedgelengths(ret+1);};return ret;};
  void filledges(){numed=n;for(int i=0;i<n;i++){(subtree+i)->filledges();numed+=(subtree+i)->numed;};};

  void print(std::ostream& out=std::cout) const;
  void print(long double *bl,std::ostream& out=std::cout) const;
  friend std::ostream &operator <<(std::ostream &o,const tree &T);
  void liklistdown(const Factmatrix& f,const sequence *data,int i,const long double *ex,long double len=-1); 
                              //builds the list of likelihoods
  void liklistdownfast(const Factmatrix& f,const sequence *data,int i,const long double *ex,const Realmatrix& gis,long double len=-1); 
  void liklistup(const params &p,const Factmatrix& f,const long double *ex,long double *above=NULL,long double len=0);
                              //builds the lists of upwards likelihoods.
  void printlists(int level,int start,int u,int st=0,int ed=0) const;

  const tree *findedge(int e,long double &len) const;

  void setextra(int ed);

  void loglengths();

void scale(long double x){for(int i=0;i<n;i++){(subtree+i)->scale(x);*(length+i)*=x;};};

  void debugneg(long double val,std::ostream& out=std::cout,int siteno=-1,int l=0);
  friend void dneg(void *);

  friend void sitehess(tree &,const Factmatrix&,const sequence *,const params&,int,long double *,const precalc &,mspace &);

  friend void pparssite(tree &T,const sequence *data,int n,long double *freqs,int step);

  friend void siteBranchInf(const tree &T,long double *up,long double *&answer,const Realmatrix *&lp,const long double *&ex,int abovebranches1,int abovebranches2,const Realmatrix *DQ,const Factmatrix &f,const long double *pi);

  friend long double *stBInf(tree &T,const precalc &x,const Realmatrix *DQ,const Factmatrix &f,const sequence *data,const params &p);

  void downpass(const sequence *data,int n);
void uppass(long double *freqs,int *up=NULL);//,int step,int *up=NULL);

  void makeLikelihoodlistsSafely(const Realmatrix& Q,const Realmatrix& Q2,const Realmatrix& Q3,const Realmatrix& Q4,const Realmatrix& Q5,const Factmatrix& f);

long double safeSiteLikelihood(const Factmatrix &f,const params& p);

  //public:
  int n;
  long double *length;
  tree *subtree;
  char *label;
  long double *down;//basic downwards lists.
  long double *down2;//downwards lists from top of branch
  long double *down3;//transformed downwards lists
  long double *up;//basic upwards lists
  long double *up2;//transformed upwards lists
  long double *up3;//upwards lists from bottom of branch
  long double *extra;
  long double *extra2;
  long double *extra3;//Just for parameters
