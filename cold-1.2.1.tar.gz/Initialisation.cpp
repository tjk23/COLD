/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

 
//   Routines for initialising various constructs


#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string.h>


#include "ErrorHandler.h"
#include "CommandLine.h"
#include "Matrix.h"
#include "Sequence.h"
#include "Parameters.h"
#include "Tree.h"
#include "TreeLikelihood.h"
#include "MixTreeLikelihood.h"
#include "Macros.h"
#include "Input.h"
#include "SignalHandler.h"
#include "recovercommands.h"
#include "recovercommandsunderride.h"
#include "flags.h"

using namespace std;
extern ostream& comm;//commentry;


char *locate(const char *const*path,const char *filename){
  int ml=0;
  for(int i=0;*(path+i);i++){
    int l=strlen(*(path+i));
    if(l>ml){
      ml=l;
    };
  };
  char *fullname=new char[ml+strlen(MAKESTRING(ROOTDIR))+strlen(filename)+3];
  ifstream test(filename);
  if(test.is_open()){
    test.close();
    strcpy(fullname,filename);
    return fullname;
  };
  strcpy(fullname,MAKESTRING(ROOTDIR));
  strcat(fullname,"/");
  strcat(fullname,filename);
  test.open(fullname);
  if(test.is_open()){
      test.close();
    return fullname;
  };
  for(int i=0;!test.is_open();i++){
    if(*(path+i)==NULL){//Not found
      delete[] fullname;
      return NULL;
    };
    strcpy(fullname,*(path+i));
    strcat(fullname,"/");
    strcat(fullname,filename);
    test.open(fullname);
    if(test.is_open()){
      test.close();
      return fullname;
    };
    strcpy(fullname,MAKESTRING(ROOTDIR));
    strcat(fullname,"/");
    strcat(fullname,*(path+i));
    strcat(fullname,"/");
    strcat(fullname,filename);
    test.open(fullname);
    if(test.is_open()){
      test.close();
      return fullname;
    };
  };
  delete[] fullname;
  return NULL;
};

extern int debuglevel;

const char *geneticCodeName="universal";

inline char *fullfilename(const char *basefilename){
  char *fmfn=new char[strlen(basefilename)+strlen(geneticCodeName)+5];
  strcpy(fmfn,basefilename);
  strcat(fmfn,"-");
  strcat(fmfn,geneticCodeName);
  return fmfn;
};

void setcodespecificifstream(const char* basename,ifstream &in){
    char *fullname=fullfilename(basename);
    try{
      setifstreamthrow(fullname,&in);
    }catch(...){
      variable *rec=vars.seektag("-codesfile");
      ifstream codesfile;
      const char *cfn;
      if(rec==NULL){
	cfn=MAKESTRING(DEFAULTCODEFILE);
      }else{
	cfn=*(const char * const *)rec->value;
      };
      setifstream(cfn,&codesfile);      
      rec=vars.seektag("-path");
      if(rec==NULL){
	char *msg=new char[50+strlen(geneticCodeName)+strlen(basename)];
	sprintf(msg,"Creating new file: \"%s-%s\"",basename,geneticCodeName);
	info(msg);
	makematrices(geneticCodeName,codesfile,basename);
      }else{
	const char *const*path=*(const char *const*const*)rec->value;
	char *fullbasename=locate(path,basename);
	if(fullbasename==NULL){
	  char *msg=new char[50+strlen(geneticCodeName)+strlen(basename)];
	  sprintf(msg,"Could not locate file: \"%s\"",basename);
	  recoverableError(msg);
	};
	char *msg=new char[50+strlen(geneticCodeName)+strlen(fullbasename)];
	sprintf(msg,"Creating new file: \"%s-%s\"",fullbasename,geneticCodeName);
	info(msg);
	makematrices(geneticCodeName,codesfile,fullbasename);
	delete[] fullbasename;
      };
      codesfile.close();
      setifstream(fullname,&in);
    };
    delete[] fullname;
};

void setmodels(){
  const char *modelfile=MAKESTRING(DEFAULTMODELFILE);
  variable *rec=vars.seektag("-modelfile");
  if(rec!=NULL){//Use non-standard model file.
    modelfile=*(char **)rec->value;  
  };
  rec=vars.seektag("-model");
  if(rec!=NULL){
    const char *mdl=*(char**)rec->value;
    int mnamelen=0;
    const char *mdlps=mdl;
    for(;*mdlps&&*mdlps!='(';mdlps++){//Need to add support for quotes
      mnamelen++;
      if(*mdlps=='\\'){
	mdlps++;
	if(!*mdlps){
	  break;
	};
      };
    };
    char *mname=new char[mnamelen+1];
    const char *mdlpos2=mdl;
    for(int i=0;i<mnamelen;i++){
      if(*mdlpos2=='\\'){
	mdlpos2++;
	if(!*mdlpos2){
	  break;
	};
      };
      *(mname+i)=*(mdlpos2++);
    };
    *(mname+mnamelen)='\0';
    for(;*mdlps&&*mdlps!='(';mdlps++);
    mdlpos2=mdlps;
    int npars=0;
    for(;*mdlps;mdlps++){
      if(*mdlps==','){
	npars++;
      };
      if(*mdlps==')'){
	npars++;
	break;
      };
      if(*mdlps=='\\'){
	mdlps++;
	if(!*mdlps){
	  break;
	};
      };
    };
    mdlps=++mdlpos2;
    char **vvals=new char *[npars];
    for(int i=0;i<npars;i++){
      int len=0;
      for(;*mdlpos2&&*mdlpos2!=','&&*mdlpos2!=')';mdlpos2++){
	if(*mdlpos2=='\\'){
	  mdlpos2++;
	  if(!*mdlpos2){
	    break;
	  };
	};
	len++;
      };
      *(vvals+i)=new char[len+1];
      char *vvcur=*(vvals+i);
      for(;*mdlps&&*mdlps!=','&&*mdlps!=')';mdlps++){
	if(*mdlps=='\\'){
	  mdlps++;
	  if(!*mdlps){
	    break;
	  };
	};
	*(vvcur++)=*mdlps;
      };
      *vvcur='\0';
      mdlps++;
      mdlpos2++;
    };
    ifstream modelstream;
    setifstream(modelfile,&modelstream);
    readmodel(modelstream,mname,npars,vvals);
    modelstream.close();
    for(int i=0;i<npars;i++){
      delete[] *(vvals+i);
    };
    delete[] vvals;
    delete[] mname;
  };
};

void checkformask(){
  ifstream mask;
  variable *rec=vars.seektag("-maskfile");
  if(rec!=NULL){
    setcodespecificifstream(*(char**)rec->value,mask);
    if(!mask.is_open()){
      char *msg=new char[80+strlen(*(char**)rec->value)];
      strcpy(msg,"Unable to open mask file \"");
      strcat(msg,fullfilename(*(char**)rec->value));
      strcat(msg,"\"");
      warning(msg);
      delete[] msg;
    };
  }else{  
    setcodespecificifstream(MAKESTRING(DEFAULTMASKFILE),mask);
  };
  rec=vars.seektag("-mask");
  if(rec!=NULL){
    int msk=atoi(*(char**)rec->value);
    if(!mask.is_open()){
      recoverableError("Unable to open mask file.");
    };
    params::getmask(msk,mask);
  };
  mask.close();
};

//Need to break this up into smaller pieces.

void selectcode(){
  variable *rec=vars.seektag("-code");
  if(rec!=NULL){
    const char *code=*((const char *const *)rec->value);
    rec=vars.seektag("-codesfile");
    ifstream codesfile;
    const char *cfn;
    if(rec==NULL){
      cfn=MAKESTRING(DEFAULTCODEFILE);
    }else{
      cfn=*(const char * const *)rec->value;
    };
    setifstream(cfn,&codesfile);
    if(setcode(code,codesfile)==1){
      char msg[80];
      sprintf(msg,"Using %s genetic code",code);
      info(msg);
      geneticCodeName=code;
    }else{
      char msg[80];
      sprintf(msg,"\"%s\" genetic code not available, switching to universal.",code);
      warning(msg,msgcode(0,1));
    };
    codesfile.close();
  };
};

void setprobs(Mixtreelikelihood *ff,int num){
  long double *pr=new long double[num-1];
  variable* rec=vars.seektag("-fixedprobs");
  if(rec==NULL){
    rec=vars.seektag("-equalprobs");
    if(rec==NULL){
      rec=vars.seektag("-initprobs");
      if(rec==NULL){
	for(int i=0;i<num-1;i++){
	  *(pr+i)=0; 
	};
	ff->setprob(pr);
	ff->setvarprobs(num-1);
      }else{
	const char *pbs=*(char **)rec->value;
	long double lstp=1;
	for(int i=0;i<num-1;i++){
	  *(pr+i)=atof(pbs);
	  lstp-=*(pr+i);
	  for(;*pbs&&*pbs!=',';pbs++);
	  pbs++;
	};
	for(int i=0;i<num-1;i++){
	  *(pr+i)/=lstp;
	  *(pr+i)-=1;
	};
	ff->setprob(pr);
	ff->setvarprobs(num-1);
      };
    }else{
      ff->setequalprobs();	  
    };
  }else{
    const char *pbs=*(char **)rec->value;
    long double lstp=1;
    for(int i=0;i<num-1;i++){
      *(pr+i)=atof(pbs);
      lstp-=*(pr+i);
      for(;*pbs&&*pbs!=',';pbs++);
      pbs++;
    };
    for(int i=0;i<num-1;i++){
      *(pr+i)/=lstp;
      *(pr+i)-=1;
    };
    ff->setprob(pr);
    ff->setvarprobs(0);
  };
  rec=vars.seektag("-varprobs");
  if(rec!=NULL){
    const char *vp=*(char **)rec->value;
    int ps=atoi(vp);
    ff->setvarprobs(ps);
  }
  delete[] pr;
};

Mixtreelikelihood *makemixtreelikelihood(int num,char *a,ifstream& data,ifstream& Qmat,int skip){
  Mixtreelikelihood *ff=new Mixtreelikelihood(num,a,data);
  setprobs(ff,num);
  variable *rec=vars.seektag("-mixfile");
  if(rec!=NULL&&num>1){
    const char* mf=*(const char **)rec->value;
    rec=vars.seektag("-path");
    const char **pt;
    if(rec==NULL){
      pt=NULL;
    }else{
      pt=*(const char ***)rec->value;
    };
    ff->setmixfile(mf,pt);
  };
  rec=vars.seektag("-mixstring");
  if(rec!=NULL&&num>1){
    const char* mf=*(const char **)rec->value;
    ff->setmix(mf);
  };
  return ff;
};

  
treelk* maketreelikelihood(char *a,ifstream& data,ifstream& Qmat,int skip){
  treelk* ff;
  int num=1;
  variable *rec=vars.seektag("-mixture");
  if(rec!=NULL){
    num=atoi(*(char**)rec->value);
  };
  if(num>1){
    ff=makemixtreelikelihood(num,a,data,Qmat,skip);
  }else{
    ff=new treelikelihood(a,data);
    //    ff->orthpars();
  };
  if(vars.seektag("-justbl")){
    info("Using constant parameters.");
    ff->constpars();
  };
  rec=vars.seektag("-usematrix");
  if(rec!=NULL){
    Realmatrix Q(Qmat);
    params::usematrix(Q);
    ff->setpars(Q);      
    return ff;
  };
  rec=vars.seektag("-initparsfile");
  if(rec!=NULL){
    char *x=new char[50+strlen(*(char **)rec->value)];
    sprintf(x,"Reading parameters from file \"%s\".",*(char**)rec->value);
    info(x,msgcode(1,0));
    ifstream in;
    setifstream(*(char**)rec->value,&in);
    if(!in.good()){
      sprintf(x,"Could not open initial parameter file \"%s\"",*(char**)rec->value);
      recoverableError(x);//should give file menu.
    };
    ff->setpars(in);
    in.close();
    delete[] x;
  }else{
    rec=vars.seektag("-initpars");
    if(rec!=NULL){
      const char *initpars=*(char**)rec->value;
      ff->setpars(initpars);
    }else{
      rec=vars.seektag("-parsimony");
      if(rec==NULL||atoi(*(const char *const*)rec->value)%2==0){
	Realmatrix Q(Qmat);
	ff->setpars(Q);
      }else{
	ff->setzeropars();
      };
    };
  };
  rec=vars.seektag("-setfixedpars");
  if(rec!=NULL){
    const char *prs=*(char **)rec->value;
    int prnos=1;
    for(const char *prs2=prs;*prs2;prs2++){
      if(*prs2==','){
	prnos++;
      };
    };
    long double *prr=new long double[prnos];
    for(int i=0;i<prnos;i++){
      *(prr+i)=atof(prs);
      for(;*prs&&*prs!=',';prs++);
      prs++;
    };
    ff->setfixedpars(prr,prnos);
    delete[] prr;
  };
    ff->normalisejustpars();
  /*  if(skip==0&&!vars.seektag("-noparsimony")){
    info("Using parsimony to obtain first estimate.");
    ff->parsimony();
    };*/
  rec=vars.seektag("-empirical");
  if(rec!=NULL){
    const char *empname=*(char **)rec->value;
    int type=0;
    if(!strcmp(empname,"F3x4")){
      type=1;
    }else if(!strcmp(empname,"F1x4")){
      type=2;
    }else if(!strcmp(empname,"Fequal")){
      type=3;
    };
    ff->empirical(type);
  };
  if(vars.seektag("-empiricalpi")!=NULL){
    ff->empirical();
  };
  rec=vars.seektag("-parsimony");
  if(rec!=NULL){
    int parsimonytype=atoi(*(const char *const*)rec->value);
    if(parsimonytype==1||parsimonytype==3){
      info("Using parsimony to estimate parameters.");
      ff->parsimonypars();
    };
    //    ff->printall();
    ff->normalisejustpars();
    if(parsimonytype==2||parsimonytype==3){
      info("Using parsimony to estimate branch lengths.");
      ff->parsimonybl();
    };
  };
  //  long double *x=new long double[ff->dim];
  //  ff->getx(x);
  ff->normalisejustpars();
  //  ((treelikelihood *)ff)->testderiv(x);
  if(vars.seektag("-usebranchlengths")){
    ff->setblfix();
  };
  return ff;
};


void setdebugoutput(ostream& comm){
  variable *rec=vars.seektag("i");
  if(rec!=NULL){
    int inter=atoi(*(char**)rec->value);
    setinteractive(inter);
    if(inter==-1){
      rec=vars.seektag("-logfile");
      if(rec!=NULL){
	setlogfile(*(char **)rec->value);
      }else{
	setlogfile(MAKESTRING(DEFAULTLOG));//Should probably do something cleverer.
      };
    };
  };
  rec=vars.seektag("D");
  debuglevel=0;
  if(rec!=NULL){
    debuglevel=atoi(*(char**)rec->value);
    setdebug(debuglevel);
    if(debuglevel>0){
      comm<<vars;
    };
  };
};

void replacemodeloptions(const char *command,ifstream &tr,ifstream &data){
  //Loads the command used for a previous execution, and replaces all
  //model options with those from that command.

  //Currently doesn't deal with escaped single quotes.
  const char *nextarg=command;
  for(;*nextarg&&*nextarg!='\'';nextarg++);
  while(*nextarg){
    nextarg++;
    for(int i=0;*(nextarg+i)&&*(nextarg+i)!='\'';i++);
    if(*nextarg=='-'){
      nextarg++;
      if(*nextarg=='-'){//long option
	int i=0;
	for(;*(nextarg+i)&&*(nextarg+i)!='\'';i++);
	char *opt=new char[i+1];
	for(int j=0;j<i;j++){
	  *(opt+j)=*(nextarg++);
	};
	*(opt+i)='\0';
	cout<<opt<<"\n";
	nextarg++;
	char *opt2=NULL;
	int isflag=0;
	for(int k=0;k<NUMFLAG;k++){
	  if(!strcmp(opt,flag[k])){
	    isflag=1;
	  };
	};
	if(!isflag){
	  for(;*nextarg&&*nextarg!='\'';nextarg++);
	  int ii=0;
	  for(nextarg++;*(nextarg+ii)&&*(nextarg+ii)!='\'';ii++);
	  opt2=new char[ii+1];
	  for(int jj=0;jj<ii;jj++){
	    *(opt2+jj)=*(nextarg++);
	  };
	  *(opt2+ii)='\0';
	  cout<<opt2<<"\n\n";
	}
	for(int j=0;j<NUMRECOVERCOMMAND;j++){
	  if(!strcmp(opt,recovercommand[j])){
	    if(opt2==NULL){
	      vars.addvar("",recovercommand[j],NULL,setflag,opt2,noprnt,NULL);		
	    }else{
	      vars.addvar("",recovercommand[j],new const char*[1],setstr,opt2,prntstr,delstr);	      
	      delete[] opt2;
	    };
	  };
	};
	for(int j=0;j<NUMRECOVERCOMMANDUNDERRIDE;j++){
	  if(!strcmp(opt,recovercommandunderride[j])){
	    if(vars.seektag(opt)==NULL){//Don't override values given on command line.
	      if(opt2==NULL){
		vars.addvar("",recovercommandunderride[j],NULL,setflag,opt2,noprnt,NULL);		
	      }else{
		vars.addvar("",recovercommandunderride[j],new const char*[1],setstr,opt2,prntstr,delstr);	      
		delete[] opt2;
	      };
	    };
	  };
	};
	delete[] opt;
      }else{
	char o=*nextarg++;
	char *opt=NULL;
	int isflag=0;
	for(int k=0;k<NUMFLAG;k++){
	  if(o==*flag[k]){
	    isflag=1;
	    nextarg++;
	  };
	};
	if(!isflag){       
	  if(*nextarg=='\''){
	    nextarg++;
	    for(nextarg++;*nextarg&&*nextarg!='\'';nextarg++);
	    int ii=0;
	    nextarg++;
	    for(;*(nextarg+ii)&&*(nextarg+ii)!='\'';ii++);
	    opt=new char[ii+1];
	    for(int jj=0;jj<ii;jj++){
	      *(opt+jj)=*(nextarg+jj);
	    };
	    *(opt+ii)='\0';
	    if(*nextarg){
	      nextarg++;
	    };
	  }else{
	    int ii=0;
	    for(;*(nextarg+ii)&&*(nextarg+ii)!='\'';ii++);
	    opt=new char[ii+1];
	    for(int jj=0;jj<ii;jj++){
	      *(opt+jj)=*(nextarg++);
	    };
	    *(opt+ii)='\0';
	    if(*nextarg){
	      nextarg++;
	    };
	  };
	};
	for(int j=0;j<NUMRECOVERCOMMAND;j++){
	  if(o==*recovercommand[j]){
	    if(o=='t'){
	      setifstream(opt,&tr);
	      delete[] opt;
	    }else if(o=='d'){
	      setifstream(opt,&data);
	      delete[] opt;
	    }else if(opt==NULL){
	      vars.addvar("",recovercommand[j],NULL,setflag,opt,noprnt,NULL);		
	    }else{
	      vars.addvar("",recovercommand[j],new const char*[1],setstr,opt,prntstr,delstr);
	      delete[] opt;
	    };
	  };
	};
	for(int j=0;j<NUMRECOVERCOMMANDUNDERRIDE;j++){
	  if(o==*recovercommandunderride[j]){
	    char x[2];
	    x[0]=o;
	    x[1]='\0';
	    if(vars.seektag(x)==NULL){//Don't override values given on command line.
	      if(opt==NULL){
		vars.addvar("",recovercommandunderride[j],NULL,setflag,opt,noprnt,NULL);		
	      }else{
		vars.addvar("",recovercommandunderride[j],new const char*[1],setstr,opt,prntstr,delstr);	      
		delete[] opt;
	      };
	    };
	  };
	};
      };
    };
  };
};

void resetvals(){
  //used if new commandline options are received.
  variable *rec=vars.seektag("T");
  if(rec!=NULL){
    setnumthreads(atoi(*(char**)rec->value));
  };
  rec=vars.seektag("-state");
  if(rec!=NULL){
    CurrentState->setfile(*(char**)rec->value);
  }else{
    CurrentState->setfile("statefile");
  };
  rec=vars.seektag("-approximatehessian");
  if(rec==NULL){
    useapproxhessian=0;
  }else{
    useapproxhessian=1;
  };
  setdebugoutput(cout);
};

void setglobals(ifstream &Qmat,const char *command){
  selectcode();
  variable *rec=vars.seektag("p");
  if(rec!=NULL){
    const char *basename=(*((char**)rec->value));
    setcodespecificifstream(basename,params::in);
  }else{
    setcodespecificifstream(MAKESTRING(DEFAULTPARAMS),params::in);
  };
  rec=vars.seektag("-m");
  if(rec!=NULL){
    const char *basename=(*((char**)rec->value));
    setcodespecificifstream(basename,Qmat);
  }else{
    setcodespecificifstream(MAKESTRING(DEFAULTMATRIX),Qmat);
  };
  rec=vars.seektag("T");
  if(rec!=NULL){
    setnumthreads(atoi(*(char**)rec->value));
  };
  static state s("start",command);
  rec=vars.seektag("-state");
  if(rec!=NULL){
    s.setfile(*(char**)rec->value);
  }else{
    s.setfile("statefile");
  };
  setstate(&s);
  rec=vars.seektag("-approximatehessian");
  if(rec!=NULL){
    useapproxhessian=1;
  };
  setupdatecommandline(resetvals);
};
