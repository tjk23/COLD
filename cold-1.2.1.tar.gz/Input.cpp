/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>

#include "ErrorHandler.h"
#include "Matrix.h"
#include "Parameters.h"
#include "Sequence.h"
#include "Tree.h"
#include "Miscellaneous.h"
#include "CommandLine.h"
#include "MixTreeLikelihood.h"
#include "Distributions.h"

using namespace std;

char *parseexp(const char *);


void inline dummyreadmodel(istream& in){ 
  char x='-';
  in.get();
  int ql=0;
  char lq='\0';
  for(int level=1;in.good()&&level>0;x=in.get()){
    switch(x){
    case '}':
      if(ql==0){
	level--;
      };
      break;
    case '{':
      if(ql==0){
	level++;
      };
      break;
    case '\"':
      if(lq=='"'){
	ql--;
	lq=(ql>0)?'\'':'\0';
      }else{
	ql++;
	lq='\"';
      };
      break;
    case '\'':
      if(lq=='\''){
	ql--;
	lq=(ql>0)?'\"':'\0';
      }else{
	ql++;
	lq='\'';
      };
      break;
    case '\\':
      in.get();//Ignore next character
    };
  };
};

#include "ModelFields.h"

void readmodel(istream& in,int narg,const char * const * vnames,const char *const *vvals){
  int fct=1;
  for(int i=0;i<narg;i++){
    int fc=(strlen(*(vvals+i)))/strlen(*(vnames+i));
    if(fc>fct){
      fct=fc;
    };
  };
  for(;in.good()&&!in.eof()&&in.peek()!='}';){//for each line
    for(;in.good()&&!in.eof()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\n'||in.peek()=='\r');in.get());
    char *field=readstring(in,"=",'\\');
    for(char *a=field+strlen(field)-1;*a==' '||*a=='\t'||*a=='\n'||*a=='\r';a--){
      *a='\0';
    };
    char *vl=readstring(in,"\n",'\\');
    char *val=vl;
    for(int ii=0;strlen(fieldnamesandtags[2*ii]);ii++){
      if(!strcmp(fieldnamesandtags[2*ii],field)){
	//Modify val by filling in parameters, stripping leading
	//whitespace and escaping as appropriate.
	char *modval=new char[strlen(val)*fct+1];
	int parse=0;
	if(*val=='#'){
	//Also allow basic numerical expressions. Numerical
	//expressions should be written in reverse polish notation.

	  //	  int ans=0;
	  val++;
	  parse=1;
	};
	char *mv=val;
	for(;*mv==' '||*mv=='\t'||*mv=='\n'||*mv=='\r';mv++);
	for(char *a=val+strlen(val)-1;*a==' '||*a=='\t'||*a=='\n'||*a=='\r';a--){
	  *a='\0';
	};
	//Stripped leading and trailing spaces.
	char lq='\0';
	char *b=modval;
	int *mtch=new int[narg];
	for(int i=0;i<narg;i++){
	  *(mtch+i)=0;
	};
	for(char *a=mv;*a;a++){
	  if(lq=='\0'){
	    if(*a=='\"'||*a=='\''){
	      lq=*a;
	      for(int i=0;i<narg;i++){
		*(mtch+i)=0;
	      };
	    }else if(*a==' '||*a=='\t'||*a=='\r'){
	      *(b++)=*a;
	      for(int i=0;i<narg;i++){
		*(mtch+i)=0;
	      };
	    }else{
	      int cm=0;
	      for(int i=0;i<narg;i++){
		if(*(mtch+i)>=0){
		  if(*a==*(*(vnames+i)+*(mtch+i))){
		    (*(mtch+i))++;
		    if(*(mtch+i)==(signed int)strlen(*(vnames+i))){//match
		      if(*(a+1)==' '||*(a+1)=='\t'||*(a+1)=='\r'||*(a+1)=='\0'||*(a+1)=='\"'||*(a+1)=='\''){
			for(const char *aa=*(vvals+i);*aa;aa++){
			  *(b++)=*aa;
			};
			for(int i=0;i<narg;i++){
			  *(mtch+i)=0;
			};
			cm=1;
		      }else{
			*(mtch+i)=-1;
			if(cm==0){
			  cm=-*(mtch+i);
			};
		      };
		    }else{
		      cm=*(mtch+i);
		    };
		  }else{
		    if(cm==0){
		      cm=-*(mtch+i);
		    };
		    *(mtch+i)=-1;
		  };
		};
	      };
	      if(cm<=0){//no matching
		for(char *aa=a+cm;aa<=a;aa++){
		  *(b++)=*aa;
		};
	      };
	    };
	  }else{
	    if(*a=='\\'){
	      a++;
	      *b++=*a;
	    }else{
	      if(*a==lq){
		lq='\0';  
	      }else{
		*b++=*a;
	      };
	    };
	  };
	};
	*b='\0';
	delete[] mtch;
	if(lq!='\0'){
	  fatalError("Badly formated model file.");
	};
	if(parse){
	  char *tmp=parseexp(modval);
	  delete[] modval;
	  modval=tmp;
	};
	variable* rec=vars.seektag(fieldnamesandtags[2*ii+1]);
	if(rec==NULL){
	  char *msg=new char[strlen(fieldnamesandtags[2*ii+1])+strlen(modval)+40];
	  sprintf(msg,"Adding command line option -%s %s\n",fieldnamesandtags[2*ii+1],modval);
	  info(msg,msgcode(2,0));
	  delete[] msg;
	  vars.addvar(fieldnamesandtags[2*ii],fieldnamesandtags[2*ii+1],new char*[1],setstr,modval,prntstr,delstr);
	}else{
	  rec->setval(modval);
	};
	delete[] modval;
	break;
      };
    };
    delete[] field;
    delete[] vl;
  };
};

void passquotes(istream& in,char q){
  int ql=1;
  char lq=q;
  for(char a=in.get();in.good()&&!in.eof()&&ql>0;a=in.get()){
    if(a=='\''){
      if(a==lq){
	ql--;
	lq='\"';
      }else{
	ql++;
	lq='\'';
      };
    }else if(a=='"'){
      if(a==lq){
	ql--;
	lq='\'';
      }else{
	ql++;
	lq='\"';
      };
    }else if(a=='\\'){
      a=in.get();
    };
  };
};

void skipto(istream& in,char x){
  char a='0';
  for(;in.good()&&!in.eof()&&in.peek()!=x;a=in.get()){
    if(a=='\''||a=='\"'){
      passquotes(in,a);
    }else if(a=='\\'){
      a=in.get();
    };
  };
};


void thismodel(istream& in,const char *name,int narg,const char *const *vvals){
  for(;in.good()&&!in.eof()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\n'||in.peek()=='\r');in.get());
  char x=in.get();
  if(x=='('){//Parameters
    char *pnames=readstring(in,")",'\\');	  
    int esc=0;
    int pno=1;
    for(char *pos=pnames;*pos;pos++){
      if(esc==0&&*pos==','){
	pno++;
      };
      esc=0;
      if(*pos=='\\'){
	esc=1;
      };
    };
    if(narg<pno){//too few parameters
      char *msg=new char[80+strlen(name)];
      strcpy(msg,"Too few parameters for model: \"");
      strcat(msg,name);
      strcat(msg,"\".");
      recoverableError(msg);
      delete[] msg;
    };
    char **vn=new char*[pno];
    int cpno=0;
    char *lpos=pnames;
    char *pos=pnames;
    for(;*pos;pos++){
      if(esc==0&&*pos==','){
	*(vn+cpno)=new char[pos-lpos+1];
	*pos='\0';
	strcpy(*(vn+cpno),lpos);
	lpos=pos+1;
	cpno++;
      };
      esc=0;
      if(*pos=='\\'){
	esc=1;
      };
    };
    *(vn+cpno)=new char[pos-lpos+1];
    *pos='\0';
    strcpy(*(vn+cpno),lpos);
    lpos=pos+1;
    cpno++;
    for(x=in.get();in.good()&&!in.eof()&&x!='{';x=in.get());
    readmodel(in,pno,vn,vvals);
    for(int i=0;i<pno;i++){
      delete[] *(vn+i);
    };
    delete[] vn;
    delete[] pnames;
  }else if(x=='{'){
    readmodel(in,0,NULL,vvals);  
  }else{//Badly formatted model file
    warning("Badly formatted model file: expected '{' or '('");
    skipto(in,'{');
    readmodel(in,0,NULL,vvals);  
  };
};

void readmodel(istream& in,const char *name,int narg,const char *const *vvals){
  for(;in.good()&&!in.eof();){
    for(;in.good()&&!in.eof()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\n'||in.peek()=='\r');in.get());//Skip whitespace
    char x=in.get();
    if(x=='\"'){//Read until closing quote
      char *mname=readstring(in,"\"",'\\');
      if(!strcmp(mname,name)){//This model
	thismodel(in,name,narg,vvals);
	delete[] mname;
	return;
      }else{//ignore this model
	skipto(in,'{');
	dummyreadmodel(in);
      };
      delete[] mname;
    }else{//First character of model name
      if(x=='\\'){//start of escape sequence
	x=in.get();
	if(x==*name){
	  char *mname=readstring(in,"( \t\r\n{",'\\');
	  if(!strcmp(mname,name+1)){//This model
	    thismodel(in,name,narg,vvals);
	    delete[] mname;
	    delete[] mname;
	    return;
	  }else{
	    skipto(in,'{');
	    dummyreadmodel(in);
	    delete[] mname;
	  };
	}else{
	  skipto(in,'{');
	  dummyreadmodel(in);
	};
      }else if(x==*name){//possible match
	char *mname=readstring(in,"( \t\r\n",'\\');
	if(!strcmp(mname,name+1)){//This model
	  thismodel(in,name,narg,vvals);
	  delete[] mname;
	  return;
	}else{//ignore this model
	  skipto(in,'{');
	  dummyreadmodel(in);
	delete[] mname;
	};
      }else{
	skipto(in,'{');
	dummyreadmodel(in);
      };
    };
  };
  char *msg=new char[80+strlen(name)];
  strcpy(msg,"Model: \"");
  strcat(msg,name);
  strcat(msg,"\" not defined.");
  recoverableError(msg);
  delete[] msg;
};




