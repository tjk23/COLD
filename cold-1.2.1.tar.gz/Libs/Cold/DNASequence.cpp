/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <string.h>


#include "Macros.h"
using namespace std;

/* Classes and routines for dealing with DNA sequences */

int codon(char *seq){
  //Anything except ACGT is treated as unknown. Maybe better in future
  //to do something cleverer.
  //  cout<<"Converting sequence \""<<*seq<<*(seq+1)<<*(seq+2)<<"\"\n";
  int a=*seq=='A'?2:*seq=='C'?1:*seq=='G'?3:*seq=='T'?0:5;
  return a;
};

char *displayCodon(int cod){
  char x[5]="TCAG";
  char *a=new char[2];
  *(a+1)='\0';
  *a=x[cod];
  if(cod>3){
    *a='-';
  };
  return a;
};

class sequence{
public:
  int length; //Maybe make these data private
  char *seq;  //But for the moment, this is fine.
  sequence(){length=0;seq=NULL;};
  sequence(char *s){int l=strlen(s);length=l/CodonLength;seq=new char[l];for(int i=0;i<l;i++){*(seq+i)=*(s+i);};};
  ~sequence(){if(seq!=NULL){delete[] seq;};};
  void assign(char *s){int l=strlen(s);length=l/CodonLength;seq=new char[l];for(int i=0;i<l;i++){*(seq+i)=*(s+i);};};
  void display() const;
  void copypos(int pos,char *target) const {for(int i=0;i<CodonLength;i++){*(target+i)=*(seq+pos*CodonLength+i);};};
  int getLength() const {return length;};
  void assign(ifstream &in);
  void assign(ifstream &in,int len);
  friend ostream& operator <<(ostream& out,const sequence& s);
};

ostream& operator <<(ostream& out,const sequence& s){
  for(int i=0;i<s.length;i++){
    for(int j=0;j<CodonLength;j++){
      out<<*(s.seq+i*CodonLength+j);
    };
    out<<" ";
  };
  return out;
};

char *comparepos(sequence *s,int pos,int numseq){
  char *a=new char[numseq*CodonLength];
  for(int i=0;i<numseq;i++){
    (s+i)->copypos(pos,a+i*CodonLength);
  };
  return a;
};

void sequence::display() const {
  for(int i=0;i<length*CodonLength;i++){
    cout<<*(seq+i);
  };
};


long double *emppi(sequence *data,int len,int type=0){
  long double *ans=new long double[NumCodons];
  int total=0;
  for(int i=0;i<NumCodons;i++){
    *(ans+i)=0;
  };
  for(int i=0;i<len;i++){
    total+=(data+i)->length;
    for(int j=0;j<(data+i)->length;j++){
      char c=*((data+i)->seq+j);
      switch(c){
      case 'T':
	*ans+=1;
	break;
      case 'C':
	*(ans+1)+=1;
	break;
      case 'A':
	*(ans+2)+=1;
	break;
      case 'G':
	*(ans+3)+=1;
	break;
      default:
	*ans+=0.25;
	*(ans+1)+=0.25;
	*(ans+2)+=0.25;
	*(ans+3)+=0.25;
      };
    };
  };
  for(int i=0;i<NumCodons;i++){
    *(ans+i)/=total;
  };
  return ans;
};
