/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#if NumCodons==4

void inline putcodon(int c,long double *down){
  if(c<4){
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i==c)?1:0;
    };
  }else{
    for(int i=0;i<NumCodons;i++){
      *(down+i)=1;
    };
  };
};

#else

void inline putcodon(int c,long double *down){
  if(c<61){
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i==c)?1:0;
    };
  }else if(c<125){//second nucleotide unknown
    c-=61;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/4==c)?1:0;
    };
  }else if(c<189){//first Nucleotide unknown
    c-=125;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%4==c%4)&&(i/16==c/16))?1:0;
    };
  }else if(c<253){//first two Nucleotides unknown
    c-=189;
    c/=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/16==c)?1:0;
    };
  }else if(c<317){//Third nucleotide unknown
    c-=253;      
    c%=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%16==c)?1:0;
    };
  }else if(c<381){//Third and second nucleotides unknown
    c-=317;
    c%=16;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%16)/4==c)?1:0;
    };
  }else if(c<445){//Third and second nucleotides unknown
    c-=381;
    c%=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%4==c)?1:0;
    };
  }else{//all unknown
    for(int i=0;i<NumCodons;i++){
      *(down+i)=1;
    };
  };
};

#endif
