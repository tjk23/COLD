/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */


//           Routines for printing structures and debugging.


#include <iostream>
#include <math.h>

#include "Tree.h"
#include "Sequence.h"
#include "Parameters.h"
//#include "Matrix.h"
#include "MixTreeLikelihood.h"

using namespace std;

void Mixture::print(){
  for(int i=0;i<params::numpars;i++){
    for(int j=0;j<num;j++){
      int pr=-1;
      int pn=-1;
      for(int *p=pars;*p;p++){
	if(*p>0){
	  pn++;
	};
	if(*p==j*params::numpars+i){
	  pr=pn;
	}else if(*p==-j*params::numpars-i){
	  pr=pn;
	};
      };
      cout<<pr<<"\t";
    };
    cout<<"\n";
  };
  for(unsigned int i=0;i<numconstraints;i++){
    cout<<(cst+i)->prnt()<<"\n";
  };
};


void tree::printlists(int level,int start,int u,int st,int ed) const{
  //Mostly for debugging.
  cout<<"tree number "<<start<<" at level"<<level<<":\n\n";
  cout<<*this<<"\n\n";
  cout<<"down lists:\n\n";
  for(int i=0;i<NumCodons;i++){
    cout<<*(down+i)<<"  ";
  };
  cout<<"\n\n";
  if(ed==0){
    ed=this->edges();
  };
  if(u){
    cout<<"up lists:\n\n";
    for(int i=0;i<NumCodons;i++){
      cout<<*(up+i)<<"  ";
    };
    cout<<"\n\n";
  };
  cout<<"extra lists:\n\n";
  for(int j=0;j<params::numpars;j++){
    for(int i=0;i<NumCodons;i++){
      cout<<*(extra+j*NumCodons+i)<<"  ";
    };
    cout<<"\n\n";
  };
  cout<<"Numbers "<<st<<" to "<<st+this->edges()-1<<":\n\n";
  for(int j=st;j<st+this->edges();j++){
    for(int i=0;i<NumCodons;i++){
      cout<<*(extra+(params::numpars+j)*NumCodons+i)<<"  ";
    };
    cout<<"\n\n";
  };
  cout<<"\n\n";
  int e=0;
  for(int i=0;i<n;i++){
    (subtree+i)->printlists(level+1,i,1,st+e+1,ed);
    e+=(subtree+i)->edges()+1;
  };
};


void tree::debugneg(long double val,ostream& out,int siteno,int l){
  //Called when the likelihood function for the current site would
  //give a non-positive number. It attempts to determine the cause
  //and tries to determine where the problem occurs.
  if(l==0){//Root node
    out<<*this<<"\n\n";
    out<<"Likelihood function for ";
    if(siteno==-1){
      out<<"unknown site";
    }else{
      out<<"site number "<<siteno+1;
    };
    out<<" gives invalid value: "<<val<<".\n";
  };
  int problem=0;//all values zero.
  for(int i=0;i<NumCodons;i++){
    if(*(down+i)<0){//Oh dear!
      problem=1;
      break;
    };
    if(*(down+i)>0){
      problem=2;
    };
  };
  switch(problem){
  case 0://All values zero. Almost certainly caused by underflow.
    out<<"Probable Underflow.\n";
    break;
  case 1://Some negative values. Possibly caused by rounding errors?
    out<<"Negative values encountered:\nCodon\tvalue\n";
    for(int i=0;i<NumCodons;i++){
      if(*(down+i)<0){
	out<<i<<"\t"<<*(down+i)<<"\n";
      };
    };
    out<<"\n";
    break;
  case 2://Good values. Problem must be caused by underflow when
	 //multiplying by pi.
    out<<"Values in likelihood list seem valid. Problem most likely caused by errors in the Q-Matrix.\n";
    out<<"Values:\n";
    for(int i=0;i<NumCodons;i++){
      out<<*(down+i)<<"\t";
    };
    out<<"\n\n";
    return;
  };
  problem=0;
  for(int i=0;i<n;i++){//test subtrees for root of problem.
    int prob=0;
    for(int j=0;j<NumCodons;j++){
      if(*((subtree+i)->down2+j)<0){//Oh dear!
	prob=1;
	break;
      };
      if(*((subtree+i)->down2+j)>0){
	prob=2;
      };
    };
    if(prob!=2){//problem in this subtree.
      out<<"Problem comes from subtree number "<<i<<" at level "<<l+1<<".\n";
      for(int j=0;j<NumCodons;j++){
	cout<<*((subtree+i)->down2+j)<<"\t";
      };
      cout<<"\n";
      //      (subtree+i)->debugneg(val,out,siteno,l+1);
      problem=prob;
    };
  };
  if(problem==0&&n>0){//all subtrees OK
    out<<"All subtrees seem OK. Probable underflow in combining them.\n";
  };
  if(n==0){//Problem assigning codon likelihoods
    out<<"Data corrupted. Likelihood list at leaf:\n";
    for(int i=0;i<NumCodons;i++){
      out<<*(down+i)<<"\t";
    };
    out<<"\n\n";
  };
};

ostream &operator <<(ostream &o,const tree &T){
  if(T.n==0){
    o<<T.label;
    return o;
  };
  o<<'(';
  for(int i=0;i<T.n;i++){
    o<<*(T.subtree+i);
    o<<':'<<*(T.length+i);
    if(i<T.n-1){
      o<<',';
    };
  };
  o<<')';
  if(T.up==NULL){
    o<<";";
  };
  return o;
};


void tree::printdata(ostream& out, sequence* d) const{
  if(n==0){
    out<<*d<<"\n";
  }else{
    int pos=0;
    for(int i=0;i<n;i++){
      (subtree+i)->printdata(out,d+pos);
      pos+=(subtree+i)->leaves();
    };
  };
};

void tree::printspecies(ostream& out,int* no) const{
  if(n==0){
    if(*no){
      out<<"\""<<label<<"\"\n";
    };
  }else{
    for(int i=0;i<n;i++){
      (subtree+i)->printspecies(out,no);
      no+=(subtree+i)->leaves();
    };
  };
};


//Output Routines

void tree::print(ostream& out) const{
  if(n==0){
    //    out<<"\""<<label<<"\"";
    out<<label;
    return;
  };
  out<<'(';
  for(int i=0;i<n;i++){
    (subtree+i)->print(out);
    out<<':'<<*(length+i);
    if(i<n-1){
      out<<',';
    };
  };
  out<<')';
  if(up==NULL){
    out<<";";
  };
};

void tree::print(long double *bl,ostream& out) const{
  if(n==0){
    out<<label;
    return;
  };
  out<<'(';
  for(int i=0;i<n;i++){
    (subtree+i)->print(bl+1,out);
    out<<':'<<*bl;
    if(i<n-1){
      out<<',';
      bl+=(subtree+i)->numed+1;
    };
  };
  out<<')';
  if(up==NULL){
    out<<";";
  };
};

void Mixtreelikelihood::printall(ostream &out,int *valpars){
  //prints all coefficients, even fixed ones.
  //  T.print(out);
  T.up=NULL;
  out<<T;
  out<<"\n\n";
  long double *x=new long double[dim];
  this->getx(x);
  m.showdistpars(out,x+T.numed+varprobs);
  delete[] x;
  long double tp=0;
  for(int i=0;i<num-1;i++){
    tp+=*(prob+i)+1;
  };
  tp=1/(tp+1);
  if(params::numpars>0){
    for(int i=0;i<num-1;i++){
      out<<"Site class "<<i<<" probability="<<(*(prob+i)+1)*tp<<":\n\n";
      out<<"Parameter";
      out.width(25);
      out<<"Coefficient";
      out.width(40);
      out<<"Exponential of Coefficient\n\n";
      long double *tc=(p+i)->truepars();
      for(int j=0;j<params::numpars;j++){
	out.width(5);
	out<<j;
	out.width(29);
	out<<*(tc+j);
	out.width(30);
	out<<exp(*(tc+j))<<"\n";
      };
      out<<"\n\n";
      delete[] tc;
    };
    out<<"Site class "<<num-1<<" probability="<<tp<<":\n\n";
    out<<"Parameter";
    out.width(25);
    out<<"Coefficient";
    out.width(40);
    out<<"Exponential of Coefficient\n\n";
    long double *tc=(p+num-1)->truepars();
    for(int j=0;j<params::numpars;j++){
      out.width(5);
      out<<j;
      out.width(29);
      out<<*(tc+j);
      out.width(30);
      out<<exp(*(tc+j))<<"\n";
    };
    delete[] tc;
    out<<"\n\n";
  };
  //  delete[] x;
};

/*
void displayMat(long double *ent, int sz){
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      cout<<(ZERO(*(ent+i*sz+j))?0:*(ent+i*sz+j))<<' ';
    };
    cout<<'\n';
    if(DBLSPACE){
      cout<<'\n';
    };
  };
};


ostream &operator <<(ostream &o,const Factmatrix &F){
  for(int i=0;i<F.sz;i++){
    for(int j=0;j<F.sz;j++){
      o<<*(F.gamma.entries+i*F.sz+j)<<' ';
    };
    o<<"\t";
    for(int j=0;j<F.sz;j++){
      o<<(i==j?*(F.D.entries+i):0)<<' ';
    };
    o<<"\t";
    for(int j=0;j<F.sz;j++){
      o<<*(F.gammainv.entries+i*F.sz+j)<<' ';
    };
    o<<"\n";
  };
  return o;
};

*/
/*
ostream &operator <<(ostream &o,const Realmatrix &R){
  for(int i=0;i<R.sz;i++){
    for(int j=0;j<R.sz;j++){
      o<<(ZEROM(*(R.entries+i*R.sz+j))?0:*(R.entries+i*R.sz+j))<<' ';
    };
    o<<'\n';
    if(DBLSPACE){
      o<<'\n';
    };
  };
  return (o);
};

void Realmatrix::display() const {
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      cout<<(ZERO(*(entries+i*sz+j))?0:*(entries+i*sz+j))<<' ';
    };
    cout<<'\n';
  };
};

void Factmatrix::display() const {
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      cout<<*(gamma.entries+i*sz+j)<<' ';
    };
    cout<<"\t";
    for(int j=0;j<sz;j++){
      cout<<(i==j?*(D.entries+i):0)<<' ';
    };
    cout<<"\t";
    for(int j=0;j<sz;j++){
      cout<<*(gammainv.entries+i*sz+j)<<' ';
    };
    cout<<"\n";
  };
};

void multQRtrisym(long double *HT,long double *R,int n,long double *prod){
  //Tests a QR factorisation. Mostly for debugging purposes
  long double z=0;
  long double a=*R;
  long double b=*(R+1);
  long double c=*(R+2);
  for(int i=0;i<n-2;i++){
    long double mod=sqrt(1+*(HT+n-2-i)*(*(HT+n-2-i)));
    long double v1=1/mod;
    long double v2=*(HT+n-2-i)/mod;    
    long double m11=(1-2*v1*v1);
    long double m12=(-2*v1*v2);
    long double m22=(1-2*v2*v2);
    if(i>0){
      if(NONZEROST(z*m11-*(prod+n+i-1))){
	cout<<"Assymmetry fault.\nz*m11="<<z*m11<<"\t*(prod+"<<n+i-1<<")="<<*(prod+n+i-1)<<"\n\n";
      };
    };
    *(prod+i)=m11*a;
    *(prod+i+n)=m11*b+m12*(*(R+3*i+3));
    if(NONZEROST(m11*c+m12*(*(R+3*i+4)))){
      cout<<"Nonzero fault.\ni="<<i<<"\tentry ="<<m11*c+m12*(*(R+3*i+4))<<"\n\n";
    };
    z=m12*a;
    a=m12*b+m22*(*(R+3*i+3));
    b=m12*c+m22*(*(R+3*i+4));
    c=m22*(*(R+3*i+5));
  };
  long double mod=sqrt(1+*(HT+n-2)*(*(HT+n-2)));
  long double v1=1/mod;
  long double v2=*(HT+n-2)/mod;    
  long double m11=(1-2*v1*v1);
  long double m12=(-2*v1*v2);
  long double m22=(1-2*v2*v2);
  if(NONZEROST(z*m11-*(prod+2*n-3))){
    cout<<"Assymmetry fault.\nz*m11="<<z*m11<<"\t*(prod+"<<2*n-3<<")="<<*(prod+2*n-3)<<"\n\n";
  };
  *(prod+n-2)=m11*a;
  *(prod+2*n-2)=m11*b+m12*(*(R+3*n-4));
  if(NONZEROST(m12*a-*(prod+2*n-2))){
    cout<<"Assymmetry fault.\nz="<<m12*a<<"\t*(prod+"<<2*n-2<<")="<<*(prod+2*n-2)<<"\n\n";
  };
  *(prod+n-1)=m12*b+m22*(*(R+3*n-4));
};

Realmatrix testtrisym(Realmatrix Q,long double *v1,long double *v2){
  //Multiplies a tridiagonal factorisation, to test that it is correct.
  Realmatrix ans(Q.sz);
  for(int i=0;i<Q.sz;i++){
    for(int j=0;j<Q.sz;j++){
      *(ans.entries+i*Q.sz+j)=*(Q.entries+i*Q.sz+j)*(*(v1+j));
      if(j>0){
	*(ans.entries+i*Q.sz+j)+=(*(Q.entries+i*Q.sz+j-1)*(*(v2+j-1)));
      };
      if(j<Q.sz-1){
	*(ans.entries+i*Q.sz+j)+=(*(Q.entries+i*Q.sz+j+1)*(*(v2+j)));
      };
    };
  };
  RealmatrixT QT=Q.transpose();
  Realmatrix QTM(QT);
  ans.mult(QTM);
  return ans;
};


void Realmatrix::testdiagfact(long double *v) const {
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      long double val=0;
      for(int k=0;k<sz;k++){
	val+=*(entries+i*sz+k)*(*(entries+j*sz+k))*(*(v+k));
      };
      cout<<((ZEROM(val))?0:val)<<"  ";
    };
    cout<<"\n";
  };
};

*/
