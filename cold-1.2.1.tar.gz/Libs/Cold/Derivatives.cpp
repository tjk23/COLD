/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */


//Functions for differentiating with respect to parameters. Kept in a
//separate file for easier modification.

inline long double params::X(int i,int j,int k){
  //Returns the parameter matrices. The logarithm of the R matrix is
  //expressed as a linear combination of some fixed X matrices. This
  //function retrieves the values of the X matrices.
  /*  if(isnan(*((XX+k)->entries+i*NumCodons+j))){
    cout<<"*(XX["<<k<<"].entries+"<<i<<"*"<<NumCodons<<"+"<<j<<")=NaN\n";
    exit(1);
    };*/
  return *((XX+k)->entries+i*NumCodons+j);
};

RealmatrixT params::dR(int k) const {
  Realmatrix ans(NumCodons);
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(ans.entries+i*NumCodons+j)=X(i,j,k)*(*(R.entries+i*NumCodons+j));
    };
    long double d=0;
    for(int j=0;j<NumCodons;j++){
      if(j!=i){
	d-=*(pi+j)*(*(ans.entries+i*NumCodons+j));
      };
    };
    *(ans.entries+i*(NumCodons+1))=d/(*(pi+i));
  };
  return ans;
};

RealmatrixT params::d2R(int k,int l) const {
  Realmatrix ans(NumCodons);
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(ans.entries+i*NumCodons+j)=X(i,j,k)*X(i,j,l)*(*(R.entries+i*NumCodons+j));
    };
    long double d=0;
    for(int j=0;j<NumCodons;j++){
      if(j!=i){
	d-=*(pi+j)*(*(ans.entries+i*NumCodons+j));
      };
    };
    *(ans.entries+i*(NumCodons+1))=d/(*(pi+i));
  };
  return ans;
};

void params::calculate_derivs(const Factmatrix& f){//Should perhaps try to fix faster version.
  /* 

     d(d_ij)/d(b_k)=sum_{l,m}( c_il (c_jm-c_jl) X_lmk R_lm )

   */
  for(int k=0;k<numpars;k++){
    Realmatrix dr=dR(k);
    for(int i=0;i<NumCodons;i++){
      for(int j=0;j<NumCodons;j++){
	*((derivs+k)->entries+i*NumCodons+j)=*(f.gammainv.entries+i*NumCodons+j);
      };
    };
    (derivs+k)->mult(dr);
    for(int i=0;i<NumCodons;i++){
      for(int j=0;j<NumCodons;j++){
	*((derivs+k)->entries+i*NumCodons+j)*=*(pi+j);    
      };
    };
    (derivs+k)->mult(f.gamma);
    for(int l=k;l<numpars;l++){
      Realmatrix d2r=d2R(l,k);
      int kl=numpars+tri(k,l);
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  *((derivs+kl)->entries+i*NumCodons+j)=*(f.gammainv.entries+i*NumCodons+j);
	};
      };
      (derivs+kl)->mult(d2r);
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  *((derivs+kl)->entries+i*NumCodons+j)*=*(pi+j);    
	};
      };
      (derivs+kl)->mult(f.gamma);
    };
  };
};


const Realmatrix& params::dD(int k) const{
  //Differentiates with respect to parameter number k. f gives the
  //diagonalised matrix, precalculated to save time. May be more
  //efficient to include it in the params class. This may simply
  //lookup the true value if it has already been calculated.  
  return *(derivs+k);//look up answer. 
};

const Realmatrix& params::d2D(int j,int k) const{
  //Differentiates twice with respect to parameter numbers j and k. f
  //gives the diagonalised matrix, precalculated to save time. May be
  //more efficient to include it in the params class.
  //  int s=(j<k)?j:k;
  //  int l=(j<k)?k:j;
  return *(derivs+numpars+tri(j,k));
};

const Realmatrix *params::Derivmats() const{
  return derivs;
};

