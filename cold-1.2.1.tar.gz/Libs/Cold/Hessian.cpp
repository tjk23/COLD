/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Routines used for calculating the hessian of the likelihood. */

class tree;
class Realmatrix;
class Factmatrix;
class sequence;
class params;
class precalc;
class mspace;


void sitehess(tree &t,const Factmatrix& f,const sequence *data,const params& p,int i,long double *siteliks,const precalc &x,mspace &mem);

void makematrices(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4);

long double *stBInf(tree &T,const long double *ex,const Realmatrix *DQ,const Factmatrix &f,const Realmatrix *lp,const params &p);

extern "C"{
  void (*sthss)(tree &t,const Factmatrix& f,const sequence *data,const params& p,int i,long double *siteliks,const precalc &x,mspace &mem)=sitehess;

  void (*mkmtrcs)(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4)=makematrices;

  long double *(*sbi)(tree &T,const long double *ex,const Realmatrix *DQ,const Factmatrix &f,const Realmatrix *lp,const params &p)=stBInf;
}

#include "Tree.h"
#include "Matrix.h"
#include "Parameters.h"
#include "Likelihood.h"
#include <iostream>
#include <stddef.h>

#include "DefineNumCodons.h"
//#define NumCodons 61
#define NumCodonsSq (NumCodons*NumCodons)

using namespace std;

double log(long double x,void* onerror=NULL);

class precalc{//stores all the precalculated data.
public:
  int e;
  int l;
  long double **mats;
  const Realmatrix *dD;
  const Factmatrix *ff;
  long double *ex;
  long double *le;
  long double *FIJ;
  int *part;
  long double *coeffs;
  precalc(){e=0;l=0;mats=NULL;dD=NULL;ex=NULL;le=NULL;FIJ=NULL;part=NULL;coeffs=NULL;ff=NULL;};
  precalc(const tree &t,const Factmatrix& f,const sequence *data,const params& p);
  void calc(const tree &t,const Factmatrix& f,const sequence *data,const params& p);
  ~precalc();
};

class mspace{
public:
  long double *coeffsums;
  long double *coeffsums2;
  long double *coeffsums3;
  long double *coeffsums4;
  long double *coeffsums5;
  long double *lsq;
  long double *T;
  long double *U;
  mspace(int e){coeffsums=new long double[NumCodonsSq];coeffsums2=new long double[NumCodonsSq];coeffsums3=new long double[NumCodonsSq];coeffsums4=new long double[NumCodonsSq];coeffsums5=new long double[NumCodonsSq];lsq=new long double[NumCodons];T=new long double[e*params::numpars*NumCodons];U=new long double[e*params::numpars*NumCodons];};
  ~mspace(){delete[] coeffsums;delete[] coeffsums2;delete[] coeffsums3;delete[] coeffsums4;delete[] coeffsums5;delete[] lsq;delete[] T;delete[] U;};
};


//void accumulate(const long double *siteliks,long double *ans,int e,int l,void *dbn=NULL);

//extern "C"{
void sitehess(tree &t,const Factmatrix& f,const sequence *data,const params& p,int i,long double *siteliks,const precalc &x,mspace &mem){
  t.sitehess(f,data,p,i,siteliks,x,mem);
};
//}

void tree::sitehess(const Factmatrix& f,const sequence *data,const params& p,int i,long double *siteliks,const precalc &x,mspace &mem){
  //Calculates the hessian for the loglikelihood on the chosen site, i. 
  this->liklistdown(f,data,i,x.ex);
  this->liklistup(p,f,x.ex,NULL);
  //Start with likelihood
  *(siteliks)=0;
  for(int j=0;j<NumCodons;j++){
    *(siteliks)+=*(p.pi+j)*(*(down+j));
  };
  for(int j=1+x.e;j<x.l;j++){
    *(siteliks+j)=0;
  };
  this->liklistextra(f,p,x.ex,x.coeffs,x.dD,mem.T,mem.U);

    //Actually, the following few lines should be able to be run once for all parameters, saving time.
  long double *upvals=new long double[x.e*NumCodons]; 
  long double *downvals=new long double[x.e*NumCodons]; 
  /*    const long double **tmp=this->getuplists();
	f.gamma.MultiTranspActProd(e,tmp,p.pi,upvals);//Actually, these can be replaced.
	delete[] tmp;
	tmp=this->getdownlists();
    f.gammainv.MultiAct(e,tmp,downvals);
    delete[] tmp;  */
  this->getallup2lists(upvals);
  this->getalldown3lists(downvals);
  for(int j=0;j<NumCodons;j++){
    for(int k=0;k<NumCodons;k++){
      *(mem.coeffsums+j*NumCodons+k)=0;
      *(mem.coeffsums2+j*NumCodons+k)=0;
      *(mem.coeffsums3+j*NumCodons+k)=0;
      *(mem.coeffsums4+j*NumCodons+k)=0;
      *(mem.coeffsums5+j*NumCodons+k)=0;
    };
    *(mem.lsq+j)=0;
  };
  for(int ed=0;ed<x.e;ed++){	
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){//These loops take up about 5% total time
	long double w=(*(upvals+ed*NumCodons+j))*(*(downvals+ed*NumCodons+k));
	*(mem.coeffsums+j*NumCodons+k)+=*(x.coeffs+ed*NumCodonsSq+j*NumCodons+k)*w;
	long double t=(*(x.ex+ed*NumCodons+j))*w;
	*(mem.coeffsums2+j*NumCodons+k)+=t;
	*(mem.coeffsums3+j*NumCodons+k)+=t*(*(x.le+ed));
	long double u=(*(x.ex+ed*NumCodons+k))*w;
	*(mem.coeffsums4+j*NumCodons+k)+=u;
	*(mem.coeffsums5+j*NumCodons+k)+=u*(*(x.le+ed));
	if(*(x.part+j)==*(x.part+k)){
	  *(mem.lsq+j)+=*(x.le+ed)*(*(x.le+ed))*(*(x.ex+ed*NumCodons+j))*w;
	};
      };
    };
  };
  //Up to here, this can all be precalculated.
  long double *jj=siteliks+1+x.e+params::numpars;
  for(int j=0;j<x.e;j++){
    //Second derivative with respect to branch j
    long double len=*(x.le+j);
    const tree *curr=this->findedge(j,len);
    *(jj++)=d2liketact(f,curr->up2,curr->down3,len,p,x.ex+j*NumCodons);
    this->secderbl(j,p,f,x.ex,jj,x.e,0);
    for(int k=0;k<params::numpars;k++){
      //Derivative with respect to branch j and parameter k
      *(jj++)=this->secderblp(j,k,p,f,x.ex,*(x.dD+k),0,upvals,x.coeffs);
    };
  };
  long double *acc=siteliks+1+x.e+params::numpars+x.e*params::numpars+x.e*(x.e+1)/2;
  int ii=0;
  for(int j=0;j<params::numpars;j++){
    for(int k=j;k<params::numpars;k++){
      const long double *ext=x.ex;
      const long double *cfs=x.coeffs;
      *(acc+ii)=this->secder(j,k,p,f,0,*(x.dD+j),*(x.dD+k),ext,cfs);
      *(acc+ii)+=this->sdsame(j,k,f,p,*(x.dD+j),*(x.dD+k),p.d2D(j,k),*(x.mats+4*ii),*(x.mats+4*ii+1),*(x.mats+4*ii+2),*(x.mats+4*ii+3),x.part,upvals,downvals,x.ex,x.le,x.FIJ,x.coeffs,mem.coeffsums2,mem.coeffsums3,mem.coeffsums4,mem.coeffsums5,mem.lsq,mem.T,mem.U);
      long double *ent=p.d2D(j,k).entries;
      for(int jj=0;jj<NumCodonsSq;jj++){
	*(acc+ii)+=*(ent+jj)*(*(mem.coeffsums+jj));
      };
      ii++;
    };
  };//Need to take derivatives with respect to branch lengths.
  for(int j=0;j<x.e;j++){//for each edge
    long double len;
    this->findedge(j,len);
    *(siteliks+j+1)=dliketact2(f,upvals+j*NumCodons,downvals+j*NumCodons,len,p,x.ex+j*NumCodons);
  };
  delete[] upvals;
  delete[] downvals;
  for(int k=0;k<params::numpars;k++){
      //Calculate first derivatives with respect to parameters.
    long double *lks=new long double[NumCodons];
    for(int kk=0;kk<NumCodons;kk++){
      *(lks+kk)=0;
    };
    for(int kk=0;kk<NumCodons;kk++){
      for(int ii=0;ii<n;ii++){
	long double th=1;	  
	for(int jj=0;jj<n;jj++){
	  if(jj==ii){	      
	    th*=*((subtree+ii)->extra+k*NumCodons+kk);
	  }else{
	    th*=*((subtree+jj)->down2+kk);
	  };
	};
	*(lks+kk)+=th;
      };
    };
    for(int kk=0;kk<NumCodons;kk++){
      *(siteliks+1+x.e+k)+=*(lks+kk)*(*(p.pi+kk));
    };
    delete[] lks;
  };
};



long double tree::secder(int i,int j,const params& p,const Factmatrix& f,long double ul,const Realmatrix &M,const Realmatrix &N,const long double *&ex,const long double *&coeffs) const {
  //Calculates part of the second derivative with respect to
  //parameters i and j. Doesn't calculate for the case where they
  //occur on the same edge.
  //int e=offset;
  long double t=0;
  long double *ui=new long double[NumCodons];
  for(int k=0;k<NumCodons;k++){
    *(ui+k)=0;
  };
  for(int k=0;k<n;k++){
    for(int l=0;l<n;l++){//For each pair of subtrees
      if(k!=l){
	for(int m=0;m<NumCodons;m++){
	  long double q=1;
	  for(int u=0;u<n;u++){
	    if(u==l){
	      q*=*((subtree+l)->extra+j*NumCodons+m);
	    }else if(u==k){
	      q*=*((subtree+k)->extra+i*NumCodons+m);
	    }else{
	      q*=*((subtree+u)->down2+m);
	    };
	  };
	  if(up==NULL){
	    t+=*(p.pi+m)*q;
	  }else{
	    *(ui+m)+=q;
	  };
	};
      };
    };
  };
  if(up!=NULL){
    if(n>0){
      for(int ii=0;ii<NumCodons;ii++){
	t+=*(up3+ii)*(*(ui+ii))*(*(p.pi+ii));
	t+=*(extra3+i*NumCodons+ii)*(*(extra2+j*NumCodons+ii));
	t+=*(extra3+j*NumCodons+ii)*(*(extra2+i*NumCodons+ii));
      };
      //	      t+=Likelihoodactval(f,up2,ui,ul,ex);
      //      t+=dlikeqact2(up2,extra2+j*NumCodons,M,coeffs);
      //      t+=dlikeqact2(up2,extra2+i*NumCodons,N,coeffs);
    };
    ex+=NumCodons;
    coeffs+=NumCodonsSq;
  };
  for(int k=0;k<n;k++){
    t+=(subtree+k)->secder(i,j,p,f,*(length+k),M,N,ex,coeffs);
  };
  delete[] ui;
  return t;
};

void makematrices(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4){
  /* 

     mat_ik=sum_j(M_ijN_jkA_ijA_ik)
     mat2_ik=sum_j(M_ijN_jkA_jkA_ik)
     mat3_ik=sum_j(M_ijN_jk)

   */
  for(int i=0;i<NumCodonsSq;i++){
    *(mat+i)=0;
    *(mat2+i)=0;
    *(mat3+i)=0;
    *(mat4+i)=0;
  };
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<NumCodons;k++){
      for(int j=0;j<NumCodons;j++){
#define M_ij (*(M.entries+i*NumCodons+j))
#define M_jk (*(M.entries+j*NumCodons+k))
#define N_ij (*(N.entries+i*NumCodons+j))
#define N_jk (*(N.entries+j*NumCodons+k))
	long double t=M_ij*N_jk+N_ij*M_jk;
	if(*(part+i)!=*(part+j)&&*(part+j)!=*(part+k)&&*(part+i)!=*(part+k)){
	  *(mat+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+j)));
	  *(mat2+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+j)-*(d+k)));
	}else if(*(part+i)==*(part+j)&&*(part+j)!=*(part+k)){
	  *(mat+i*NumCodons+k)-=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+k)));
	  *(mat2+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+j)-*(d+k)));
	  *(mat3+i*NumCodons+k)+=t/(*(d+i)-*(d+k));
	}else if(*(part+i)!=*(part+j)&&*(part+j)==*(part+k)){
	  *(mat2+i*NumCodons+k)-=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+k)));
	  *(mat+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+j)));
	  *(mat4+i*NumCodons+k)+=t/(*(d+k)-*(d+i));
	}else if(*(part+i)==*(part+k)&&*(part+j)!=*(part+k)){
	  *(mat+i*NumCodons+k)-=t/((*(d+i)-*(d+j))*(*(d+i)-*(d+j)));
	  *(mat3+i*NumCodons+k)+=t/(*(d+i)-*(d+j));
	}else if(*(part+i)==*(part+j)&&*(part+j)==*(part+k)){
	  *(mat4+i*NumCodons+k)+=t/2;
	};
      };
    };
  };
};

#define M_ji (*(M.entries+j*NumCodons+i))
#define N_ji (*(N.entries+j*NumCodons+i))


long double tree::sdsame(int ii,int jj,const Factmatrix& f, const params &p,const Realmatrix& M,const Realmatrix& N,const Realmatrix& O,const long double *mat,const long double *mat2,const long double *mat3,const long double *mat4,const int* part,const long double* upvals,const long double* downvals,const long double* ex,const long double *l,const long double *FIJ,const long double *coeffs,const long double *coeffs2,const long double *coeffs3,const long double *coeffs4,const long double *coeffs5,const long double *lsq,const long double *T,const long double *U)const throw(){
  //Adds up the second derivatives with respect to parameters i and j
  //in the case where they are applied to the same branch.  Uses a
  //single computation of the relevant matrix, thereby reducing the
  //number of operations almost by a factor of NumCodons. There is an
  //alternative method that reduces by a factor of numpars. Therefore,
  //choice of method will depend on the relative sizes of these
  //numbers.

  //coeffs2=sum_ed(v+i)(w+k)e^(l*di)
  //coeffs3=sum_ed(v+i)(w+k)le^(l*di)
  //coeffs4=sum_ed(v+i)(w+k)e^(l*dk)
  //coeffs5=sum_ed(v+i)(w+k)le^(l*dk)
  //lsq=sum_ed l^2e^(l*di)

  int e=this->numed;
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<NumCodons;k++){
      ans+=*(mat+i*NumCodons+k)*(*(coeffs2+i*NumCodons+k));
      ans+=*(mat3+i*NumCodons+k)*(*(coeffs3+i*NumCodons+k));
      ans+=*(mat2+i*NumCodons+k)*(*(coeffs4+i*NumCodons+k));
      if(*(part+i)==*(part+k)){
      	ans+=*(mat4+i*NumCodons+k)*(*(lsq+i));
      }else{
	ans+=*(mat4+i*NumCodons+k)*(*(coeffs5+i*NumCodons+k));
      };
    };
  };
  for(int ed=0;ed<e;ed++){
    for(int i=0;i<NumCodons;i++){      
      ans+=(*(T+ii*e*NumCodons+ed*NumCodons+i)*(*(U+jj*e*NumCodons+ed*NumCodons+i))+*(T+jj*e*NumCodons+ed*NumCodons+i)*(*(U+ii*e*NumCodons+ed*NumCodons+i)))*(*(ex+ed*NumCodons+i));
    };
  };
  return ans;
};

long double tree::secderbl(int i,int j,const params& p,const Factmatrix& f,const long double *ex,long double ul,int offset){
  /* 
     Calculates the second derivative of the likelihood with respect
     to the lengths of branches i and j. i should always be less than
     j.
  */
  int e=offset;
  if(up!=NULL){//upward branch
    if(i==0){//one branch above another
      long double *x=new long double[NumCodons];
      e++;
      j--;
      for(int k=0;k<NumCodons;k++){
	*(x+k)=1;
      };
      long double ans=dliketact2(f,up2,extra2+(params::numpars+j+e)*NumCodons,ul,p,ex+offset*NumCodons);
      delete[] x;
      return ans;      
    }else{
      i--;
      j--;
      e++;
    };
  };
  int st1=-1;
  int st2=-1;
  for(int k=0;k<n;k++){
    int ed=(subtree+k)->numed+1;
    if(st1==-1){
      if(i<ed){
	if(j<ed){//both in subtree k
	  return (subtree+k)->secderbl(i,j,p,f,ex,*(length+k),e);
	}else{//
	  st1=k;
	  i+=e;
	};
      }else{
	i-=ed;
      };
    }else{
      if(j<ed){
	st2=k;
	j+=e;
	break;
      };
    };
    j-=ed;
    e+=ed;
  };
  long double ans=0;
  if(up==NULL){//root of tree
    for(int k=0;k<NumCodons;k++){
      long double prod=1;
      for(int l=0;l<n;l++){
	if(l==st1){
	  prod*=*((subtree+l)->extra+(params::numpars+i)*NumCodons+k);
	}else if(l==st2){
	  prod*=*((subtree+l)->extra+(params::numpars+j)*NumCodons+k);
	}else{
	  prod*=*((subtree+l)->down2+k);
	};
      };
      ans+=prod*(*(p.pi+k));
    };
  }else{
    long double *x=new long double[NumCodons];
    for(int k=0;k<NumCodons;k++){
      *(x+k)=1;
      for(int l=0;l<n;l++){
	if(l==st1){
	  *(x+k)*=*((subtree+l)->extra+(params::numpars+i)*NumCodons+k);
	}else if(l==st2){
	  *(x+k)*=*((subtree+l)->extra+(params::numpars+j)*NumCodons+k);
	}else{
	  *(x+k)*=*((subtree+l)->down2+k);
	};
      };
    };    
    for(int k=0;k<NumCodons;k++){
      ans+=*(up3+k)*(*(x+k))*(*(p.pi+k));
    };
    delete[] x;
  };
  return ans;
};

void tree::secderbl(int i,const params& p,const Factmatrix& f,const long double *ex,long double *&output,int edg,long double ul,int offset){
  /* 
     Calculates the second derivative of the likelihood with respect
     to the lengths of branch i and all later branches. 
  */
  int e=offset;
  if(up!=NULL){//upward branch
    if(i==0){//This branch
      e++;
      for(int j=0;j<numed;j++){
	*(output++)=dliketact2(f,up2,extra2+(params::numpars+j+e)*NumCodons,ul,p,ex+offset*NumCodons);
      };
      return;
    }else{
      i--;
      e++;
    };
  };
  int st1=1;
  long double *x=new long double[NumCodons];
  long double *y=new long double[NumCodons];
  for(int k=0;k<NumCodons;k++){
    *(x+k)=*(p.pi+k);
  };
  for(int k=0;k<n;k++){    
    int ed=(subtree+k)->numed+1;
    if(st1){//still searching for first edge.
      if(i<ed){
	(subtree+k)->secderbl(i,p,f,ex,output,ed,*(length+k),e);
	st1=0;
	for(int l=0;l<NumCodons;l++){
	  *(x+l)*=*((subtree+k)->extra+(params::numpars+i+e)*NumCodons+l);
	};
	e+=ed;
      }else{
	i-=ed;
	e+=ed;
	for(int l=0;l<NumCodons;l++){
	  *(x+l)*=*((subtree+k)->down2+l);
	};
      };
    }else{
      for(int l=0;l<NumCodons;l++){
	*(y+l)=*(x+l);
      };
      for(int m=k+1;m<n;m++){
	for(int l=0;l<NumCodons;l++){
	  *(y+l)*=*((subtree+m)->down2+l);
	};
      };
      for(int l=0;l<NumCodons;l++){
	*(x+l)*=*((subtree+k)->down2+l);
      };
      if(up==NULL){
	for(int j=0;j<ed;j++){
	  *output=0;
	  for(int l=0;l<NumCodons;l++){
	    *output+=*(y+l)*(*((subtree+k)->extra+(params::numpars+j+e)*NumCodons+l));
	  };
	  //	  if(*output<0){cout<<"";};
	  output++;
	};
      }else{
	for(int j=0;j<ed;j++){
	  *output=0;
	  for(int l=0;l<NumCodons;l++){
	    *output+=*(y+l)*(*((subtree+k)->extra+(params::numpars+j+e)*NumCodons+l))*(*(up3+l));
	  };
	  //	  if(*output<0){cout<<"";};
	  output++;
	};
      };
      e+=ed;
    };
  };
  delete[] x;
  delete[] y;
};


long double tree::secderblp(int i,int j,const params& p,const Factmatrix& f,const long double *ex,const Realmatrix& M,long double ul,const long double *upvals,const long double *coeffs,int offset){
  /* 
     Calculates the second derivative of the likelihood with respect
     to the length of branch i and to parameter j, whose derivative
     matrix is given by M.
  */

  int e=offset;
  const long double *ext=ex+offset*NumCodons;
  if(up!=NULL){
    if(i==0){
      long double ans=dliketact2(f,up2,extra2+j*NumCodons,ul,p,ext);
      ans+=d2liketqact(f,up2,down3,ul,p,j,ext);
      return ans;
    }else{
      i--;
      e++;
    };
  };
  int str=-1;
  for(int k=0;k<n;k++){
    int ed=(subtree+k)->numed+1;
    if(i<ed){
      str=k;
      break;
    }else{
      i-=ed;
      e+=ed;
    };
  };
  long double ans=0;
  long double* x=new long double[NumCodons];
  for(int ii=0;ii<NumCodons;ii++){
    *(x+ii)=0;
  };
  for(int k=0;k<n;k++){//For each edge where Q derivative might happen ...
    if(k==str){
      ans+=(subtree+k)->secderblp(i,j,p,f,ex,M,*(length+k),upvals,coeffs,e);
    }else{
      for(int l=0;l<NumCodons;l++){
	long double xx=1;
	for(int kk=0;kk<n;kk++){
	  if(kk==str){
	    xx*=*((subtree+kk)->extra+(params::numpars+i+e)*NumCodons+l);
	  }else if(kk==k){
	    xx*=*((subtree+kk)->extra+j*NumCodons+l);
	  }else{
	    xx*=*((subtree+kk)->down2+l);
	  };
	};
	*(x+l)+=xx;
      };
    };
  };
  if(up!=NULL){
    for(int ii=0;ii<NumCodons;ii++){
      ans+=*(up3+ii)*(*(x+ii))*(*(p.pi+ii));//,ul,ext);
    };
    //    ans+=Likelihoodactval(f,up2,x,ul,ext);
  }else{
    for(int l=0;l<NumCodons;l++){
      ans+=*(p.pi+l)*(*(x+l));
    };
  };
  delete[] x;
  if(up!=NULL){//Differentiate wrt j on upward edge
    //ans+=dlikeqact2(up2,extra2+(params::numpars+i+e)*NumCodons,M,coeffs+offset*NumCodonsSq);
    for(int ii=0;ii<NumCodons;ii++){
      ans+=*(extra2+(params::numpars+i+e)*NumCodons+ii)*(*(extra3+j*NumCodons+ii));//*(*(p.pi+ii));
    };
  };
  return ans;
};

void tree::liklistextra(const Factmatrix& f,const params& p,const long double* ex,const long double *coeffs,const Realmatrix* dD,long double *T,long double *U){
  //builds all lists of cumulative likelihoods.
  int e=this->numed;
  for(int i=0;i<params::numpars;i++){//for each parameter i.
    //    this->liklistextra(f,i,p,ex);      
    this->liklistextra(f,i,*(dD+i),ex,coeffs,T+i*e*NumCodons,U+i*e*NumCodons);      
  };
  // this->liklistextrabl(f,p,0,0,ex);/*
  for(int j=0;j<e;j++){//For each edge
    this->liklistextrabl(f,j+1,p,0,0,ex);
  };//*/
};

void tree::liklistextrabl(const Factmatrix &f,int j,const params& p,int st,long double ul,const long double *ex){
  //calculates likelihood lists replacing the P matrix for one edge by
  //its derivative with respect to branch length.

  if(j==0){//upward branch
    dliketlact(f,down3,extra+(params::numpars+st-1)*NumCodons,ul,p,ex-NumCodons);
    for(int i=0;i<NumCodons;i++){
      *(extra2+(params::numpars+st-1)*NumCodons+i)=0;//*(down3+i);
    };
    return;
  };
  j--;
  int s=1;
  long double *tmp=new long double[NumCodons];
  for(int i=0;i<n;i++){
    int e=(subtree+i)->numed;
    if(j<=e){
      (subtree+i)->liklistextrabl(f,j,p,st+s,*(length+i),ex+s*NumCodons);
      for(int m=0;m<NumCodons;m++){
	*(tmp+m)=1;
	for(int ii=0;ii<n;ii++){
	  if(ii==i){
	    *(tmp+m)*=*((subtree+i)->extra+(params::numpars+j+st+s-1)*NumCodons+m);
	  }else{
	    *(tmp+m)*=*((subtree+ii)->down2+m);
	  };
	};
      };
      if(up!=NULL){
	f.gammainv.act(tmp,extra2+(params::numpars+j+st+s-1)*NumCodons);
	Likelihoodact(f,extra2+(params::numpars+j+st+s-1)*NumCodons,extra+(params::numpars+j+st+s-1)*NumCodons,ul,ex-NumCodons); 
      }else{
	for(int c=0;c<NumCodons;c++){
	  *(extra+(params::numpars+j+st+s-1)*NumCodons+c)=*(tmp+c);
	};
      };
      delete[] tmp;
      return;
    }else{
      s+=e+1;
      j-=e+1;
    };
  };
  cout<<"Failed to locate edge.\n";
  delete[] tmp;
};

void tree::liklistextrabl(const Factmatrix &f,const params& p,int st,long double ul,const long double *ex){
  //calculates likelihood lists replacing the P matrix for one edge by
  //its derivative with respect to branch length. Does all branches at
  //once for better efficiency.
  //  if(j==0){//upward branch
  // cout<<st<<"\n";
  if(up!=NULL){
    dliketlact(f,down3,extra+(params::numpars+st)*NumCodons,ul,p,ex);
    for(int i=0;i<NumCodons;i++){
      *(extra2+(params::numpars+st)*NumCodons+i)=*(down3+i);
    };
  };
    //    return;
    //  };
    //  j--;
  int s=(up==NULL)?0:1;
  long double *tmp=new long double[NumCodons*this->numed];
  long double *pos=tmp;
  for(int i=0;i<n;i++){
    int e=(subtree+i)->numed+1;
    //    if(j<=e){
    (subtree+i)->liklistextrabl(f,p,st+s,*(length+i),ex+s*NumCodons);
    for(int m=0;m<NumCodons;m++){
      *(pos+m)=1;
      for(int ii=0;ii<n;ii++){
	if(ii==i){
	  //	    *(tmp+m)*=*((subtree+i)->extra+(params::numpars+st+s-1)*NumCodons+m);
	}else{
	  *(pos+m)*=*((subtree+ii)->down2+m);
	};
      };
    };
    for(int j=1;j<=(subtree+i)->numed;j++){ 
      memcpy(pos+j*NumCodons,pos,NumCodons*sizeof(long double));
      for(int m=0;m<NumCodons;m++){
	*(pos+j*NumCodons+m)*=*((subtree+i)->extra+(params::numpars+st+s-1+j)*NumCodons+m);
      };
    };
    s+=e;
    pos+=((subtree+i)->numed+1)*NumCodons;
  };
  if(up!=NULL){
    f.gammainv.MultiActLin(this->numed,tmp,extra2+(params::numpars+st)*NumCodons);
    LikelihoodMultiact(f,this->numed,extra2+(params::numpars+st)*NumCodons,extra+(params::numpars+st)*NumCodons,ul,ex); 
  }else{
    for(int c=0;c<NumCodons*this->numed;c++){
      *(extra+(params::numpars+st)*NumCodons+c)=*(tmp+c);
    };
  };
  delete[] tmp;
};

void tree::liklistextra(const Factmatrix& f,int i,const params& p,const long double *ex,long double len){
  //builds the lists of cumulative likelihoods for parameter i.
  //Gets messed up by branch length 0.
  if(n==0){
    dlikeqlact(f,down3,extra+i*NumCodons,len,p,i,ex);
    for(int j=0;j<NumCodons;j++){
      *(extra2+i*NumCodons+j)=0;//*(down3+j);//Should this be 0
    };
    return;
  };
  long double *tmp=new long double[NumCodons];
  long double *tmp2=new long double[NumCodons];
  int pos=(len==0)?0:1;
  for(int l=0;l<NumCodons;l++){
    *(tmp2+l)=0;
  };
  for(int j=0;j<n;j++){       //for each subtree
    (subtree+j)->liklistextra(f,i,p,ex+pos*NumCodons,*(length+j));
    pos+=(subtree+j)->numed+1;
    for(int k=0;k<NumCodons;k++){
      *(tmp+k)=*((subtree+j)->extra+i*NumCodons+k);    
    };
    for(int k=0;k<n;k++){      //This can be made more efficient for
			       //multifurcating trees.
      if(k!=j){
	for(int l=0;l<NumCodons;l++){
	  *(tmp+l)*=*((subtree+k)->down2+l);
	};
      };
    };
    for(int l=0;l<NumCodons;l++){
      *(tmp2+l)+=*(tmp+l);
    };
  };
  f.gammainv.act(tmp2,extra2+i*NumCodons);
  Likelihoodact(f,extra2+i*NumCodons,extra+i*NumCodons,len,ex);
  if(len!=0){
    dlikeqlact(f,down3,tmp,len,p,i,ex);
    for(int j=0;j<NumCodons;j++){
      *(extra+i*NumCodons+j)+=*(tmp+j);
    };
  }
  delete[] tmp;
  delete[] tmp2;
};

void tree::liklistextra(const Factmatrix &f,int i,const Realmatrix& M,const long double *ex,const long double *coeffs,long double *T,long double *U){
  //builds the lists of cumulative likelihoods for parameter i.
  //Gets messed up by branch length 0.
  if(n==0){
    dlikeqlactsv(f,down3,extra+i*NumCodons,M,coeffs,U);
    calcT(f,up2,M,coeffs,T);
    for(int j=0;j<NumCodons;j++){
      *(extra2+i*NumCodons+j)=0;//*(down3+j);//Should this be 0
    };
    return;
  };
  long double *tmp=new long double[NumCodons];
  long double *tmp2=new long double[NumCodons];
  int pos=(up==NULL)?0:1;
  for(int l=0;l<NumCodons;l++){
    *(tmp2+l)=0;
  };
  for(int j=0;j<n;j++){       //for each subtree
    (subtree+j)->liklistextra(f,i,M,ex+pos*NumCodons,coeffs+pos*NumCodonsSq,T+pos*NumCodons,U+pos*NumCodons);
    pos+=(subtree+j)->numed+1;
    for(int k=0;k<NumCodons;k++){
      *(tmp+k)=*((subtree+j)->extra+i*NumCodons+k);    
    };
    for(int k=0;k<n;k++){      //This can be made more efficient for
			       //multifurcating trees.
      if(k!=j){
	for(int l=0;l<NumCodons;l++){
	  *(tmp+l)*=*((subtree+k)->down2+l);
	};
      };
    };
    for(int l=0;l<NumCodons;l++){
      *(tmp2+l)+=*(tmp+l);
    };
  };
  f.gammainv.act(tmp2,extra2+i*NumCodons);
  PreLikelihoodact(f,extra2+i*NumCodons,tmp,ex);//extra+i*NumCodons,ex);
  if(up!=NULL){
    Predlikeqlactsv(f,down3,tmp2,M,coeffs,U);
    for(int j=0;j<NumCodons;j++){
      *(tmp+j)+=*(tmp2+j);//*(extra+i*NumCodons+j)
    };
    dlikeqlactdownsv(f,up2,extra3+i*NumCodons,M,coeffs,T);
  }else{
    for(int k=0;k<NumCodons;k++){
      *(extra3+i*NumCodons+k)=0;
    };
  };
  f.gamma.act(tmp,extra+i*NumCodons);
  delete[] tmp;
  delete[] tmp2;
};

void testprint(int c){
  //  cout<<c;
};

void (*tp)(int)=testprint;
//*coeff(*(ex+i),*(ex+j),*(f.D.entries+i),*(f.D.entries+j))

int firsttime=0;

void siteBranchInf(const tree &T,long double *up,long double *&answer,const Realmatrix *&lp,const long double *&ex,int abovebranches1,int abovebranches2,const Realmatrix *DQ,const Factmatrix &f,const long double *pi){
  //Calculates the influence of each branch on all derivatives of likelihood
  if(T.up!=NULL){   
    //Likelihood
    for(int i=0;i<NumCodons;i++){
      for(int j=0;j<NumCodons;j++){
	(*answer)+=*(T.down3+j)*(*(T.up2+i))*(*(lp->entries+i*(NumCodons)+j));
      };
    };
    answer++;
    //Derivatives with respect to branches above
    for(int b=0;b<abovebranches1;b++){
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  (*answer)+=*(T.down3+j)*(*(up+b*NumCodons+i))*(*(lp->entries+i*(NumCodons)+j));      
	};
      };
      answer++;
    };
    //Derivative with respect to this branch
    for(int i=0;i<NumCodons;i++){
      for(int j=0;j<NumCodons;j++){
	(*answer)+=*(T.down3+j)*(*(T.up2+i))*(*((lp+1)->entries+i*(NumCodons)+j));      
      };
    };
    answer++;
    //Derivatives with respect to branches below
    for(int b=0;b<T.numed;b++){
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  (*answer)+=*(T.extra2+(params::numpars+abovebranches1+1+b)*NumCodons+j)*(*(T.up2+i))*(*(lp->entries+i*(NumCodons)+j));      
	};
      };
      answer++;
    };
    //Derivatives with respect to other branches above
    for(int b=0;b<abovebranches2;b++){
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  (*answer)+=*(T.down3+j)*(*(up+(b+abovebranches1)*NumCodons+i))*(*(lp->entries+i*(NumCodons)+j));      
	};
      };
      answer++;
    };
    /*    for(int i=0;i<NumCodons;i++){
      cout<<*(T.up2+i)<<" ";
    };
    cout<<"\n";*/
    //Derivatives with respect to parameters:
    for(int p=0;p<params::numpars;p++){
      //Branches above
      long double test=0;
      for(int i=0;i<NumCodons;i++){
	test+=*(T.down3+i)*(*(up+(p+abovebranches1+abovebranches2)*NumCodons+i))*(*(ex+i));
	//	cout<<*(up+(p+abovebranches1+abovebranches2)*NumCodons+i)<<"\t";
	for(int j=0;j<NumCodons;j++){
	  (*answer)+=*(T.down3+j)*(*(up+(p+abovebranches1+abovebranches2)*NumCodons+i))*(*(lp->entries+i*(NumCodons)+j));      
	};
      };
      //      cout<<"\n";
      //branches below
      for(int i=0;i<NumCodons;i++){
	test+=*(T.extra2+p*NumCodons+i)*(*(T.up2+i))*(*(ex+i)); 
	for(int j=0;j<NumCodons;j++){
	  (*answer)+=*(T.extra2+p*NumCodons+j)*(*(T.up2+i))*(*(lp->entries+i*(NumCodons)+j));      
	};
      };
      //      cout<<test<<" ";
      //This branch
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  //	  long double t=*(T.down3+j)*(*(T.up2+i))*(*((lp+2+p)->entries+i*(NumCodons)+j));      
	  long double t=*(T.down+j)*(*(T.up+i))*(*(pi+i))*(*((lp+2+p)->entries+i*(NumCodons)+j));      
	  	  (*answer)+=t;
	  //cout<<t<<" ";
	  //	  if(t>1e-15){
	    //	    cout<<"\np="<<p<<"  i="<<i<<"  j="<<j<<"  d_i="<<*(T.down3+i)<<"  u_j="<<(*(T.up2+j))<<"  P_ij="<<(*((lp+2+p)->entries+i*(NumCodons)+j))<<"  t="<<t<<"\n\n";     
	  //	  };
	};
	//cout<<"\n";
      };
      //cout<<"\n\n";
      answer++;      
    };
    //cout<<"\n";
  };
  //Now recursively call trees below.
  long double *tmp=new long double[(abovebranches1+abovebranches2+1+params::numpars)*NumCodons];
  for(int i=0;i<abovebranches1+abovebranches2+params::numpars;i++){
    for(int j=0;j<NumCodons;j++){
      *(up+i*NumCodons+j)*=*(ex+j);
    };
  };
  for(int i=0;i<abovebranches1;i++){
    f.gamma.act(up+i*NumCodons,tmp+i*NumCodons);
  };
  long double *dbr=new long double[NumCodons];
  if(T.up!=NULL){
    for(int j=0;j<NumCodons;j++){
      *(dbr+j)=*(T.up2+j)*(*(ex+j))*(*(f.D.entries+j));
    };
    f.gamma.act(dbr,tmp+abovebranches1*NumCodons);
    //    for(int j=0;j<NumCodon;j++){
    //      *(tmp+abovebranches1*Numcodons+i)=*(T.extra?+??*NumCodons+i);
    //    };
    abovebranches1++;
    for(int i=0;i<abovebranches2+params::numpars;i++){
      f.gamma.act(up+(i+abovebranches1-1)*NumCodons,tmp+(abovebranches1+i)*NumCodons);
    };
  }else{
    for(int i=0;i<abovebranches2+params::numpars;i++){
      f.gamma.act(up+(i+abovebranches1)*NumCodons,tmp+(abovebranches1+i)*NumCodons);
    };
  };
  if(T.up!=NULL){
    ex+=NumCodons;
    lp+=params::numpars+2;
  };

  //Now tmp covers has derivatives wrt all branches above current.


  long double *unxt=new long double[(abovebranches1+abovebranches2+T.numed+params::numpars)*NumCodons];
  long double *temporary=new long double[NumCodons];
  long double *hash=new long double[NumCodons];
  long double *hash2=new long double[NumCodons];
  long double *temp2=new long double[NumCodons];
  int ab2=abovebranches2+T.numed;
  int ab1=abovebranches1;
  for(int i=0;i<T.n;i++){
    for(int j=0;j<NumCodons;j++){
      *(hash+j)=*(pi+j);
    };   
    for(int k=0;k<T.n;k++){
      if(k!=i){
	for(int j=0;j<NumCodons;j++){
	  *(hash+j)*=*((T.subtree+k)->down2+j);
	};	
      };
    };
    for(int j=0;j<abovebranches1;j++){
      for(int k=0;k<NumCodons;k++){
	*(temporary+k)=*(tmp+j*NumCodons+k)*(*(hash+k));	
      };
      f.gamma.TranspAct(temporary,unxt+j*NumCodons);
    };
    int bb=0;
    int bc=0;
    for(int j=0;j<T.n;j++){
      if(j!=i){
	for(int jj=0;jj<NumCodons;jj++){
	  *(hash2+jj)=*(pi+jj);
	};   
	for(int k=0;k<T.n;k++){
	  if(k!=i&&k!=j){
	    for(int jj=0;jj<NumCodons;jj++){
	      *(hash2+jj)*=*((T.subtree+k)->down2+jj);
	    };	
	  };
	};
	for(int l=0;l<(T.subtree+j)->numed+1;l++){
	  if(T.up3!=NULL){
	    for(int k=0;k<NumCodons;k++){
	      *(temporary+k)=*((T.subtree+j)->extra+(params::numpars+abovebranches1+bb+l)*NumCodons+k)*(*(T.up3+k))*(*(hash2+k));	
	    };
	  }else{
	    for(int k=0;k<NumCodons;k++){
	      *(temporary+k)=*((T.subtree+j)->extra+(params::numpars+abovebranches1+bb+l)*NumCodons+k)*(*(hash2+k));	
	    };
	  };
	  f.gamma.TranspAct(temporary,unxt+(abovebranches1+bc+l)*NumCodons);
	};    
	bc+=(T.subtree+j)->numed+1;
      };  
      bb+=(T.subtree+j)->numed+1;
    };
    for(int j=0;j<abovebranches2;j++){
      for(int k=0;k<NumCodons;k++){
	*(temporary+k)=*(tmp+(abovebranches1+j)*NumCodons+k)*(*(hash+k));	
      };
      f.gamma.TranspAct(temporary,unxt+(abovebranches1+bc+j)*NumCodons);
    };
    for(int p=0;p<params::numpars;p++){
      for(int k=0;k<NumCodons;k++){
	*(temporary+k)=*(hash+k)*(*(T.extra3+p*NumCodons+k)+*(tmp+(abovebranches1+abovebranches2+p)*NumCodons+k));
      };
      f.gamma.TranspAct(temporary,unxt+(abovebranches1+abovebranches2+bc+p)*NumCodons);
      for(int j=0;j<T.n;j++){
	if(j!=i){
	  for(int k=0;k<NumCodons;k++){
	    long double prod=*((T.subtree+j)->extra+p*NumCodons+k);
	    for(int l=0;l<T.n;l++){
	      if(l!=i&&l!=j){
		prod*=*((T.subtree+l)->down2+k);
	      };
	    };
	    if(T.up3!=NULL){
	      *(temporary+k)=*(T.up3+k)*prod*(*(pi+k));
	    }else{
	      *(temporary+k)=prod*(*(pi+k));
	    };
	  };
	  f.gamma.TranspAct(temporary,temp2);
	  for(int k=0;k<NumCodons;k++){
	    *(unxt+(abovebranches1+abovebranches2+bc+p)*NumCodons+k)+=*(temp2+k);
	  };	    
	};
      };
    };
    ab2-=(T.subtree+i)->numed+1;
    siteBranchInf(*(T.subtree+i),unxt,answer,lp,ex,ab1,ab2,DQ,f,pi);
    ab1+=(T.subtree+i)->numed+1;
  };
  delete[] tmp;
  delete[] dbr;
  delete[] unxt;
  delete[] hash;
  delete[] hash2;
  delete[] temporary;
  delete[] temp2;
};

long double *stBInf(tree &T,const long double *ex,const Realmatrix *DQ,const Factmatrix &f,const Realmatrix *lp,const params &p){
  //Wrapper function that prepares arguments for recursive call to siteBranchInf

  /*  T.liklistdown(f,data,i,x.ex);
  T.liklistup(p,f,x.ex,NULL);
  T.liklistextra(f,p,x.ex,x.coeffs,x.dD,mem.T,mem.U);*/


  long double *an=new long double[T.numed*(T.numed+params::numpars+1)];
  for(int i=0;i<T.numed*(T.numed+params::numpars+1);i++){
    *(an+i)=0;
  };
  long double *ans=an;
  long double *up=new long double[params::numpars*NumCodons];
  for(int i=0;i<params::numpars*NumCodons;i++){
    *(up+i)=0;
  };
  siteBranchInf(T,up,ans,lp,ex,0,0,DQ,f,p.pi);
  delete[] up;
  return an;    
};

#include "Hessian2.cpp"
