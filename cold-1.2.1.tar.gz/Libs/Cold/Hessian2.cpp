/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//Routines for calculating directional derivatives

long double tree::secderdir(const params& p,const Factmatrix& f,long double ul,const Realmatrix &M,const long double *&ex,const long double *coeffs) const {
  //Calculates part of the second derivative with respect to
  //parameters i and j. Doesn't calculate for the case where they
  //occur on the same edge.
  //  int e=offset;
  long double t=0;
  long double *ui=new long double[NumCodons];
  for(int k=0;k<NumCodons;k++){
    *(ui+k)=0;
  };
  for(int k=0;k<n;k++){
    for(int l=k+1;l<n;l++){//For each pair of subtrees
      for(int m=0;m<NumCodons;m++){
	long double q=1;
	for(int u=0;u<n;u++){
	  if(u==l||u==k){
	    q*=*((subtree+u)->extra+m);
	  }else{
	    q*=*((subtree+u)->down2+m);
	  };
	};
	  //	  cout<<q;
	if(up==NULL){
	  t+=*(p.pi+m)*q;
	}else{
	  *(ui+m)+=q;
	};
      };
    };
  };
  if(up!=NULL){
    if(n>0){
      for(int ii=0;ii<NumCodons;ii++){
	t+=*(up3+ii)*(*(ui+ii))*(*(p.pi+ii));
	t+=*(extra3+ii)*(*(extra2+ii));
      };
    };
    ex+=NumCodons;
    coeffs+=NumCodonsSq;
  };
  t*=2;
  for(int k=0;k<n;k++){
    t+=(subtree+k)->secderdir(p,f,*(length+k),M,ex,coeffs);
  };
  delete[] ui;
  return t;
};


long double tree::secderblpdir(const long double *dir,const params& p,const Factmatrix& f,const long double *ex,const Realmatrix& M,long double ul,const long double *coeffs,int offset){
  /* 
     Calculates the second derivative of the likelihood with respect
     to the length of branch i and to parameter j, whose derivative
     matrix is given by M.
  */

  int e=offset;
  const long double *ext=ex+offset*NumCodons;
  long double ans=0;
  if(up!=NULL){
    ans=*(dir+e)*dliketact2(f,up2,extra2,ul,p,ext);
    ans+=*(dir+e)*d2liketqact(f,up2,down3,ul,p,M,ext);//????
    e++;
  };
  long double* x=new long double[NumCodons];
  for(int ii=0;ii<NumCodons;ii++){
    *(x+ii)=0;
  };
  for(int k=0;k<n;k++){//For each edge where Q derivative might happen ...
    ans+=(subtree+k)->secderblpdir(dir,p,f,ex,M,*(length+k),coeffs,e);
    for(int str=0;str<n;str++){
      if(str!=k){
	for(int l=0;l<NumCodons;l++){
	  long double xx=1;
	  for(int kk=0;kk<n;kk++){
	    if(kk==str){
	      xx*=*((subtree+kk)->extra+(params::numpars)*NumCodons+l);
	    }else if(kk==k){
	      xx*=*((subtree+kk)->extra+l);
	    }else{
	      xx*=*((subtree+kk)->down2+l);
	    };
	  };
	  *(x+l)+=xx;
	};
      };
    };
  };
  if(up!=NULL){
    for(int l=0;l<NumCodons;l++){
      ans+=*(up3+l)*(*(p.pi+l))*(*(x+l));
    };
  }else{
    for(int l=0;l<NumCodons;l++){
      ans+=*(p.pi+l)*(*(x+l));
    };
  };
  delete[] x;
  if(up!=NULL){//Differentiate wrt j on upward edge
    //    ans+=dlikeqact2(f,upvals+offset*NumCodons,extra2+(params::numpars)*NumCodons,ul,p,M,ext);
    for(int l=0;l<NumCodons;l++){
      ans+=*(extra2+l)*(*(extra3+l));
    };
  };
  return ans;
};



void tree::liklistextradir(const Factmatrix& f,const params& p,const long double* ex,const Realmatrix& M,const long double *dir){
  //builds all lists of cumulative likelihoods.
  this->liklistextradir(f,M,p,ex);      
  this->liklistextrabldir(f,p,0,0,ex,dir);
};

void tree::liklistextradir(const Factmatrix& f,const Realmatrix& M,const params& p,const long double *ex,long double len){
  //builds the lists of cumulative likelihoods for parameters giving matrix M.
  if(n==0){
    dlikeqlact(f,down3,extra,len,p,M,ex);
    for(int j=0;j<NumCodons;j++){
      *(extra2+j)=0;//*(down3+j);
    };
    return;
  };
  long double *tmp=new long double[NumCodons];
  long double *tmp2=new long double[NumCodons];
  int pos=0;
  for(int l=0;l<NumCodons;l++){
    *(tmp2+l)=0;
  };
  for(int j=0;j<n;j++){       //for each subtree
    (subtree+j)->liklistextradir(f,M,p,ex+pos*NumCodons,*(length+j));
    pos+=(subtree+j)->edges();
    for(int k=0;k<NumCodons;k++){
      *(tmp+k)=*((subtree+j)->extra+k);    
    };
    for(int k=0;k<n;k++){      //This can be made more efficient for
			       //multifurcating trees.
      if(k!=j){
	for(int l=0;l<NumCodons;l++){
	  *(tmp+l)*=*((subtree+k)->down2+l);
	};
      };
    };
    for(int l=0;l<NumCodons;l++){
      *(tmp2+l)+=*(tmp+l);
    };
  };
  f.gammainv.act(tmp2,extra2);
  PreLikelihoodact(f,extra2,tmp2,ex);
  if(len!=0){
    dlikeqlact(f,down3,tmp,len,p,M,ex);
    for(int j=0;j<NumCodons;j++){
      *(tmp2+j)+=*(tmp+j);
    };
  };
  f.gamma.act(tmp2,extra);
  delete[] tmp;
  delete[] tmp2;
};


void tree::liklistextrabldir(const Factmatrix &f,const params& p,int st,long double ul,const long double *ex,const long double* dir){
  //calculates likelihood lists replacing the P matrix for each edge by
  //its derivative with respect to branch length.
  long double *tmp=new long double[NumCodons];
  int s=1;
  for(int i=0;i<NumCodons;i++){
    *(tmp+i)=0;
  };
  for(int i=0;i<n;i++){
    int e=(subtree+i)->edges();
    (subtree+i)->liklistextrabldir(f,p,st+s,*(length+i),ex+s*NumCodons,dir);
    for(int m=0;m<NumCodons;m++){
      long double t=1;
      for(int ii=0;ii<n;ii++){
	if(ii==i){
	  t*=*((subtree+i)->extra+(params::numpars)*NumCodons+m);
	}else{
	  t*=*((subtree+ii)->down2+m);
	};
      };
      *(tmp+m)+=t;
    };
    s+=e+1;
  };
  if(up!=NULL){
    f.gammainv.act(tmp,extra2+(params::numpars)*NumCodons);
    Likelihoodact(f,extra2+(params::numpars)*NumCodons,extra+(params::numpars)*NumCodons,ul,ex-NumCodons); 
  }else{
    for(int c=0;c<NumCodons;c++){
      *(extra+(params::numpars)*NumCodons+c)=*(tmp+c);
      *(extra2+(params::numpars)*NumCodons+c)=*(tmp+c);
    };
  };
  if(up!=NULL){//upward branch
    dliketlact(f,down3,tmp,ul,p,ex-NumCodons);    
    for(int i=0;i<NumCodons;i++){
      if(n==0){
	*(extra+params::numpars*NumCodons+i)=*(tmp+i)*(*(dir+st-1));
      }else{
	*(extra+params::numpars*NumCodons+i)+=*(tmp+i)*(*(dir+st-1));
      };
    };
  };
  delete[] tmp;
};

long double tree::secderbldir(const long double *dir,const params& p,const Factmatrix& f,const long double *ex,long double ul,int offset){
  /* 
     Calculates the second derivative of the likelihood with respect
     to the direction dir.
  */
  long double ans=0;
  int e=offset;
  if(up!=NULL){//upward branch   
    long double *x=new long double[NumCodons];
    e++;
    for(int k=0;k<NumCodons;k++){
      *(x+k)=1;
    };
    ans+=2*(*(dir+offset))*dliketact(f,up2,extra2+(params::numpars)*NumCodons,ul,p,ex+offset*NumCodons);
    ans+=*(dir+offset)*(*(dir+offset))*d2liketact(f,up2,down3,ul,p,ex+offset*NumCodons);
    delete[] x;
  };
  long double *fact=new long double[NumCodons];
  if(up==NULL){
    for(int i=0;i<NumCodons;i++){
      *(fact+i)=0;
      for(int j=0;j<n;j++){
	long double d=*((subtree+j)->extra+(params::numpars)*NumCodons+i)/(*((subtree+j)->down2+i));
	*(fact+i)+=d;
	ans-=d*d*(*(down+i))*(*(p.pi+i));    
      };
    };  
  }else{
    long double *d=new long double[NumCodons];
    for(int i=0;i<NumCodons;i++){
      *(fact+i)=0;
      for(int j=0;j<n;j++){
	*(d+i)=*((subtree+j)->extra+(params::numpars)*NumCodons+i)/(*((subtree+j)->down2+i));
	*(fact+i)+=*(d+i);
	*(d+i)=*(d+i)*(*(d+i))*(*(down+i))*(*(p.pi+i));   
      };
    };  
    ans-=Likelihoodactval(f,up2,d,ul,ex+offset*NumCodons);
    delete[] d;
  };
  if(up==NULL){
    for(int i=0;i<NumCodons;i++){    
      ans+=*(fact+i)*(*(fact+i))*(*(down+i))*(*(p.pi+i));
    };
  }else{
    ans+=Likelihoodactval(f,up2,fact,ul,ex+offset*NumCodons);
  };
  delete[] fact;
  return ans;
};


void makematricesdir(const Realmatrix& M,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4){
  /* 
     mat_ik=sum_j(M_ijM_jkA_ijA_ik)?
     mat2_ik=sum_j(M_ijM_jkA_jkA_ik)?
     mat3_ik=sum_j(M_ijM_jk)?
   */
  for(int i=0;i<NumCodonsSq;i++){
    *(mat+i)=0;
    *(mat2+i)=0;
    *(mat3+i)=0;
    *(mat4+i)=0;
  };
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<NumCodons;k++){
      for(int j=0;j<NumCodons;j++){
#define M_ij (*(M.entries+i*NumCodons+j))
#define M_jk (*(M.entries+j*NumCodons+k))
//#define N_ij (*(N.entries+i*NumCodons+j))
//#define N_jk (*(N.entries+j*NumCodons+k))
	long double t=2*M_ij*M_jk;
	if(*(part+i)!=*(part+j)&&*(part+j)!=*(part+k)&&*(part+i)!=*(part+k)){
	  *(mat+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+j)));
	  *(mat2+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+j)-*(d+k)));
	}else if(*(part+i)==*(part+j)&&*(part+j)!=*(part+k)){
	  *(mat+i*NumCodons+k)-=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+k)));
	  *(mat2+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+j)-*(d+k)));
	  *(mat3+i*NumCodons+k)+=t/(*(d+i)-*(d+k));
	}else if(*(part+i)!=*(part+j)&&*(part+j)==*(part+k)){
	  *(mat2+i*NumCodons+k)-=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+k)));
	  *(mat+i*NumCodons+k)+=t/((*(d+i)-*(d+k))*(*(d+i)-*(d+j)));
	  *(mat4+i*NumCodons+k)+=t/(*(d+k)-*(d+i));
	}else if(*(part+i)==*(part+k)&&*(part+j)!=*(part+k)){
	  *(mat+i*NumCodons+k)-=t/((*(d+i)-*(d+j))*(*(d+i)-*(d+j)));
	  *(mat3+i*NumCodons+k)+=t/(*(d+i)-*(d+j));
	}else if(*(part+i)==*(part+j)&&*(part+j)==*(part+k)){
	  *(mat4+i*NumCodons+k)+=t/2;
	};
      };
    };
  };
};

long double tree::sdsamedir(const Factmatrix& f, const params &p,const Realmatrix& M,const Realmatrix& O,const long double *mat,const long double *mat2,const long double *mat3,const long double *mat4,const int* part,const long double* upvals,const long double* downvals,const long double* ex,const long double *l,const long double *FIJ)const throw(){
  //Calculates the second derivative with respect to a direction which
  //produces a matrix derivative M, in the case where the derivatives
  //are applied to the same branch. 
  int e=this->edges();
  long double ans=0;
  int pmax=0;
  for(int i=0;i<NumCodons;i++){
    if(*(part+i)>pmax){
      pmax=*(part+i);
    };
  };
  if(pmax<NumCodons-1){
    cout<<"pmax="<<pmax<<"\n";
  };
  for(int ed=0;ed<e;ed++){
    const long double *v=upvals+ed*NumCodons;
    const long double *w=downvals+ed*NumCodons;
    for(int i=0;i<NumCodons;i++){
      long double term=0;
      long double ett=*(v+i)*(*(ex+ed*NumCodons+i))*(*(l+ed))*(*(l+ed));
      long double t=0;
      long double t2=0;
      long double u=0;
      long double u2=0;
      long double excess=0;
      long double cf1=((*(l+ed))-1)*(*(ex+ed*NumCodons+i));
      for(int j=0;j<NumCodons;j++){
	int k=j;
	long double coeff=(*(part+i)==*(part+j))?*(l+ed)*(*(ex+ed*NumCodons+i)):*(FIJ+i*NumCodons+j)*(*(ex+ed*NumCodons+i)-(*(ex+ed*NumCodons+j)));
	term+=*(O.entries+i*NumCodons+j)*(*(w+j))*coeff;
	//firstly, we consider the case i~j~k
	if(*(part+i)==*(part+k)){
	  ans+=*(w+k)*ett*(*(mat3+i*NumCodons+k))/2;
	  ans+=*(v+i)*(*(ex+ed*NumCodons+i))*(*(mat+i*NumCodons+k))*(*(w+k));
	  ans+=*(v+i)*(*(ex+ed*NumCodons+k))*(*(mat2+i*NumCodons+k))*(*(w+k));
	  t+=*(v+j)*M_ji*(*(FIJ+j*NumCodons+i));
	  t2+=*(v+j)*M_ji*(*(FIJ+j*NumCodons+i));
	  u+=*(w+j)*M_ij*(*(FIJ+j*NumCodons+i));
	  u2+=*(w+j)*M_ij*(*(FIJ+j*NumCodons+i));
	  excess+=*(v+j)*(M_ji*M_ij+M_ji*M_ji)*(*(w+k))*(*(FIJ+j*NumCodons+i))*(*(FIJ+k*NumCodons+i));
#define AA (*(f.D.entries+i))
#define BB (*(f.D.entries+j))
	  long double cf=(cf1+*(ex+ed*NumCodons+j)*(*(FIJ+i*NumCodons+j)))*(*(FIJ+i*NumCodons+j));//((AA-BB)*(AA-BB));
#undef AA
#undef BB
	  //i~k
	  long double inner=*(v+i)*(M_ij*M_ji+M_ji*M_ij);
	  //j~k swap i and j
	  inner+=*(v+j)*(M_ji*(*(M.entries+i*(NumCodons+1)))+M_ji*(*(M.entries+i*(NumCodons+1))));
	  inner*=*(w+i);
	  //i~j use j for k
	  inner+=*(v+i)*(*(w+j))*(M_ij*(*(M.entries+i*(NumCodons+1)))+M_ij*(*(M.entries+i*(NumCodons+1))));
	  ans+=inner*cf;
	  //Need to multiply all of these by appropriate size of equivalence classes.
	};
      };
      ans+=*(v+i)*term;
      ans+=((t*u2+t2*u)-excess)*(*(ex+ed*NumCodons+i));
    };    
  };
  return ans;
};
