/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//Call to load up the correct Hessian library.
#include <dlfcn.h>
#include <stdio.h>
#include "ErrorHandler.h"
#include <stdlib.h>

class tree;
class Realmatrix;
class Factmatrix;
class sequence;
class params;
class precalc;
class mspace;

static void *lib=NULL;

extern int NumCodons;
extern int NumCodonsSq;

extern void (*sthss)(tree &T,const Factmatrix &f,const sequence *data,const params & p,int i, long double *siteliks,const precalc &x,mspace &mem);

extern void (*mkmtrcs)(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4);

extern long double *(*sbi)(tree &T,const long double *ex,const Realmatrix *DQ,const Factmatrix &f,const Realmatrix *lp,const params &p);

void closelib(){
  if(lib!=NULL){
    dlclose(lib);
    lib=NULL;
  };
};

void setNumCodons(int n){
  NumCodons=n;
  NumCodonsSq=NumCodons*NumCodons;
  char filename[16];//As long as no matrix of size 10000 or more.
  sprintf(filename,"libCode%d.so",n);
  if(lib!=NULL){
    if(!dlclose(lib)){
      info(filename);
      if (const char* err = dlerror())
	warning(err);          
      warning("Could not close hessian library.");  // should be fatal?
    };
  };
  if(!(lib=dlopen(filename,RTLD_NOW))){
    info(filename);
    if(const char* err=dlerror()){
      warning(err);
    };
    fatalError("Could not open hessian library. Aborting!");
  };
  atexit(closelib);
  dlerror();
  void *addr=dlsym(lib,"sthss");
  if(dlerror()){
    fatalError("Could not open resolve symbol \"sthss\". Aborting!");
  };
  sthss=*(void(**)(tree &,const Factmatrix &,const sequence *,const params &,int, long double *,const precalc &,mspace &))addr;
  addr=dlsym(lib,"mkmtrcs");
  if(dlerror()){
    fatalError("Could not open resolve symbol \"mkmtrcs\". Aborting!");
  };
  mkmtrcs=*(void(**)(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4))addr;
  addr=dlsym(lib,"sbi");
  if(dlerror()){
    fatalError("Could not open resolve symbol \"sbi\". Aborting!");
  };
  sbi=*(long double *(**)(tree &,const long double *,const Realmatrix *,const Factmatrix &,const Realmatrix *,const params &))addr;
};
