/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
//#include <stdarg.h>
#include <stdio.h>

#include "ErrorHandler.h"
#include "Matrix.h"
#include "Parameters.h"
#include "Sequence.h"
#include "Tree.h"
#include "Miscellaneous.h"
#include "CommandLine.h"
#include "MixTreeLikelihood.h"
#include "Distributions.h"

using namespace std;

int match(const char *a,const char *str){
  int m=0;
  for(;*(str+m)&&*(a+m)&&(*(a+m)==*(str+m)||*(a+m)==toupper(*(str+m)));m++);
  return m;
};

void params::usematrix(const Realmatrix &Q){
  numpars=0;
  if(XX!=NULL){
    delete[] XX;
    XX=NULL;
  };
  if(mask!=NULL){
    delete mask;
    mask=NULL;
  };
  A=Q;//Need to symmetrise and get pi.
  setupp=1;
};

void params::getmask(int n,ifstream& in){
  for(int i=1;i<n;i++){
    dummyreadmatrix(in);
  };
  for(;in.good()&&!(in.eof())&&in.peek()=='\n';in.get());
  if(mask!=NULL){
    delete mask;
  };
  mask=new Realmatrix(in); 
};

void params::setup(ifstream& in){
  //Should change the function for matrices to allow a matrix to be
  //input from a stream. When that is done, can change this function to
  //accept any istream.
  //Reads in the fixed matrices from the input stream.
  //  numpars=NUMPARS;

  streampos st=in.tellg();
  int maskpos=-1;//No mask
  int nm1=0;
  int nm2=0;
  for(char c='\n';c=='\n'&&in.good()&&!(in.eof());in.get(c));
  in.seekg(-1,ios::cur);
  char *firstline=readstring(in,"\n");
  //Format of first line:
  //nummats [mask] nummats
  char *pos=firstline;
  for(;*pos==' '||*pos=='\t';pos++);//strip leading spaces
  int msk=match(pos,"mask");
  pos+=msk;
  for(;*pos==' '||*pos=='\t';pos++);//strip leading spaces
  if(msk>0){
    maskpos=0;
    nm2=atoi(pos);
  }else{
    nm1=atoi(pos);
    for(;isdigit(*pos);pos++);
    for(;*pos==' '||*pos=='\t';pos++);//strip leading spaces
    msk=match(pos,"mask");
    if(msk>0){
      maskpos=nm1;
      pos+=msk;
      for(;*pos==' '||*pos=='\t';pos++);//strip leading spaces
      nm2=atoi(pos);
      for(;isdigit(*pos);pos++);
      for(;*pos==' '||*pos=='\t';pos++);//strip leading spaces
    };
    if(isdigit(*pos)||*pos=='-'){//first line isn't correctly
				 //formatted. probably first line of a
				 //matrix.
      //      cout<<"Hello.\n";
      maskpos=-2;
    };
  };
  if(maskpos==-2){/* Matrices start on first line */
    in.seekg(st);
    if(in.fail()){//Can't return to chosen position.
      char* msg=new char[50+strlen(Filename)];
      sprintf(msg,"IO error reading parameter file \"%s\".",Filename);
      recoverableError(msg);
      //Could improve this later in order to allow recovery.
    };
    nm1=-1;
  };
  delete[] firstline;

  variable* rec=vars.seektag("-numpars");
  if(rec!=NULL){
    numpars=atoi(*(char**)(rec->value));
  };

  if(nm1==-1){
    nm1=numpars;
    nm2=0;
  };

  if(nm1+nm2<numpars){//Some problem with format of file
    if(rec!=NULL){
      char msg[100];
      sprintf(msg,"Too few matrices in parameter file.\n Reducing number of parameters in the model to %i.",nm1+nm2);
      warning(msg);
    };
    numpars=nm1+nm2;
  }else if(nm1+nm2>numpars){
    if(rec!=NULL){
      nm2=numpars-nm1;
    }else{
      numpars=nm2+nm1;
    };
  };

  rec=vars.seektag("-parameterselection");
  if(rec!=NULL){
    int *sel=selection(*(char **)rec->value);
    sortlist(sel);
    for(numpars=0;*(sel+numpars)>0;numpars++){
      (*(sel+numpars))--;
    };
    numpars++;
    XX=new Realmatrix[numpars];
    XX->sz=NumCodons;
    XX->entries=new long double[NumCodonsSq];
    for(int i=0;i<NumCodonsSq;i++){
      *(XX->entries+i)=1;
    };
    for(int i=0;i<NumCodons;i++){
      *(XX->entries+i*(NumCodons+1))=1-NumCodons;
    };
    int p=0;
    for(int i=0;*(sel+p)>=0&&in.good();i++){
      //      cout<<i<<"\n";
      if(i==maskpos){
	//	cout<<"mask\n";
	if(!vars.seektag("-nomask")){
	  mask=new Realmatrix(in);
	}else{
	  dummyreadmatrix(in);
	};
      };
      if(*(sel+p)==i){
	*(XX+p+1)=RealmatrixT(in);
	//	cout<<(*(XX+p+1))<<"\n\n";
	p++;
      }else{
	dummyreadmatrix(in);
      };
    };
    if(!in.good()&&*(sel+p)>=0){
      char message[200];
      sprintf(message,"Insufficient parameters in file. Stopped after reading parameter number %i, which is parameter number %i in the list.",*(sel+p),p);
      warning(message);
      numpars=p;
    };
    delete[] sel;
  }else{
    for(char c='\n';c=='\n'&&in.good()&&!(in.eof());in.get(c));
    in.seekg(-1,ios::cur);
    numpars++;
    XX=new Realmatrix[numpars];//Should add a way to specify no. of
    XX->sz=NumCodons;
    XX->entries=new long double[NumCodonsSq];
    for(int i=0;i<NumCodonsSq;i++){
      *(XX->entries+i)=1;
    };
    for(int i=0;i<NumCodons;i++){
      *(XX->entries+i*(NumCodons+1))=1-NumCodons;
    };
    //params in the file.
    for(int i=0;i<nm1;i++){
      if(i<numpars-1){
	*(XX+i+1)=RealmatrixT(in);
      }else{
	dummyreadmatrix(in);
      };
      for(char c='\n';c=='\n'&&in.good()&&!(in.eof());in.get(c));
      in.seekg(-1,ios::cur);
      if(in.good()){
	in.seekg(-1,ios::cur);
      };
    };
    if(maskpos>=0){
      if(!(vars.seektag("-nomask"))){
	mask=new Realmatrix(in);
      }else{
	dummyreadmatrix(in);
      };
      for(char c='\n';c=='\n'&&in.good()&&!(in.eof());in.get(c));
      for(int i=0;i<nm2;i++){
	*(XX+i+nm1+1)=RealmatrixT(in);
	for(char c='\n';c=='\n'&&in.good()&&!(in.eof());in.get(c));
	in.seekg(-1,ios::cur);
	if(in.good()){
	  in.seekg(-1,ios::cur);
	};
      };
    };
  };
  //  A=Realmatrix(in);
  A=normalisemats(XX,numpars);//Need to sort out
				     //orthonormalisation for Mixture
				     //models.
  atexit(unsetupParams);
  setupp=1;
};

void params::readpars(istream &in){//Reads in a starting set of parameters.
  /*  for(int i=0;i<NumCodons&&in.good();i++){
    char *a=readnonemptystring(in," \n\t\r");
    *(pi+i)=atof(a);    
    delete[] a;
    };

pi normally found empirically.
  */
  for(int i=0;i<NumCodons;i++){
    *(pi+i)=1.0L/61;
  };
  long double *cf=new long double[numpars];
  for(int i=0;i<numpars;i++){
    char *a=readnonemptystring(in,", \n\t\r");
    *(cf+i)=atof(a);    
    delete[] a;    
  };
  ((Realmatrix)A.inverse()).act(cf,coeff);
  delete[] cf;
  this->setR();
  long double *d=new long double[NumCodons];
  C=R.diagonalisesymmetric(d);
  delete[] d;
};

void params::readpi(istream &in){//Mostly useful for simulation
  //No checking for completeness of codon list - one codon could be
  //multiply defined, another could be undefined.
  for(int i=0;i<NumCodons;i++){
    char *a=readnonemptystring(in,", \n\t\r");
    if(isdigit(*a)||*a=='.'){
      *(pi+i)=atof(a); 
    }else if(*a=='A'||*a=='a'||*a=='C'||*a=='c'||*a=='G'||*a=='g'||*a=='T'||*a=='t'){
      int j=codon(a);
      a=readnonemptystring(in,", \n\t\r");
      *(pi+j)=atof(a);
    }else{
      fatalError("Unrecognised character in frequency file.");
    };   
    delete[] a;    
  };
};

const char* validnucleotides="AaCcGgTtUu-?";
const char* validnucleotidesubst="AACCGGTTTT-?";

int inline validseq(char c){
  for(int i=0;*(validnucleotides+i);i++){
    if(*(validnucleotides+i)==c){
      return i;
    };
  };
  return -1;
};

void sequence::assign(ifstream &in){
  char *a=new char[25];
  *a=' ';
  for(;*a==' '||*a=='\t';in.get(*a)); //strip leading spaces.
  in.get(a+1,24,' ');
  in.clear();
  length=atoi(a);
  seq=new char[length+2];
  int i=0;
  for(;in.good()&&i<length;i++){
    for(*(seq+i)=' ';validseq(*(seq+i))==-1;in.get(*(seq+i)));
    *(seq+i)=*(validnucleotidesubst+validseq(*(seq+i)));
  };
  *(seq+i)='\0';
  if(strlen(seq)<(unsigned)length){//Short sequence
    cerr<<"Short sequence. Aborting.\n";
    exit(1);
  };
  length/=CodonLength;
  //continue to newline;
  for(char t=' ';t!='\n'&&in.good();in.get(t));
  delete[] a;
};

void sequence::assign(ifstream &in,int len){
  char *a=new char[25];
  *a=' ';
  for(;*a==' '||*a=='\t';in.get(*a)); //strip leading spaces.
  if(isdigit(*a)){
    in.get(a+1,24,' ');
    length=atoi(a);
    seq=new char[length+2];
    *seq=' ';
  }else{
    length=len;
    seq=new char[length+2];
    *seq=*a;
  };
  int i=0;
  for(;in.good()&&i<length;i++){
    for(;in.good()&&validseq(*(seq+i))==-1;in.get(*(seq+i)));
    *(seq+i)=*(validnucleotidesubst+validseq(*(seq+i)));
    *(seq+i+1)=' ';
  };
  *(seq+i)='\0';
  if(strlen(seq)<(unsigned)length){//Short sequence
    cerr<<"Short sequence. Aborting.\n";
    exit(1);
  };
  length/=CodonLength;
  //continue to newline;
  for(char t=' ';t!='\n'&&in.good();in.get(t));
  delete[] a;
};

tree::tree(int l,const char *s){
  char *rubbish;
  up=new long double[NumCodons];
  up2=new long double[NumCodons];
  up3=new long double[NumCodons];
  down=new long double[NumCodons];
  down2=new long double[NumCodons];
  down3=new long double[NumCodons];
  n=0;
  int depth=0;
  for(int i=0;i<l;i++){
    if(*(s+i)=='('){
      depth++;
    }else if(*(s+i)==')'){
      depth--;
    }else if(*(s+i)==','&&depth==1){
      n++;
    };
  };
  for(;l>0&&(*s==' '||*s=='\t'||*s=='\r'||*s=='\n');s++){
    l--;
  };
  if(n==0){
    int len=l+1;
    if(*s=='('){
      len-=2;
      s++;
    };
    label=new char[len];
    for(int i=0;i<len-1;i++){
      *(label+i)=*(s+i);
    };
    *(label+len-1)='\0';
    for(int i=len-2;*(label+i)==' '||*(label+i)=='\t'||*(label+i)=='\r'||*(label+i)=='\n';*(label+i--)='\0');
    return;
  }else{
    label=NULL;
    n++;
  };
  if(depth!=0){
    char dep[5];//If parantheses are mismatched worse than this, we
		//have a problem.
    sprintf(dep,"%d",depth);
    char *x=new char[100+strlen(s)];
    strcpy(x,"Mismatched parantheses in tree definition. \"");
    strcat(x,s);
    strcat(x,"\"\n");
    strcat(x,"a total of ");
    strcat(x,dep);
    strcat(x,"parantheses are unmatched.");
    recoverableError(x);
    delete[] x;
  };
  depth=0;
  length=new long double[n];
  subtree=new tree[n];
  int j=0;
  int kold=1;
  for(int i=0;i<l;i++){
    for(;*(s+i)==' '||*(s+i)=='\t'||*(s+i)=='\r'||*(s+i)=='\n';i++);
    if(*(s+i)=='('){
      depth++;
    }else if(*(s+i)==')'){
      depth--;
    }else if(*(s+i)==','&&depth==1){
      int k=i;
      for(;k>=kold&&(*(s+k)!=':');k--);
      if(*(s+k)==':'){
	*(length+j)=strtod(s+k+1,&rubbish);
      }else{
	*(length+j)=1;
	k=i;
      };
      *(subtree+j)=tree(k-kold,s+kold);
      j++;
      kold=i+1;
    };
  };
  int k=l-1;
  for(;k>=0&&*(s+k)!=':';k--);
  if(*(s+k)==':'){
    *(length+j)=strtod(s+k+1,&rubbish);
  }else{
    *(length+j)=1;
    k=l-1;
  };
  *(subtree+j)=tree(k-kold,s+kold);
};

tree::tree(const char *s){//Should make this more robust.
  char *rubbish;
  int l=strlen(s);
  up=NULL;//new long double[NumCodons];
  up2=NULL;//new long double[NumCodons];
  up3=NULL;//new long double[NumCodons];
  down=new long double[NumCodons];
  down2=new long double[NumCodons];
  down3=new long double[NumCodons];//Could perhaps modify this to put similar types of lists together in memory.
  n=0;
  int depth=0;
  for(int i=0;i<l;i++){
    if(*(s+i)=='('){
      depth++;
    }else if(*(s+i)==')'){
      depth--;
    }else if(*(s+i)==','&&depth==1){
      n++;
    };
  };
  for(;*s==' '||*s=='\t'||*s=='\r'||*s=='\n';s++){
    l--;
  };
  if(n==0){
    int len=l+1;
    if(*s=='('){
      len-=2;
      s++;
    };
    label=new char[len];
    for(int i=0;i<len-1;i++){
      *(label+i)=*(s+i);
    };
    *(label+len-1)='\0';
    //strip trailing whitespace
    for(int i=len-2;*(label+i)==' '||*(label+i)=='\t'||*(label+i)=='\r'||*(label+i)=='\n';*(label+i--)='\0');
    return;
  };
  label=NULL;
  n++;
  if(depth!=0){
    char dep[5];//If parantheses are mismatched worse than this, we
		//have a problem.
    sprintf(dep,"%d",depth);
    char *x=new char[100+strlen(s)];
    strcpy(x,"Mismatched parantheses in tree definition. \"");
    strcat(x,s);
    strcat(x,"\"\n");
    strcat(x,"a total of ");
    strcat(x,dep);
    strcat(x," parantheses are unmatched.");
    recoverableError(x);
    delete[] x;
  };
  //  depth=0;
  length=new long double[n];
  subtree=new tree[n];
  int j=0;
  int kold=1;
  for(int i=0;i<l;i++){
    for(;*(s+i)==' '||*(s+i)=='\t'||*(s+i)=='\r'||*(s+i)=='\n';i++);
    if(*(s+i)=='('){
      depth++;
    }else if(*(s+i)==')'){
      depth--;
    }else if(*(s+i)==','&&depth==1){
      int k=i;
      for(;k>kold&&(*(s+k)!=':')&&(*(s+k)!=')');k--);
      if(k==kold){
	*(subtree+j)=tree(i-kold,s+kold);
	*(length+j)=1;
      }else if(*(s+k)==':'){
	*(subtree+j)=tree(k-kold,s+kold);
	*(length+j)=strtod(s+k+1,&rubbish);
      }else{
	*(subtree+j)=tree(k-kold+1,s+kold);
	*(length+j)=1;
      };
      j++;
      kold=i+1;
    };
  };
  int k=l-1;
  for(;k>kold&&*(s+k)!=':';k--);
  if(k==kold){
    *(length+j)=1;
    k=l-1;
    for(;*(s+k)!=')';k--);
    //    k--;
  }else{
    *(length+j)=strtod(s+k+1,&rubbish);
  };
  *(subtree+j)=tree(k-kold,s+kold);
  this->setextra(this->edges());
};

sequence *getdata(ifstream& f,const tree& T){
  streampos st=f.tellg();
  int numseq;
  int len;
  sequence *seq=new sequence[T.leaves()];
  char *rd=new char[50];
  int i;
  int* ass=new int[T.leaves()];
  for(int i=0;i<T.leaves();i++){
    *(ass+i)=1;
  };
  int assno=0;
  char *firstline=readstring(f,"\n");
  try{
    readline(firstline,"uU",&numseq,-1,&len);
  }catch(char x){//firstline doesn't give general information
    f.seekg(st);
    len=-1;
    numseq=-1;
  };
  //  f.clear();
  while(f.good()){
    f.get(*rd);
    for(;f.good()&&(*rd==' '||*rd=='\n'||*rd=='\r'||*rd=='\t');f.get(*rd));
    int i=0;
    for(;i<49&&f.good()&&*(rd+i)!=' '&&*(rd+i)!='\t'&&*(rd+i)!='\r'&&*(rd+i)!='\n';f.get(*(rd+(++i))));
    *(rd+i)='\0';
    //    f.get(rd+1,49,' ');
    //    cout<<"\""<<rd<<"\"\n";
    i=T.findlabel(rd);
    if(i==-1){
      for(char c=' ';c!='\n'&&f.good();f.get(c));
    }else{
      try{
	if(len==-1){
	  (seq+i)->assign(f);
	}else{
	  (seq+i)->assign(f,len);
	};
	if(*(ass+i)){       
	  *(ass+i)=0;
	  assno++;
	};
      }catch(int i){//IO error reading sequence
	char *x=new char[50+strlen(rd)];
	strcpy(x,"Problem reading sequence for species \"");
	strcat(x,rd);
	strcat(x,"\"");
	recoverableError(x);
	delete[] x;
      };
    };
  };
  if(assno<T.leaves()){//No data for some nodes
    //Should rewrite this to use error functions.
    //But need to allow T.printspecies to output a string.
    //Change this to specify the data file and tree file.
    cerr<<"Unable to find all data sequences.\n";
    cerr<<"Data missing for species:\n";
    T.printspecies(cerr,ass);
    exit(1);
  };
  delete[] rd;
  delete[] ass;
  delete[] firstline;
  return seq;
};



Mixture::Mixture(const char *s,int n){
  num=n;
  this->assign(s);
};

Mixture::Mixture(istream& s,int n){
  num=n;
  this->assign(s);
};


linklist getmixturerow(const char *&t,linkedlist<int> &row,int num, int rn, long double *lb,long double *ub){
  //  cout<<t<<"\n";
  linklist dists;
  int nextcodeddist=num+11;
  const char *currentdistname=NULL;
  int *bm=new int[num];
  if(*t&&*t!='\n'&&*t!=';'){//Pattern present, delete previous pattern.
    row.clear();
    for(int i=0;i<num;i++){
      *(bm+i)=-1;
    };
    //      cur.clear();
  };
  linkedlist<int> cur;
  //  int *bm=new int[num];
  int rf=-1;
  int rs=-1;
  int ps=0;
  for(;*t&&*t!='\n'&&*t!=';';){//read pattern
    int indist=0;
    if(isdigit(*t)){
      ps=atoi(t);
      if(ps<0){
	ps=0;
      };
      if(ps>=num){
	ps=num-1;//Not good.
      };
      for(;isdigit(*t);t++);
      for(;*t==' '||*t=='\t'||*t=='\r';t++);
      if(*t=='('){//range
	//	  cout<<t<<"\n";
	for(t++;*t==' '||*t=='\t'||*t=='\r';t++);
	if(*t!='_'&&*t!=','){//Lower bound
	  char *tt;
	  *(lb+rn*(num+1)+ps+1)=strtod(t,&tt);
	  t=tt;
	  *(ub+rn*(num+1)+ps+1)=*(lb+rn*(num+1)+ps+1)-0.5;
	};
	for(;*t&&*t!='\n'&&*t!=')'&&*t!=',';t++);
	t++;
	//	  cout<<t<<"\n";
	for(;*t==' '||*t=='\t'||*t=='\r';t++);
	if(*t!='_'&&*t!=')'){//Upper bound
	  long double comp=*(lb+rn*(num+1)+ps+1)-*(ub+rn*(num+1)+ps+1);
	  char *tt;
	  *(ub+rn*(num+1)+ps+1)=strtod(t,&tt);
	  t=tt;
	  if(comp>0.9){//No lower bound
	    *(lb+rn*(num+1)+ps+1)=*(ub+rn*(num+1)+ps+1)+1.5;
	  };
	};
	for(;*t&&*t!='\n'&&*t!=')';t++);
	if(!*t){
	  fatalError("Error reading mixture string.");
	};
	for(t++;*t==' '||*t=='\t'||*t=='\r';t++);
      };
      //	lastjoinrow=joinrow;
      if(rf!=-1){//Fill in from previous pattern
	if(rf<ps){
	  for(int i=rf+1;i<=ps;i++){	      
	    if(*(bm+i)==-1){
	      *(bm+i)=1;
	      cur.insert(1,&i);
	    };
	  };
	}else{
	  for(int i=rf-1;i>=ps;i++){	      
	    if(*(bm+i)==-1){
	      *(bm+i)=1;
	      cur.insert(1,&i);
	    };
	  };
	};
      }else if(rs!=-1){
	row.insert(cur);
	cur.clear();
	if(rs<ps){
	  for(int i=rs+1;i<ps;i++){	      
	    if(*(bm+i)==-1){
	      *(bm+i)=1;
	      row.insert(1,&i);
	    };
	  };
	}else{
	  for(int i=rs-1;i>ps;i++){	      
	    if(*(bm+i)==-1){
	      *(bm+i)=1;
	      row.insert(1,&i);
	    };
	  };
	};
	cur.insert(1,&ps);
      }else{
	cur.insert(1,&ps);
	*(bm+ps)=1;
      };
      rs=-1;
      rf=-1;
    }else if(*t=='.'){
      rs=ps;
      t++;
    }else if(*t=='-'){
      rf=ps;
      t++;
    }else if(*t==','){
      row.insert(cur);
      if(indist>=0){
	indist+=row.sz;
      };
      cur.clear();
      t++;
    }else if(*t=='<'){
      //      cout<<"Inserting coded element: "<<nextcodeddist<<"\n";
      row.insert(1,&nextcodeddist);
      nextcodeddist++;
      t++;
      currentdistname=t;
      for(;*t&&*t!=' '&&*t!='\t'&&*t!='\r'&&*t!='>';t++);
      indist=0;
    }else if(*t=='>'){
      if(cur.sz>0&&rf==-1){
	row.insert(cur);
	indist+=row.sz;
	cur.clear();
      };
      if(rf!=-1){//Ends with a -
	ps=num-1;
	for(int i=rf+1;i<=ps;i++){	      
	  if(*(bm+i)==-1){
	    *(bm+i)=1;
	    cur.insert(1,&i);
	  };
	};
	row.insert(cur);
	indist+=row.sz;
	cur.clear();
      }else if(rs!=-1){
	ps=num-1;
	for(int i=rs+1;i<=ps;i++){	      
	  //	  cout<<"indist="<<indist<<" i="<<i<<"\n";
	  if(*(bm+i)==-1){
	    *(bm+i)=1;
	    row.insert(1,&i);
	    indist++;
	  };
	};
      };
      dists.insert(getdistribution(currentdistname,indist));
      int codeddistnum0=num+10;
      row.insert(1,&codeddistnum0);
      indist=-1;      
      t++;
    }else/* if(*t==':')*/{
      t++;
    };
  };
  if(cur.sz>0&&rf==-1){
    row.insert(cur);
    cur.clear();
  };
  if(rf!=-1){//Ends with a -
    ps=num-1;
    for(int i=rf+1;i<=ps;i++){	      
      if(*(bm+i)==-1){
	*(bm+i)=1;
	cur.insert(1,&i);
      };
    };
    row.insert(cur);
    cur.clear();
  }else if(rs!=-1){
    ps=num-1;
    for(int i=rs+1;i<=ps;i++){	      
      if(*(bm+i)==-1){
	*(bm+i)=1;
	row.insert(1,&i);
      };
    };
  };
  cur.remove();
  delete[] bm;
  return dists;
};

void fillrow(int num,const linkedlist<int> &row,int *cl,int *joinrow,int *dists,int &nextcl,int &nextdist){
  *cl=1;
  int currentdist=-1;
  if(joinrow==NULL){//New blocks for each row
    for(const linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
      /*      if(rw->sz>0){
	cout<<*(rw->l)<<"\n";
	};*/
      if(rw->sz>0&&*(rw->l)==num+10){
	currentdist=nextdist++;
	//cout<<"Distribution number: "<<currentdist<<"\n";
      }else if(rw->sz>0&&*(rw->l)>num){
	currentdist=-1;
      }else{
	for(unsigned int j=0;j<rw->sz;j++){
	  if(*(cl+1+*(rw->l+j))==-1){
	    *(cl+1+*(rw->l+j))=nextcl;
	    *(dists+*(rw->l+j))=currentdist;
	  }else{
	    nextcl--;
	    break;
	  };
	};
	if(rw->sz>0){
	  nextcl++;
	};
      };
    };
  }else{//Use same blocks for all rows
    for(const linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
      int cno=*(joinrow+1+*(rw->l));
      for(unsigned int j=0;j<rw->sz;j++){
	*(cl+1+*(rw->l+j))=cno;
      };
    };
  };
};

void fillwithrow(int num,int from, int rn,const linkedlist<int> &row,int joinrow,int *cl,int *dists,int &nextcl,int &nextdist,linklist &alldists,linklist &dsts){
  //Need to copy upper and lower bounds(?)
  if(from<rn){
    for(int i=from+1;i<rn;i++){
      alldists.insertcplst(dsts);
      if(*(cl+i*(num+1))==-1){
	int *jr=(joinrow==-1)?NULL:cl+joinrow*(num+1);
	fillrow(num,row,jr,cl+i*(num+1),dists+i*num,nextcl,nextdist);
      };
    };
  }else{
    for(int i=from-1;i>rn;i--){
      alldists.insertcplst(dsts);
      if(*(cl+i*(num+1))==-1){
	int *jr=(joinrow==-1)?NULL:cl+joinrow*(num+1);
	fillrow(num,row,jr,cl+i*(num+1),dists+i*num,nextcl,nextdist);
      };
    };
  };
};

int Mixture::getparptr(int i){
  if(dists==NULL){
    return i;
  };
  Distribution **curr=dist;
  int * skip=distpnum;
  int *d=dists;
  int j=0;
  for(;*d<npars&&*d<i;d++){
    j++;
    if(*curr!=NULL&&j==*skip){
      skip++;
      j+=(*(curr++))->pars;
    };
  };
  return j;
};

void Mixture::assign(const char *s){
  linklist alldists;
  linklist distsll;
  const char *t=s;
  int rn=0;
  int *cl=new int[(num+1)*params::numpars];
  int *dn=new int[num*params::numpars];
  for(int i=0;i<num*params::numpars;i++){
    *(dn+i)=-1;
  };
  int dstno=0;
  for(int i=0;i<(num+1)*params::numpars;i++){
    *(cl+i)=-1;
  };
  long double *lb=new long double[(num+1)*params::numpars];
  long double *ub=new long double[(num+1)*params::numpars];
  for(int i=0;i<(num+1)*params::numpars;i++){
    *(lb+i)=1;
    *(ub+i)=0;//ub = lb-1 means no bounds set. ub=lb-1/2 means no ub set. ub= lb-3/2 means no lb.
  };
  int nextcl=0;
  int joinrow=-1;
  int lastjoinrow=-1;
  int from=-1;
  //  linkedlist<int> cur;
  linkedlist<int> row;
  for(;*t;){
    //First deal with row number
    for(;*t==' '||*t=='\t'||*t=='\r'||*t=='\n'||*t==';';t++);
    if(isdigit(*t)){
      rn=atoi(t);
      if(rn>=params::numpars){
	if(from==-1){
	  for(;*t&&*t!='\n'&&*t!=';';t++);
	  continue;
	}else{
	  rn=params::numpars;
	};
	//Could give surprising behaviour. Should improve this.
	//Danger if there is a range higher than numpars.
      };
      for(;isdigit(*t);t++);
      for(;*t==' '||*t=='\t'||*t=='\r';t++);
      lastjoinrow=joinrow;
      if(from!=-1){//Fill in from previous pattern
	fillwithrow(num,from,rn,row,joinrow,cl,dn,nextcl,dstno,alldists,distsll);
	joinrow=-1;
      };
      from=-1;
    }else if(*t=='.'){
      from=rn;
      t++;
    }else if(*t=='|'){
      if(lastjoinrow==-1){
	joinrow=rn;
      }else{
	joinrow=lastjoinrow;
      };
      //Ignore rest of line;
      for(;*t&&*t!='\n'&&*t!=';';t++);
      continue;
    };
    for(;*t==' '||*t=='\t'||*t=='\r';t++);
    distsll.unlink();
    distsll=getmixturerow(t,row,num,rn,lb,ub);
    alldists.insertcplst(distsll);
    if(from!=rn){
      int *jr=(joinrow==-1)?NULL:cl+joinrow*(num+1);
      fillrow(num,row,cl+rn*(num+1),jr,dn+rn*num,nextcl,dstno);
      joinrow=-1;
    };
    //    delete[] bm;
  };
  if(from!=-1){
    fillwithrow(num,from,params::numpars,row,joinrow,cl,dn,nextcl,dstno,alldists,distsll);
  };
  //Collected all information. Now just need to sort into data structure.

  npars=nextcl;
  numconstraints=0;
  int pos=0;
  for(int i=0;i<params::numpars;i++){
    for(int j=1;j<=num;j++){
      if(*(cl+i*(num+1)+j)>=0){
	pos++;
      };
      long double comp=*(ub+i*(num+1)+j)-*(lb+i*(num+1)+j);
      if(comp>0){
	numconstraints+=2;
      }else if(comp>-0.9||comp<-1.1){
	numconstraints++;
      };
    };
  };
  pars=new int[pos+1];
  int ps=0;
  int con=0;
  long double one=1;
  long double minus=-1;
  for(int parno=0;parno<npars;parno++){
    int sn=1;
    for(int i=0;i<params::numpars;i++){
      for(int j=1;j<=num;j++){
	if(*(cl+i*(num+1)+j)==parno){
	  *(pars+ps++)=sn*((j-1)*params::numpars+i);
	  sn=-1;
	};
      };
    };
  };
  *(pars+ps)=0;
  inpars=npars;
  dists=NULL;
  if(dstno>0){//some distributions
    dist=new Distribution*[dstno+1];
    *(dist+dstno)=NULL;
    dists=new int[npars+dstno+1];
    distpnum=new int[dstno];
    linklist *ll=&alldists;
    for(int i=dstno-1;i>=0;i--){
      for(;ll->data==NULL&&ll->next!=NULL;ll=ll->next);
      *(distpnum+i)=-1;
      *(dist+i)=(Distribution *)ll->data;
      ll=ll->next;
    };
    int *used=new int[npars];
    for(int i=0;i<npars;i++){
      *(used+i)=0;
    };
    int ps=0;
    for(int distrno=-1;distrno<dstno;distrno++){
      for(int i=0;i<params::numpars;i++){
	for(int j=1;j<=num;j++){
	  if(*(dn+i*(num)+j-1)==distrno&&*(cl+i*(num+1)+j)>=0&&!*(used+*(cl+i*(num+1)+j))){
	    *(dists+ps++)=*(cl+i*(num+1)+j);
	    *(used+*(cl+i*(num+1)+j))=1;
	  };
	};
      };
      *(dists+ps++)=npars+10;
    };    
    delete[] used;
    int tp=0;
    for(int i=0;*(pars+i);){
      if(*(dn+*(pars+i))>=0){
	if(*(distpnum+*(dn+*(pars+i)))==-1){
	  *(distpnum+*(dn+*(pars+i)))=tp;
	  tp+=(*(dist+*(dn+*(pars+i))))->pars;
	  inpars+=(*(dist+*(dn+*(pars+i))))->pars-(*(dist+*(dn+*(pars+i))))->num;
	  //Add constraints
	  numconstraints+=(*(dist+*(dn+*(pars+i))))->numconstraints();
	};
      }else{
	tp++;
      };
      for(i++;*(pars+i)<0;i++);
    };
  };
  cst=new constraint[numconstraints];
  for(int i=0;i<params::numpars;i++){
    for(int j=1;j<=num;j++){
      //      cout<<*(ub+i*(num+1)+j)<<"\t";
      //      cout<<*(cl+i*(num+1)+j)<<"\t";
      long double comp=*(ub+i*(num+1)+j)-*(lb+i*(num+1)+j);
      int vn=this->getparptr(*(cl+i*(num+1)+j));
      if(comp>0){
	(cst+con++)->set(1,*(ub+i*(num+1)+j),&vn,&one);
	(cst+con++)->set(1,-*(lb+i*(num+1)+j),&vn,&minus);
      }else if(comp>-0.9){
	(cst+con++)->set(1,-*(lb+i*(num+1)+j),&vn,&minus);
      }else if(comp<-1.1){
	(cst+con++)->set(1,*(ub+i*(num+1)+j),&vn,&one);
      };
    };
    //    cout<<"\n";
  };
  for(int i=0;i<dstno;i++){
    (*(dist+i))->putconstraint(cst+con,*(distpnum+i));
    con+=(*(dist+i))->numconstraints();
  };
  delete[] cl;
  delete[] dn;
  delete[] lb;
  delete[] ub;
  alldists.unlink();
  //  cur.remove();
  row.remove();
  //  this->print();
};


//Need to rewrite this to allow distributions.

void Mixture::assign(istream &s){
  int rn=0;
  int *cl=new int[(num+1)*params::numpars];
  for(int i=0;i<(num+1)*params::numpars;i++){
    *(cl+i)=-1;
  };
  long double *lb=new long double[(num+1)*params::numpars];
  long double *ub=new long double[(num+1)*params::numpars];
  for(int i=0;i<(num+1)*params::numpars;i++){
    *(lb+i)=1;
    *(ub+i)=0;//ub = lb-1 means no bounds set. ub=lb-1/2 means no ub set. ub= lb-3/2 means no lb.
  };
  int nextcl=0;
  int joinrow=-1;
  int lastjoinrow=-1;
  int from=-1;
  linkedlist<int> cur;
  linkedlist<int> row;
  char x[2];
  x[1]='\0';
  for(;s.good()&&!s.eof();){
    for(;s.good()&&!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r'||s.peek()=='\n'||s.peek()==';');s.get());
    if(s.good()&&!s.eof()&&isdigit(s.peek())){
      rn=0;
      for(;s.good()&&!s.eof()&&isdigit(s.peek());){
	rn*=10;
	x[0]=s.get();
	rn+=atoi(x);
      };
      if(rn>=params::numpars){
	if(from==-1){
	  for(;s.good()&&!s.eof()&&s.peek()!='\n'&&s.peek()!=';';s.get());
	  continue;
	}else{
	  rn=params::numpars;
	};
	//Could give surprising behaviour. Should improve this.
      };
      for(;s.good()&&!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r');s.get());
      lastjoinrow=joinrow;
      if(from!=-1){//Fill in from previous pattern
	if(from<rn){
	  for(int i=from+1;i<rn;i++){
	    if(*(cl+i*(num+1))==-1){
	      *(cl+i*(num+1))=1;
	      if(joinrow==-1){//New blocks for each row
		for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
		  for(unsigned int j=0;j<rw->sz;j++){
		    *(cl+i*(num+1)+1+*(rw->l+j))=nextcl;
		  };
		  if(rw->sz>0){
		    nextcl++;
		  };
		};
	      }else{//Use same blocks for all rows
		for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
		  int cno=*(cl+joinrow*(num+1)+1+*(rw->l));
		  for(unsigned int j=0;j<rw->sz;j++){
		    *(cl+i*(num+1)+1+*(rw->l+j))=cno;
		  };
		};
	      };
	    };
	  };
	}else{
	  for(int i=from-1;i>rn;i--){
	    if(*(cl+i*(num+1))==-1){
	      *(cl+i*(num+1))=1;
	      if(joinrow==-1){//New blocks for each row
		for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
		  for(unsigned int j=0;j<rw->sz;j++){
		    *(cl+i*(num+1)+1+*(rw->l+j))=nextcl;
		  };
		  if(rw->sz>0){
		    nextcl++;
		  };
		};
	      }else{//Use same blocks for all rows
		for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
		  int cno=*(cl+joinrow*(num+1)+1+*(rw->l));
		  for(unsigned int j=0;j<rw->sz;j++){
		    *(cl+i*(num+1)+1+*(rw->l+j))=cno;
		  };
		};
	      };
	    };
	  };
	};
      };
      from=-1;
    }else if(s.good()&&!s.eof()&&s.peek()=='.'){
      from=rn;
      s.get();
      //      for(;s.good()&&!s.eof()&&s.peek()!='\n'&&s.peek()!=';';s.get());
      //      continue;
    }else if(s.good()&&!s.eof()&&s.peek()=='|'){
      if(lastjoinrow==-1){
	joinrow=rn;
      }else{
	joinrow=lastjoinrow;
      };
      //Ignore rest of line;
      for(;s.good()&&!s.eof()&&s.good()&&!s.eof()&&s.peek()!='\n'&&s.peek()!=';';s.get());
      continue;
    };
    for(;s.good()&&!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r');s.get());
    int *bm=new int[num];
    if(s.good()&&!s.eof()&&s.peek()!='\n'&&s.peek()!=';'){//Pattern present, delete previous pattern.
      row.clear();
      for(int i=0;i<num;i++){
	*(bm+i)=-1;
      };
      cur.clear();
    };
    int rf=-1;
    int rs=-1;
    int ps=0;
    for(;s.good()&&!s.eof()&&s.peek()!='\n'&&s.peek()!=';';){//read pattern
      if(isdigit(s.peek())){
	ps=0;
	for(;s.good()&&!s.eof()&&isdigit(s.peek());){
	  ps*=10;
	  x[0]=s.get();
	  ps+=atoi(x);
	};
	if(ps<0){
	  ps=0;
	};
	if(ps>=num){
	  ps=num-1;//Not good.
	};
	for(;s.good()&&!s.eof()&&isdigit(s.peek());s.get());
	for(;s.good()&&!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r');s.get());
	if(s.peek()=='('){//range
	  //	  cout<<t<<"\n";
	  for(s.get();!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r');s.get());
	  if(s.peek()!='_'&&s.peek()!=','){//Lower bound
	    s>>*(lb+rn*(num+1)+ps+1);
	    *(ub+rn*(num+1)+ps+1)=*(lb+rn*(num+1)+ps+1)-0.5;
	  };
	  for(;!s.eof()&&s.peek()!='\n'&&s.peek()!=')'&&s.peek()!=',';s.get());
	  if(!s.eof()){
	    s.get();
	  };
	  //	  cout<<t<<"\n";
	  for(;!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r');s.get());
	  if(s.eof()||(s.peek()!='_'&&s.peek()!=')')){//Upper bound
	    long double comp=*(lb+rn*(num+1)+ps+1)-*(ub+rn*(num+1)+ps+1);
	    s>>*(ub+rn*(num+1)+ps+1);
	    if(comp>0.9){//No lower bound
	      *(lb+rn*(num+1)+ps+1)=*(ub+rn*(num+1)+ps+1)+1.5;
	    };
	  };
	  for(;!s.eof()&&s.peek()!='\n'&&s.peek()!=')';s.get());
	  if(s.eof()){
	    fatalError("Error reading mixture file.");
	  };
	  for(s.get();!s.eof()&&(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r');s.get());
	};
	//	lastjoinrow=joinrow;
	if(rf!=-1){//Fill in from previous pattern
	  if(rf<ps){
	    for(int i=rf+1;i<=ps;i++){	      
	      if(*(bm+i)==-1){
		*(bm+i)=1;
		cur.insert(1,&i);
	      };
	    };
	  }else{
	    for(int i=rf-1;i>=ps;i++){	      
	      if(*(bm+i)==-1){
		*(bm+i)=1;
		cur.insert(1,&i);
	      };
	    };
	  };
	}else if(rs!=-1){
	  row.insert(cur);
	  cur.clear();
	  if(rs<ps){
	    for(int i=rs+1;i<ps;i++){	      
	      if(*(bm+i)==-1){
		*(bm+i)=1;
		row.insert(1,&i);
	      };
	    };
	  }else{
	    for(int i=rs-1;i>ps;i++){	      
	      if(*(bm+i)==-1){
		*(bm+i)=1;
		row.insert(1,&i);
	      };
	    };
	  };
	  cur.insert(1,&ps);
	}else{
	  cur.insert(1,&ps);
	  *(bm+ps)=1;
	};
	rs=-1;
	rf=-1;
      }else if(s.good()&&!s.eof()&&s.peek()=='.'){
	rs=ps;
	s.get();
      }else if(s.good()&&!s.eof()&&s.peek()=='-'){
	rf=ps;
	s.get();
      }else if(s.good()&&!s.eof()&&s.peek()==','){
	row.insert(cur);
	cur.clear();
	s.get();
      }else if(s.good()&&!s.eof()/*&&s.peek()==':'*/){
	s.get();
      };
    };
    if(cur.sz>0&&rf==-1){
      row.insert(cur);
      cur.clear();
    };
    if(rf!=-1){//Ends with a -
      ps=num-1;
      for(int i=rf+1;i<=ps;i++){	      
	if(*(bm+i)==-1){
	  *(bm+i)=1;
	  cur.insert(1,&i);
	};
      };
      row.insert(cur);
      cur.clear();
    }else if(rs!=-1){
      ps=num-1;
      for(int i=rs+1;i<=ps;i++){	      
	if(*(bm+i)==-1){
	  *(bm+i)=1;
	  row.insert(1,&i);
	};
      };
    };
    if(from!=rn){
      if(joinrow==-1){
	for(linkedlist<int>* rw=&row;rw!=NULL;rw=rw->next){
	  for(unsigned int i=0;i<rw->sz;i++){
	    *(cl+rn*(num+1)+1+*(rw->l+i))=nextcl;
	  };
	  if(rw->sz>0){
	    nextcl++;
	  };
	};
	*(cl+rn*(num+1))=1;
      }else{
	for(linkedlist<int>* rw=&row;rw!=NULL;rw=rw->next){
	  int cno=*(cl+joinrow*(num+1)+1+*(rw->l));
	  for(unsigned int i=0;i<rw->sz;i++){
	    *(cl+rn*(num+1)+1+*(rw->l+i))=cno;
	  };
	};
	*(cl+rn*(num+1))=1;
	joinrow=-1;
      };
    };
    delete[] bm;
  };
  if(from!=-1){
    rn=params::numpars;
    if(from<rn){
      for(int i=from+1;i<rn;i++){
	if(*(cl+i*(num+1))==-1){
	  *(cl+i*(num+1))=1;
	  if(joinrow==-1){//New blocks for each row
	    for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
	      for(unsigned int j=0;j<rw->sz;j++){
		*(cl+i*(num+1)+1+*(rw->l+j))=nextcl;
	      };
	      if(rw->sz>0){
		nextcl++;
	      };
	    };
	  }else{//Use same blocks for all rows
	    for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
	      int cno=*(cl+joinrow*(num+1)+1+*(rw->l));
	      for(unsigned int j=0;j<rw->sz;j++){
		*(cl+i*(num+1)+1+*(rw->l+j))=cno;
	      };
	    };
	  };
	};
      };
    }else{
      for(int i=from-1;i>rn;i--){
	if(*(cl+i*(num+1))==-1){
	  *(cl+i*(num+1))=1;
	  if(joinrow==-1){//New blocks for each row
	    for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
	      for(unsigned int j=0;j<rw->sz;j++){
		*(cl+i*(num+1)+1+*(rw->l+j))=nextcl;
	      };
	      if(rw->sz>0){
		nextcl++;
	      };
	    };
	  }else{//Use same blocks for all rows
	    for(linkedlist<int> *rw=&row;rw!=NULL;rw=rw->next){
	      int cno=*(cl+joinrow*(num+1)+1+*(rw->l));
	      for(unsigned int j=0;j<rw->sz;j++){
		*(cl+i*(num+1)+1+*(rw->l+j))=cno;
	      };
	    };
	  };
	};
      };
    };    
  };
  npars=nextcl;
  numconstraints=0;
  int pos=0;
  for(int i=0;i<params::numpars;i++){
    for(int j=1;j<=num;j++){
      if(*(cl+i*(num+1)+j)>=0){
	pos++;
      };
      long double comp=*(ub+i*(num+1)+j)-*(lb+i*(num+1)+j);
      if(comp>0){
	numconstraints+=2;
      }else if(comp>-0.9||comp<-1.1){
	numconstraints++;
      };
    };
  };
  cst=new constraint[numconstraints];
  pars=new int[pos+1];
  int ps=0;
  int con=0;
  long double one=1;
  long double minus=-1;
  for(int parno=0;parno<npars;parno++){
    int sn=1;
    for(int i=0;i<params::numpars;i++){
      for(int j=1;j<=num;j++){
	if(*(cl+i*(num+1)+j)==parno){
	  *(pars+ps++)=sn*((j-1)*params::numpars+i);
	  sn=-1;
	};
      };
    };
  };
  for(int i=0;i<params::numpars;i++){
    for(int j=1;j<=num;j++){
      long double comp=*(ub+i*(num+1)+j)-*(lb+i*(num+1)+j);
      if(comp>0){
	(cst+con++)->set(1,*(ub+i*(num+1)+j),(cl+i*(num+1)+j),&one);
	(cst+con++)->set(1,-*(lb+i*(num+1)+j),(cl+i*(num+1)+j),&minus);
      }else if(comp>-0.9){
	(cst+con++)->set(1,-*(lb+i*(num+1)+j),(cl+i*(num+1)+j),&minus);
      }else if(comp<-1.1){
	(cst+con++)->set(1,*(ub+i*(num+1)+j),(cl+i*(num+1)+j),&one);
      };
    };
  };
  *(pars+ps)=0;
  delete[] cl;
  delete[] lb;
  delete[] ub;
  cur.remove();
  row.remove();
  this->Normalise();
};

