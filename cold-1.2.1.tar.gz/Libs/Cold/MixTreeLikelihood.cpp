/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "MixTreeLikelihood.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <math.h>

double sqrt(double);


#include "ErrorHandler.h"
#include "Macros.h"
#include "Matrix.h"
#include "Miscellaneous.h"
#include "Sequence.h"
#include "Parameters.h"
#include "Optimisation.h"
#include "Tree.h"
#include "TreeLikelihood_base.h"
#include "Distributions.h"

using namespace std;
extern ostream& comm;//commentry;
// Code needed for optimisation.

void Mixture::insvars(int i){
  for(unsigned int j=0;j<numconstraints;j++){
    (cst+j)->add(i);
  };
};

Mixture::~Mixture(){
  if(pars!=NULL){
    delete[] pars;
  };
  if(cst!=NULL){
    delete[] cst;
  };
  if(dists!=NULL){
    for(Distribution **d=dist;*d!=NULL;d++){
      deletedistribution(*d);
    };
    delete[] dists;
    delete[] dist;
    delete[] distpnum;
  };
};

void Mixture::Normalise(int offset){
  long double *dv=new long double[offset+npars];
  int *p=pars;
  for(int i=0;i<npars;i++){
    *(dv+offset+i)=*(params::A.entries+(*p%params::numpars)*(params::A.sz+1));
    p++;
    for(;*p<0;p++);
  };
  for(unsigned int j=0;j<numconstraints;j++){
    (cst+j)->normalise(dv);
  };
  delete[] dv;
};

long double *Mixture::applydistributions(const long double *vals,int scale){
  long double *ans=new long double[npars];
  int *d=dists;
  Distribution** curr=dist;
  int *skip=distpnum;
  if(d!=NULL){
    for(int i=0;*d<npars;d++){
      *(ans+*d)=*(vals+i);
      i++;
      if(*curr!=NULL&&i==*skip){
	skip++;
	i+=(*(curr++))->pars;
      };
    };
    for(int i=0;*(dist+i)!=NULL;i++){
      long double *dans=(*(dist+i))->vals(vals+*(distpnum+i));
      int j=0;
      for(d++;*d<npars;d++){
	*(ans+*d)=*(dans+j);
	if(scale){
	  *(ans+*d)/=(*(params::A.entries+(getparno(*d)%params::numpars)*(params::numpars+1)));
	};
	j++;
      };
      delete[] dans;
    };
  }else{
    for(int i=0;i<npars;i++){
      *(ans+i)=*(vals+i);
    };
  };
  return ans;
};

void Mixture::showdistpars(ostream &out,const long double *x){
  if(dist!=NULL){
    for(int i=0;*(dist+i)!=NULL;i++){
      out<<"For Distribution "<<i<<", parameters are:\n\n";
      for(int j=0;j<(*(dist+i))->pars;j++){
	out<<*(x+*(distpnum+i)+j)<<"  ";
      };
      out<<"\n";
    };
  };
};


void Mixture::seeddists(const long double *seeds,long double *out){
  int *d=dists;
  Distribution** curr=dist;
  int *skip=distpnum;
  if(d!=NULL){
    for(int i=0;*d<npars;d++){
      *(out+i)=*(seeds+*d);
      i++;
      if(*curr!=NULL&&i==*skip){
	skip++;
	i+=(*(curr++))->pars;
      };
    };
    for(int i=0;*(dist+i)!=NULL;i++){
      long double *s=new long double[(*(dist+i))->num];
      d++;
      for(int j=0;j<(*(dist+i))->num;j++){
	*(s+j)=*(seeds+*d)*(*(params::A.entries+(getparno(*d)%params::numpars)*(params::numpars+1)));
	d++;
      };
      (*(dist+i))->seed(s,out+*(distpnum+i));
      delete[] s;
    };
  }else{
    for(int i=0;i<npars;i++){
      *(out+i)=*(seeds+i);
    };
  };
};

void Mixture::writedists(const long double *seeds,const long double *dpars,long double *out){
  int *d=dists;
  Distribution** curr=dist;
  int *skip=distpnum;
  const long double *dp=dpars;
  if(d!=NULL){
    for(int i=0;*d<npars;d++){
      *(out+i)=*(seeds+*d);
      i++;
      if(*curr!=NULL&&i==*skip){
	skip++;
	i+=(*(curr++))->pars;
      };
    };
    for(int i=0;*(dist+i)!=NULL;i++){
      for(int j=0;j<(*(dist+i))->pars;j++){
	*(out+*(distpnum+i)+j)=*(dp++);
      };
    };
  }else{
    for(int i=0;i<npars;i++){
      *(out+i)=*(seeds+i);
    };
  };
};

void Mixture::sumdistderivpars(const long double *vals,const long double* in,long double *out){
  int *d=dists;
  Distribution** curr=dist;
  int *skip=distpnum;
  if(d==NULL){
    for(int i=0;i<npars;i++){
      *(out+i)=*(in+i);
    };
  }else{
    for(int i=0;*d<npars;d++){      
      *(out+i)=*(in+*d);
      i++;
      if(*curr!=NULL&&i==*skip){
	skip++;
	i+=(*(curr++))->pars;
      };
    };
    for(int i=0;*(dist+i)!=NULL;i++){
      long double *dans=(*(dist+i))->derivvals(vals+*(distpnum+i));
      int j=0;
      for(int *dd=d+1;*dd<npars;dd++){
	*(dans+j)/=(*(params::A.entries+(getparno(*dd)%params::numpars)*(params::numpars+1)));
	j++;
      };
      j=0;
      for(int k=0;k<(*(dist+i))->pars;k++){
	*(out+*(distpnum+i)+k)=0;
      };
      for(d++;*d<npars;d++){
	for(int k=0;k<(*(dist+i))->pars;k++){
	  *(out+*(distpnum+i)+k)+=*(in+*d)*(*(dans+j));
	  j++;
	};
      };
      delete[] dans;
    };  
  };
};

void Mixture::sumdistsecderparssq(const long double *vals,const long double* in, const long double *in2,long double *out,int dim){
  int *d=dists;
  Distribution** curr=dist;
  int *skip=distpnum;
  if(d==NULL){
    for(int i=0;i<npars;i++){
      for(int j=0;j<npars;j++){
	*(out+i*dim+j)=*(in+i*npars+j);
      };
    };
  }else{
    for(int i=0;*d<npars;d++){
      int *e=dists;
      Distribution** cu=dist;
      int *sk=distpnum;
      for(int j=0;*e<npars;e++){
	*(out+i*dim+j)=*(in+*d*npars+*e);
	j++;
	if(*cu!=NULL&&j==*sk){
	  sk++;
	  j+=(*(cu++))->pars;
	};
      };
      for(int j=0;*(dist+j)!=NULL;j++){
	long double *dans=(*(dist+j))->derivvals(vals+*(distpnum+j));
	int l=0;
	for(int *dd=e+1;*dd<npars;dd++){
	  *(dans+l)/=(*(params::A.entries+(getparno(*dd)%params::numpars)*(params::numpars+1)));
	  l++;
	};
	l=0;
	for(int k=0;k<(*(dist+j))->pars;k++){
	  *(out+i*dim+*(distpnum+j)+k)=0;
	};
	for(e++;*e<npars;e++){
	  for(int k=0;k<(*(dist+j))->pars;k++){
	    *(out+i*dim+*(distpnum+j)+k)+=*(in+*d*npars+*e)*(*(dans+l));
	    l++;
	  };
	};
	delete[] dans;
      };  
      i++;
      if(*curr!=NULL&&i==*skip){
	skip++;
	i+=(*(curr++))->pars;
      };
    };
    for(int i=0;*(dist+i)!=NULL;i++){
      long double *dans=(*(dist+i))->derivvals(vals+*(distpnum+i));
      
      for(int k=0;k<(*(dist+i))->pars;k++){
	for(int j=0;j<inpars;j++){
	  *(out+(*(distpnum+i)+k)*dim+j)=0;
	};
      };
      int l=0;
      for(int *dd=d+1;*dd<npars;dd++){
	for(int k=0;k<((*(dist+i))->pars);k++){
	  *(dans+l)/=(*(params::A.entries+(getparno(*dd)%params::numpars)*(params::numpars+1)));
	  l++;
	};
      };
      l=0;
      long double *sdans=(*(dist+i))->secdervals(vals+*(distpnum+i));
      int ll=0;
      for(int *dd=d+1;*dd<npars;dd++){
	for(int k=0;k<((*(dist+i))->pars)*((*(dist+i))->pars);k++){
	  *(sdans+ll)/=(*(params::A.entries+(getparno(*dd)%params::numpars)*(params::numpars+1)));
	  ll++;	
	};
      };
      for(d++;*d<npars;d++){
	for(int k=0;k<(*(dist+i))->pars;k++){
	  int *e=dists;
	  Distribution** cu=dist;
	  int *sk=distpnum;
	  for(int j=0;*e<npars;e++){
	    *(out+(*(distpnum+i)+k)*dim+j)+=*(in+*d*npars+*e)*(*(dans+l));
	    j++;
	    if(*cu!=NULL&&j==*sk){
	      sk++;
	      j+=(*(cu++))->pars;
	    };
	  };
	  for(int j=0;*(dist+j)!=NULL;j++){
	    long double *dans2=(*(dist+j))->derivvals(vals+*(distpnum+j));
	    int m=0;
	    for(int *ee=e+1;*ee<npars;ee++){
	      for(int k=0;k<(*(dist+j))->pars;k++){
		*(dans2+m)/=(*(params::A.entries+(getparno(*ee)%params::numpars)*(params::numpars+1)));
		m++;
	      };
	    };
	    m=0;
	    for(e++;*e<npars;e++){
	      for(int kk=0;kk<(*(dist+j))->pars;kk++){
		*(out+(*(distpnum+i)+k)*dim+*(distpnum+j)+kk)+=*(in+*d*npars+*e)*(*(dans+l))*(*(dans2+m));
		m++;
	      };
	    };
	    delete[] dans2;
	  }; 
	  l++;	 
	};
	for(int k=0;k<(*(dist+i))->pars;k++){
	  for(int kk=0;kk<(*(dist+i))->pars;kk++){
	    *(out+(*(distpnum+i)+k)*dim+*(distpnum+i)+kk)+=*(in2+*d)*(*(sdans+(l-(*(dist+i))->pars)*(*(dist+i))->pars+k*(*(dist+i))->pars+kk));
	  };
	};
      };
      delete[] sdans;
      delete[] dans;
    };  
  };
};

void Mixture::setpars(const long double *vals,long double *in){
  //Fills the values vals into the appropriate places in the list in.
  int *pos=pars;
  for(int i=0;i<npars&&*pos;i++){
    *(in+*(pos++))=*(vals+i);
    for(;*(pos)<0;pos++){
      *(in-*(pos))=*(vals+i);
    };
  };
};

void Mixture::sumpars(const long double *in,long double *out){
  int *pos=pars;
  for(int i=0;i<npars;i++){
    *(out+i)=*(in+*(pos++));
    for(;*(pos)<0;pos++){
      *(out+i)+=*(in-*(pos));
    };
  };
};

int decsum(int a,int b){
  return (b*(b+1)-(b-a)*(b-a+1))/2;
};

void Mixture::sumparsdecstep(const long double *in,long double *out,int firststep){
  int *pos=pars;
  for(int i=0;i<npars;i++){
    *(out+i)=*(in+decsum(*(pos++),firststep));
    for(;*(pos)<0;pos++){
      *(out+i)+=*(in+decsum(-*(pos),firststep));
    };
  };
};

void Mixture::sumparstrisquare(const long double *dt,long double *to,int dim,int offset){
  int *pos=pars;
  for(int i=0;i<npars;i++){
    int *ps=pars;
    for(int j=0;j<npars;j++){
      *(to+i*(dim)+j)=*(dt+tri(*pos,*(ps++),(num*params::numpars+offset)));
      for(;*(ps)<0;ps++){
	*(to+i*(dim)+j)+=*(dt+tri(*pos,-*ps,(num*params::numpars+offset)));
      };
    };
    for(pos++;*(pos)<0;pos++){
      ps=pars;
      for(int j=0;j<npars;j++){
	*(to+i*(dim)+j)+=*(dt+tri(-*pos,*(ps++),(num*params::numpars+offset)));
	for(;*(ps)<0;ps++){
	  *(to+i*(dim)+j)+=*(dt+tri(-*pos,-*ps,(num*params::numpars+offset)));
	};
      };
    };
  };
};











int Mixtreelikelihood::numsites(){
  return d->length;
};

void Mixtreelikelihood::setblfix(){
  fixbl=1;
  cout<<"dim="<<dim<<"\n";
  dim-=T.numed;
  m.insvars(-T.numed);
};

void Mixtreelikelihood::readpars(std::istream &in){
  for(int i=0;i<num;i++){
    (p+i)->readpars(in);
    *(f+i)=(p+i)->fmatrix();
  };
};

void Mixtreelikelihood::orthpars(){
  params::orthmats();
};


Mixtreelikelihood::~Mixtreelikelihood(){
  delete[] d;
  delete[] p;
  delete[] prob;
  T.up=NULL;
  T.remove();
  for(int i=0;i<num;i++){
    (f+i)->remove();
  };
  delete[] f;
  delete[] lastval;
  if(vals!=NULL){
    delete[] vals;
  };
  delete[] variablepars;  
  if(distpars!=NULL){
    delete[] distpars;
  };
};


void Mixtreelikelihood::setmix(const char*s){
  m.assign(s);
  dim=T.numed+varprobs+m.inpars;
  m.insvars(T.edges()+varprobs);
  int totmxpars=0;
  if(m.dist!=NULL){
    for(int i=0;(*(m.dist+i))!=NULL;i++){
      totmxpars+=(*(m.dist+i))->pars;
    };
    if(distpars!=NULL){
      delete[] distpars;
    };
    distpars=new long double[totmxpars];
  };
};

void Mixtreelikelihood::setmix(std::ifstream& s){
  m.assign(s);
  dim=T.numed+varprobs+m.inpars;
  this->satisfyconstraints();
  m.insvars(T.edges()+varprobs);
  int totmxpars=0;
  for(int i=0;*(m.dist+i)!=NULL;i++){
    totmxpars+=(*(m.dist+i))->pars;
  };
  if(distpars!=NULL){
    delete[] distpars;
  };
  distpars=new long double[totmxpars];
};

void Mixtreelikelihood::printtreedev(const Realmatrix &oi,std::ostream& out){
  long double *std=new long double[T.numed]; 
  for(int i=0;i<T.numed;i++){
    *(std+i)=sqrt(*(oi.entries+i*(oi.sz+1)));
  };
  T.print(std,out);
  delete[] std;
};

void Mixtreelikelihood::empirical(int type){
  long double *epi=emppi(d,T.leaves(),type);
  for(int i=0;i<num;i++){
    (p+i)->setpi(epi);
  }; 
  delete[] epi;
};

void Mixtreelikelihood::setequalprobs(){
  this->setvarprobs(0);
  for(int i=0;i<num-1;i++){
    *(prob+i)=0;
  };
};

long double* Mixtreelikelihood::getmixprobs(){
  long double *ans=new long double[num];
  *(ans+num-1)=0;
  for(int i=0;i<num-1;i++){
    *(ans+num-1)+=*(prob+i)+1;
  };
  *(ans+num-1)=1/(*(ans+num-1)+1);
  for(int i=0;i<num-1;i++){
    *(ans+i)=(*(prob+i)+1)*(*(ans+num-1));
  };
  return ans;
};


unsigned int Mixtreelikelihood::constraints(){
  return m.numconstraints+varprobs; 
};

constraint *Mixtreelikelihood::cst(){
  if(varprobs==0){
    return m.cst;
  }else{
    constraint *cs=new constraint[m.numconstraints+varprobs];
    for(unsigned int i=0;i<m.numconstraints;i++){
      *(cs+i)=*(m.cst+i);
    };
    int vn=fixbl?0:T.numed;
    long double minone=-1;
    for(int i=0;i<varprobs;i++){
      *(cs+m.numconstraints+i)=constraint(1,1,&vn,&minone);
      vn++;
    };
    return cs;
  };
};

long double *Mixtreelikelihood::truepars(int *valpars){
  long double *tp=new long double[params::numpars*num];
  for(int i=0;i<num;i++){
    long double *temp=(p+i)->truepars();
    for(int j=0;j<params::numpars;j++){
      *(tp+i*params::numpars+j)=*(temp+j);
    };
    delete[] temp;
  };
  return tp;
};

RealmatrixT Mixtreelikelihood::oi(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    this->calculatevals(x);
  };
  //  long double *tc=p.truepars();
  int acc=T.numed+num+params::numpars*num;
  Realmatrix hmat(T.numed+num+params::numpars*num-1);
  for(int i=0;i<hmat.sz;i++){
    for(int j=i;j<hmat.sz;j++){
      *(hmat.entries+i*hmat.sz+j)=*(vals+acc);
      *(hmat.entries+j*hmat.sz+i)=*(vals+acc);
      acc++;
    };
  };
  Realmatrix lcorner(params::numpars*num);
  for(int i=0;i<params::numpars*num;i++){
    for(int j=0;j<params::numpars*num;j++){
      *(lcorner.entries+i*params::numpars*num+j)=*(hmat.entries+(T.numed+num-1+i)*hmat.sz+T.numed+num-1+j)*(*(params::A.entries+(i%params::numpars)*(params::numpars+1)))/(*(params::A.entries+(j%params::numpars)*(params::numpars+1)));
    };
  };
  /*  Realmatrix Ai=params::A.inverse();
  Realmatrix AiT=Ai.transpose();
  lcorner.premult(AiT.entries);//Mismatched entry sizes!!!
  lcorner.mult(Ai);*/
  //  long double *sum=new long double[params::numpars*num];
  for(int i=0;i<T.numed+num-1;i++){
    /*    for(int k=0;k<params::numpars*num;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars*num;j++){
      for(int k=0;k<params::numpars*num;k++){
	*(sum+j)+=*(Ai.entries+(k%params::numpars)*params::numpars+j)*(*(hmat.entries+(T.numed+num-1+k)*hmat.sz+i));
      };
      };*/
    for(int k=0;k<params::numpars*num;k++){
      *(hmat.entries+(T.numed+num-1+k)*hmat.sz+i)/=*(params::A.entries+(k%params::numpars)*(params::numpars+1));//(sum+k);
    };
  };
  for(int i=0;i<T.numed+num-1;i++){
    /*    for(int k=0;k<params::numpars*num;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars*num;j++){
      for(int k=0;k<params::numpars*num;k++){
	*(sum+j)+=*(Ai.entries+(k%params::numpars)*params::numpars+j)*(*(hmat.entries+i*hmat.sz+T.numed+num-1+k));
      };
      };*/
    for(int k=0;k<params::numpars*num;k++){
      *(hmat.entries+i*hmat.sz+(T.numed+num-1+k))*=*(params::A.entries+(i%params::numpars)*(params::numpars+1));//*(sum+k);
    };
  };
  for(int i=0;i<params::numpars*num;i++){
    for(int j=0;j<params::numpars*num;j++){
      *(hmat.entries+(T.numed+num-1+i)*hmat.sz+T.numed+num-1+j)=*(lcorner.entries+i*params::numpars*num+j);
    };
  };
  for(int i=0;i<hmat.sz;i++){
    *(hmat.entries+i*(hmat.sz+1))-=0.1;//Does this make things too insignificant?
  };
  Realmatrix oi=hmat.inverse();
  for(int i=0;i<hmat.sz;i++){
    if(*(oi.entries+i*(hmat.sz+1))>=0){//Should figure out a better way to deal with this.
      char msg[100];
      sprintf(msg,"Found positive diagonal element in inverse of hessian, for entry %d. Replacing by -1",i);
      info(msg,msgcode(1,0));
      *(oi.entries+i*(hmat.sz+1))=-1;
    };
  };
  for(int i=0;i<oi.sz*oi.sz;i++){
    *(oi.entries+i)*=-1;
  };
  return oi;
};

void Mixtreelikelihood::undoselect(int *sel,int lastpars){
  //NEED TO WRITE THIS.
};

void Mixtreelikelihood::selectpars(int *sel){
  //NEED TO WRITE THIS.
};

long double *Mixtreelikelihood::tstats(const long double *x){
  //THIS GIVE T-STATISTICS FOR SEPERATE PARAMETERS. NEED TO CONVERT TO COMBINED PARAMETERS.
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    this->calculatevals(x);
  };
  long double *tc=this->truepars();
  Realmatrix oi=this->oi(x);
  long double *ans=new long double[params::numpars*num];
  for(int j=0;j<params::numpars*num;j++){
    *(ans+j)=*(tc+j)/sqrt(*(oi.entries+(T.numed+j)*(oi.sz+1)));
  };
  delete[] tc;
  return ans;
};


int* Mixtreelikelihood::tstatsel(const long double *x,long double threshold){
  return NULL;//NEED TO WRITE THIS.
};

void Mixtreelikelihood::tstat(const long double *x,ostream& out){
  Realmatrix hmat(T.numed+params::numpars*num+num);
};

void Mixtreelikelihood::normalisejustpars(){
  long double *pp=new long double[num];
  long double tp=0;
  for(int i=0;i<num-1;i++){
    tp+=*(prob+i)+1;
  };
  *(pp+num-1)=1/(tp+1);
  for(int i=0;i<num-1;i++){
    *(pp+i)=(*(prob+i)+1)*(*(pp+num-1));
  };
  if(params::numpars>0){
    long double ans=0;
    for(int i=0;i<num;i++){
      long double l=0;
      for(int j=0;j<NumCodons;j++){
	for(int k=0;k<NumCodons;k++){
	  if(j!=k){
	    l+=*((p+i)->pi+j)*(*((p+i)->pi+k))*(*((p+i)->R.entries+j*NumCodons+k));
	  };
	};
      };
      ans+=l*(*(pp+i));
    };
    delete[] pp;
    long double la=log(ans)/(*(p->XX->entries+1));
    for(int i=0;i<num;i++){
      //      *(p+i)->coeff-=la;
      (p+i)->rescale(la);//setR();
    };
    m.Normalise(T.numed+varprobs);
  };
};

void Mixtreelikelihood::normalise(){
  long double *pp=new long double[num];
  long double tp=0;
  for(int i=0;i<num-1;i++){
    tp+=*(prob+i)+1;
  };
  *(pp+num-1)=1/(tp+1);
  for(int i=0;i<num-1;i++){
    *(pp+i)=(*(prob+i)+1)*(*(pp+num-1));
  };
  if(params::numpars>0){
    long double ans=0;
    for(int i=0;i<num;i++){
      long double l=0;
      for(int j=0;j<NumCodons;j++){
	for(int k=0;k<NumCodons;k++){
	  if(j!=k){
	    l+=*((p+i)->pi+j)*(*((p+i)->pi+k))*(*((p+i)->R.entries+j*NumCodons+k));
	  };
	};
      };
      ans+=l*(*(pp+i));
  };
    delete[] pp;
    long double la=log(ans)/(*(p->XX->entries+1));
    for(int i=0;i<num;i++){
      //*(p+i)->coeff-=la;
      (p+i)->rescale(la);//      (p+i)->setR();
    };
    T.scale(ans);
    m.Normalise(T.numed+varprobs);
  };
};

void Mixtreelikelihood::setfixedpars(long double *vls,int max){
  int *fx=new int[num*params::numpars];
  for(int i=0;i<num*params::numpars;i++){
    *(fx+i)=1;
  };  
  for(int *mpr=m.pars;*mpr;mpr++){
    int j=abs(*(mpr));
    *(fx+j)=0;
  };
  long double *y=new long double[params::numpars];
  long double *z=new long double[params::numpars];
  int vlno=0;
  for(int i=0;i<num;i++){
    for(int j=0;j<params::numpars;j++){
      *(z+j)=*((p+i)->coeff+j);
    };
    ((Realmatrix)params::A.inverse()).act(z,y);
    for(int j=0;j<params::numpars;j++){
      if(*(fx+i*params::numpars+j)){
	*(y+j)=*(vls+vlno);
	if(vlno<max-1){
	  vlno++;
	};
      };
    };
    params::A.act(y,z);
    (p+i)->setCoeff(z);
  };
  delete[] fx;
  delete[] y;    
  delete[] z;    
};

void Mixtreelikelihood::getx(long double *out){
  unsigned int edgedirs=fixbl?0:T.numed;
  if(m.valid()){
    int *pos=m.pars;
    long double *tmp=new long double[m.npars];
    for(int i=0;i<m.npars;i++){
      int pv=*(pos++);
      *(tmp+i)=*((p+pv/params::numpars)->coeff+pv%params::numpars);
      for(;*pos<0;pos++);
    };
    if(distpars!=NULL){
      m.writedists(tmp,distpars,out+edgedirs+varprobs);
    }else{
      m.seeddists(tmp,out+edgedirs+varprobs);
    };
    delete[] tmp;
  }else{
    for(unsigned int i=0;i<dim-edgedirs-varprobs;i++){
      *(out+i+edgedirs+varprobs)=(p+*(variablepars+i)/params::numpars)->coeff[*(variablepars+i)%params::numpars];
    };
  };
  for(unsigned int i=0;i<(unsigned)varprobs;i++){
    *(out+edgedirs+i)=*(prob+i);
  };
  if(!fixbl){
    T.putedgelengths(out);
  };
};

int search(const char *const*path,const char *filename,ifstream& in);

void Mixtreelikelihood::setmixfile(const char* s,const char *const*pt){
  ifstream in;
  while(!search(pt,s,in)){
    char *msg=new char[strlen(s)+45];
    strcpy(msg,"Unable to open mixture file: \"");
    strcat(msg,s);
    strcat(msg,"\"");
    recoverableError(msg,msgcode(0,3),&filemenu);
    delete[] msg;
  };
  m.assign(in);
  in.close();
  dim=T.numed+varprobs+m.npars;
  m.insvars(T.edges());
};

Mixtreelikelihood::Mixtreelikelihood(int mx,const char *tr,const Realmatrix& Q,ifstream& data){
  fixbl=0;
  if(mx<2){
    throw mx;
  };
  p=new params[mx];
  T=tree(tr);
  T.filledges();
  num=mx;
  varprobs=num-1;
  m.setnum(num);
  prob=new long double[num-1];
  f=new Factmatrix[mx];
  p->getpars(Q);
  for(int i=1;i<num;i++){
    *(p+i)=*p;
  };
  for(int i=0;i<num;i++){
    *(f+i)=(p+i)->fmatrix();
  };
  d=getdata(data,T);
  dim=T.edges()+num*p->numpars+num-2;
  if(p->numpars==0){
    dim++;
  };
  lastval=new long double[dim];
  vals=NULL;
  variablepars=new int[num*params::numpars+1];
  for(int i=0;i<num*params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  *(variablepars+params::numpars-1)=-1;
  dir=0;
  distpars=NULL;
};


Mixtreelikelihood::Mixtreelikelihood(int mx,const char *tr,ifstream& data){
  fixbl=0;
  if(mx<2){
    throw mx;
  };
  p=new params[mx]; //Need to create params before tree to ensure numpars is known.
  T=tree(tr);
  T.filledges();
  num=mx;
  varprobs=num-1;
  m.setnum(num);
  prob=new long double[num-1];
  f=new Factmatrix[mx];
  d=getdata(data,T);
  dim=T.edges()+num*params::numpars+num-2;
  if(p->numpars==0){
    dim++;
  };
  lastval=new long double[dim];
  vals=NULL;
  variablepars=NULL;
  dir=0;
  distpars=NULL;
};

void Mixtreelikelihood::setpars(const Realmatrix& Q){
  if(p->numpars==0){
    dim=T.numed+varprobs;
  };
  p->getpars(Q);
  for(int i=1;i<num;i++){
    *(p+i)=*p;
  };
  for(int i=0;i<num;i++){
    *(f+i)=(p+i)->fmatrix();
  };
  vals=NULL;
  if(variablepars!=NULL){
    delete[] variablepars;
  };
  variablepars=new int[num*params::numpars+1];
  for(int i=0;i<num*params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  if(params::numpars>0){
    *(variablepars+num*params::numpars-1)=-1;
  };
  if(distpars!=NULL){
    delete[] distpars;
    distpars=NULL;
  }else{
    this->satisfyconstraints();
  };
};

void Mixtreelikelihood::setzeropars(){
  if(params::numpars==0){
    dim=T.numed;
  };
  long double *cf=new long double[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(cf+i)=0;
  };
  for(int i=0;i<num;i++){
    (p+i)->setCoeff(cf);
    *(f+i)=(p+i)->fmatrix();
  };
  vals=NULL;
  if(variablepars!=NULL){
    delete[] variablepars;
  };
  variablepars=new int[params::numpars*num+1];
  for(int i=0;i<params::numpars*num-1;i++){
    *(variablepars+i)=i+1;
  };
  if(params::numpars>0){
    *(variablepars+params::numpars*num-1)=-1;
  };
};

void Mixtreelikelihood::satisfyconstraints(){
  //Check constraints.
  long double *dv=new long double[dim];
  int *pp=m.pars;
  unsigned int edgedirs=fixbl?0:T.numed;
  for(int i=0;i<m.inpars;i++){
    *(dv+edgedirs+varprobs+i)=*((p+(*pp/params::numpars))->coeff+(*pp%params::numpars));
    pp++;
    for(;*pp<0;pp++);
  };
  for(unsigned int i=0;i<m.numconstraints;i++){
    int c=(m.cst+i)->correct(dv);
    if(c>=0){//Need to change value.
      pp=m.pars;
      for(int j=edgedirs+varprobs;j<c;j++){
	pp++;
	for(;*pp<0;pp++);
      };      
      *((p+(*pp/params::numpars))->coeff+(*pp%params::numpars))=*(dv+c);
      for(;*pp<0;pp++){
	*((p+((-*pp)/params::numpars))->coeff+((-*pp)%params::numpars))=*(dv+c);
      };
    };
  };
  delete[] dv;
};

void Mixtreelikelihood::setpars(ifstream& I){
  if(m.valid()){
    long double *ps=new long double[m.inpars];
    for(int i=0;i<m.inpars;i++){
      char *a=readnonemptystring(I,", \n\t\r");
      *(ps+i)=atof(a);    
      delete[] a;    
    };
    long double *y=new long double[num*params::numpars];
    for(int i=0;i<num;i++){
      for(int j=0;j<params::numpars;j++){
	*(y+i*params::numpars+j)=*((p+i)->coeff+j);//*params::A
      };
    };
    long double *tmp=m.applydistributions(ps,0);
    m.setpars(tmp,y);
    delete[] tmp;
    for(int i=0;i<num;i++){
      (p+i)->setTrueCoeff(y+i*params::numpars);
      *(f+i)=(p+i)->fmatrix();
    };
    vals=NULL;
    if(m.dist!=NULL){
      long double *dp=distpars;
      for(int i=0;*(m.dist+i)!=NULL;i++){
	for(int j=0;j<(*(m.dist+i))->pars;j++){
	  *(dp++)=*(ps+*(m.distpnum+i)+j);
	};
      };
    };
    delete[] y;
  }else{
    if(p->numpars==0){
      dim=T.numed+varprobs;
    };
    p->readpars(I);
    for(int i=1;i<num;i++){
      *(p+i)=*p;
    };
    for(int i=0;i<num;i++){
      *(f+i)=(p+i)->fmatrix();
    };
    vals=NULL;
    if(variablepars!=NULL){
      delete[] variablepars;
    };
    variablepars=new int[num*params::numpars+1];
    for(int i=0;i<num*params::numpars-1;i++){
      *(variablepars+i)=i+1;
    };
    if(params::numpars>0){
      *(variablepars+num*params::numpars-1)=-1;
    };
  };
  this->satisfyconstraints();
};

void Mixtreelikelihood::setpars(const char *c){
  if(m.valid()){
    long double *ps=new long double[m.inpars];
    const char *a=c;
    for(int i=0;i<m.inpars;i++){
      *(ps+i)=atof(a);    
      for(;*a&&*a!=','&&*a!=' '&&*a!='\t'&&*a!='\n'&&*a!='\r';a++);
      for(;*a==','||*a==' '||*a=='\t'||*a=='\n'||*a=='\r';a++);
    };
    long double *y=new long double[num*params::numpars];
    for(int i=0;i<num;i++){
      for(int j=0;j<params::numpars;j++){
	*(y+i*params::numpars+j)=*((p+i)->coeff+j);
      };
    };
    long double *tmp=m.applydistributions(ps,0);
    m.setpars(tmp,y);
    long double *dp=distpars;
    if(m.dist!=NULL){
      for(int i=0;*(m.dist+i)!=NULL;i++){
	for(int j=0;j<(*(m.dist+i))->pars;j++){
	  *(dp++)=*(ps+*(m.distpnum+i)+j);
	};
      };
    };
    delete[] tmp;
    for(int i=0;i<num;i++){
      (p+i)->setTrueCoeff(y+i*params::numpars);
      *(f+i)=(p+i)->fmatrix();
    };
    vals=NULL;
    delete[] y;
    delete[] ps;
  }else{
    if(p->numpars==0){
      dim=T.numed+varprobs;
    };
    istringstream in(c);
    p->readpars(in);
    for(int i=1;i<num;i++){
      *(p+i)=*p;
    };
    for(int i=0;i<num;i++){
      *(f+i)=(p+i)->fmatrix();
    };
    vals=NULL;
    if(variablepars!=NULL){
      delete[] variablepars;
    };
    variablepars=new int[num*params::numpars+1];
    for(int i=0;i<num*params::numpars-1;i++){
      *(variablepars+i)=i+1;
    };
    if(params::numpars>0){
      *(variablepars+num*params::numpars-1)=-1;
    };
  };
  //  this->satisfyconstraints();
};

void Mixtreelikelihood::parsimonybl(){
  //  this->parsimonypars();
  //  this->normalisejustpars();
  //Uses parsimony to seed the branch lengths.
  Realmatrix *C=new Realmatrix[num];
  for(int iii=0;iii<num;iii++){
    Realmatrix R=(p+iii)->Rmatrix();
    for(int i=0;i<NumCodons;i++){
      for(int j=0;j<NumCodons;j++){
	if(i!=j){
	  *(R.entries+i*NumCodons+j)*=sqrt(*(p->pi+i)*(*(p->pi+j)));
	};
      };
    };
    for(int i=0;i<NumCodons;i++){
      *(R.entries+i*(NumCodons+1))=0;
      for(int j=0;j<NumCodons;j++){
	if(i!=j){
	  *(R.entries+i*(NumCodons+1))-=*(R.entries+i*NumCodons+j);
	};
      };
    };
    *(C+iii)=R.getresistance();
  };
  long double *pprobs=this->getmixprobs();
  for(int i=0;i<num;i++){
    *(pprobs+i)=-log(*(pprobs+i));
  };
  T.parsimonybl(num,C,pprobs,d);
  delete[] pprobs;
  delete[] C;
};

long double Mixtreelikelihood::quickEvaluate(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(dim>T.numed){
      long double *y=new long double[num*params::numpars];
      if(m.valid()){
	for(int i=0;i<num;i++){
	  for(int j=0;j<params::numpars;j++){
	    *(y+i*params::numpars+j)=*((p+i)->coeff+j);
	  };
	};
	if(distpars!=NULL){	
	  int *start=m.distpnum;
	  long double *dstpr=distpars;
	  for(Distribution **ds=m.dist;*ds!=NULL;ds++){
	    for(int i=0;i<(*ds)->pars;i++){
	      *(dstpr++)=*(x+T.numed+varprobs+*start+i);
	    };
	    start++;
	  };	
	};
	long double *tmp=m.applydistributions(x+T.numed+varprobs);
	m.setpars(tmp,y);
	delete[] tmp;
      }else{
	int j=0;
	for(int i=0;i<dim-varprobs-T.numed;i++){
	  for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	    *(y+k)=(p+j)->coeff[k%num];
	  };
	  *(y+*(variablepars+i))=*(x+T.numed+varprobs+i);
	};
      }
      for(int i=0;i<num;i++){
	(p+i)->setCoeff(y+i*params::numpars);
	*(f+i)=(p+i)->fmatrix();
      };
      delete[] y;      
    };
    T.setedgelengths(x);
    for(int i=0;i<varprobs;i++){
      *(prob+i)=*(x+T.numed+i);
    };
    return T.Mixlikelihood(f,d,num,prob,p);
  }else{
    return(*vals);
  };
};


int Mixtreelikelihood::testlast(const long double *x){
  if(lastval==NULL){
    return 0;
  };
  for(int i=0;i<dim;i++){
    if(NONZEROSTSQ(*(x+i)-*(lastval+i))){
      return 0;
    };
  };
  return 1;
};

inline void Mixtreelikelihood::calculatevals(const long double *x){
  if(vals!=NULL){
    delete[] vals;
  };
  //Need to change to new values x
  unsigned int edgedirs=fixbl?0:T.numed;
  if(dim>T.numed||fixbl){
    long double *y=new long double[num*params::numpars];
    if(m.valid()){
      for(int i=0;i<num;i++){
	for(int j=0;j<params::numpars;j++){
	  *(y+i*params::numpars+j)=*((p+i)->coeff+j);
	};
      };
      if(distpars!=NULL){	
	int *start=m.distpnum;
	long double *dstpr=distpars;
	for(Distribution **ds=m.dist;*ds!=NULL;ds++){
	  for(int i=0;i<(*ds)->pars;i++){
	    *(dstpr++)=*(x+T.numed+varprobs+*start+i);
	  };
	  start++;
	};	
      };
      long double *tmp=m.applydistributions(x+edgedirs+varprobs);
      m.setpars(tmp,y);
      delete[] tmp;
    }else{
      int j=0;
      for(int i=0;i<dim-varprobs-T.numed;i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=(p+j)->coeff[k%num];
	};
	*(y+*(variablepars+i))=*(x+T.numed+varprobs+i);
      };
    };
    for(int i=0;i<num;i++){
      (p+i)->setCoeff(y+i*params::numpars);
      *(f+i)=(p+i)->fmatrix();
    };
    delete[] y;    
  };
  for(int i=0;i<varprobs;i++){
    *(prob+i)=*(x+edgedirs+i);
  };
  for(int i=0;i<dim;i++){
    *(lastval+i)=*(x+i);
  };
  if(!fixbl){
    T.setedgelengths(x);
  };
  vals=Mixcalchess(T,f,d,num,prob,p);
  //    vals=T.hessian(f,d,p);
};

long double Mixtreelikelihood::evaluate(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    this->calculatevals(x);
  };
  return *vals;
};


void Mixtreelikelihood::deriv(const long double *x,long double *out){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    this->calculatevals(x);
  };
  unsigned int edgedirs=fixbl?0:T.numed;
  for(unsigned int i=0;i<edgedirs;i++){
    *(out+i)=*(vals+i+1);
  };
  if(m.valid()){
    long double *tmp=new long double[m.npars];
    m.sumpars(vals+T.numed+1,tmp);
    m.sumdistderivpars(x+T.numed+varprobs,tmp,out+edgedirs+varprobs);
    delete[] tmp;
  }else{
    for(unsigned int i=0;i<(unsigned)(dim-varprobs-T.edges());i++){
      *(out+edgedirs+varprobs+i)=*(vals+T.numed+*(variablepars+i)+1);
    };
  };
  for(unsigned int i=0;i<(unsigned)varprobs;i++){
    *(out+edgedirs+i)=*(vals+1+T.numed+num*params::numpars+i);
  };
};

void Mixtreelikelihood::hessian(const long double *x,long double *out){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    this->calculatevals(x);
  };
  unsigned int edgedirs=fixbl?0:T.numed;
  int acc=T.numed+num*params::numpars+num;
  for(unsigned int i=0;i<edgedirs;i++){
    for(unsigned int j=i;j<edgedirs;j++){
      *(out+i*dim+j)=*(vals+acc);
      *(out+j*dim+i)=*(vals+acc);
      acc++;
    };
    for(unsigned int j=0;j<(unsigned)varprobs;j++){
      *(out+i*dim+edgedirs+j)=*(vals+acc+num*params::numpars);
      *(out+i+(edgedirs+j)*dim)=*(vals+acc+num*params::numpars);
      acc++;
    };
    if(m.valid()){
      long double *tmp=new long double[m.npars];
      m.sumpars(vals+acc-varprobs,tmp);
      m.sumdistderivpars(x+edgedirs+varprobs,tmp,out+i*dim+edgedirs+varprobs);
      delete[] tmp;
      for(unsigned int j=0;j<dim-varprobs-edgedirs;j++){
	*(out+(j+edgedirs+varprobs)*dim+i)=*(out+i*dim+edgedirs+j+varprobs);
      };
    }else{
      for(unsigned int j=0;j<(unsigned)(dim-varprobs-T.numed);j++){
	*(out+i*dim+T.numed+j+varprobs)=*(vals+acc+num-1-varprobs+*(variablepars+j));
	*(out+(j+T.numed+varprobs)*dim+i)=*(vals+acc+num-1-varprobs+*(variablepars+j));
      };
    };
    acc+=num*params::numpars+num-1-varprobs;
  };
  acc=T.numed*(T.numed+1)/2+T.numed*(num*params::numpars+num)+num*params::numpars+num;
  //  cout<<T.numed<<" "<<num<<" "<<params::numpars<<"  "<<acc<<"\n";
  //  cout<<*(vals+acc)<<"\n\n";
  if(m.valid()){
    long double *tmp=new long double[m.npars*m.npars];
    long double *tmp2=new long double[m.npars];
    m.sumpars(vals+T.numed+1,tmp2);
    m.sumparstrisquare(vals+acc,tmp,m.npars,num-1);
    m.sumdistsecderparssq(x+T.numed+varprobs,tmp,tmp2,out+(edgedirs+varprobs)*dim+(edgedirs+varprobs),dim);
    delete[] tmp;
    delete[] tmp2;
    //    m.sumparstrisquare(vals+acc,out+(T.numed+varprobs)*dim+(T.numed+varprobs),dim,num-1);
    acc+=num*params::numpars;
    for(int j=0;j<varprobs;j++){
      m.sumparsdecstep(vals+acc,out+(edgedirs+j)*dim+edgedirs+varprobs,params::numpars*num+num-2);
      for(int i=edgedirs+varprobs;i<dim;i++){
	*(out+i*dim+j+edgedirs)=*(out+(j+edgedirs)*dim+i);
      };
      acc++;
    };
  }else{
    for(unsigned int i=0;i<dim-varprobs-edgedirs;i++){
      for(int k=(i>0)?*(variablepars+i-1):0;k<*(variablepars+i);k++){
	acc+=num*params::numpars+varprobs-k;//*(variablepars+i);
      };
      for(unsigned int j=i;j<dim-varprobs-edgedirs;j++){
	*(out+(i+T.numed)*dim+j+edgedirs)=*(vals+acc+*(variablepars+j)-*(variablepars+i));
	*(out+(j+T.numed)*dim+i+edgedirs)=*(vals+acc+*(variablepars+j)-*(variablepars+i));
      };
      for(int j=0;j<varprobs;j++){
	*(out+(i+edgedirs)*dim+dim+j-varprobs)=*(vals+acc+num*params::numpars-*(variablepars+i)+j);
	*(out+(dim+j-varprobs)*dim+i+edgedirs)=*(vals+acc+num*params::numpars-*(variablepars+i)+j);
      };
    };
  };
  acc=(T.numed+num*params::numpars+num)*(T.numed+num*params::numpars+num+1)/2-num*(num-1)/2;
  for(int i=0;i<varprobs;i++){
    for(int j=i;j<varprobs;j++){
      *(out+(edgedirs+i)*dim+edgedirs+j)=*(vals+acc);
      *(out+(edgedirs+j)*dim+edgedirs+i)=*(vals+acc);
      acc++;
    };
    acc+=num-1-varprobs;
  };
  /*
  for(int i=0;i<dim;i++){
    for(int j=0;j<dim;j++){
      cout<<*(out+i*dim+j)<<" ";
    };
    cout<<"\n";
  };
  cout<<"\n";*/
};


long double *Mixtreelikelihood::sitepostprobs(){
  long double *pp=new long double[num];
  long double tp=0;
  for(int i=0;i<num-1;i++){
    tp+=*(prob+i)+1;
  };
  *(pp+num-1)=1/(tp+1);
  for(int i=0;i<num-1;i++){
    *(pp+i)=(*(prob+i)+1)*(*(pp+num-1));
  };
  long double **sl=new long double *[num];
  for(int i=0;i<num;i++){
    *(sl+i)=T.sitelikelihoods(*(f+i),d,*(p+i));
  };
  int s=this->numsites();
  long double *ans=new long double[num*s];
  for(int i=0;i<s;i++){
    long double tl=0;
    for(int j=0;j<num;j++){
      tl+=*(*(sl+j)+i)*(*(pp+j));
    };
    for(int j=0;j<num;j++){
      *(ans+i*num+j)=*(*(sl+j)+i)*(*(pp+j))/tl;
    };
  };
  delete[] pp;
  for(int i=0;i<num;i++){
    delete[] *(sl+i);
  };
  delete[] sl;
  return ans;
};

long double *Mixtreelikelihood::likelihoodDisplacement(int *params){
  return NULL;
};

long double *Mixtreelikelihood::branchinfluences(int *params){
  return NULL;
};
