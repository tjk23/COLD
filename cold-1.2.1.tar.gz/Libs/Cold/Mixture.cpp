/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */


// Routines for Mixture models


//  long double *Mixhessian(const Factmatrix& f,const sequence *data,const params& p);

//  long double *approxHessian(const Factmatrix& f,const sequence *data,const params& p);

//  long double *derivs(const Factmatrix& f,const sequence *data,const params& p);


//Implement these later.

//  long double Mixlikelihood(const Factmatrix& f,const sequence *data,const params& p);

//  long double fastMixlikelihood(const Factmatrix& f,const sequence *data,const params& p);

//  long double *Mixsitelikelihoods(const Factmatrix& f,const sequence *data,const params& p);

//  long double *Mixhessian_threaded(const Factmatrix& f,const sequence *data,const params& p,int st=-1);


void accumulateMix(const long double *siteliks,long double *ans,int e,int l,int num,const long double *p,void *dbn=NULL){
  //Used to add the calculated likelihoods for the current site to the
  //cumulative totals.
  //Could make this faster by sending pp
  long double *pp=new long double[num];
  long double tp=0;
  for(int i=0;i<num-1;i++){
    tp+=*(p+i)+1;
  };
  *(pp+num-1)=1/(tp+1);
  long double tlik=*(pp+num-1)*(*(siteliks+l*(num-1)));
  for(int i=0;i<num-1;i++){
    *(pp+i)=(*(p+i)+1)*(*(pp+num-1));
    tlik+=*(siteliks+l*i)*(*(pp+i));
  };
  //  tlik+=*(siteliks+l*(num-1))*(*(pp+num-1));
  if(tlik<=0){
    //Whoops;
    char* msg=new char[100*num+100];
    strcpy(msg,"Zero site likelihood:\n\n");
    for(unsigned int i=0;i<num;i++){
      sprintf(msg+strlen(msg),"%Lg\t%Lg\n",*(pp+i),*(siteliks+l*i));
    };
    fatalError(msg,0);
  };
  *ans+=log(tlik);
  for(int j=1;j<1+e;j++){
    for(int k=0;k<num;k++){
      *(ans+j)+=*(pp+k)*(*(siteliks+l*k+j))/tlik;
    };   
  };
  for(int j=0;j<params::numpars;j++){
    for(int k=0;k<num;k++){
      *(ans+e+1+k*params::numpars+j)+=*(pp+k)*(*(siteliks+k*l+e+1+j))/tlik;
    };
  };
  for(int j=0;j<num-1;j++){
    *(ans+e+1+num*params::numpars+j)+=*(pp+num-1)*(*(siteliks+j*l)/tlik-1);
  };
  int v=e+num*params::numpars+num;
  int w=1+e+params::numpars;
  for(int j=0;j<e;j++){
    for(int k=j;k<e;k++){
      for(int jj=0;jj<num;jj++){
	*(ans+v)+=*(pp+jj)*(*(siteliks+jj*l+w))/(tlik);
	for(int kk=0;kk<num;kk++){
	  *(ans+v)-=*(pp+jj)*(*(pp+kk))*(*(siteliks+jj*l+j+1))*(*(siteliks+kk*l+k+1))/(tlik*tlik);
	};
      };
      v++;
      w++;
    };
    int w0=w;
    long double x=0;
    for(int jj=0;jj<num;jj++){
      x+=*(pp+jj)*(*(siteliks+jj*l+j+1));//so x is what was added to *(ans+j+1)
    };
    x/=tlik;
    for(int kk=0;kk<num;kk++){
      w=w0;
      for(int k=0;k<params::numpars;k++){
	*(ans+v)+=*(pp+kk)*(*(siteliks+kk*l+w)-*(siteliks+kk*l+e+1+k)*x)/(tlik);
	v++;
	w++;
      };
    };
    for(int k=0;k<num-1;k++){
      *(ans+v)+=*(pp+num-1)*(*(siteliks+k*l+j+1)-*(siteliks+k*l)*x)/tlik;
      v++;
    };
  };
  int w0=1+e+params::numpars+e*(e+1)/2+e*params::numpars;
  for(int jj=0;jj<num;jj++){
    w=w0;
    for(int j=0;j<params::numpars;j++){    
      for(int k=j;k<params::numpars;k++){
	*(ans+v)+=*(pp+jj)*(*(siteliks+jj*l+w))/tlik;
	*(ans+v)-=*(pp+jj)*(*(pp+jj))*(*(siteliks+jj*l+j+e+1))*(*(siteliks+jj*l+k+e+1))/(tlik*tlik);
	v++;
	w++;
      };
      for(int kk=jj+1;kk<num;kk++){
	for(int k=0;k<params::numpars;k++){
	  //	  cout<<jj<<" "<<j<<" "<<kk<<" "<<k<<"\n";
	  //	  cout<<*(siteliks+jj*l+j+e+1)/tlik<<"  "<<*(siteliks+kk*l+k+e+1)/tlik<<"\n";
	  *(ans+v++)-=*(pp+jj)*(*(pp+kk))*(*(siteliks+jj*l+j+e+1))*(*(siteliks+kk*l+k+e+1))/(tlik*tlik);
	  //	  cout<<*(ans+v-1)<<"\n\n";
	};
      };
      for(int k=0;k<num-1;k++){
	if(k==jj){
	  *(ans+v)+=*(pp+num-1)*(*(siteliks+k*l+j+e+1))/tlik;
	};
	//	cout<<*(ans+v-1)<<"\n\n";
	*(ans+v++)-=*(pp+num-1)*(*(pp+jj))*(*(siteliks+jj*l+j+e+1))/tlik+*(pp+num-1)*(*(siteliks+jj*l+j+e+1))*(*(siteliks+k*l)-tlik)*(*(pp+jj))/(tlik*tlik);
      };
    };
  };
  for(int j=0;j<num-1;j++){
    for(int k=j;k<num-1;k++){
      *(ans+v++)+=*(pp+num-1)*(*(pp+num-1))*(1-*(siteliks+j*l)*(*(siteliks+k*l))/(tlik*tlik));
    };
  };
  /*
  for(int i=num+e+num*params::numpars;i>0;i--){
    for(int j=0;j<i;j++){
      cout<<*(ans+ww++)<<"  ";
    };
    cout<<"\n";
  };
  cout<<"\n\n";*/
  delete[] pp;
};


class allmixdata{
public:
  tree *t;
  const Factmatrix *f;
  const sequence *data;
  int num;
  const long double *prob;
  const params *p;
  const precalc *x;
  allmixdata(){t=NULL;f=NULL;data=NULL;num=0,prob=NULL;p=NULL;x=NULL;};
  allmixdata(tree &tr,const Factmatrix *fa,const sequence *d,int n,const long double *pr,const params *pa,const precalc *xx){t=&tr;f=fa;data=d;num=n;prob=pr;p=pa;x=xx;};
  void assign(tree &tr,const Factmatrix *fa,const sequence *d,int n,const long double *pr,const params *pa,const precalc *xx){t=&tr;f=fa;data=d;num=n;prob=pr;p=pa;x=xx;};
};

void *callmixhessthreaded(void *d){
  allmixdata *a=(allmixdata *)d;
  return (a->t)->Mixhessian_threaded((a->f),a->data,(a->num),a->prob,a->p,a->x);
};


long double *Mixcalchess(tree &t, const Factmatrix* f,const sequence *data,int num,const long double *prob,const params* p){
  int e=t.edges();
  int l=e+params::numpars*num+num;
  //For now, don't allow branch lengths to vary across sites. Also,
  //use fixed mixing probabilities.
  l=l*(l+1)/2;// add space for the hessian
  currentpos=0;
  if(numthreads==0){
    numthreads=NUMTHREADS;
  };
  char msg[40];
  sprintf(msg,"Producing %i threads for computation.",numthreads);
  info(msg,msgcode(2,0));
  pthread_t *worker=new pthread_t[numthreads-1];
  tree *tcopy=t.clone(numthreads-1);
  int i=0;
  int ecode=0;
  precalc *x=new precalc[num];
  for(i=0;i<num;i++){
    (x+i)->calc(t,*(f+i),data,*(p+i));
    //    (x+i)->print();
  };
  allmixdata *a=new allmixdata[numthreads-1];
  for(i=0;i<numthreads-1;i++){
    (a+i)->assign(*(tcopy+i),f,data,num,prob,p,x);
  };
  currentpos=0;
  for(i=0;i<numthreads-1&&!ecode;i++){
    //for(i=0;i<1&&!ecode;i++){
    ecode=pthread_create((worker+i),NULL,callmixhessthreaded,a+i);
  };//Now i stores the actual number of pthreads created.
  if(ecode){
    sprintf(msg,"only able to produce %i threads.",i);
    warning(msg);
    i--;
  };
  long double *ans=t.Mixhessian_threaded(f,data,num,prob,p,x);
  void *temp;
  ecode=0;
  for(int j=0;j<i;j++){
    //    cout<<"Trying to rejoin thread "<<j+1<<".\n";
    ecode=pthread_join(*(worker+j),&temp);
    if(ecode){
      char x[60];
      sprintf(x,"Threading error rejoining thread number %d",j);
      fatalError(x);
      //      cerr<<"Threading error rejoining thread number "<<j<<".\n";
      //      exit(1);
    };
    long double *tmp=(long double *)temp;
    for(int k=0;k<l;k++){
      *(ans+k)+=*(tmp+k);
    };
    delete[] tmp;
  };
  for(i=0;i<numthreads-1;i++){
    (tcopy+i)->remove();
  };
  delete[] tcopy;
  delete[] worker;
  delete[] a;
  delete[] x;
  return ans;
};

long double *tree::Mixhessian_threaded(const Factmatrix* f,const sequence *data,int num,const long double *prob,const params* p,const precalc *x,int st){
  int *shst=(int *)vars.seekval("showeverysite");
  int showeverysite=(shst==NULL)?0:*shst;

  int i=0;
  mspace mem(x->e);
  int sites=data->length;
  if(st!=-1){
    sites=st;
  };
  int l=x->e+params::numpars*num+num;
  l=l*(l+1)/2;
  long double *ans=new long double[l];
  for(int j=0;j<l;j++){
    *(ans+j)=0;
  };
  long double *siteliks=new long double[x->l*num];
//Store values currently being calculated here, to avoid corrupting
//the state in case of interruption
  i=getnext();
  int stv1=CurrentState->addvar('i',1,&i);
  CurrentState->addvar('L',l,ans,"hessian");
  void **dbn=new void*[3];
  *dbn=this;
  *(dbn+2)=&i;
  for(;i<sites;){//for each site.
    if(!((i+1)%showeverysite)){//should make this depend on the number of sites
      cout<<"Working on site "<<i+1<<" of "<<sites<<":\n";
      //      cout<<"In thread \""<<pthread_self()<<"\"\n";
    };
    for(int j=0;j<num;j++){
      (*sthss)(*this,*(f+j),data,*(p+j),i,siteliks+x->l*j,*(x+j),mem);
      /*      if(*(siteliks+x->l*j)<=0){
	char m[100];
	sprintf(m,"Site likelihood has non-positive value: %Lg",*(siteliks+x->l*j));
	menuitem debneg("Debug.",dneg);
	menu neglog(2,stop,debneg);
	*(dbn+1)=siteliks+x->l*j;
	neglog.setpars(dbn);
	fatalError(m,0,&neglog);//Should add debugging menu.
	};*/
      if(*(siteliks+x->l*j)<=0){
	cout<<"Negative site likelihood found: "<<*(siteliks+x->l*j)<<"\ncalculating in a different way.\n";      
	*(siteliks+x->l*j)=this->safeSiteLikelihood(*(f+j),*(p+j));
	cout<<"New value: "<<*(siteliks+x->l*j)<<"\n";
      };
    };
    sigset_t all;
    sigset_t old;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
    accessState();
    accumulateMix(siteliks,ans,x->e,x->l,num,prob,dbn);
    accessStateFinished();
    i=getnext();
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
  };
  delete[] dbn;
  //  CurrentState->addvar('L',l,ans);
  CurrentState->remvar(stv1,"endhessian",1);
  delete[] siteliks;
  //  delete[] x;
  return ans;
};

long double tree::Mixlikelihood(const Factmatrix* f,const sequence *data,int num,const long double *prob,const params* p){
  int i=0;
  int sites=data->length;
  int e=(this->numed);
  long double *ex=new long double[NumCodons*e*num];
  long double *le=this->getlengths();
  for(int n=0;n<num;n++){
    for(int i=0;i<e;i++){
      for(int j=0;j<NumCodons;j++){
	*(ex+n*NumCodons*e+i*NumCodons+j)=exp(*(le+i)*(*((f+n)->D.entries+j)));//Should only calculate this matrix once.
      };
    };
  };
  long double *pp=new long double[num];
  long double tp=0;
  for(int i=0;i<num-1;i++){
    tp+=*(prob+i)+1;
  };
  *(pp+num-1)=1/(tp+1);
  for(int i=0;i<num-1;i++){
    *(pp+i)=(*(prob+i)+1)*(*(pp+num-1));
  };
  long double *siteliks=new long double[sites];
  for(i=0;i<sites;i++){//for each site.
    *(siteliks+i)=0;
    for(int n=0;n<num;n++){
      this->liklistdown(*(f+n),data,i,ex+n*NumCodons*e);
      long double slm=0;
      for(int j=0;j<NumCodons;j++){
	slm+=*((p+n)->pi+j)*(*(down+j));
      };
      *(siteliks+i)+=slm*(*(pp+n));
    };
  };
  long double ans=0;
  for(int j=0;j<sites;j++){
    ans+=log(*(siteliks+j));
  };
  delete[] ex;
  delete[] le;
  delete[] siteliks;
  delete[] pp;
  return ans;
};
