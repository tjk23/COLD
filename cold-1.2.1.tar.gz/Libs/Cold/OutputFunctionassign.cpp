/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

  switch(*(type+CURRENTNUMBER)){
  case 'i':
  case 'e':
  case 'I':
  case 'E':
    *(array+CURRENTNUMBER)=new intcomp(FUNCTIONNAME(CURRENTNUMBER));
    break;
  case 'd':
  case 'D':
    *(array+CURRENTNUMBER)=new ldcomp(FUNCTIONNAME(CURRENTNUMBER));
    break;
  default:
    *(array+CURRENTNUMBER)=new strcomp(FUNCTIONNAME(CURRENTNUMBER));
  };
#define DIMENSIONFUNCTION(a) a##_dim
#define DIMFUNCTION(a) DIMENSIONFUNCTION(a)
  *(dims+CURRENTNUMBER)=DIMFUNCTION(FUNCTIONNAME(CURRENTNUMBER));
