/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Parameters.h"
#include <fstream>
#include <math.h>

#include <iostream>


#include "ErrorHandler.h"
#include "Macros.h"
#include "Matrix.h"

using namespace std;
/* Class and routines affecting parameters */

int setifstream(const char *val,void *address);

inline int tri(int a,int b){//For indexing triangular arrays.
  int x=(a>b)?a:b;
  int n=(a>b)?b:a;
  return(x*(x+1)/2+n);
};

/*

The R matrix is given by R_ij=exp(sum_k(x_ijk b_k)), when i!=j.  Hence
the derivative is given by dR_ij/db_k=x_ijk R_ij, whenever i!=j, and
is constrained by the sum of each row being zero otherwise.

 */

#define DEFAULTFILENAME "parametermatrices"

void unsetupParams();
RealmatrixT orthonormalisemats(Realmatrix *X,int n);
RealmatrixT normalisemats(Realmatrix *X,int n);

void params::selectpars(const int *sel){
  Realmatrix AA=A.inverse();
  int np=1;
  for(;*(sel+np-1)>=0;np++);
  /*  for(int i=0;i<numpars;i++){
    cout<<(XX+i)->entries<<" ";
  };
  cout<<"\n";*/
  for(int i=numpars-1;i>=0;i--){
    for(int k=0;k<NumCodonsSq;k++){
      *((XX+i)->entries+k)*=*(AA.entries+i*(numpars+1));
    };
    for(int j=0;j<i;j++){
      for(int k=0;k<NumCodonsSq;k++){
	*((XX+i)->entries+k)+=*((XX+j)->entries+k)*(*(AA.entries+j*numpars+i));
      };
    };
  };
  long double **tmp=new long double*[numpars-np];
  int cur=0;
  for(int i=1;i<np;i++){
    if(*(sel+i-1)!=i&&(XX+i)->entries!=NULL){
      *(tmp+cur++)=(XX+i)->entries;
    };
    (XX+i)->entries=(XX+*(sel+i-1))->entries;
    if(*(sel+i-1)!=i){
      (XX+*(sel+i-1))->entries=NULL;
    };
  };
  for(int i=np;i<numpars;i++){
    if((XX+i)->entries!=NULL){
      *(tmp+cur++)=(XX+i)->entries;
    };
    (XX+i)->entries=*(tmp+i-np);
  };
  /*  for(int i=0;i<numpars;i++){
    cout<<(XX+i)->entries<<" ";
  };
  cout<<"\n";*/
  numpars=np;
  A=orthonormalisemats(XX,numpars);
  delete[] tmp;
};

void params::undoselect(const int *sel,int num){
  Realmatrix AA=A.inverse();
  for(int i=numpars-1;i>=0;i--){
    for(int k=0;k<NumCodonsSq;k++){
      *((XX+i)->entries+k)*=*(AA.entries+i*(AA.sz+1));
    };
    for(int j=0;j<i;j++){
      for(int k=0;k<NumCodonsSq;k++){
	*((XX+i)->entries+k)+=*((XX+j)->entries+k)*(*(AA.entries+j*numpars+i));
      };
    };
  };
  //  cout<<"Got here.\n";
  long double **tmp=new long double *[num-numpars];
  for(int i=0;i<num-numpars;i++){
    *(tmp+i)=(XX+i+numpars)->entries;
  };
  int cur=num-numpars-1;
  int sl=numpars-2;
  for(int j=num-1;j>=1;j--){
    if(sl>=0&&*(sel+sl)==j){
      (XX+j)->entries=(XX+sl+1)->entries;
      sl--;
    }else{
      (XX+j)->entries=*(tmp+cur);
      cur--;
    };
  };
  //  cout<<"Got here.\n";
  numpars=num;
  /*  for(int i=0;i<numpars;i++){
    cout<<(XX+i)->entries<<" ";
  };
  cout<<"\n";*/
  A=orthonormalisemats(XX,numpars);
  delete[] tmp;
};

long double params::dist(int *cf){
//Measures the real distance between two different sets of parameters.
  return 0;

};

params::~params(){
  delete[] pi;
  delete[] derivs;
  delete[] coeff;
};

params::params(){
  if(setupp!=1){
    params::setup(DEFAULTFILENAME);
  };
  pi=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(pi+i)=1/((long double)NumCodons);
  };
  R=RealmatrixT(NumCodons);
  derivs=new Realmatrix[numpars*(numpars+3)/2];
  for(int i=0;i<numpars*(numpars+3)/2;i++){
    *(derivs+i)=RealmatrixT(NumCodons);
  };
  coeff=new long double[numpars];
  for(int i=0;i<numpars;i++){
    *(coeff+i)=0;
  };
  if(numpars==0){
    R=getsym(A,pi);
  };    
};

long double *params::truepars(){
  long double *ans=new long double[numpars];
  A.act(coeff,ans);
  return ans;
};

void params::setTrueCoeff(const long double *cnew){
  Realmatrix Ai=A.inverse();
  Ai.act(cnew,coeff);
  this->setR();
};


void unsetupParams();

void params::setup(const char *name){
  //    cout<<"Setting up parameters using values from file \""<<name<<"\".\n";
  if(!in.is_open()){
    //    cout<<"in is not open.\n";
    setifstream(name,&in);
    //    in.open(name);
  };
  if(!in.good()){
    unsetupParams();
    char *errmess=new char[strlen(name)+30];
    strcpy(errmess,"Could not open file \"");
    strcat(errmess,name);
    strcat(errmess,"\".\n");
    recoverableError(errmess);
  };
  setup(in);
  in.close();
  //  comm<<"Parameters successfully set up.\n";
};

ifstream params::in(DEFAULTFILENAME);
int params::setupp=0;
Realmatrix* params::XX=NULL;
Realmatrix params::A=Realmatrix(0);
char params::Filename[50]=DEFAULTFILENAME;
int params::numpars=NUMPARS;
Realmatrix* params::mask=NULL;

void unsetupParams(){
  if(params::setupp==1){
    //    comm<<"Cleaning up class Params.\n";
    if(params::XX!=NULL){
      delete[] params::XX;
    };
    if(params::mask!=NULL){
      delete params::mask;
    };
    //    for(int i=0;i<NUMPARS;i++){
      //      delete (params::XX+i);
    //    };
  };
};

RealmatrixT orthonormalisemats(Realmatrix *X,int n){
  Realmatrix A(n);
  for(int i=0;i<n;i++){
    *(A.entries+i*(n+1))=1;
  };
  int ssq=(X->sz)*(X->sz);
  for(int i=0;i<n;i++){
    for(int j=0;j<i;j++){
      long double dot=0;
      for(int k=0;k<ssq;k++){
	dot+=*((X+j)->entries+k)*(*((X+i)->entries+k));
      };
      for(int k=0;k<=j;k++){
	*(A.entries+k*n+i)-=dot*(*(A.entries+k*n+j));
      };
      for(int k=0;k<ssq;k++){
	*((X+i)->entries+k)-=dot*(*((X+j)->entries+k));
      };
    };
    long double mods=0;
    for(int k=0;k<ssq;k++){
      mods+=*((X+i)->entries+k)*(*((X+i)->entries+k));
    };
    for(int k=0;k<=i;k++){
      *(A.entries+k*n+i)/=sqrt(mods);
    };
    for(int k=0;k<ssq;k++){
      *((X+i)->entries+k)*=(*(A.entries+i*(n+1)));
    };
  };
  return A;
};

RealmatrixT normalisemats(Realmatrix *X,int n){
  Realmatrix A(n);
  int ssq=(X->sz)*(X->sz);
  for(int i=0;i<n;i++){
    //    cout<<i<<"\n";
    long double mods=0;
    for(int k=0;k<ssq;k++){
      mods+=*((X+i)->entries+k)*(*((X+i)->entries+k));
    };
    for(int j=0;j<n;j++){
      *(A.entries+i*n+j)=(i==j)?(X->sz/sqrt(mods)):0;
    };
    for(int k=0;k<ssq;k++){
      //      cout<<k<<"\t"<<*((X+i)->entries+k)<<"\t"<<*(A.entries+i*(n+1))<<"\n";
      *((X+i)->entries+k)*=(*(A.entries+i*(n+1)));
    };
  };
  return A;
};

void params::setR(){
  //recalculates the Rmatrix to adjust for changes to the parameters.
  if(numpars==0){//Don't do anything if using a fixed matrix.
    return;
  };
  /*
  scale=-100;
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      if(i!=j){
	long double l=0;
	for(int k=0;k<numpars;k++){
	  l+=X(i,j,k)*(*(coeff+k));
	};
	if(l>scale){
	  scale=l;
	};
      };
    };
  };
  cout<<"scale="<<scale<<"\n";
  if(scale>SCALEMAX){
    scale-=SCALEMAX;
  }else if(scale<SCALEMIN){
    scale-=SCALEMIN;
    }else{*/
    //  };
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      if(i!=j){
	long double l=0;
	for(int k=0;k<numpars;k++){
	  l+=X(i,j,k)*(*(coeff+k));
	};
	*(R.entries+i*NumCodons+j)=exp(l);//-scale
      };
    };
  };
  scale=1;
  //  scale=exp(scale);
  if(mask!=NULL){
    for(int i=0;i<NumCodonsSq;i++){
      *(R.entries+i)*=*(mask->entries+i);
    };
  };
  for(int i=0;i<NumCodons;i++){
    *(R.entries+i*(NumCodons+1))=0;
    for(int j=0;j<NumCodons;j++){
      if(j!=i){
	*(R.entries+i*(NumCodons+1))-=*(pi+j)*(*(R.entries+i*NumCodons+j));
      };
    };
    *(R.entries+i*(NumCodons+1))/=*(pi+i);
  };
};


long double params::testpars(const Realmatrix& Q){
  //tests whether a given attempt to find the parameters works.
  long double err=0;
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      long double e=*(R.entries+i*NumCodons+j)*(*(pi+j))-*(Q.entries+i*NumCodons+j);
      if(NONZEROST(e)&&(e>err||e<-err)){
	err=e>0?e:-e;
      };
    };
  };
  return err;
};

void params::regressionpars(const long double *temp){
  if(R.sz!=0){
    delete[] R.entries;
  };
  R.entries=new long double[NumCodonsSq];
  for(int i=0;i<NumCodonsSq;i++){
    *(R.entries+i)=*(temp+i);
  };
  R.sz=NumCodons;
  long double *a=new long double[numpars];
  for(int k=0;k<numpars;k++){
    *(a+k)=0;
  };
  for(int i=0;i<NumCodons;i++){
    for(int j=i+1;j<NumCodons;j++){
      if(mask==NULL||*(mask->entries+i*NumCodons+j)>1e-5){
	long double l=log(*(R.entries+i*NumCodons+j));
	for(int k=0;k<numpars;k++){
	  long double sc=exp(-l*l/100)*(*(pi+j));
	  *(a+k)+=l*X(i,j,k)*sc;
	};
      };
    };
  };
  Realmatrix tem(numpars);
  for(int i=0;i<numpars;i++){
    for(int ii=0;ii<numpars;ii++){
      *(tem.entries+i*numpars+ii)=0;
    };
  };
  for(int j=0;j<NumCodons;j++){
    for(int k=j+1;k<NumCodons;k++){
      if(mask==NULL||*(mask->entries+j*NumCodons+k)>1e-5){
	long double l=log(*(R.entries+j*NumCodons+k));
	long double sc=exp(-l*l/100)*(*(pi+k));      
	for(int i=0;i<numpars;i++){
	  for(int ii=0;ii<numpars;ii++){
	    *(tem.entries+i*numpars+ii)+=X(j,k,i)*X(j,k,ii)*sc;
	  };
	};
      };
    };
  };
  Realmatrix(tem.inverse()).act(a,coeff);
  delete[] a;
};


long double params::getpars(const Realmatrix& Q){
  //Finds the parameters that give a fixed Q matrix. Returns 0 on
  //success, nonzero on error. Assume Q=Rpi for a diagonal matrix
  //pi. and symmetric R.
  long double *temp=new long double[NumCodonsSq];
  long double *temp2=new long double[NumCodonsSq];
  long double *normsq=new long double[NumCodons];
  long double *norm2sq=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(normsq+i)=0;
    *(norm2sq+i)=0;
  };
  for(int i=0;i<NumCodonsSq;i++){
    *(temp+i)=*(Q.entries+i);
  };
  for(int i=0;i<NumCodons;i++){
    *(pi+i)=0;
    for(int j=0;j<NumCodons;j++){
      if(NONZEROST(*(temp+j*NumCodons+i))){
	*(pi+i)+=*(temp+i*NumCodons+j)/(*(temp+j*NumCodons+i));//Should do something to deal better with zero values.
      };
    };
  };
  long double s=0;
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(temp2+i*NumCodons+j)=*(temp+i*NumCodons+j)*(*(pi+j))-*(temp+j*NumCodons+i)*(*(pi+i));
      *(norm2sq+j)+=*(temp2+i*NumCodons+j)*(*(temp2+i*NumCodons+j));
      *(normsq+j)+=*(temp+i*NumCodons+j)*(*(temp+i*NumCodons+j));
    };
  };
  for(int i=0;i<NumCodons;i++){
    s+=*(norm2sq+i);
  };           //Now temp2 should store the antisymmetric part of the
	       //matrix, and s should store its size.
  for(int i=0;i<100&&NONZEROSTSQ(s);i++){
    s=0;
    for(int j=0;j<NumCodons;j++){
      long double d=0;
      for(int k=0;k<NumCodons;k++){
	d+=*(temp2+k*NumCodons+j)*(*(temp+k*NumCodons+j));
      };
      long double lam=d/(*(normsq+j));
      *(pi+j)-=lam;
      for(int k=0;k<NumCodons;k++){
	long double l=lam*(*(temp+k*NumCodons+j));
	*(temp2+k*NumCodons+j)-=l;
	if(k!=j){
	  *(norm2sq+k)+=2*(*(temp2+j*NumCodons+k)*l)+l*l;
	};
	*(temp2+j*NumCodons+k)+=l;
      };
      *(norm2sq+j)-=lam*d;
    };
    for(int j=0;j<NumCodons;j++){
      s+=*(norm2sq+j);
    };
  };    
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(temp+i*NumCodons+j)*=*(pi+j);
    };
  };
  for(int i=0;i<NumCodons;i++){
    *(pi+i)=1/(*(pi+i));
  };
  delete[] temp2;
  delete[] norm2sq;
  delete[] normsq;
  //  comm<<"Symmetrised matrix.\n";
  if(numpars==0){
    return NONZEROSTSQ(s)?s:0;
  };
  //Now need to perform a linear regression on the appropriate logarithm.
  this->regressionpars(temp);
  delete[] temp;
  long double *d=new long double[NumCodons];
  this->setR();
  C=R.diagonalisesymmetric(d);//Can possibly work this out from Q.
  delete[] d;
  return (NONZEROSTSQ(s))?s:0;
       //If the matrix is symmetric, then it returns 0. Otherwise, the
       //return value measures how far from symmetric the original
       //matrix was.
};

long double params::getparsFixedPi(const Realmatrix& Q){
  //Finds the parameters that give a fixed Q matrix. Returns 0 on
  //success, nonzero on error. Assume Q=Rpi for a diagonal matrix
  //pi. and symmetric R.
  long double s=0;
  //Now need to perform a linear regression on the appropriate logarithm.
  long double *temp=new long double[NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(temp+i*NumCodons+j)=*(Q.entries+i*NumCodons+j)/(*(pi+j));
    };
  };

  this->regressionpars(temp);
  delete[] temp;
  /*  

  if(R.sz!=0){
    delete[] R.entries;
  };
  R.entries=new long double[NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(R.entries+i*NumCodons+j)=*(Q.entries+i*NumCodons+j)/(*(pi+j));
    };
  };
  R.sz=NumCodons;
  if(numpars==0){
    return NONZEROSTSQ(s)?s:0;
  };

  long double *a=new long double[numpars];
  for(int k=0;k<numpars;k++){
    *(a+k)=0;
  };
  for(int i=0;i<NumCodons;i++){
    for(int j=i+1;j<NumCodons;j++){
      if(mask==NULL||*(mask->entries+i*NumCodons+j)>1e-5){
	long double l=log(*(R.entries+i*NumCodons+j));
	for(int k=0;k<numpars;k++){
	  long double sc=exp(-l*l/100)*(*(pi+j));
	  //(*(R.entries+i*NumCodons+j))*(*(R.entries+i*NumCodons+j))*(*(pi+j));
	  *(a+k)+=l*X(i,j,k)*sc;
	};
      };
    };
  };
  Realmatrix tem(numpars);
  for(int i=0;i<numpars;i++){
    for(int ii=0;ii<numpars;ii++){
      *(tem.entries+i*numpars+ii)=0;
    };
  };
  for(int j=0;j<NumCodons;j++){
    for(int k=j+1;k<NumCodons;k++){
      if(mask==NULL||*(mask->entries+j*NumCodons+k)>1e-5){
	long double l=log(*(R.entries+j*NumCodons+k));
	long double sc=exp(-l*l/100)*(*(pi+k));      
	for(int i=0;i<numpars;i++){
	  for(int ii=0;ii<numpars;ii++){
	    *(tem.entries+i*numpars+ii)+=X(j,k,i)*X(j,k,ii)*sc;
	  };
	};
      };
    };
  };
  Realmatrix(tem.inverse()).act(a,coeff);
  delete[] a;
  */
  long double *d=new long double[NumCodons];
  this->setR();
  C=R.diagonalisesymmetric(d);//Can possibly work this out from Q.
  delete[] d;
  return (NONZEROSTSQ(s))?s:0;
};


Factmatrix params::fmatrix(){//almost const, but sets up C to the correct value.
  Factmatrix o(NumCodons);
  Realmatrix Q;
  //  Realmatrix R=this->Rmatrix();
  Realmatrix S(NumCodons);
  long double *d=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(S.entries+i*NumCodons+j)=*(R.entries+i*NumCodons+j)*sqrt(*(pi+i))*sqrt(*(pi+j));
    };
  };
  Q=S.diagonalisesymmetric(d);//May change this function specification.
  //Rpi=pi^{-1/2}pi^{1/2}Rpi^{1/2}pi^{1/2}
  o.D.assign(d,NumCodons);
  //  long double *r=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(o.gamma.entries+i*NumCodons+j)=*(Q.entries+i*NumCodons+j)/sqrt(*(pi+i));
    };
  };
  for(int i=0;i<NumCodons;i++){
    if(*(o.D.entries+i)>0){
      *(o.D.entries+i)=0;//Avoid large eigenvalues
      for(int j=0;j<NumCodons;j++){
	//      	*(o.gamma.entries+j*NumCodons+i)=*(pi+j); //To avoid the diagonalisation choosing -1 instead.
      };
    };
  };
  o.gammainv=o.gamma.inverse();
  o.setA();
  //  cout<<Realmatrix(o.A)<<"\n\n";
  delete[] d;
  //  delete[] r;
  this->calculate_derivs(o);
  return(o);
};

Realmatrix params::Rmatrix() const {
  return R;
};

long double params::normalise(){
  //Normalises parameters, so that branch lengths correspond to expected
  //number of changes.
  //Need to satisfy the formula
  //sum_i\ne j pi_i pi_j Rij = 1  
  this->setR();
  if(numpars==0){
    return 1;
  };
  long double ans=0;
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      if(i!=j){
	ans+=*(pi+i)*(*(pi+j))*(*(R.entries+i*NumCodons+j));
      };
    };
  };
  //Now ans is the inaccuracy in the scaling. We need to rescale by ans.
  long double l=log(ans);
  *coeff-=l/X(0,1,0);
  this->setR();
  return ans;
};

#include "Derivatives.cpp"
