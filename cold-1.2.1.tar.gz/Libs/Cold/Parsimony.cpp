/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Tree.h"
#include "Parameters.h"
#include "Sequence.h"
#include "TreeLikelihood.h"
#include "MixTreeLikelihood.h"
#include "Miscellaneous.h"

#include <math.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
#define ZEROST(a) ((a)<1e-17&&(a)>-1e-17)


class temp{
public:
  unsigned int sst;
  unsigned int sstfrq;
  long double prob;
};

void inserttemp(linkedlist<temp> &list,unsigned int sst,long double prb){
  linkedlist<temp> *tmp=&list;
  for(;tmp!=NULL&&tmp->l!=NULL&&tmp->l->sst!=sst;tmp=tmp->next);
  if(tmp==NULL||tmp->l==NULL){
    temp a;
    a.sst=sst;
    a.sstfrq=1;
    a.prob=prb;
    list.insert(1,&a);    
  }else{
    tmp->l->sstfrq++;
    tmp->l->prob+=prb;
  };
};

void normalisetemplist(linkedlist<temp> &list){
  for(linkedlist<temp> *tmp=&list;tmp!=NULL&&tmp->l!=NULL;tmp=tmp->next){
    tmp->l->prob/=tmp->l->sstfrq;
  };
};

class partialf2basis{
  unsigned int dim;
  unsigned int sz;
  long unsigned int *v;
  //  long double *val;
public:
  partialf2basis(unsigned int d){dim=d;sz=0;v=new long unsigned int[d];};
  ~partialf2basis(){delete[] v;};
  int addvector(unsigned int i);
  void clear(){sz=0;};
  void remlast(){sz--;};
};

inline int before(unsigned int i,unsigned int j){
  //returns 1 if the most significant digit of i is larger than that of j.
  return (i&(i^j))>j;
};

int partialf2basis::addvector(unsigned int i){
  //Returns   -1 if already a basis
  //           0 if linearly dependent
  //           1 if added OK.
  //           2 if forms a basis after adding i
  if(sz==dim){
    return -1;
  };
  for(unsigned int s=0;s<sz;s++){
    if(before(i,*(v+s))){
      for(unsigned int ps=sz;ps>s;ps--){
	*(v+ps)=*(v+ps-1);
      };
      *(v+s)=i;
      sz++;
      //      cout<<"sz="<<sz<<" dim="<<dim<<"\n";
      return (sz==dim)?2:1;
    }else if(!before(*(v+s),i)){
      i^=*(v+s);
    };
  };
  if(i==0){
    return 0;
  }else{
    *(v+sz++)=i;
    //    cout<<"sz="<<sz<<" dim="<<dim<<"\n";
    return (sz==dim)?2:1;
  };
};

void solvelosematrix(long double *M,const long double *v,long double *w,int dim);


unsigned int incrementlast(linkedlist<temp> **basis,int dim,unsigned int from){
  if(*(basis+from)==NULL){
    if(from==0){
      return 0;
    };
    return incrementlast(basis,dim,from-1);
  };
  *(basis+from)=(*(basis+from))->next;
  if(*(basis+from)==NULL||(*(basis+from))->l==NULL){
    if(from==0){
      return 0;
    };
    return incrementlast(basis,dim,from-1);
  }else{
    return from;
  };
};

unsigned int increment(linkedlist<temp> **basis,unsigned int dim,unsigned int from){
  if(from==dim-1){
    return incrementlast(basis,dim,from);
  };
  *(basis+from+1)=(*(basis+from))->next;
  if(*(basis+from+1)==NULL||(*(basis+from+1))->l==NULL){
    return incrementlast(basis,dim,from);
  }else{
    return from+1;
  };
};

void addestimates(long double *to,unsigned int dim,linkedlist<temp> **basis,long double factor){
  long double *R=new long double[dim*dim];
  long double *vals=new long double[dim];
  long double *sol=new long double[dim];
  for(unsigned int i=0;i<dim;i++){
    for(unsigned int j=0;j<dim;j++){
      *(R+i*dim+j)=((*(basis+i))->l->sst&(1<<j))>>j;
      //      cout<<*(R+i*dim+j)<<" ";
    };
    //    cout<<"\n";
    *(vals+i)=(*(basis+i))->l->prob;
  };
  //  cout<<"\n";
  solvelosematrix(R,vals,sol,dim);//Very slow
  for(unsigned int i=0;i<dim;i++){
    *(to+i)+=*(sol+i)*factor;
  };
  delete[] R;
  delete[] vals;
  delete[] sol;
};

long double *estimatefromsubsetestimates(unsigned int dim,linkedlist<temp> ests){
  //  unsigned int subsets=(1<<dim)-1;

  partialf2basis bas(dim);
  linkedlist<temp> **currentbasis=new linkedlist<temp> *[dim];
  unsigned int basislength=0;
  unsigned long int *cbf=new unsigned long int[dim];
  long double *estimates=new long double[dim];
  long double totfreq=0;
  for(unsigned int i=0;i<dim;i++){
    *(estimates+i)=0;
    *(currentbasis+i)=NULL;
  };
  int lastbasislength=-1;
  for(*currentbasis=&ests;*currentbasis!=NULL;){    
    //    cout<<"basis length="<<basislength<<" last basis length="<<lastbasislength<<"\n";
    //    for(int i=0;i<=basislength;i++){
      //      cout<<(*(currentbasis+i))->l->sst<<"  "<<(*(currentbasis+i))->l->sstfrq<<"  "<<(*(currentbasis+i))->l->prob<<"\n";
    //    };
    //    cout<<"\n";
    linkedlist<temp> *pos=*(currentbasis+basislength);
    int av;
    if(basislength==lastbasislength+1){
      av=bas.addvector(pos->l->sst);
      //      cout<<"av="<<av<<"\n";
    }else{
      bas.clear();
      if(basislength>0){
	av=bas.addvector((*currentbasis)->l->sst);
	*cbf=((*currentbasis)->l->sstfrq);
      };
      for(unsigned int i=1;i<basislength;i++){
	av=bas.addvector((*(currentbasis+i))->l->sst);
	*(cbf+i)=*(cbf+i-1)*((*(currentbasis+i))->l->sstfrq);
	if(av!=1){//shouldnt happen
	  throw av;
	};
      };
      av=bas.addvector((*(currentbasis+basislength))->l->sst);
      //      cout<<"av="<<av<<"\n";
    };
    lastbasislength=basislength;
    switch(av){
    case -1: //Shouldn't happen
      throw -1;
    case 0:
      basislength=incrementlast(currentbasis,dim,basislength);
    case 1:
      *(cbf+basislength)=((basislength>0)?*(cbf+basislength-1):1)*(pos->l->sstfrq);
      basislength=increment(currentbasis,dim,basislength);
      break;
    case 2:
      *(cbf+basislength)=((basislength>0)?*(cbf+basislength-1):1)*(pos->l->sstfrq);
      //      for(unsigned int i=0;i<dim;i++){
	addestimates(estimates,dim,currentbasis,*(cbf+basislength));
	//      };
      totfreq+=*(cbf+basislength);
      basislength=increment(currentbasis,dim,basislength);
    };
  };
  //  cout<<totfreq<<"\t";
  for(unsigned int i=0;i<dim;i++){
    *(estimates+i)/=totfreq;
    //    cout<<*(estimates+i)<<"  ";
  };
  delete[] cbf;
  //  cout<<"\n";
  return estimates;
};


void regression(const Realmatrix &R,long double *out,const Realmatrix *X,int num,int *valid,const Realmatrix *mask){
  int numpars=0;
  for(int i=0;i<num;i++){
    numpars+=*(valid+i)?1:0;
  };
  //Performs a weighted regression designed to reduce the influence of outliers.
  long double *a=new long double[numpars];
  for(int k=0;k<numpars;k++){
    *(a+k)=0;
  };
  for(int i=0;i<NumCodons;i++){
    for(int j=i+1;j<NumCodons;j++){
      if(mask==NULL||*(mask->entries+i*NumCodons+j)>1e-5){
	long double l=*(R.entries+i*NumCodons+j);
	for(int k=0;k<numpars;k++){
	  long double sc=1;//exp(-l*l/100);
	  //	  cout<<l<<" "<<*((X+k)->entries+i*NumCodons+j)<<" "<<sc<<"\n";
	  *(a+k)+=l*(*((X+k)->entries+i*NumCodons+j))*sc;
	};
      };
    };
  };
  //  for(int i=0;i<numpars;i++){
  //    cout<<*(a+i)<<"\n";
  //  };
  Realmatrix tem(numpars);
  for(int i=0;i<numpars;i++){
    for(int ii=0;ii<numpars;ii++){
      *(tem.entries+i*numpars+ii)=0;
    };
  };
  for(int j=0;j<NumCodons;j++){
    for(int k=j+1;k<NumCodons;k++){
      if(mask==NULL||*(mask->entries+j*NumCodons+k)>1e-5){
	//	long double l=*(R.entries+j*NumCodons+k);
	//	cout<<"l="<<l<<"\n";
	long double sc=1;//exp(-l*l/100);      
	int ij=0;
	for(int i=0;i<num;i++){
	  if(*(valid+i)){
	    int iij=0;
	    for(int ii=0;ii<num;ii++){
	      if(*(valid+ii)){
		//		cout<<ij<<" "<<iij<<"  "<<i<<" "<<ii<<"  "<<*((X+i)->entries+j*NumCodons+k)*(*((X+ii)->entries+j*NumCodons+k))<<"\n";
		*(tem.entries+ij*numpars+iij)+=*((X+i)->entries+j*NumCodons+k)*(*((X+ii)->entries+j*NumCodons+k))*sc;
		iij++;
	      };
	    };
	    ij++;
	  };
	};
      };
    };
  };
  //  cout<<tem<<"\n";
  long double *temp=new long double[numpars];
  Realmatrix(tem.inverse()).act(a,temp);
  int j=0;
  for(int i=0;i<num;i++){
    if(*(valid+i)){
      *(out+i)=*(temp+j);
      j++;
    };
  };
  delete[] temp;
  delete[] a;  
};

void inline putcodonps(int c,long double *down,long double inf){
  //Need to modify this to work for arbitrary number of codons.
  if(c<61){
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i==c)?0:inf;
    };
  }else if(c<125){//second nucleotide unknown
    c-=61;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/4==c)?0:inf;
    };
  }else if(c<189){//first Nucleotide unknown
    c-=125;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%4==c%4)&&(i/16==c/16))?0:inf;
    };
  }else if(c<253){//first two Nucleotides unknown
    c-=189;
    c/=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/16==c)?0:inf;
    };
  }else if(c<317){//Third nucleotide unknown
    c-=253;      
    c%=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%16==c)?0:inf;
    };
  }else if(c<381){//Third and second nucleotides unknown
    c-=317;
    c%=16;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%16)/4==c)?0:inf;
    };
  }else if(c<445){//Third and second nucleotides unknown
    c-=381;
    c%=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%4==c)?0:inf;
    };
  }else{//all unknown
    for(int i=0;i<NumCodons;i++){
      *(down+i)=0;
    };
  };
};

inline void swaprows(int i,int j,long double *mat,int d){
  for(int k=0;k<d;k++){
    long double temp=*(mat+i*d+k);
    *(mat+i*d+k)=*(mat+j*d+k);
    *(mat+j*d+k)=temp;
  };    
};

long double evalpoly(const long double *coeff,long double val,int deg){
  long double ans=*coeff;
  long double pow=val;
  for(int i=1;i<deg;i++){
    ans+=pow*(*(coeff+i));
    pow*=val;
  };
  return ans+pow;
};

long double findroot(const long double *coeff,long double bot,long double top,int deg){
  //Use interval bisection for robustness and simplicity.  
  int sn=(evalpoly(coeff,bot,deg)>0)?1:-1;
  long double md=(top+bot)/2;
  while((top-bot)>(((md<0 )?-md:md)+1e-20)*1e-12){
    if(sn*evalpoly(coeff,md,deg)>0){
      bot=md;
    }else{
      top=md;
    };
    md=(top+bot)/2;
  };
  return md;
};

void solvemonicpolyrev(const long double *coeff,long double *output, int deg){
  if(deg==1){
    *output=-*coeff;
    return;
  };
  long double *dercoeff=new long double[deg-1];
  for(int i=0;i<deg-1;i++){
    *(dercoeff+i)=(*(coeff+i+1)*(i+1))/deg;
  };
  solvemonicpolyrev(dercoeff,output+1, deg-1);
  *output=0;
  for(int i=0;i<deg;i++){
    *output-=(*(coeff+i)>0)?*(coeff+i):-*(coeff+i);
  };
  if(*output>-1){
    *output=-1;
  };
  long double top=-*output;
  for(int i=0;i<deg-1;i++){
    *(output+i)=findroot(coeff,*(output+i),*(output+i+1),deg);
  };
  *(output+deg-1)=findroot(coeff,*(output+deg-1),top,deg);
  delete[] dercoeff;
};

void solvelosematrix(long double *M,const long double *v,long double *w,int dim){
  //Uses Gaussian elimination to solve Mw=v. Doesn't resolve case for
  //singular M.
  //Destroys original matrix.
  /*
  for(int i=0;i<dim;i++){
    for(int j=0;j<dim;j++){
      cout<<*(M+i*dim+j)<<" ";
    };
    cout<<"\n";
    };*/
  long double *v0=new long double[dim];
  for(int i=0;i<dim;i++){
    *(v0+i)=*(v+i);
  };
  long double scale=*M;
  for(int r=0;r<dim;r++){
    if(fabs(*(M+r*dim))>scale){
      scale=fabs(*(M+r*dim));
    };
  };
  for(int c=1;c<dim;c++){
    long double mx=*(M+c);
    for(int r=0;r<dim;r++){
      if(fabs(*(M+r*dim+c))>mx){
	mx=fabs(*(M+r*dim+c));
      };
    };
    if(mx<scale){
      scale=mx;
    };
  };
  for(int i=0;i<dim-1;i++){
    long double mmod=0;
    int mxrw=i;
    for(int j=i;j<dim;j++){
      long double e=(*(M+j*dim+i)<0)?-*(M+j*dim+i):*(M+j*dim+i);
      if(mmod<e){
	mmod=e;
	mxrw=j;
      };
    };
    if(ZEROST(mmod/scale)){
      throw(0);//singular matrix
    };
    if(mxrw!=i){
      mmod=*(v0+i);
      *(v0+i)=*(v0+mxrw);
      *(v0+mxrw)=mmod;
      swaprows(i,mxrw,M,dim);
    };
    for(int j=i+1;j<dim;j++){
      long double pivot=*(M+j*dim+i)/(*(M+i*dim+i));
      *(M+j*dim+i)=0;
      for(int k=i+1;k<dim;k++){
	*(M+j*dim+k)-=*(M+i*dim+k)*pivot;
      };
      *(v0+j)-=*(v0+i)*pivot;
    };
  };
  if(ZEROST(*(M+dim*dim-1)/scale)){
    throw(0); //Matrix is singular;
  };
  for(int i=dim-1;i>=0;i--){
    *(w+i)=*(v0+i)/(*(M+i*(dim+1)));
    for(int j=0;j<i;j++){
      *(v0+j)-=*(w+i)*(*(M+j*dim+i));
    };
  };
  delete[] v0;
};

void solvenonlinVDM(int n,const long double *x,long double *ans){
  long double *M=new long double[n*n];
  for(int i=0;i<n;i++){  
    for(int j=0;j<n;j++){  
      *(M+i*n+j)=-*(x+i+j);
    };
  };
  long double *sim=new long double[n];
  solvelosematrix(M,x+n,sim,n);
  solvemonicpolyrev(sim,ans+n,n);
  for(int i=0;i<n;i++){
    long double Ai=1;
    for(int j=0;j<n;j++){
      if(j!=i){
	Ai*=(*(ans+n+i)-*(ans+n+j));
      };
    };

    //    *(sim+i)=sym(i+1)
    Ai=1/(Ai);
    long double sm=pow(-1,n)*(*(x+n-1));
    long double sij=1;
    for(int j=0;j<n-1;j++){
      sij=pow(-1,j+1)*(*(sim+n-j-1))-*(ans+n+i)*sij;
      sm+=pow(-1,n-j-1)*(*(x+n-2-j))*sij;
    };
    if(n%2==0){
      *(ans+i)=(sm*Ai);
    }else{
      *(ans+i)=(-sm*Ai);
    };
  };
  delete[] M;
};

void solvenonlinVDM(int n,const long double *x,int m,const long double *v,long double *ans){
  //Solves a Vandermonde system where some of the values are known.
  long double *sig=new long double[m+1];
  for(int i=0;i<=m;i++){
    *(sig+i)=0;
  };
  *sig=1;
  for(int i=1;i<=m;i++){
    for(int j=i;j>0;j--){
      *(sig+j)+=*(sig+j-1)*(*(v+i-1));      
    };
  };
  long double *M=new long double[(n-m)*(n-m)];
  for(int i=0;i<n-m;i++){  
    for(int j=0;j<n-m;j++){  
      *(M+i*(n-m)+j)=((i+j==0)?1:*(x+i+j-1))*(*(sig+m))*pow(-1,m);
      for(int k=1;k<=m;k++){
	//	if(i+j+k==0){
	//	  *(M+i*(n-m)+j)-=(*(sig+k));	
	//	}else{
	*(M+i*(n-m)+j)+=(*(x+i+j+k-1))*(*(sig+m-k))*pow(-1,m-k);
	  //	};
      };
    };
  };
  long double *nf=new long double[n-m];
  for(int i=0;i<n-m;i++){
    *(nf+i)=*(x+i+n-1);//*pow(-1,m+1);
    for(int k=0;k<m;k++){
      *(nf+i)-=*(x+i+n-m+k-1)*(*(sig+m-k))*pow(-1,m-k-1);
    };
  };

  delete[] sig;
  /*      cout<<"\nmoments:\n";
  for(int i=0;i<n*2-m-1;i++){
    cout<<*(x+i)<<" ";
  };
  cout<<"\n\n";
  //  */
  /*
  cout<<"fixed values:\n";
  for(int i=0;i<m;i++){
    cout<<*(v+i)<<" ";
  };
  cout<<"\n\n";

  for(int i=0;i<(n-m);i++){
    for(int j=0;j<(n-m);j++){
      cout<<*(M+i*(n-m)+j)<<" ";
    };
    cout<<"\t"<<*(nf+i)<<"\n";
  };
  cout<<"\n";
  */

  long double *sim=new long double[n];
  solvelosematrix(M,nf,sim+m,n-m);
  delete[] nf;
  for(int i=m;i<n;i++){
    *(sim+i)=-*(sim+i);
    //    cout<<*(sim+i)<<" ";
  };
  //  cout<<"\n";
  solvemonicpolyrev(sim+m,ans+n,n-m);
  for(int i=0;i<m;i++){
    *(sim+i)=0;
  };
  for(int i=m-1;i>=0;i--){
    for(int j=i+1;j<n;j++){
      *(sim+j-1)-=*(v+i)*(*(sim+j));
    };
    *(sim+n-1)-=*(v+i);
  };

  /*    
  for(int i=0;i<n-m;i++){
    cout<<*(ans+n+i)<<" ";
  };

  for(int i=0;i<m;i++){
    cout<<*(v+i)<<" ";
  };
  cout<<"\n";
  
  for(int i=0;i<n;i++){
    cout<<*(sim+i)<<" ";
  };
  cout<<"\n";
  */

  for(int i=0;i<n-m;i++){
    long double Ai=1;
    for(int j=0;j<n-m;j++){
      if(j!=i){
	Ai*=(*(ans+n+i)-*(ans+n+j));
      };
    };
    //    cout<<*(ans+n+i-1)<<"\t"<<Ai<<"\n";
    for(int j=0;j<m;j++){
      Ai*=(*(ans+n+i)-*(v+j));
    };
    //    cout<<Ai<<"\n";
    //    *(sim+i)=sym(i+1)
    Ai=1/(Ai);
    long double sm=(n>1)?pow(-1,n-1)*(*(x+n-2)):1;
    long double sij=1;
    for(int j=0;j<n-2;j++){
      sij=pow(-1,j+1)*(*(sim+n-j-1))-*(ans+n+i)*sij;
      //        cout<<"i="<<i<<" j="<<j+1<<" sij="<<sij<<"\n";
      sm+=pow(-1,n-j)*(*(x+n-3-j))*sij;
    };
    if(n>1){
      sij=pow(-1,n-1)*(*(sim+1))-*(ans+n+i)*sij;
      //      cout<<"i="<<i<<" j="<<n-1<<" sij="<<sij<<"\n";
      sm+=sij;
    };
    //        cout<<"sm="<<sm<<" Ai="<<Ai<<"\n";
    //    cout<<"\n";
    if(n%2==0){
      *(ans+i)=(-sm*Ai);
    }else{
      *(ans+i)=(sm*Ai);
    };
  };
  for(int i=0;i<m;i++){
    long double Ai=1;
    for(int j=0;j<n-m;j++){
      Ai*=(*(v+i)-*(ans+n+j));
    };
    for(int j=0;j<m;j++){
      if(j!=i){
	Ai*=(*(v+i)-*(v+j));
      };
    };
    //    cout<<"Ai="<<Ai<<"\n";
    //    *(sim+i)=sym(i+1)
    Ai=1/(Ai);

    long double sm=(n>1)?pow(-1,n-1)*(*(x+n-2)):1;
    long double sij=1;
    for(int j=0;j<n-2;j++){
      sij=pow(-1,j+1)*(*(sim+n-j-1))-*(v+i)*sij;
      //      cout<<"sij="<<sij<<"\n";
      sm+=pow(-1,n-j)*(*(x+n-3-j))*sij;
    };
    //    cout<<*sim;
    if(n>1){
      sij=pow(-1,n-1)*(*(sim+1))-*(v+i)*sij;
      //      cout<<"sij="<<sij<<"\n";
      sm+=sij;
    };
    //cout<<"sm="<<sm<<" Ai="<<Ai<<"\n";

    /*    long double sm=pow(-1,n)*(*(x+n-2));
    long double sij=1;
    for(int j=0;j<n-1;j++){
      sij=pow(-1,j+1)*(*(sim+n-j-1))-*(ans+n+i)*sij;
      sm+=pow(-1,n-j-1)*(*(x+n-2-j))*sij;
      };*/
    if(n%2==0){
      *(ans+i+n-m)=(-sm*Ai);
    }else{
      *(ans+i+n-m)=(sm*Ai);
    };
  };
  delete[] sim;
  delete[] M;
};

inline void getmoments(int num,int numdata,long double *data,long double *m){
  //This calculates a linear combination of moments which gives powers
  //of lambda for a poisson distribution.
  *m=1;
  for(int i=1;i<num;i++){
    *(m+i)=0;
  };
  for(int i=0;i<numdata;i++){
    //    x+=*(data+i)*(log(*(data+i)+1e-10));
    long double p=*(data+i);
    for(int j=1;j<num;j++){
      *(m+j)+=p;
      p*=*(data+i);
    };
  };
  for(int i=1;i<num;i++){
    *(m+i)/=numdata;
  };
  for(int i=1;i<num-1;i++){
    for(int j=1;j<=i;j++){
      *(m+num-1+j-i)-=*(m+num+j-i-2)*j;
    };
  };
};

inline void getmomentsbinomial(int num,int numdata,long double *data,long double *m){
  //This calculates a linear combination of moments which gives powers
  //of lambda for a binomial distribution.
  *m=1;
  unsigned int *p=new unsigned int[num];
  for(int i=1;i<num;i++){
    *(m+i)=0;
    *(p+i)=0;
  };
  for(int i=0;i<numdata;i++){
    int l=floor(*(data+2*i));
    l=(l<num)?l+1:num;
    long double w=*(data+2*i);//-l;
    long double v=*(data+2*i+1);
    long double *e=new long double[num];
    *e=1;
    for(int j=1;j<l;j++){
      *(e+j)=*(e+j-1)*v;
      //      *(m+j)+=*(e+j);
    };
    
    /*
    for(int j=1;j<l-1;j++){
      for(int k=0;k<j;k++){
	*(e+l-j+k)-=*(e+l-j+k-1)*(k+1)/(w);
      };
    };
    */

    long double fact=1;
    //        cout<<w<<"\t";
    for(int j=1;j<l;j++){
      //      cout<<*(e+j)<<" ";
      if(*(e+j)>0){
	*(m+j)+=*(e+j)*fact;
      };
      fact*=w/(w-j);
      (*(p+j))++;
    };
    delete[] e;
    //    cout<<"\n";
  };
  for(int i=1;i<num;i++){
    *(m+i)/=*(p+i);
  };
  delete[] p;
};

void MixPoissonEstimate(int numdata,long double *data,int nummix,long double *out){
  long double *m=new long double[2*nummix];
  getmoments(2*nummix,numdata,data,m);
  solvenonlinVDM(nummix,m,out);
};


long double *parsimonyPars(tree &T,const sequence *data,int num=1,long double *pi=NULL);//int *m=NULL);

void treelikelihood::parsimonypars(){
  long double *pp;  
  pp=parsimonyPars(T,d,1,p.pi);
  p.setCoeff(pp);
  /*  Realmatrix R(NumCodons,pp);
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      if(i!=j){
	*(R.entries+i*NumCodons+j)/=*(R.entries+i*(NumCodons+1));
      };
    };
  };
  p.getpars(R);*/
  delete[] pp;
};

inline int noub(int k,long double *lbi,long double *ubi){
  return *(lbi+k)-*(ubi+k)>0.6;
};

inline int nolb(int k,long double *lbi,long double *ubi){
  long double diff=*(lbi+k)-*(ubi+k);
  return diff>0.3&&(diff<0.6||diff>0.8);
};

void Mixtreelikelihood::parsimonypars(){
  long double *pp;  
  int *nm=new int[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(nm+i)=0;
  };
  for(int *i=m.pars;*i!=0;i++){
    if(*i>0){
      (*(nm+*i%params::numpars))++;
    };
  };
  pp=parsimonyPars(T,d,num,p->pi);
  delete[] nm;
  long double *y=new long double[2*num*params::numpars];
  long double *z=new long double[2*num*params::numpars];
  for(int i=0;i<2*num*params::numpars;i++){
    *(y+i)=*(pp+i);//0;
  };
  params tmp;
  //  int *validpars=new int[params::numpars];
  //  for(int i=0;i<params::numpars;i++){
  //    *(validpars+i)=true;
  //  };
  int *mnum=new int[params::numpars];
  int *mncl=new int[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(mnum+i)=0;
    *(mncl+i)=0;
  };
  for(int *cpar=m.pars;*cpar!=0;){
    //    cout<<*cpar%params::numpars<<","<<*cpar/params::numpars<<"\n";
    (*(mnum+(*cpar)%params::numpars))++;
    (*(mncl+(*cpar)%params::numpars))++;
    cpar++;
    for(;*cpar<0;cpar++){
      //cout<<(-*cpar)%params::numpars<<","<<(-*cpar)/params::numpars<<"\n";
      (*(mnum+(-(*cpar))%params::numpars))++;
      //      (*(mncl-(*cpar)%params::numpars))--;
    };
  };
  //mnum is number of parameters involved. mncl is number of non-fixed
  //classes. Number of different values taken is given by
  //num+1/2(mnum-num+1-mncl)=(num+mnum+1-mncl)/2


  //  for(int i=1;i<2*num;i++){
    //    for(int j=0;j<params::numpars;j++){
      //      *(validpars+j)=(*(mnum+j)>=i);
      //      *(y+j*2*num+)=*(
    //    };
    /*    Realmatrix R(NumCodons);
    for(int j=0;j<NumCodonsSq;j++){
      *(R.entries+j)=log(((*(pp+2*num*j+i)>0)? *(pp+2*num*j+i):1e-3)/(*(p->pi+j%NumCodons)));
    };
    regression(R,y+(i-1)*params::numpars,params::XX,params::numpars,validpars,params::mask);*/
  //  };
  for(int i=1;i<params::numpars;i++){
    //    cout<<i<<" "<<*(mnum+i)<<" "<<*(mncl+i)<<"\n";
    int numm=(*(mncl+i)-*(mnum+i)+num);
    long double *mmts=new long double[numm*2];
    for(int j=0;j<numm*2-1;j++){
      //      cout<<"i="<<i<<" j="<<j<<"   "<<*(mnum+i)<<"\n";
      *(mmts+j)=*(y+i*2*num+j+1);//*params::numpars+i);
      //      cout<<*(mmts+j)<<" ";
    };
    //    cout<<"\n";
    int *w=new int[num];
    for(int j=0;j<num;j++){
      *(w+j)=0;
    };
    for(int *cpars=m.pars;*cpars!=0;cpars++){
      int cp=*cpars;//(*(cpars)>0)?*(cpars):-*(cpars);
      if(cp>0&&cp%params::numpars==i){
	*(w+cp/params::numpars)=1;
      };
    };
    long double *temp=z+2*num*(i-1);//new long double[2*num];
    int jj=0;
    for(int j=0;j<num-*(mnum+i);j++){
      for(;*(w+j)==1;j++);
      //      cout<<*((p+j)->coeff+i)<<" ";
      long double exc=exp(*((p+j)->coeff+i));
      *(temp+numm+*(mncl+i)+jj)=exc/(exc+1);
      jj++;
    };
    //    cout<<"\n\n";
    solvenonlinVDM(numm,mmts,num-*(mnum+i),temp+numm+*(mncl+i),temp);
    //    cout<<"\n";
    for(int j=0;j<2*numm;j++){
      //            cout<<*(z+2*num*(i-1)+j)<<" ";
    };
    //        cout<<"\n";
    for(int j=numm;j<2*numm;j++){
      if(*(z+2*num*(i-1)+j)<=0){
	*(z+2*num*(i-1)+j)=1e-4;
      };
      *(z+2*num*(i-1)+j)=log(*(z+2*num*(i-1)+j)/(1-*(z+2*num*(i-1)+j)));
    };
    delete[] w;
    delete[] mmts;
  };

  /*  int *which=new int[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(which+i)=0;
    };*/
  int pno=0;
  long double *test=new long double[m.npars];
  for(int i=0;i<m.npars;i++){
    *(test+i)=0;
  };
  long double *ub=new long double[num*params::numpars];
  long double *lb=new long double[num*params::numpars];
  for(int i=0;i<num*params::numpars;i++){
    *(ub+i)=0;
    *(lb+i)=1;
  };
  int *nn=new int[num*params::numpars];
  for(int i=0;i<num*params::numpars;i++){
    *(nn+i)=-1;
  };
  m.insvars(-T.numed-varprobs);
  unsigned int *mpset=new unsigned int[m.npars];
  for(int *par=m.pars;*par!=0;pno++){
    *(mpset+pno)=1<<(*par/params::numpars);
    for(par++;*par<0;par++){
      *(mpset+pno)|=1<<((-*par)/params::numpars);
    };
  };
  unsigned int *mpsetrec=new unsigned int[params::numpars*num];
  pno=0;
  for(int *par=m.pars;*par!=0;pno++){
    *(ub+*par)=-0.5;
    *(lb+*par)=0.5;
    *(mpsetrec+*par)=*(mpset+pno);
    int nnval=*par/params::numpars;
    for(unsigned int c=0;c<m.numconstraints;c++){
      *(test+pno)=1;
      long double slk=(m.cst+c)->slack(test);
      *(test+pno)=0;
      long double slk2=(m.cst+c)->slack(test);
      *(nn+*par)=nnval;
      if(slk<slk2){//upper bound
	long double upb=slk2/(slk-slk2);
	if(*(ub+*par)-*(lb+*par)>-0.9){
	  *(ub+*par)=upb;
	}else{
	  *(ub+*par)=upb;
	  *(lb+*par)=upb+0.5;
	};
      }else if(slk>slk2){
	long double lob=slk2/(slk-slk2);
	if(*(ub+*par)-*(lb+*par)>-0.9){
	  *(lb+*par)=lob;
	}else{
	  *(ub+*par)=lob-0.75;
	  *(lb+*par)=lob;
	};
      };
    };
    for(par++;*par<0;par++){
      *(ub-*par)=-1;
      *(lb-*par)=0;
      *(nn-*par)=nnval;
      *(mpsetrec-*par)=*(mpset+pno);
    };
  };
  /*
  for(int j=0;j<params::numpars;j++){
    for(int i=0;i<num;i++){
      cout<<*(mpsetrec+i*params::numpars+j)<<" ";
    };
    cout<<"\n";
  };
  cout<<"\n";*/
  delete[] mpset;
  m.insvars(T.numed+varprobs);
  delete[] test;
  linkedlist<temp> probests;

  for(int i=1;i<params::numpars;i++){
    int numm=(*(mncl+i)-*(mnum+i)+num);//This is the total number of values
    int nmm=*(mncl+i);//The number of variable values
    //    cout<<"numm="<<numm<<" nmm="<<nmm<<"\n";
    long double *ubi=new long double[numm];     
    long double *lbi=new long double[numm];     
    long double *vals=new long double[numm];
    long double *valsprb=new long double[numm];
    int j=0;
    for(int k=0;k<num;k++){
      if(*(nn+k*params::numpars+i)==k){
	*(ubi+j)=*(ub+k*params::numpars+i);
	*(lbi+j)=*(lb+k*params::numpars+i);
	j++;
      };
    };
    long double *srt=new long double[numm];
    long double *srtprb=new long double[numm];
    for(j=0;j<nmm;j++){
      long double value=*(z+2*num*(i-1)+numm+j);    
      int k=0;
      for(k=0;(k<j)&&(value>=*(srt+k));k++);
      for(int l=j;l>k;l--){
	*(srt+l)=*(srt+l-1);
	*(srtprb+l)=*(srtprb+l-1);
      };
      *(srt+k)=value;
      *(srtprb+k)=*(z+2*num*(i-1)+j);
    };
    for(int j=0;j<nmm;j++){
      //      cout<<i<<" "<<j<<"\t"<<*(srt+j)<<" "<<*(srtprb+j)<<"\n";
      long double bestup=*(srt+j);
      int bst=-1;
      for(int k=0;k<nmm;k++){
	if((*(lbi+k)<=*(srt+j)||nolb(k,lbi,ubi))&&(*(ubi+k)>=bestup||noub(k,lbi,ubi))){
	  bestup=*(ubi+k);
	  bst=k;
	};
      };
      if(bst>-1){
	*(vals+bst)=*(srt+j);
	*(valsprb+bst)=*(srtprb+j);
	*(ubi+bst)=*(lbi+bst)-1;
      };
    };
    for(int j=nmm;j<numm;j++){
      *(valsprb+j)=*(z+2*num*(i-1)+j);
    };
    int *acnum=new int[num];
    int k=0;
    for(int j=0;j<num;j++){
      int anm=*(nn+j*params::numpars+i);
      if(anm==j){
	*(acnum+j)=k++;
      }else if(anm==-1){
	*(acnum+j)=-1;
      }else{
	*(acnum+j)=*(acnum+anm);
      };
    };
    for(int j=0;j<num;j++){
      if(*(acnum+j)>-1){
	*((p+j)->coeff+i)=*(vals+*(acnum+j))/(*(params::A.entries+i*(params::numpars+1)));
      };
    };
    for(int *par=m.pars;*par!=0;){
      if(*par%params::numpars==i){
	int j=*par/params::numpars;
	inserttemp(probests,*(mpsetrec+*par),*(valsprb+*(acnum+j)));
      };
      for(par++;*par<0;par++);
    };
    delete[] ubi;
    delete[] lbi;
    delete[] vals;
    delete[] srt;
    delete[] valsprb;
    delete[] srtprb;
    delete[] acnum;
  };
  delete[] nn;
  delete[] mpsetrec;
  delete[] ub;
  delete[] lb;

  /*  for(linkedlist<temp> *tm=&probests;tm!=NULL&&tm->l!=NULL;tm=tm->next){
    cout<<tm->l->sst<<" "<<tm->l->sstfrq<<" "<<tm->l->prob<<"\n";
    };*/
  //Next need to work out probabilities.

  /*  if(varprobs<10){//Computationally infeasible for larger mixtures - need to find better method.
    unsigned int subsets=(1<<varprobs)-1;
    long double *ests=new long double[subsets];
    unsigned int *frqs=new unsigned int[subsets];//number of bases of subsets of a given set.
    unsigned int *compfrqs=new unsigned int[subsets];//number of extensions of bases of subset.
    for(unsigned int i=0;i<subsets;i++){
      *(ests+i)=0;
      *(frqs+i)=0;
      *(compfrqs+i)=0;
    };
    for(int i=0;i<m.npars;i++){
      int j=0;//subset whose probability we have.       
      long double prob=0;//probability of subset.
      (*(frqs+j))++;
      *(ests+j)+=prob;
      for(unsigned int k=1;k<subsets;){//For all non-empty subsets k disjoint from j 
	*(frqs+j+k-1)+=*(frqs+k-1);
	*(ests+j+k-1)+=*(frqs+k-1)*(prob+*ests+k-1);
	for(k++;k&j;k+=k&j);
      };
    };
    long double *probs=new long double[varprobs];
    for(int i=0;i<num;i++){
      *(probs+i)=0;
    };





    for(unsigned int k=1;k<=subsets;k++){
      int j=0;
      for(unsigned int i=1;i<subsets;i=i<<1){
	*(prob+j++)+=(*(ests+(k|i)-1)-*(ests+k-1))*(*(frqs+k)*(*(frqs+i))*(*(frqs+(subsets^(k|i)))));
      };      
    };

  };
  */

  for(linkedlist<temp> *t=&probests;t!=NULL&&t->l!=NULL;t=t->next){
    //    cout<<t->l->sst<<" "<<t->l->sstfrq<<" "<<t->l->prob<<"\n";
  };

  if(varprobs<=10){//Computationally infeasible for larger mixtures - need to find better method.
    long double *prbs=estimatefromsubsetestimates(varprobs+1,probests);
    for(int i=0;i<varprobs;i++){
      *(prob+i)=(*(prbs+i)/(*(prbs+varprobs)))-1;
      //      cout<<*(prob+i)<<" ";
    };
    //    cout<<"\n";
    delete[] prbs;
  };

  probests.remove();
  delete[] mncl;
  delete[] mnum;
  delete[] y;    
  delete[] z;    
  delete[] pp;
};

long double *parsimonyPars(tree &T,const sequence *data,int num,long double *pi){//int *m){
  //Assumes each parameter has independant mixture distribution.
  //Also doesn't work for parametrised distributions.
  unsigned int s=data->length;
  long double *freqs=new long double[s*NumCodonsSq];
  for(unsigned int i=0;i<s*NumCodonsSq;i++){
    *(freqs+i)=0;
  };
  for(unsigned int i=0;i<s;i++){
    pparssite(T,data,i,freqs+i,s);
  };
  int *validpars=new int[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(validpars+i)=true;
  };
  long double *temp=new long double[params::numpars];
  if(num==1){
    long double *ans=new long double[params::numpars];
    for(int i=0;i<params::numpars;i++){
      *(ans+i)=0;
    };
    for(int i=0;i<s;i++){
      long double frq=0;
      for(int j=0;j<NumCodons;j++){
	for(int k=j+1;k<NumCodons;k++){
	  frq+=*(freqs+s*j*NumCodons+s*k+i);
	};
      };
      Realmatrix R(NumCodons);
      for(int j=0;j<NumCodonsSq;j++){
	*(R.entries+j)=log(((*(freqs+s*j+i)>0)? *(freqs+s*j+i):1e-6)/(*(pi+j%NumCodons)));
      };
      regression(R,temp,params::XX,params::numpars,validpars,params::mask);
      //    cout<<frq<<" ";
      for(int i=0;i<params::numpars;i++){
	*(ans+i)+=*(temp+i);
      };
    };
    for(int i=0;i<params::numpars;i++){
      *(ans+i)/=s;
    };
    delete[] temp;
    delete[] validpars;
    delete[] freqs;
    return ans;
  };
  long double *ans=new long double[num*2*params::numpars];
  //  if(m==NULL){
  long double *pardata=new long double[2*s*params::numpars];//NumCodonsSq*num*2];
  for(int i=0;i<s;i++){
    long double frq=0;
    for(int j=0;j<NumCodons;j++){
      for(int k=j+1;k<NumCodons;k++){
	frq+=*(freqs+s*j*NumCodons+s*k+i);
      };
    };
    Realmatrix R(NumCodons);
    for(int j=0;j<NumCodonsSq;j++){
      *(R.entries+j)=log(((*(freqs+s*j+i)>0)? *(freqs+s*j+i):1e-6)/(*(pi+j%NumCodons)));
    };
    regression(R,temp,params::XX,params::numpars,validpars,params::mask);
    //    cout<<frq<<" ";
    for(int j=0;j<params::numpars;j++){
      *(pardata+j*2*s+2*i)=5*frq+1;
      //      cout<<*(temp+j)<<" "<<*(params::A.entries+j*(params::numpars+1))<<"\n";
      long double par=*(temp+j)/sqrt(sqrt(*(params::A.entries+j*(params::numpars+1))));
      if(par<100){
	long double exc=exp(par);
	*(pardata+j*2*s+2*i+1)=exc/(exc+1);
      }else{
	*(pardata+j*2*s+2*i+1)=1;
      };
      //      cout<<*(pardata+j*2*s+2*i+1)<<" ";
    };
    //    cout<<"\n";
  };
  for(int j=0;j<params::numpars;j++){
    getmomentsbinomial(2*num,s,pardata+j*2*s,ans+j*2*num);
    /*    for(int i=0;i<2*num;i++){
      cout<<*(ans+j*2*num+i)<<" ";
    };
    cout<<"\n";*/
  };

  delete[] validpars;
  delete[] temp;
  delete[] freqs;
  delete[] pardata;
  return ans;
  //  }else{
  //    int l=0;
  //    for(int i=0;i<params::numpars;i++){
  //      l+=*(m+i)*2-1;
  //    };
  //    ans=new long double[l];
  //  };
  long double *ps=ans;
  for(int i=0;i<NumCodonsSq;i++){
    if(num==1){
      long double mu=0;
      for(unsigned int j=0;j<s;j++){
	mu+=*(freqs+i*s+j);
      };
      *(ps++)=mu/s;
    }else{
      getmoments(num*2,s,freqs+i*s,ps);
      ps+=num*2;//*(m+i)*2-1;
    };
  };
  delete[] freqs;
  return ans;
};

//long double *

void pparssite(tree &T,const sequence *data,int N,long double *freqs,int step){
  T.downpass(data,N);  
  Realmatrix tmp(NumCodons);
  T.uppass(tmp.entries);//freqs,step);
  for(int i=0;i<NumCodonsSq;i++){
    *(tmp.entries+i)+=1e-4;
  };
  //  params p;
  //  p.getpars(tmp);
  for(int i=0;i<NumCodonsSq;i++){
    *(freqs+i*step)=*(tmp.entries+i);//*(p.coeff+i);
  };
};

void inline putcodon(int c,long double *down){
  if(c<61){
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i==c)?1.1:0;
    };
  }else if(c<125){//second nucleotide unknown
    c-=61;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/4==c)?1.1:0;
    };
  }else if(c<189){//first Nucleotide unknown
    c-=125;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%4==c%4)&&(i/16==c/16))?1.1:0;
    };
  }else if(c<253){//first two Nucleotides unknown
    c-=189;
    c/=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/16==c)?1.1:0;
    };
  }else if(c<317){//Third nucleotide unknown
    c-=253;      
    c%=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%16==c)?1.1:0;
    };
  }else if(c<381){//Third and second nucleotides unknown
    c-=317;
    c%=16;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%16)/4==c)?1.1:0;
    };
  }else if(c<445){//Third and second nucleotides unknown
    c-=381;
    c%=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%4==c)?1.1:0;
    };
  }else{//all unknown
    for(int i=0;i<NumCodons;i++){
      *(down+i)=1.1;
    };
  };
};

void tree::downpass(const sequence *data,int N){
  if(n==0){
    char cd[3];
    data->copypos(N,cd);
    int j=codon(cd);
    putcodon(j,down);
    return;
  };
  const sequence *d=data;
  for(int i=0;i<n;i++){
    (subtree+i)->downpass(d,N);
    d+=(subtree+i)->leaves();
  };
  int *temp=new int[NumCodons];
  for(int i=0;i<NumCodons;i++){
    *(temp+i)=0;
  };
  int max=0;
  for(int i=0;i<n;i++){
    for(int j=0;j<NumCodons;j++){
      *(temp+j)+=(*((subtree+i)->down+j)>1)?1:0;
      if(*(temp+j)>max){
	max=*(temp+j);
      };
    };
  };
  for(int i=0;i<NumCodons;i++){
    if(*(temp+i)==max){
      *(down+i)=1.1;
    }else{
      *(down+i)=0;
    };
  };
  delete[] temp;
};

void tree::uppass(long double *freqs,int *up){//int step,
  int delup=0;
  if(up==NULL){
    delup=1;
    up=new int[NumCodons];
    for(int j=0;j<NumCodons;j++){
      if(*(down+j)>1){
	*(up+j)=1;
      }else{
	*(up+j)=0;
      };
    };
  };  
  int *temp=new int[NumCodons];
  for(int i=0;i<n;i++){
    int count=0;
    int count2=0;
    for(int j=0;j<NumCodons;j++){
      if(*((subtree+i)->down+j)>1){
	*(temp+j)=1;
	count2++;
      }else{
	*(temp+j)=0;
      };
      count+=(1-*(temp+j))*(*(up+j));
    };
    if(count>0){
      for(int j=0;j<NumCodons;j++){
	if(*(up+j)&&!*(temp+j)){
	  for(int k=0;k<NumCodons;k++){
	    if(*(temp+k)){
	      *(freqs+j*NumCodons+k)+=1/((long double)count*count2);
	      /*	      for(int p=0;p<params::numpars;p++){
		*(freqs+p*step)+=(*((params::XX+p)->entries+j*NumCodons+k)>0)?1/(count*count2):0;//(*((params::XX+p)->entries+j*NumCodons+k))
		};*/
	    };
	  };
	};
      };
      for(int j=0;j<NumCodons;j++){
	*(temp+j)*=*(up+j);
	*(freqs+j*(NumCodons+1))+=*(up+j)/((long double)count2);
      };
    };
    (subtree+i)->uppass(freqs,temp);
    //    cout<<"count="<<count<<" count2="<<count2<<"\n";
  };
  delete[] temp;
  if(delup){
    delete[] up;
  };
};

void tree::setblzero(){
  //Sets all branchlengths to zero - used at the start of the
  //parsimony algorithm.
  for(int i=0;i<n;i++){
    (subtree+i)->setblzero();
    *(length+i)=0;
  };
};

void tree::parsimonybl(const Realmatrix &C,sequence *data){
  //Uses parsimony, with cost matrix C to fit the branch lengths.
  int l=data->getLength();
  long double inf=0;
  for(int i=0;i<NumCodonsSq;i++){
    if(*(C.entries+i)>inf){
      inf=*(C.entries+i);
    };
  };
  inf+=1;
  inf*=(numed*numed+1);//probably not necessary, but best to be safe.
  this->setblzero();
  for(int m=0;m<l;m++){//For each site
    this->parsimonyblsno(C,data,m,inf);
    int small=0;
    long double sval=inf;
    for(int i=0;i<NumCodons;i++){
      if(*(down+i)<sval){
	sval=*(down+i);
	small=i;
      };
    };
    this->parsimonyupdatebl(C,small,inf);
  };
  this->scale(1/(long double)l);
  this->makenonzerobranches();
};

void tree::parsimonybl(int num,const Realmatrix *C,const long double *probs,sequence *data){
  //Uses parsimony, with cost matrix C to fit the branch lengths.
  int l=data->getLength();
  long double inf=0;
  for(int j=0;j<num;j++){
    for(int i=0;i<NumCodonsSq;i++){
      if(*((C+j)->entries+i)>inf){
	inf=*((C+j)->entries+i);
      };
    };
  };
  inf+=1;
  inf*=(numed*numed+1);//probably not necessary, but best to be safe.
  this->setblzero();
  for(int m=0;m<l;m++){//For each site
    int best=0;
    long double low=inf;
    for(int i=0;i<num;i++){//Choose the best site class for this site.
      this->parsimonyblsno(*(C+i),data,m,inf);
      long double bot=inf;
      for(int j=0;j<NumCodons;j++){
	if(*(down+j)<bot){
	  bot=*(down+j);
	};
      };
      if(bot+*(probs+i)<low){
	low=bot+*(probs+i);
	best=i;
      };
    };
    this->parsimonyblsno(*(C+best),data,m,inf);
    int small=0;
    long double sval=inf;
    for(int i=0;i<NumCodons;i++){
      if(*(down+i)<sval){
	sval=*(down+i);
	small=i;
      };
    };
    this->parsimonyupdatebl(*(C+best),small,inf);
  };
  this->scale(1/(long double)l);
  this->makenonzerobranches();
};


void tree::parsimonyblsno(const Realmatrix &C,sequence *data,int m,long double inf){
  int j=0;
  for(int i=0;i<n;i++){
    (subtree+i)->parsimonyblsno(C,data+j,m,inf);
    j+=(subtree+i)->leaves();
  };
  for(int i=0;i<NumCodons;i++){
    *(down+i)=0;
    for(int j=0;j<n;j++){
      long double ij=inf;
      for(int k=0;k<NumCodons;k++){
	long double pij=*((subtree+j)->down+k)+*(C.entries+i*NumCodons+k);
	if(pij<ij){
	  ij=pij;
	};
      };
      *(down+i)+=ij;
    };
  };
  if(n==0){
    int c=codon((data->seq)+CodonLength*m);
    putcodonps(c,down,inf);
  }; 
};

void tree::parsimonyupdatebl(const Realmatrix& C,int i,long double inf){
  for(int j=0;j<n;j++){
    long double ij=inf;
    int l=0;
    for(int k=0;k<NumCodons;k++){
      long double pij=*((subtree+j)->down+k)+*(C.entries+i*NumCodons+k);
      if(pij<ij){
	ij=pij;
	l=k;
      };
    };
    *(length+j)+=*(C.entries+i*NumCodons+l);
    (subtree+j)->parsimonyupdatebl(C,l,inf);
  };
};
