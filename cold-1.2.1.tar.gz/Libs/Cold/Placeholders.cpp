/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <stdlib.h>
#include <sstream>
#include <fstream>
#include <math.h>

//General headers
#include "CommandLine.h"
#include "ErrorHandler.h"
#include "Miscellaneous.h"
#include "State.h"

//COLD-specific headers
#include "TreeLikelihood.h"
#include "MixTreeLikelihood.h"


 void setup(int mn,treelk *tr,const long double *ps,const int *pn,int c,const int *vs=NULL,const char *comm=NULL);

using std::ostream;

class calculationdata{
  static long double tl;
  static int mixnum;
  static treelk *ff;
  static const long double *x;
  static const int *trueparnums;
  static const char *com;
  static int conv;
  static int *count;
  calculationdata(){};
  //Calculated Data
  static long double* bi;
  static long double* loglike;
  static long double* tp;
  static long double* extp;
  static long double* tst;
  static long double* bl;
  static long double* bst;
  static long double* mxpr;
  static long double* sl;
  static long double* spp;
  static const int* sn;
  static const int* vars;
  static const int* tvn;
  static Realmatrix oi;
  static Realmatrix oii;
  static Realmatrix ldisp;
  static long double *inf;
public:  
  static const long double* branchinf();
  static const long double *LL();
  static const int *varsel();
  static const int *converge();
  static const int *varnum();
  static const int *truevarnum();
  static const long double *coeff();
  static const long double *expcoeff();
  static const long double *tstat();
  static const int *branchno();
  static const int *branchtop();
  static const int *branchbot();
  static const long double *branchlen();
  static const long double *branchlenstd();
  static void tree(ostream& out);
  static void treestd(ostream& out);
  static const int *mixno();
  static const int *mixclass();
  static const long double *mixprob();
  static const int *siteno();
  static const long double *sitelike();
  static const long double *sitepostprob();
  static const long double *treelen();
  static void observedinformation(ostream& out);
  static void observedinformationinverse(ostream& out);
  static void likelihooddisplacement(ostream& out);
  static void parameterinfluence(ostream& out);
  static void command(ostream& out);
  static int treelen_dim(int n);
  static int LL_dim(int n);
  static int command_dim(int n);
  static int branchinf_dim(int n);
  static int varsel_dim(int n);
  static int converge_dim(int n);
  static int varnum_dim(int n);
  static int truevarnum_dim(int n);
  static int coeff_dim(int n);
  static int expcoeff_dim(int n);
  static int tstat_dim(int n);
  static int branchno_dim(int n);
  static int branchtop_dim(int n);
  static int branchbot_dim(int n);
  static int branchlen_dim(int n);
  static int branchlenstd_dim(int n);
  static int mixno_dim(int n);
  static int mixclass_dim(int n);
  static int mixprob_dim(int n);
  static int siteno_dim(int n);
  static int sitelike_dim(int n);
  static int sitepostprob_dim(int n);
  static int observedinformation_dim(int n);
  static int observedinformationinverse_dim(int n);
  static int likelihooddisplacement_dim(int n);
  static int parameterinfluence_dim(int n);
  static int tree_dim(int n);
  static int treestd_dim(int n);
  friend void setup(int mn,treelk *tr,const long double *ps,const int *pn,int c,const int *vs,const char *comm);
  friend void cleanup();
};

#include "PlaceholderTemplate.cpp"


using namespace std;


void cleanup(){
  calculationdata::ff=NULL;
  calculationdata::x=NULL;
  calculationdata::trueparnums=NULL;
  delete[] calculationdata::count;
  calculationdata::vars=NULL;
  calculationdata::tvn=calculationdata::vars;

  if(calculationdata::bi!=NULL){
    delete[] calculationdata::bi;
  };
  if(calculationdata::loglike!=NULL){
    delete calculationdata::loglike;
  };
  if(calculationdata::tp!=NULL){
    delete[] calculationdata::tp;
  };
  if(calculationdata::extp!=NULL){
    delete[] calculationdata::extp;   
  };
  if(calculationdata::tst!=NULL){
    delete[] calculationdata::tst;
  };
  if(calculationdata::bst!=NULL){
    delete[] calculationdata::bst;
  };
  if(calculationdata::mxpr!=NULL){
    delete[] calculationdata::mxpr;
  };
  if(calculationdata::sl!=NULL){
    delete[] calculationdata::sl;
  };
  if(calculationdata::spp!=NULL){
    delete[] calculationdata::spp;
  };
  if(calculationdata::bl!=NULL){
    delete[] calculationdata::bl;
  };
  if(calculationdata::inf!=NULL){
    delete[] calculationdata::inf;
  };
  calculationdata::bl=NULL;
  calculationdata::inf=NULL;
  calculationdata::loglike=NULL;
  calculationdata::tp=NULL;
  calculationdata::extp=NULL;
  calculationdata::tst=NULL;
  calculationdata::bst=NULL;
  calculationdata::bi=NULL;
  calculationdata::mxpr=NULL;
  calculationdata::sl=NULL;
  calculationdata::spp=NULL;
};

extern "C" {
  void (*clnp)()=cleanup;
}

void setup(int mn,treelk *tr,const long double *ps,const int *pn,int c,const int *vs,const char *comm){
  calculationdata::com=comm;
  calculationdata::mixnum=mn;
  calculationdata::ff=tr;
  calculationdata::x=ps;
  calculationdata::trueparnums=pn;
  calculationdata::conv=c;
  calculationdata::bl=NULL;
  calculationdata::loglike=NULL;
  calculationdata::tp=NULL;
  calculationdata::extp=NULL;
  calculationdata::tst=NULL;
  calculationdata::bst=NULL;
  calculationdata::bi=NULL;
  calculationdata::inf=NULL;
  calculationdata::mxpr=NULL;
  int nsites=calculationdata::ff->numsites();
  int mx=nsites>params::numpars?(nsites):params::numpars;
  calculationdata::count=new int[mx];
  for(int i=0;i<mx;i++){
    *(calculationdata::count+i)=i;
  };
  calculationdata::sn=calculationdata::count;
  if(vs==NULL){
    calculationdata::vars=calculationdata::count;
  }else{
    calculationdata::vars=vs;
  };
  calculationdata::tvn=calculationdata::vars;
  calculationdata::sl=NULL;
  calculationdata::spp=NULL;
  atexit(cleanup);
};



extern "C"{
  void (*stp)(int,treelk *,const long double *,const int *,int,const int *,const char *)=setup;
}

const long double* calculationdata::branchinf(){
  if(bi==NULL){
    int x[2];
    x[0]=ff->edges()+1;//Need to change this to provide influence on arbitrary parameters.
    x[1]=-1;
    bi=ff->branchinfluences(x);
  };
  return bi;
};

int calculationdata::branchinf_dim(int n){
  if(n==0){
    return ff->edges();
  }else{
    return -1;
  };
};

int calculationdata::likelihooddisplacement_dim(int n){
  return -1;
};

int calculationdata::parameterinfluence_dim(int n){
  return -1;
};

int calculationdata::LL_dim(int n){
  return -1;
};

int calculationdata::varsel_dim(int n){
  if(n==0){
    return params::numpars-1;
  }else{
    return -1;
  };
};

int calculationdata::converge_dim(int n){
  return -1;
};

int calculationdata::varnum_dim(int n){
  if(n==0){
    return params::numpars;
  }else{
    return -1;
  };
};

int calculationdata::truevarnum_dim(int n){
  if(n==0){
    return params::numpars;
  }else{
    return -1;
  };
};

int calculationdata::coeff_dim(int n){
  if((n==0&&mixnum==1)||(n==1&&mixnum>1)){
    return params::numpars;
  }else if(n==0&&mixnum>1){
    return mixnum;
  }else{
    return -1;
  };
};

int calculationdata::expcoeff_dim(int n){
  if((n==0&&mixnum==1)||(n==1&&mixnum>1)){
    return params::numpars;
  }else if(n==0&&mixnum>1){
    return mixnum;
  }else{
    return -1;
  };
};

int calculationdata::tstat_dim(int n){
  if((n==0&&mixnum==1)||(n==1&&mixnum>1)){
    return params::numpars;
  }else if(n==0&&mixnum>1){
    return mixnum;
  }else{
    return -1;
  };
};

int calculationdata::branchno_dim(int n){
  if(n==0){
    return ff->edges();
  }else{
    return -1;
  };
};

int calculationdata::branchtop_dim(int n){
  if(n==0){
    return ff->edges();
  }else{
    return -1;
  };
};

int calculationdata::branchbot_dim(int n){
  if(n==0){
    return ff->edges();
  }else{
    return -1;
  };
};

int calculationdata::branchlen_dim(int n){
  if(n==0){
    return ff->edges();
  }else{
    return -1;
  };
};

int calculationdata::treelen_dim(int n){
  if(n==0){
    return 1;
  }else{
    return -1;
  };
};

int calculationdata::branchlenstd_dim(int n){
  if(n==0){
    return ff->edges();
  }else{
    return -1;
  };
};

int calculationdata::mixno_dim(int n){
  return -1;
};

int calculationdata::mixclass_dim(int n){
  if(n==0&&mixnum>1){
    return mixnum;
  }else{
    return -1;
  };
};


int calculationdata::mixprob_dim(int n){
  if(mixnum==1||n!=0){
    return -1;
  }else{
    return mixnum;
  };
};

int calculationdata::siteno_dim(int n){
  if(n==0){
    return ff->numsites();
  }else{
    return -1;
  };
};

int calculationdata::sitelike_dim(int n){
  if(n==0){
    return ff->numsites();
  }else{
    return -1;
  };
};

int calculationdata::sitepostprob_dim(int n){
  if(mixnum==1||n>1||n<0){
    return -1;
  }else if(n==0){
    return ff->numsites();
  }else{
    return mixnum;
  };
};

int calculationdata::tree_dim(int n){
  return -1;
};

int calculationdata::treestd_dim(int n){
  return -1;
};

int calculationdata::observedinformation_dim(int n){
  return -1;
};

int calculationdata::observedinformationinverse_dim(int n){
  return -1;
};

int calculationdata::command_dim(int n){
  return -1;
};

int calculationdata::mixnum;
treelk *calculationdata::ff;
long double calculationdata::tl;
long double *calculationdata::bl;
const long double *calculationdata::x;
const int *calculationdata::trueparnums;
int calculationdata::conv;
const char* calculationdata::com;
long double* calculationdata::loglike;
long double* calculationdata::tp;
long double* calculationdata::extp;
long double* calculationdata::tst;
long double* calculationdata::bst;
long double* calculationdata::mxpr;
long double* calculationdata::sl;
long double* calculationdata::spp;
long double* calculationdata::bi;
int* calculationdata::count;
const int* calculationdata::sn;
const int* calculationdata::vars;
const int* calculationdata::tvn;
Realmatrix calculationdata::oi;
Realmatrix calculationdata::oii;
Realmatrix calculationdata::ldisp;
long double* calculationdata::inf;

const long double *calculationdata::LL(){
  if(loglike==NULL){
    loglike=new long double;
    if(oi.sz==0){
      *loglike=ff->quickEvaluate(x);
    }else{
      *loglike=ff->evaluate(x);
    };
  };
  return loglike;
};

const int *calculationdata::varsel(){
  //  if(vs==NULL){
  //  };
  return vars;
};

const int *calculationdata::converge(){
  return &conv;
};

const int *calculationdata::varnum(){
  return vars;
};

const int *calculationdata::branchno(){
  return NULL;
};

const int *calculationdata::truevarnum(){
  return vars;
};

const long double *calculationdata::coeff(){
  if(tp==NULL){
    tp=ff->truepars();
  };
  return tp;
};

const long double *calculationdata::expcoeff(){
  if(extp==NULL){
    extp=new long double[params::numpars*mixnum];
    if(tp==NULL){
      tp=ff->truepars();
    };
    for(int i=0;i<params::numpars*mixnum;i++){
      *(extp+i)=exp(*(tp+i));
    };
  };
  return extp;
};

const long double *calculationdata::tstat(){
  if(tst==NULL){
    tst=ff->tstats(x);
  };
  return tst;
};

const int* calculationdata::branchtop(){
  return NULL;
};

const int* calculationdata::branchbot(){
  return NULL;
};

const long double *calculationdata::branchlen(){
  if(bl==NULL){
    bl=ff->branchlen();
  };
  return bl;
};

const long double *calculationdata::treelen(){
  if(bl==NULL){
    bl=ff->branchlen();
  };
  tl=0;
  for(int i=0;i<ff->edges();i++){
    tl+=*(bl+i);
  };
  return &tl;
};

const long double *calculationdata::branchlenstd(){
  if(bst==NULL){
    if(oii.sz==0){//Need to calculate oii
      if(oi.sz==0){ 
	oi=ff->oi(x);
      };
      oii=oi.inverse();
    };
    bst=new long double[ff->edges()];
    for(int i=0;i<ff->edges();i++){
      *(bst+i)=*(oi.entries+i*(oi.sz+1));
    };
  };
  return bst;
};

void calculationdata::tree(ostream& out){
  ff->printtree(out);
};

void calculationdata::treestd(ostream& out){
  if(oii.sz==0){//Need to calculate oii
    if(oi.sz==0){ 
      oi=ff->oi(x);
    };
    oii=oi.inverse();
  };
  ff->printtreedev(oii,out);
};

const int *calculationdata::mixno(){
  return &mixnum;
};

const int *calculationdata::mixclass(){
  return count;
};

const long double *calculationdata::mixprob(){
  if(mixnum<2){
    return NULL;
  }else{
    mxpr=((Mixtreelikelihood *)ff)->getmixprobs();
    return mxpr;
  };
};

const int *calculationdata::siteno(){
  return sn;
};

const long double *calculationdata::sitelike(){
  if(sl==NULL){
    sl=ff->sitelikes();
  };
  return sl;
};

const long double *calculationdata::sitepostprob(){
  if(spp==NULL&&mixnum>1){
    spp=((Mixtreelikelihood *)ff)->sitepostprobs();
  };
  return spp;
};

void calculationdata::observedinformation(ostream& out){
  if(oi.sz==0){
    oi=ff->oi(x);
  };
  out<<oi;
};

void calculationdata::command(ostream& out){
  out<<com;
};


void calculationdata::observedinformationinverse(ostream& out){
  if(oii.sz==0){
    if(oi.sz==0){
      oi=ff->oi(x);
    };
    oii=oi.inverse();
  };
  out<<oii;
};

void calculationdata::parameterinfluence(ostream& out){
  //  cout<<"Hello.\n";//testing.
  variable *rec=::vars.seektag("-likelihooddisplacement");
  int *sel;
  if(rec!=NULL){
    sel=selection(*(const char *const *)rec->value);
  }else{
    sel=new int[ff->edges()+params::numpars];
    for(int i=0;i<ff->edges()+params::numpars-1;i++){
      *(sel+i)=i;
    };
    *(sel+ff->edges()+params::numpars-1)=-1;
  };
  int nv=0;
  for(;*(sel+nv)>=0;nv++);
  nv--;
  if(ldisp.sz==0){
    long double *lkd=ff->likelihoodDisplacement(sel);
    ldisp=Realmatrix(ff->numsites(),lkd);
    inf=new long double[nv*ff->numsites()];
    for(unsigned int i=0;i<nv*ff->edges();i++){
      *(inf+i)=*(lkd+i+ff->numsites()*ff->numsites());
    }; 
    delete[] lkd;
    //    ldispev=new long double[ff->numsites()];
  };
  for(unsigned int i=0;i<ff->numsites();i++){
    for(unsigned int j=0;j<nv;j++){
      out<<*(inf+i*nv+j)<<" ";
    };
    out<<"\n";
  };
};

void calculationdata::likelihooddisplacement(ostream& out){
  //  cout<<"Hello.\n";//testing.
  if(ldisp.sz==0){
    variable *rec=::vars.seektag("-likelihooddisplacement");
    int *sel;
    if(rec!=NULL){
      sel=selection(*(const char *const *)rec->value);
    }else{
      sel=new int[ff->edges()+params::numpars+1];
      for(int i=0;i<ff->edges()+params::numpars;i++){
	*(sel+i)=i;
      };
      *(sel+ff->edges()+params::numpars)=-1;
    };
    long double *lkd=ff->likelihoodDisplacement(sel);
    ldisp=Realmatrix(ff->numsites(),lkd);
    int nv=0;
    for(;*(sel+nv)>=0;nv++);
    nv--;
    inf=new long double[nv*ff->numsites()];
    for(unsigned int i=0;i<nv*ff->numsites();i++){
      *(inf+i)=*(lkd+i+ff->numsites()*ff->numsites());
    }; 
    delete[] lkd;
    //    ldispev=new long double[ff->numsites()];
  };
  out<<ldisp;
};

