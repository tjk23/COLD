/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Sequence.h"
#include "ErrorHandler.h"
#include "MiscellaneousFuns.h"
#include "Matrix.h"
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdarg.h>


#include "Macros.h"
using namespace std;

/* Classes and routines for dealing with DNA sequences */

int CodonLength=3;         //Unlikely to change.
void setNumCodons(int n);

class geneticcode{
  int numstop;
  int *stop;
public:
  geneticcode();
  void set(int n,...);
  void set(const char *stps);
  int delstop(int i);
  int insstop(int i);
  ~geneticcode(){if(stop!=NULL){delete[] stop;};};
};

geneticcode::geneticcode(){
  CodonLength=3;
  numstop=3;
  setNumCodons(61);
  stop=new int[3];
  *stop=34;
  *(stop+1)=35;
  *(stop+2)=50;
};

void geneticcode::set(int n,...){
  numstop=n;
  if(stop!=NULL){
    delete[] stop;
  };
  stop=new int[n];
  va_list argptr;
  va_start(argptr,n);
  for(int i=0;i<n;i++){
    *(stop+i)=va_arg(argptr,int);
  };
  int nc=1;
  for(int i=0;i<CodonLength;i++){
    nc*=4;
  };
  setNumCodons(nc-n);
  va_end(argptr);
};

inline int validnuc(char a){
  return a=='A'||a=='a'||a=='C'||a=='c'||a=='G'||a=='g'||a=='T'||a=='t';
};

inline int nucnumber(char a){
  return (a=='A'||a=='a')?2:(a=='C'||a=='c')?1:(a=='G'||a=='g')?3:(a=='T'||a=='t')?0:4;
};

void geneticcode::set(const char *stps){
  int len=0;
  const char *pos=stps;
  for(;*pos;len++){
    for(int j=0;j<CodonLength;j++){
      for(;*pos&&!validnuc(*pos);pos++);
      if(!*pos&&j<CodonLength){
	len--;
	break;//Maybe should give a warning!
      };
      pos++;    
    };
  };
  numstop=len;
  if(stop!=NULL){
    delete[] stop;
  };
  stop=new int[len];
  pos=stps;
  for(int i=0;i<len;i++){
    *(stop+i)=0;
    for(int j=0;j<CodonLength;j++){//This gives the correct order for
				   //codon length 3
      if(j>1){
	*(stop+i)*=4;
      };
      for(;*pos&&!validnuc(*pos);pos++);
      *(stop+i)+=nucnumber(*(pos++))*((j==1)?4:1);      
    };
  };
  int nc=1;
  for(int i=0;i<CodonLength;i++){
    nc*=4;
  };
  setNumCodons(nc-len);
};

int geneticcode::delstop(int i){
  for(int j=numstop-1;j>=0;j--){
    if(i>*(stop+j)){
      i--;
    };
  };
  return i;
};

int geneticcode::insstop(int i){
  for(int j=0;j<numstop;j++){
    if(i>=*(stop+j)){
      i++;
    };
  };
  return i;
};

geneticcode code;

int universaldelstop(int i){
  int j=(i>33)?i-2:i;
  return (i>49)?j-1:j;
};

int universalinsstop(int i){
  int j=(i>33)?i+2:i;
  return (j>49)?j+1:j;
};

int (*delstop)(int i)=universaldelstop;

int (*insstop)(int i)=universalinsstop;

int setcode(const char *name,istream &in){
  while(in.good()&&!in.eof()){
    for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r'||in.peek()=='\n');in.get());
    const char *nm=name;
    for(;in.good()&&in.peek()==*nm;in.get()){
      nm++;
    };
    if(*nm=='\0'){//match
      for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r');in.get());
      if(isdigit(in.peek())){
	in>>CodonLength;
	for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r');in.get());
      }else{
	CodonLength=3;
      };
      char *stps=readstring(in,":\n");// : character terminates list of stops.
      code.set(stps);
      delete[] stps;
      return 1;
    }else{
      for(;in.good()&&!in.eof()&&in.get()!='\n';);//Skip to next line.
    };
  };
  return -1;
};

inline int getAAno(char a){
  switch(a){
  case 'A':
    return 0;
  case 'C':
    return 1;
  case 'D':
    return 2;
  case 'E':
    return 3;
  case 'F':
    return 4;
  case 'G':
    return 5;
  case 'H':
    return 6;
  case 'I':
    return 7;
  case 'K':
    return 8;
  case 'L':
    return 9;
  case 'M':
    return 10;
  case 'N':
    return 11;
  case 'P':
    return 12;
  case 'Q':
    return 13;
  case 'R':
    return 14;
  case 'S':
    return 15;
  case 'T':
    return 16;
  case 'V':
    return 17;
  case 'W':
    return 18;
  case 'Y':
    return 19;
  default:
    return 30;
  };
};

void inline skipblanks(istream &in){
  for(;in.good()&&!in.eof()&&(in.peek()=='\n'||in.peek()=='\t'||in.peek()=='\r'||in.peek()==' ');in.get());
};

int setifstream(const char *val,void *address);

void makematrices(const char *name, const char *AA,const char *parameterfilebasename){
  int i=0;
  /*  for(;*(AA+i);i++){
    if(*(AA+i)=='-'){//stop codon
      NumCodons--;
    };
    };*/
  Realmatrix ans(NumCodons);
  //  Realmatrix M;
  ifstream in(parameterfilebasename);
  if(!(in.is_open())){
    throw 0;
  };
  ifstream matstr;
  char *mttflnm=new char[strlen(parameterfilebasename)+strlen(name)+5];
  strcpy(mttflnm,parameterfilebasename);
  strcat(mttflnm,"-");
  strcat(mttflnm,name);
  ofstream matout(mttflnm);
  delete[] mttflnm;
  int *inM=new int[NumCodons];
  for(;in.good()&&!in.eof();){
    skipblanks(in);
    if(!in.good()||in.eof()){
      break;
    };
    char *name=readstring(in,":");  
    if(in.eof()){
      break;
    };
    skipblanks(in);
    char *style=readstring(in," \t\r");
    skipblanks(in);
    char *file=readstring(in," \t\r");
    skipblanks(in);
    char *num=readstring(in," \t\r\n");
    int nm=atoi(num);
    setifstream(file,&matstr);
    if(!matstr.is_open()){
      cerr<<"Could not open file \""<<file<<"\"\n";
      throw file;
    }else{
      char *msg=new char[80+strlen(file)];
      sprintf(msg,"Successfully openned file \"%s\"\n",file);
      info(msg,msgcode(2,0));
      delete[] msg;
    };
    for(int i=1;i<nm;i++){
      dummyreadmatrix(matstr);
    };
    {
      char *msg=new char[80];
      sprintf(msg,"Reading matrix number %d\n",nm);
      info(msg,msgcode(2,0));
      delete[] msg;
    }
    Realmatrix M(matstr);
    //    cout<<M<<"\n\n";
    matstr.close();
    if(!strcmp(style,"DNA_med")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  if(a1<a2){
	    if(a2<a3){
	      *(ans.entries+i*NumCodons+j)=a2;
	    }else if(a1<a3){
	      *(ans.entries+i*NumCodons+j)=a3;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a1;
	    };
	  }else{
	    if(a3<a2){
	      *(ans.entries+i*NumCodons+j)=a2;
	    }else if(a1<a3){
	      *(ans.entries+i*NumCodons+j)=a1;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a3;
	    };
	  };
	};
      };
    }else if(!strcmp(style,"DNA_max")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  if(a1<a2){
	    if(a2<a3){
	      *(ans.entries+i*NumCodons+j)=a3;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a2;
	    };
	  }else{
	    if(a3<a1){
	      *(ans.entries+i*NumCodons+j)=a1;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a3;
	    };
	  };
	};
      };
    }else if(!strcmp(style,"DNA_min")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  if(a1<a2){
	    if(a1<a3){
	      *(ans.entries+i*NumCodons+j)=a1;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a3;
	    };
	  }else{
	    if(a3<a2){
	      *(ans.entries+i*NumCodons+j)=a3;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a2;
	    };
	  };
	};
      };
    }else if(!strcmp(style,"DNA_1+2")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  *(ans.entries+i*NumCodons+j)=a1+a2;
	};
      };
    }else if(!strcmp(style,"DNA_sum")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  *(ans.entries+i*NumCodons+j)=a1+a2+a3;
	};
      };
    }else{
      if(!strcmp(style,"DNA_1")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=i/16;
	  };
	};
      }else if(!strcmp(style,"DNA_2")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=(i/4)%4;
	  };
	};
      }else if(!strcmp(style,"DNA_3")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=i%4;
	  };
	};
      }else if(!strcmp(style,"AA")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=getAAno(*(AA+i));
	    //	    cout<<*(inM+j-1)<<"\n";
	    if(*(inM+j-1)==30){
	      cout<<*(AA+i)<<"\n";
	    };
	  };
	};
      }else{
	cerr<<"Unknown matrix style: \""<<style<<"\"\n";
	throw style;
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  *(ans.entries+i*NumCodons+j)=*(M.entries+*(inM+i)*M.sz+*(inM+j));
	};
      };
    };
    delete[] file;
    delete[] style;
    if(name!=NULL){
      delete[] name;
    };
    delete[] num;
    matout<<ans<<"\n\n";
  };
  delete[] inM;
  in.close();
  matout.close();
};

void makematrices(const char *name, ifstream &in,const char *parameterfilebasename){
  while(in.good()&&!in.eof()){
    for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r'||in.peek()=='\n');in.get());
    const char *nm=name;
    for(;in.good()&&in.peek()==*nm;in.get()){
      nm++;
    };
    if(*nm=='\0'){//match
      for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r');in.get());
      if(isdigit(in.peek())){
	in>>CodonLength;
	for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r');in.get());
      }else{
	CodonLength=3;
      };
      for(;in.good()&&in.peek()!='\n'&&in.peek()!=':';in.get());
      if(in.get()!=':'){
	throw '\n';
      };
      for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\r');in.get());
      char *AA=readnonemptystring(in," \t\n");
      makematrices(name,AA,parameterfilebasename);
      delete[] AA;
      return;
    }else{
      for(;in.good()&&!in.eof()&&in.get()!='\n';);//Skip to next line.
    };
  };
};

int codon(char *seq){
  //Anything except ACGT is treated as unknown. Maybe better in future
  //to do something cleverer.
  //  cout<<"Converting sequence \""<<*seq<<*(seq+1)<<*(seq+2)<<"\"\n";  
  int a=-1;//Assume codon length=1 (nucleotide) or codon length=3 (codon)
  if(CodonLength==3){
    a=4*nucnumber(*seq);//*seq=='A'?8:*seq=='C'?4:*seq=='G'?12:*seq=='T'?0:128;
    a+=16*nucnumber(*(seq+1));//*(seq+1)=='A'?32:*(seq+1)=='C'?16:*(seq+1)=='G'?48:*(seq+1)=='T'?0:256;
    a+=nucnumber(*(seq+2));//=='A'?2:*(seq+2)=='C'?1:*(seq+2)=='G'?3:*(seq+2)=='T'?0:64;
    a=code.delstop(a);
  }else if(CodonLength==1){
    a=nucnumber(*seq);
  };
    /*  if(a>33){//Stop codons TAA=34 and TAG=35
    a-=2;
  };
  if(a>47){//Stop codon TGA=50
    a--;
    };*/
  return a;
};

sequence::sequence(char *s){
  int l=strlen(s);
  length=l/CodonLength;
  seq=new char[l];
  for(int i=0;i<l;i++){
    *(seq+i)=*(s+i);
  };
};

void sequence::assign(char *s){
  int l=strlen(s);
  length=l/CodonLength;
  seq=new char[l];
  for(int i=0;i<l;i++){
    *(seq+i)=*(s+i);
  };
};

char *displayCodon(int cod){//Could improve this to work for arbitrary codonlength.
  char *a=new char[CodonLength];
  if(CodonLength==1){
    *a=cod>=2?(cod==3?'G':'A'):(cod==1?'C':'T');
    return a;
  };
  cod=code.insstop(cod);
  /*  if(cod>47){
    cod++;
  };
  if(cod>33){
    cod+=2;
    };*/
  if(cod>255){
    *(a+1)='-';
    cod-=256;
    if(cod>127){
      *a='-';
      *(a+2)=cod>=130?(cod==131?'G':'A'):(cod==129?'C':'T');
    }else if(cod>63){
      *(a+2)='-';
      *a=cod>=71?(cod==75?'G':'A'):(cod==67?'C':'T');
    }else{
      *a=cod>=8?(cod>=12?'G':'A'):(cod>=4?'C':'T');
      cod%=4;
      *(a+2)=cod>=2?(cod==3?'G':'A'):(cod==1?'C':'T');
    };
  }else if(cod>127){
    *a='-';
    cod-=127;
    if(cod>63){
      *(a+2)='-';
      cod-=64;
      *(a+1)=cod>=32?(cod>=48?'G':'A'):(cod>=16?'C':'T');
    };
  }else if(cod>63){
    *(a+2)='-';
    cod-=64;
    *(a+1)=cod>=32?(cod>=48?'G':'A'):(cod>=16?'C':'T');
    cod%=16;
    *a=cod>=8?(cod>=12?'G':'A'):(cod>=4?'C':'T');
    cod%=4;
  }else{
    *(a+1)=cod>=32?(cod>=48?'G':'A'):(cod>=16?'C':'T');
    cod%=16;
    *a=cod>=8?(cod>=12?'G':'A'):(cod>=4?'C':'T');
    cod%=4;
    *(a+2)=cod>=2?(cod==3?'G':'A'):(cod==1?'C':'T');
  };
  return a;
};

ostream& operator <<(ostream& out,const sequence& s){
  for(int i=0;i<s.length;i++){
    for(int j=0;j<CodonLength;j++){
      out<<*(s.seq+i*CodonLength+j);
    };
    out<<" ";
  };
  return out;
};

char *comparepos(sequence *s,int pos,int numseq){
  char *a=new char[numseq*CodonLength];
  for(int i=0;i<numseq;i++){
    (s+i)->copypos(pos,a+i*CodonLength);
  };
  return a;
};

void sequence::display() const {
  for(int i=0;i<length*CodonLength;i++){
    cout<<*(seq+i);
  };
};

long double *emppi(sequence *data,int len,int type){
  long double *ans=new long double[NumCodons];
  long double nucfreq[12];//Need to change to allow different codon lengths.
  int total=0;
  for(int i=0;i<12;i++){
    nucfreq[i]=0;
  };
  for(int i=0;i<NumCodons;i++){
    *(ans+i)=0;
  };
  for(int i=0;i<len;i++){
    total+=(data+i)->length;
    for(int j=0;j<(data+i)->length;j++){      
      int num=codon((data+i)->seq+j*CodonLength);
      if(num<NumCodons){
	*(ans+num)+=1;
      }else if(num<125){
	num-=61;
	num/=4;
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=(i/4==num)?(1/4):0;
	};
      }else if(num<189){
	num-=125;
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=((i%4==num%4)&&(i/16==num/16))?1/4:0;
	};
      }else if(num<253){
	num-=189;
	num/=16;
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=(i/16==num)?1/16:0;
	};
      }else if(num<317){
	num-=253;      
	num%=16;
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=(i%16==num)?1/4:0;
	};
      }else if(num<381){
	num-=317;      
	num%=16;
	num/=4;
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=((i%16)/4==num)?1/16:0;
	};
      }else if(num<445){
	num-=381;      
	num%=4;
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=(i%4==num)?1/16:0;
	};
      }else{
	for(int i=0;i<NumCodons;i++){
	  *(ans+i)+=1/NumCodons;
	};
      };
      for(int k=0;k<CodonLength;k++){
	switch(*((data+i)->seq+j*CodonLength+k)){
	case 'A':
	case 'a':
	  nucfreq[k*4+2]+=1;
	  break;
	case 'C':
	case 'c':
	  nucfreq[k*4+1]+=1;
	  break;
	case 'G':
	case 'g':
	  nucfreq[k*4+3]+=1;
	  break;
	case 'T':
	case 't':
	  nucfreq[k*4]+=1;
	  break;
	default:
	  nucfreq[k*4]+=0.25;
	  nucfreq[k*4+1]+=0.25;
	  nucfreq[k*4+2]+=0.25;
	  nucfreq[k*4+3]+=0.25;
	};
      };
    };
  };
  switch(type){
  case 0:  //Empirical Codon Frequencies
    for(int i=0;i<NumCodons;i++){
      *(ans+i)/=total;
      if(*(ans+i)==0){
	*(ans+i)=1e-16;
      };
    };
    break;
  case 1: { //F3x4
    for(int i=0;i<12;i++){
      nucfreq[i]/=total;
    };
    long double tfreq=0;
    for(int i=0;i<NumCodons;i++){
      int j=code.insstop(i);
      *(ans+i)=nucfreq[(j%16)/4]*nucfreq[4+j/16]*nucfreq[8+j%4];
      tfreq+=*(ans+i);
    };
    for(int i=0;i<NumCodons;i++){
      *(ans+i)/=tfreq;
    };
  };
    break;
  case 2:  {//F1x4
    for(int i=0;i<4;i++){
      nucfreq[i]+=nucfreq[i+4]+nucfreq[i+8];
      nucfreq[i]/=total*3;
    };
    long double tfreq=0;
    for(int i=0;i<NumCodons;i++){
      int j=code.insstop(i);
      *(ans+i)=nucfreq[(j%16)/4]*nucfreq[j/16]*nucfreq[j%4];
      tfreq+=*(ans+i);
    };
    for(int i=0;i<NumCodons;i++){
      *(ans+i)/=tfreq;
    };
  };
    break;
  case 3:  //Fequal
    for(int i=0;i<NumCodons;i++){
      *(ans+i)=(long double)1/NumCodons;
    };
  };
  return ans;
};

