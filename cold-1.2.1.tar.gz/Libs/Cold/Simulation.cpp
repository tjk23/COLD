/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Matrix.h"
#include "Tree.h"
#include "Sequence.h"
#include "Parameters.h"
#include "CommandLine.h"
#include "MiscellaneousFuns.h"
#include <math.h>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;


class simulationtree{//like tree, but just used for simulation, so no lists for likelihood.
public:
  int num;
  int n;
  int numed;
  const char *label;
  Realmatrix *P;
  simulationtree *subtree;
  long unsigned int *down;//basic downwards lists.
//public:
  simulationtree(){n=0;numed=0;P=NULL;subtree=NULL;down=NULL;};
  simulationtree(const tree &t,const params &p,const Factmatrix &f);
  simulationtree(const tree &t,const params *p,const Factmatrix *f,int mixnum);
  void del();
  ~simulationtree(){this->del();};
  void assign(const tree &t,const params &p,const Factmatrix &f);
  void assign(const tree &t,const params *p,const Factmatrix *f,int mixnum);
  void simulate(char **s,long unsigned int ns,const params *p,const long double *probs);
  void simsite(int start,char**s,long unsigned int offset,int pos=0,int cl=1);
  int leaves(){if(n==0){return 1;};int l=0;for(int i=0;i<n;i++){l+=(subtree+i)->leaves();};return l;};
  void printsequences(ostream &out,const char *const* s,long unsigned int len,long unsigned int offset,int &pos);
  simulationtree(const tree &t,const params *const*p,const Factmatrix *const*f);
  void assign(const tree &t,const params *const*&p,const Factmatrix *const*&f);
};

void simulationtree::del(){
  //  for(int i=0;i<n;i++){
  //    (subtree+i)->del();
  //  };
  //  if(n>0){
    delete[] subtree;
    delete[] P;
    delete[] down;
    //  };
};

simulationtree::simulationtree(const tree &t,const params &p,const Factmatrix &f){
  num=1;
  n=t.n;
  numed=t.numed;
  label=t.label;
  P=new Realmatrix[n];
  subtree=new simulationtree[n];
  down=new long unsigned int[NumCodons];
  long double *ex=new long double[NumCodons];
  for(int i=0;i<n;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+j)=exp(*(f.D.entries+j)*(*(t.length+i)));
    };
    (subtree+i)->assign(*(t.subtree+i),p,f);
    (P+i)->sz=NumCodons;
    (P+i)->entries=new long double[NumCodonsSq];
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	*((P+i)->entries+j*NumCodons+k)=0;
	for(int l=0;l<NumCodons;l++){
	  *((P+i)->entries+j*NumCodons+k)+=*(f.gamma.entries+j*NumCodons+l)*(*(ex+l))*(*(f.gammainv.entries+l*NumCodons+k));
	};
      };
    };  
  };
  delete[] ex;
};

simulationtree::simulationtree(const tree &t,const params *p,const Factmatrix *f,int mixnum){
  num=mixnum;
  n=t.n;
  numed=t.numed;
  label=t.label;
  P=new Realmatrix[n*num];
  subtree=new simulationtree[n];
  down=new long unsigned int[NumCodons];
  long double *ex=new long double[NumCodons*num];
  for(int i=0;i<n;i++){
    for(int k=0;k<num;k++){
      for(int j=0;j<NumCodons;j++){
	*(ex+k*NumCodons+j)=exp(*((f+k)->D.entries+j)*(*(t.length+i)));
      };
      (P+i*num+k)->sz=NumCodons;
      (P+i*num+k)->entries=new long double[NumCodonsSq];
      for(int j=0;j<NumCodons;j++){
	for(int l=0;l<NumCodons;l++){
	  *((P+i*num+k)->entries+j*NumCodons+l)=0;
	  for(int m=0;m<NumCodons;m++){
	    *((P+i*num+k)->entries+j*NumCodons+l)+=*((f+k)->gamma.entries+j*NumCodons+m)*(*(ex+k*NumCodons+m))*(*((f+k)->gammainv.entries+m*NumCodons+l));
	  };
	};
      };  
    };
    (subtree+i)->assign(*(t.subtree+i),p,f,mixnum);
  };
  delete[] ex;
};

simulationtree::simulationtree(const tree &t,const params *const*p,const Factmatrix *const*f){//Different parameters and corresponding matrices for each branch
  num=1;
  n=t.n;
  numed=t.numed;
  label=t.label;
  P=new Realmatrix[n];
  subtree=new simulationtree[n];
  down=new long unsigned int[NumCodons];
  long double *ex=new long double[NumCodons];
  for(int i=0;i<n;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+j)=exp(*((*f)->D.entries+j)*(*(t.length+i)));
    };
    (P+i)->sz=NumCodons;
    (P+i)->entries=new long double[NumCodonsSq];
    for(int j=0;j<NumCodons;j++){
      for(int l=0;l<NumCodons;l++){
	*((P+i)->entries+j*NumCodons+l)=0;
	for(int m=0;m<NumCodons;m++){
	  *((P+i)->entries+j*NumCodons+l)+=*((*f)->gamma.entries+j*NumCodons+m)*(*(ex+m))*(*((*f)->gammainv.entries+m*NumCodons+l));
	};
      };
    };  
    f++;
    p++;
    (subtree+i)->assign(*(t.subtree+i),p,f);
  };
  delete[] ex;
};

void simulationtree::assign(const tree &t,const params *const*&p,const Factmatrix *const*&f){//Different parameters and corresponding matrices for each branch
  num=1;
  n=t.n;
  numed=t.numed;
  label=t.label;
  P=new Realmatrix[n];
  subtree=new simulationtree[n];
  down=new long unsigned int[NumCodons];
  long double *ex=new long double[NumCodons];
  for(int i=0;i<n;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+j)=exp(*((*f)->D.entries+j)*(*(t.length+i)));
    };
    (P+i)->sz=NumCodons;
    (P+i)->entries=new long double[NumCodonsSq];
    for(int j=0;j<NumCodons;j++){
      for(int l=0;l<NumCodons;l++){
	*((P+i)->entries+j*NumCodons+l)=0;
	for(int m=0;m<NumCodons;m++){
	  *((P+i)->entries+j*NumCodons+l)+=*((*f)->gamma.entries+j*NumCodons+m)*(*(ex+m))*(*((*f)->gammainv.entries+m*NumCodons+l));
	};
      };
    };  
    f++;
    p++;
    (subtree+i)->assign(*(t.subtree+i),p,f);
  };
  delete[] ex;
};


void simulationtree::assign(const tree &t,const params &p,const Factmatrix &f){
  num=1;
  n=t.n;
  numed=t.numed;
  label=t.label;
  P=new Realmatrix[n];
  subtree=new simulationtree[n];
  down=new long unsigned int[NumCodons];
  long double *ex=new long double[NumCodons];
  for(int i=0;i<n;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+j)=exp(*(f.D.entries+j)*(*(t.length+i)));
    };
    (subtree+i)->assign(*(t.subtree+i),p,f);
    (P+i)->sz=NumCodons;
    (P+i)->entries=new long double[NumCodonsSq];
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	*((P+i)->entries+j*NumCodons+k)=0;
	for(int l=0;l<NumCodons;l++){
	  *((P+i)->entries+j*NumCodons+k)+=*(f.gamma.entries+j*NumCodons+l)*(*(ex+l))*(*(f.gammainv.entries+l*NumCodons+k));
	};
      };
    };  
  };
  delete[] ex;
};

void simulationtree::assign(const tree &t,const params *p,const Factmatrix *f,int mixnum){
  num=mixnum;
  n=t.n;
  numed=t.numed;
  label=t.label;
  P=new Realmatrix[n*num];
  subtree=new simulationtree[n];
  down=new long unsigned int[NumCodons];
  long double *ex=new long double[NumCodons*num];
  for(int i=0;i<n;i++){
    for(int k=0;k<num;k++){
      for(int j=0;j<NumCodons;j++){
	*(ex+k*NumCodons+j)=exp(*((f+k)->D.entries+j)*(*(t.length+i)));
      };
      (P+i*num+k)->sz=NumCodons;
      (P+i*num+k)->entries=new long double[NumCodonsSq];
      for(int j=0;j<NumCodons;j++){
	for(int l=0;l<NumCodons;l++){
	  *((P+i*num+k)->entries+j*NumCodons+l)=0;
	  for(int m=0;m<NumCodons;m++){
	    *((P+i*num+k)->entries+j*NumCodons+l)+=*((f+k)->gamma.entries+j*NumCodons+m)*(*(ex+k*NumCodons+m))*(*((f+k)->gammainv.entries+m*NumCodons+l));
	  };
	};
      };  
    };
    (subtree+i)->assign(*(t.subtree+i),p,f,mixnum);
  };
  delete[] ex;
};


void simulationtree::simulate(char **s,long unsigned int ns,const params *p,const long double *probs){
  for(long unsigned int i=0;i<ns/CodonLength;i++){
    long double r=((long double) rand())/RAND_MAX;
    long double psum=*probs;
    int cl=0;
    for(;psum<r;cl++){
      psum+=*(probs+cl+1);
    };
    r=((long double) rand())/RAND_MAX;
    long double rsum=*((p+cl)->pi);
    int j=0;
    for(;rsum<r&&j<NumCodons-1;j++){
      rsum+=*((p+cl)->pi+j+1);
    };
    this->simsite(j,s,i,0,cl);
  };
};

void simulationtree::simsite(int start,char**s,long unsigned int offset,int pos,int cl){
  if(n==0){
    char *dc=displayCodon(start);
    for(int i=0;i<CodonLength;i++){
      *(*(s+pos)+CodonLength*offset+i)=*(dc+i);
    };
    delete[] dc;
    return;
  };
  int ps=pos;
  for(int i=0;i<n;i++){
    long double l=((long double) rand())/RAND_MAX;
    long double rsum=*((P+i*num+cl)->entries+start*NumCodons);
    int j=0;
    for(;rsum<l&&j<NumCodons-1;j++){
      rsum+=*((P+i*num+cl)->entries+start*NumCodons+j+1);
    };
    (subtree+i)->simsite(j,s,offset,ps,cl);
    ps+=(subtree+i)->leaves();
  };    
};

void simulationtree::printsequences(ostream &out,const char *const* s,long unsigned int len,long unsigned int offset,int &pos){
  if(n==0){
    out<<label<<"   ";
    for(unsigned long int i=0;i<len;i++){
      out<<*(*(s+pos)+offset+i);
    };
    pos++;
    out<<"\n";
    return;
  };
  for(int i=0;i<n;i++){
    (subtree+i)->printsequences(out,s,len,offset,pos);
  };
};

void simulate(const char* basefilename,long unsigned int numfiles, long unsigned int seqlength,const tree &t,params *p,int num=1,long double *pr=NULL){
  Factmatrix *f=new Factmatrix[num];
  for(int i=0;i<num;i++){
    *(f+i)=(p+i)->fmatrix();
  };
  simulationtree s(t,p,f,num);
  int l=t.leaves();
  char **sq=new char*[l];
  for(int i=0;i<l;i++){
    *(sq+i)=new char[numfiles*seqlength];
  };
  long double one=1;
  if(pr==NULL){
    pr=&one;
  };
  s.simulate(sq,numfiles*seqlength,p,pr);
  ofstream out(basefilename);
  char *filename=new char[strlen(basefilename)+20];//Easily enough
  //Put metadata in basefile
  out<<t;//.print(out);
  out<<"\n\n";
  out<<"Codon Frequencies\n\n";
  for(int i=0;i<NumCodons;i++){
    char *cd=displayCodon(i);
    out<<*cd<<*(cd+1)<<*(cd+2);
    out.width(15);
    out<<*(p->pi+i)<<"\n";
    delete[] cd;
  };
  out<<"\n\n";
  if(params::numpars>0){
    out<<"Parameter";
    out.width(20);
    int *sel=NULL;
    variable *rec=vars.seektag("-parameterselection");
    if(rec!=NULL){
      sel=selection(*(char **)rec->value);
      sortlist(sel);
      out<<"Number in file";
      out.width(20);
    };
    out<<"Coefficient";
    out.width(30);
    out<<"Exponential of coefficient\n";
    for(int i=0;i<num;i++){
      if(num>1){
	out<<"Mixture class "<<i<<" probability="<<*(pr+i)<<":\n\n";
      };
      long double *tc=(p+i)->truepars();
      for(int j=0;j<params::numpars;j++){
	out.width(5);
	out<<j;
	out.width(22);
	if(sel!=NULL){
	  out<<((j==0)?0:(*(sel+j-1)));
	  out.width(25);
	};
	out<<*(tc+j);
	out.width(25);
	out<<exp(*(tc+j))<<"\n";
      };
      delete[] tc;
      out<<"\n";
    };
  };
  out.close();
  for(long unsigned int flno=0;flno<numfiles;flno++){
    sprintf(filename,"%s%06lu",basefilename,flno);
    out.open(filename);
    out<<l<<"\t"<<seqlength<<"\n";
    int p=0;
    s.printsequences(out,sq,seqlength,flno*seqlength,p);
    out.close();
  };
  for(int i=0;i<num;i++){ 
    (f+i)->remove();
  };
  delete[] f;
  for(int i=0;i<l;i++){
    delete[] *(sq+i);
  };
  delete[] sq;
  delete[] filename;
};

void simulateheterotachy(const char* basefilename,long unsigned int numfiles, long unsigned int seqlength,const tree &t,params *p,int *pno){
  int num=1;
  int e=t.edges();
  for(int i=0;i<e;i++){
    if(*(pno+i)+1>num){
      num=*(pno+i)+1;
    };
  };
  Factmatrix *f=new Factmatrix[num];
  for(int i=0;i<num;i++){
    *(f+i)=(p+i)->fmatrix();
  };
  const params ** pp=new const params*[e];
  const Factmatrix ** ff=new const Factmatrix*[e];
  for(int i=0;i<e;i++){
    *(pp+i)=p+*(pno+i);
    *(ff+i)=f+*(pno+i);
  };
  simulationtree s(t,pp,ff);
  int l=t.leaves();
  char **sq=new char*[l];
  for(int i=0;i<l;i++){
    *(sq+i)=new char[numfiles*seqlength];
  };
  long double one=1;
  s.simulate(sq,numfiles*seqlength,p,&one);
  ofstream out(basefilename);
  char *filename=new char[strlen(basefilename)+20];//Easily enough
  //Put metadata in basefile
  out<<t;//.print(out);
  out<<"\n\n";
  out<<"Codon Frequencies\n\n";
  for(int i=0;i<NumCodons;i++){
    char *cd=displayCodon(i);
    out<<*cd<<*(cd+1)<<*(cd+2);
    out.width(15);
    out<<*(p->pi+i)<<"\n";
    delete[] cd;
  };
  out<<"\n\n";
  if(params::numpars>0){
    out<<"Parameter";
    out.width(20);
    int *sel=NULL;
    variable *rec=vars.seektag("-parameterselection");
    if(rec!=NULL){
      sel=selection(*(char **)rec->value);
      sortlist(sel);
      out<<"Number in file";
      out.width(20);
    };
    out<<"Coefficient";
    out.width(30);
    out<<"Exponential of coefficient\n";
    for(int i=0;i<num;i++){
      out<<"branch class "<<i<<":\n\nBranches:\t";
      for(int j=0;j<e;j++){
	if(*(pno+j)==i){
	  out<<j<<" ";
	};
      };
      out<<"\n";
      long double *tc=(p+i)->truepars();
      for(int j=0;j<params::numpars;j++){
	out.width(5);
	out<<j;
	out.width(22);
	if(sel!=NULL){
	  out<<((j==0)?0:(*(sel+j-1)));
	  out.width(25);
	};
	out<<*(tc+j);
	out.width(25);
	out<<exp(*(tc+j))<<"\n";
      };
      delete[] tc;
      out<<"\n";
    };
  };
  out.close();
  for(long unsigned int flno=0;flno<numfiles;flno++){
    sprintf(filename,"%s%06lu",basefilename,flno);
    out.open(filename);
    out<<l<<"\t"<<seqlength<<"\n";
    int p=0;
    s.printsequences(out,sq,seqlength,flno*seqlength,p);
    out.close();
  };
  for(int i=0;i<num;i++){ 
    (f+i)->remove();
  };
  delete[] f;
  for(int i=0;i<l;i++){
    delete[] *(sq+i);
  };
  delete[] sq;
  delete[] pp;
  delete[] ff;
  delete[] filename;
};
