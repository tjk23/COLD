/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Tree.h"
#include <signal.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <math.h>
#include <pthread.h>



#include "ErrorHandler.h"
#include "Macros.h"
#include "MiscellaneousFuns.h"
#include "SignalHandler.h"
#include "CommandLine.h"
#include "Matrix.h"
#include "Sequence.h"
#include "Parameters.h"
#include "Likelihood.h"
using namespace std;

#define SMALLDOUB 1e-320
#define ADDEXP 100
#define MULTEXP (exp(ADDEXP))

void (*sthss)(tree &T,const Factmatrix &f,const sequence *data,const params & p,int i, long double *siteliks,const precalc &x,mspace &mem);

void (*mkmtrcs)(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4);

long double *(*sbi)(tree &T,const long double *ex,const Realmatrix *DQ,const Factmatrix &f,const Realmatrix *lp,const params &p);

class precalc;
class mspace;
void makematrices(const Realmatrix& M,const Realmatrix& N,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4);
void makematricesdir(const Realmatrix& M,const long double *d,const int *part,long double *mat,long double *mat2,long double *mat3,long double *mat4);


void dneg(void *d);

 double logcheck(long double x,void* onerror=NULL){
//wrapper for log function that checks its argument isn't too small,
//and deals with the problem if it is. Doesn't deal with case where x
//is too big.
  if(x>SMALLDOUB){
    return log((double) x);
  }else if(x<=0){
    char m[100];
    sprintf(m,"Attempting to take logarithm of non-positive value: %Lg",x);
    menuitem debneg("Debug.",dneg);
    menu neglog(2,stop,debneg);
    neglog.setpars(onerror);
    //throw(neglog);
    printContext();
    fatalError(m,0,&neglog);//Should add debugging menu.
    //In theory, It might be better to throw this, and let the calling
    //routine decide whether the error is fatal.
  }else{
    int i=0;
    for(;x<SMALLDOUB;i++){
      x*=MULTEXP;
    };
    return log((double) x)-i*ADDEXP;
  };
  return 0;//Can't reach this line.
};

long double *tree::branchlen(){
  long double *ans=new long double[numed];
  long double *tmp=ans;
  this->fillbranchlen(tmp);
  return ans;
};

void tree::fillbranchlen(long double *&to){
  for(int i=0;i<n;i++){
    *(to++)=*(length+i);
    (subtree+i)->fillbranchlen(to);
  };
};

void tree::loglengths(){
  for(int i=0;i<n;i++){
    if(*(length+i)<=1){
      *(length+i)=1e-6;
    }else{
      *(length+i)=logcheck(*(length+i));
    };
    (subtree+i)->loglengths();
  };
};

tree *tree::clone(int m){//produces m copies of this tree, each with their own memory for lists.
  tree *ans=new tree[m];
  int ed=this->edges();
  for(int i=0;i<m;i++){
    this->clone(ans+i);
    (ans+i)->setextra(ed);
  };
  return ans;
};

void tree::clone(tree *t){
  t->n=n;
  t->numed=numed;
  if(n>0){
    t->subtree=new tree[n];
    t->length=new long double[n];
  };
  t->up=new long double[NumCodons];
  t->up2=new long double[NumCodons];
  t->up3=new long double[NumCodons];
  t->down=new long double[NumCodons];
  t->down2=new long double[NumCodons];
  t->down3=new long double[NumCodons];
  for(int i=0;i<n;i++){
    *(t->length+i)=*(length+i);
    (subtree+i)->clone(t->subtree+i);
  };
  if(label!=NULL){
    t->label=new char[strlen(label)+1];
    strcpy(t->label,label);
  };
};

void tree::getalldown3lists(long double* list) const{
  int pos=0;
  for(int i=0;i<n;i++){
    (subtree+i)->getdown3lists(list+pos*NumCodons);
    pos+=(subtree+i)->edges()+1;
  };
};

void tree::getallup2lists(long double* list) const{
  int pos=0;
  for(int i=0;i<n;i++){
    (subtree+i)->getup2lists(list+pos*NumCodons);
    pos+=(subtree+i)->edges()+1;
  };
};

void tree::getdown3lists(long double* list) const{
  for(int i=0;i<NumCodons;i++){
    *(list+i)=*(down3+i);
  };
  int pos=1;
  for(int i=0;i<n;i++){
    (subtree+i)->getdown3lists(list+pos*NumCodons);
    pos+=(subtree+i)->edges()+1;
  };
};

void tree::getup2lists(long double* list) const{//Can't run this on root node
  for(int i=0;i<NumCodons;i++){
    *(list+i)=*(up2+i);
  };
  int pos=1;
  for(int i=0;i<n;i++){
    (subtree+i)->getup2lists(list+pos*NumCodons);
    pos+=(subtree+i)->edges()+1;
  };
};

void tree::getdownlists(const long double** list) const{
  //Usually use this to fill lists created by the root node. Not valid
  //for root node.
  *list=down;
  int pos=1;
  for(int i=0;i<n;i++){
    (subtree+i)->getdownlists(list+pos);
    pos+=(subtree+i)->edges()+1;
  };
};

void tree::getuplists(const long double** list) const{
  //Usually use this to fill lists created by the root node. Not valid
  //for root node.
  *list=up;
  int pos=1;
  for(int i=0;i<n;i++){
    (subtree+i)->getuplists(list+pos);
    pos+=(subtree+i)->edges()+1;
  };
};

const long double** tree::getdownlists() const{
  //Fetch all the lists at once to allow multiple actions to be
  //vectorised, reducing cache misses.
  const long double **ans=new const long double*[this->edges()];
  int pos=0;
  for(int i=0;i<n;i++){
    (subtree+i)->getdownlists(ans+pos);
    pos+=(subtree+i)->edges()+1;
  };
  return ans;
};

const long double** tree::getuplists() const{
  //Fetch all the lists at once to allow multiple actions to be
  //vectorised, reducing cache misses.
  const long double **ans=new const long double*[this->edges()];
  int pos=0;
  for(int i=0;i<n;i++){
    (subtree+i)->getuplists(ans+pos);
    pos+=(subtree+i)->edges()+1;
  };
  return ans;
};

const tree *tree::findedge(int e,long double &len) const{
  if(e==0){
    len=*length;
    return subtree;
  };
  const tree *curr=this;
  for(int s=e;s>0;){
    for(int t=0;t<curr->n;t++){
      int ed=(curr->subtree+t)->numed;
      if(ed<s){
	s-=ed+1;
      }else{
	len=*(curr->length+t);
	curr=curr->subtree+t;
	t=-1;
	if(s==0){
	  break;
	};
	s--;
      };
    };
  };    //now curr points to the tree at the bottom of edge e. len is
	//the length of edge e.
  return curr;
};

void tree::remove(){
  for(int i=0;i<n;i++){
    (subtree+i)->remove();
  };
  if(n>0){
    delete[] subtree;
    delete[] length;
  };
  if(label!=NULL){
    delete[] label;
  };
  if(up!=NULL){
    delete[] up; 
    delete[] up2;
    delete[] up3;
    up=NULL;
  };
  delete[] down;
  delete[] down2;
  delete[] down3;
  delete[] extra;
  delete[] extra2;
  delete[] extra3;
};

#include "DNAroutines.cpp"

void tree::liklistdown(const Factmatrix &f,const sequence *data,int m,const long double *ex,long double len){
  int l=data->getLength();
  if(l<m){
    fatalError("Sequence too short.");
    //    cout<<"Sequence too short!\n\n";
    //    exit(0);//Should probably try to improve error handling.
  };
  int j=0;
  int pos=(len<=0)?0:1;//Need a better way to distinguish the top node.
  for(int i=0;i<n;i++){
    long double ll=*(length+i);
    (subtree+i)->liklistdown(f,data+j,m,ex+pos*NumCodons,ll);
    j+=(subtree+i)->leaves();
    pos+=(subtree+i)->edges()+1;
  };
  for(int i=0;i<NumCodons;i++){
    *(down+i)=1;
    for(int j=0;j<n;j++){
      *(down+i)*=*((subtree+j)->down2+i);
    };
  };
  if(n==0){
    int c=codon((data->seq)+CodonLength*m);
    putcodon(c,down);
  };
  if(up!=NULL){
    f.gammainv.act(down,down3);
    Likelihoodact(f,down3,down2,len,ex);
  };
};

void tree::liklistdownfast(const Factmatrix &f,const sequence *data,int m,const long double *ex,const Realmatrix &gis,long double len){
  int l=data->getLength();
  if(l<m){
    fatalError("Sequence too short.");
    //    cout<<"Sequence too short!\n\n";
    //    exit(0);//Should probably try to improve error handling.
  };
  int j=0;
  int pos=(len<=0)?0:1;
  for(int i=0;i<n;i++){
    long double ll=*(length+i);
    (subtree+i)->liklistdownfast(f,data+j,m,ex+pos*NumCodons,gis,ll);
    j+=(subtree+i)->leaves();
    pos+=(subtree+i)->edges()+1;
  };
  for(int i=0;i<NumCodons;i++){
    *(down+i)=1;
  };
  long double *tmp=new long double[NumCodons];
  for(int j=0;j<n;j+=2){
    for(int i=0;i<NumCodons;i++){
      *(down3+i)=*((subtree+j)->down2+i);
    };
    if(j+1<n){
      for(int i=0;i<NumCodons;i++){
	*(down3+i)*=*((subtree+j+1)->down2+i);
      };
      gis.act(down3,tmp);
    }else{
      f.gamma.act(down3,tmp);
    };
    for(int i=0;i<NumCodons;i++){
      *(down3+i)*=*(tmp+i);
    };
  };
  if(n==0){
    int c=codon((data->seq)+CodonLength*m);
    putcodon(c,down);
  };
  if(len>0){
    f.gammainv.act(down,down3);
    for(int i=0;i<NumCodons;i++){
      *(down2+i)=*(down3+i)*(*(ex+i));
    };
  };
};

/*
New function should allow missing values.


void tree::liklistdown(const Factmatrix &f,const sequence *data,int m,const long double *ex,long double len){
  int l=data->getLength();
  if(l<m){
    cout<<"Sequence too short!\n\n";
    exit(0);//Should probably try to improve error handling.
  };
  int j=0;
  int pos=(len<=0)?0:1;
  for(int i=0;i<n;i++){
    long double ll=*(length+i);
    (subtree+i)->liklistdown(f,data+j,m,ex+pos*NumCodons,ll);
    j+=(subtree+i)->leaves();
    pos+=(subtree+i)->edges()+1;
  };
  for(int i=0;i<NumCodons;i++){
    *(down+i)=1;
    for(int j=0;j<n;j++){
      *(down+i)*=*((subtree+j)->down2+i);
    };
  };
  if(n==0){
    int c=codon((data->seq)+CodonLength*m);
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i==c)?1:0;
    };
  };
  if(len>0){
    f.gammainv.act(down,down3);
    Likelihoodact(f,down3,down2,len,ex);
  };
};
*/

void tree::liklistup(const params &p,const Factmatrix& f,const long double *ex,long double *above,long double len){
  //Call this with above=NULL - above is only for recursive calls.
  if(above==NULL){
    if(up!=NULL){
      delete[] up;
      delete[] up2;
      delete[] up3;
    };
    up=NULL;
    up2=NULL;
    up3=NULL;
  };
  //  long double *x=new long double[NumCodons];
  if(above!=NULL){
    for(int i=0;i<NumCodons;i++){
      *(up+i)=*(above+i);
      *(above+i)*=*(p.pi+i);
    };
    f.gamma.TranspAct(above,up2);
    Likelihoodact(f,up2,up3,len,ex);
  };
  long double *t=new long double[NumCodons];
  int pos=(above==NULL)?0:1;
  for(int i=0;i<n;i++){//for each subtree
    for(int k=0;k<NumCodons;k++){
      *(t+k)=1;
      for(int j=0;j<n;j++){
	if(j!=i){
	  *(t+k)*=*((subtree+j)->down2+k);
	};
      };
    };
    if(above!=NULL){//account for the tree above.
      for(int k=0;k<NumCodons;k++){
	*(t+k)*=*(up3+k);
      };
    };      
    (subtree+i)->liklistup(p,f,ex+pos*NumCodons,t,*(length+i));
    pos+=(subtree+i)->edges()+1;
  };    
  delete[] t;
  //    delete[] x;
};

int tree::findlabel(char *lab) const{
  if(n==0){
    if(strcmp(label,lab)==0){
      return 0;
    }else{
      return -1;
    };
  };
  int l=0;
  for(int i=0;i<n;i++){
    int s=(subtree+i)->findlabel(lab);
    if(s!=-1){
      return s+l;
    }else{
      l+=(subtree+i)->leaves();
    };
  };
  return -1;
};

void tree::setextra(int ed){
  for(int i=0;i<n;i++){
    (subtree+i)->setextra(ed);
  };
  extra=new long double[NumCodons*(ed+params::numpars)];
  extra2=new long double[NumCodons*(ed+params::numpars)];
  extra3=new long double[NumCodons*(params::numpars)];
};

/*
void inline putcodonps(int c,long double *down,long double inf){
  if(c<61){
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i==c)?0:inf;
    };
  }else if(c<125){//second nucleotide unknown
    c-=61;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/4==c)?0:inf;
    };
  }else if(c<189){//first Nucleotide unknown
    c-=125;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%4==c%4)&&(i/16==c/16))?0:inf;
    };
  }else if(c<253){//first two Nucleotides unknown
    c-=189;
    c/=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i/16==c)?0:inf;
    };
  }else if(c<317){//Third nucleotide unknown
    c-=253;      
    c%=16;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%16==c)?0:inf;
    };
  }else if(c<381){//Third and second nucleotides unknown
    c-=317;
    c%=16;
    c/=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=((i%16)/4==c)?0:inf;
    };
  }else if(c<445){//Third and second nucleotides unknown
    c-=381;
    c%=4;
    for(int i=0;i<NumCodons;i++){
      *(down+i)=(i%4==c)?0:inf;
    };
  }else{//all unknown
    for(int i=0;i<NumCodons;i++){
      *(down+i)=0;
    };
  };
};
*/

//#include "Hessian.cpp"

int currentpos=0;
pthread_mutex_t posmut=PTHREAD_MUTEX_INITIALIZER;
int numthreads=0;
//int stop=100;

void setnumthreads(int i){
  numthreads=i;
};

void setpos(int i){
  currentpos=i;
};

inline int getnext(){
  pthread_mutex_lock(&posmut);
  int i=currentpos++;
  pthread_mutex_unlock(&posmut);
  return i;
};

class precalc{//stores all the precalculated data.
public:
  int e;
  int l;
  long double **mats;
  const Realmatrix *dD;
  const Factmatrix *ff;
  long double *ex;
  long double *le;
  long double *FIJ;
  int *part;
  long double *coeffs;
  precalc(){e=0;l=0;mats=NULL;dD=NULL;ex=NULL;le=NULL;FIJ=NULL;part=NULL;coeffs=NULL;ff=NULL;};
  precalc(const tree &t,const Factmatrix& f,const sequence *data,const params& p);
  void calc(const tree &t,const Factmatrix& f,const sequence *data,const params& p);
  void print();
  ~precalc();
};


void precalc::print(){
  cout<<e<<" edges\n";
  cout<<l<<" parameters\n\n";

  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      cout<<*(ex+i*NumCodons+j)<<"  ";
    };
    cout<<"\n";
  };
  cout<<"\n";
  for(int i=3;i<6;i++){
    for(int l=0;l<4;l++){
      for(int j=0;j<NumCodons;j++){
	for(int k=0;k<NumCodons;k++){
	  cout<<*(*(mats+i*4+l)+j*NumCodons+k)<<"  ";
	};
	cout<<"\n";
      };
      cout<<"\n";
    };
    cout<<"\n";	
  };
};


precalc::~precalc(){
  delete[] ex;
  delete[] le;
  for(int i=0;i<(params::numpars)*(params::numpars+1)*2;i++){
    delete[] *(mats+i);
  };
  delete[] mats;
  delete[] part;
  delete[] FIJ;
  delete[] coeffs;
};

void* mkmats_threaded(void *pc){
  precalc *t=(precalc *)pc;
  for(int j=getnext();j<params::numpars;j=getnext()){
    for(int k=j;k<params::numpars;k++){
      int i=j*params::numpars-j*(j+1)/2+k;
      *(t->mats+4*i)=new long double[NumCodonsSq];    
      *(t->mats+4*i+1)=new long double[NumCodonsSq];    
      *(t->mats+4*i+2)=new long double[NumCodonsSq];    
      *(t->mats+4*i+3)=new long double[NumCodonsSq];    
      (*mkmtrcs)(*(t->dD+j),*(t->dD+k),t->ff->D.entries,t->part,*(t->mats+4*i),*(t->mats+4*i+1),*(t->mats+4*i+2),*(t->mats+4*i+3));
    };
  };
  return NULL;
};

void makemats(precalc *t){
  currentpos=0;
  if(numthreads==0){
    numthreads=NUMTHREADS;
  };
  char msg[40];
  //  sprintf(msg,"Producing %i threads for computation.",numthreads);
  //  info(msg,msgcode(2,0));
  pthread_t *worker=new pthread_t[numthreads-1];
  int ecode=0;
  int i=0;
  for(;i<numthreads-1&&!ecode;i++){
    ecode=pthread_create((worker+i),NULL,mkmats_threaded,t);
  };//Now i stores the actual number of pthreads created.
  if(ecode){
    sprintf(msg,"only able to produce %i threads.",i);
    warning(msg);
  };
  ecode=0;
  mkmats_threaded(t);
  void **vv=new void*;
  for(int j=0;j<i;j++){
    ecode=pthread_join(*(worker+j),vv);
    if(ecode){
      char x[60];
      sprintf(x,"Threading error rejoining thread number %d",j);
      fatalError(x);
    };
  };
  delete vv;
  delete[] worker;
};

precalc::precalc(const tree &t,const Factmatrix& f,const sequence *data,const params& p){
  //Should really make a threaded version of this.
  ff=&f;
  e=t.edges();
  l=e+params::numpars+1;
  l=l*(l+1)/2;// add space for the hessian
  part=partition(NumCodons,f.D.entries);
  dD=p.Derivmats();
  mats=new long double*[(params::numpars)*(params::numpars+1)*2];
  makemats(this);
  /*  int i=0;
  for(int j=0;j<params::numpars;j++){
    for(int k=j;k<params::numpars;k++){
      *(mats+4*i)=new long double[NumCodonsSq];    
      *(mats+4*i+1)=new long double[NumCodonsSq];    
      *(mats+4*i+2)=new long double[NumCodonsSq];    
      *(mats+4*i+3)=new long double[NumCodonsSq];    
      makematrices(*(dD+j),*(dD+k),f.D.entries,part,*(mats+4*i),*(mats+4*i+1),*(mats+4*i+2),*(mats+4*i+3));
      i++;
    };
    };*/
  ex=new long double[NumCodons*e];
  le=t.getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  FIJ=new long double[NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(FIJ+i*NumCodons+j)=(*(part+i)==*(part+j))?0:1/(*(f.D.entries+i)-*(f.D.entries+j));
    };
  };
  coeffs=new long double[e*NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<NumCodons;k++){
      if(*(part+i)==*(part+k)){
	for(int ed=0;ed<e;ed++){
	  *(coeffs+ed*NumCodonsSq+i*NumCodons+k)=*(le+ed)*(*(ex+ed*NumCodons+i));
	};
      }else{
	for(int ed=0;ed<e;ed++){
	  *(coeffs+ed*NumCodonsSq+i*NumCodons+k)=*(FIJ+i*NumCodons+k)*(*(ex+ed*NumCodons+i)-(*(ex+ed*NumCodons+k)));
	};
      };
    };
  };
};

void precalc::calc(const tree &t,const Factmatrix& f,const sequence *data,const params& p){
  //Should really make a threaded version of this.
  e=t.edges();
  l=e+params::numpars+1;
  l=l*(l+1)/2;// add space for the hessian
  part=partition(NumCodons,f.D.entries);
  dD=p.Derivmats();
  ff=&f;
  mats=new long double*[(params::numpars)*(params::numpars+1)*2];
  makemats(this);
  /*  int i=0;
  for(int j=0;j<params::numpars;j++){
    for(int k=j;k<params::numpars;k++){
      *(mats+4*i)=new long double[NumCodonsSq];    
      *(mats+4*i+1)=new long double[NumCodonsSq];    
      *(mats+4*i+2)=new long double[NumCodonsSq];    
      *(mats+4*i+3)=new long double[NumCodonsSq];    
      makematrices(*(dD+j),*(dD+k),f.D.entries,part,*(mats+4*i),*(mats+4*i+1),*(mats+4*i+2),*(mats+4*i+3));
      i++;
    };
    };*/
  ex=new long double[NumCodons*e];
  le=t.getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  FIJ=new long double[NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(FIJ+i*NumCodons+j)=(*(part+i)==*(part+j))?0:1/(*(f.D.entries+i)-*(f.D.entries+j));
    };
  };
  coeffs=new long double[e*NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<NumCodons;k++){
      if(*(part+i)==*(part+k)){
	for(int ed=0;ed<e;ed++){
	  *(coeffs+ed*NumCodonsSq+i*NumCodons+k)=*(le+ed)*(*(ex+ed*NumCodons+i));
	};
      }else{
	for(int ed=0;ed<e;ed++){
	  *(coeffs+ed*NumCodonsSq+i*NumCodons+k)=*(FIJ+i*NumCodons+k)*(*(ex+ed*NumCodons+i)-(*(ex+ed*NumCodons+k)));
	};
      };
    };
  };
};

class alldata{
public:
  tree *t;
  const Factmatrix *f;
  const sequence *data;
  const params *p;
  const precalc *x;
  alldata(){t=NULL;f=NULL;data=NULL;p=NULL;x=NULL;};
  alldata(tree &tr,const Factmatrix & fa,const sequence *d,const params &pa,const precalc &xx){t=&tr;f=&fa;data=d;p=&pa;x=&xx;};
  void assign(tree &tr,const Factmatrix & fa,const sequence *d,const params &pa,const precalc &xx){t=&tr;f=&fa;data=d;p=&pa;x=&xx;};
};

void *callhessthreaded(void *d){
  alldata *a=(alldata *)d;
  return (a->t)->hessian_threaded(*(a->f),a->data,*(a->p),*(a->x));
};

void *callhessthreadedWithbranchinfluences(void *d){
  alldata *a=(alldata *)d;
  return (a->t)->hessian_threaded_With_branch_influences(*(a->f),a->data,*(a->p),*(a->x));
};

class mspace{
public:
  long double *coeffsums;
  long double *coeffsums2;
  long double *coeffsums3;
  long double *coeffsums4;
  long double *coeffsums5;
  long double *lsq;
  long double *T;
  long double *U;
  mspace(int e){coeffsums=new long double[NumCodonsSq];coeffsums2=new long double[NumCodonsSq];coeffsums3=new long double[NumCodonsSq];coeffsums4=new long double[NumCodonsSq];coeffsums5=new long double[NumCodonsSq];lsq=new long double[NumCodons];T=new long double[e*params::numpars*NumCodons];U=new long double[e*params::numpars*NumCodons];};
  ~mspace(){delete[] coeffsums;delete[] coeffsums2;delete[] coeffsums3;delete[] coeffsums4;delete[] coeffsums5;delete[] lsq;delete[] T;delete[] U;};
};

long double *recovercalchess(tree &t, const Factmatrix& f,const sequence *data,const params& p){
  //resumes an unfinished hessian calculation.
  //should already have loaded x. Now just need to load partial calculation.
  int e=t.edges();
  int l=e+params::numpars+1;
  l=l*(l+1)/2;// add space for the hessian
  int nth=Recover->num('i');//Number of threads that were running in interrupted program.
  int *torepeat=new int[nth];
  long double *answer=new long double[l];
  for(int i=0;i<l;i++){
    *(answer+i)=0;
  };
  long double *temp=new long double[l];
  for(int i=0;i<nth;i++){
    Recover->load(2,1,torepeat+i,l,temp);
    for(int j=0;j<l;j++){
      *(answer+j)+=*(temp+j);
    };
  };
  currentpos=0;
  precalc x(t,f,data,p);
  mspace mem(x.e);
  for(int i=0;i<nth;i++){
    (*sthss)(t,f,data,p,*(torepeat+i),temp,x,mem);   
    for(int j=0;j<l;j++){
      *(answer+j)+=*(temp+j);
    };
    if(*(torepeat+i)>currentpos){
      currentpos=*(torepeat+i);
    };
  };
  currentpos++;
  //Finished off the sites that were only partially calculated.
  if(numthreads==0){
    numthreads=NUMTHREADS;
  };
  char msg[40];
  //  sprintf(msg,"Producing %i threads for computation.",numthreads);
  //  info(msg,msgcode(2,0));
  //  cout<<"Producing "<<numthreads<<" threads for computation.\n";
  //  if(numthreads==1){ 
  //      return t.hessian(f,data,p); 
  //  }; 

  //  Can't use normal 1-threaded hessian, as it doesn't allow an
  //  arbitrary start point.
  pthread_t *worker=new pthread_t[numthreads-1];
  tree *tcopy=t.clone(numthreads-1);
  int i=0;
  int ecode=0;
  alldata *a=new alldata[numthreads-1];
  //  precalc x(t,f,data,p);
  for(;i<numthreads-1;i++){
    (a+i)->assign(*(tcopy+i),f,data,p,x);
  };
  for(i=0;i<numthreads-1&&!ecode;i++){
    //for(i=0;i<1&&!ecode;i++){
    ecode=pthread_create((worker+i),NULL,callhessthreaded,a+i);
  };//Now i stores the actual number of pthreads created.
  if(ecode){
    sprintf(msg,"only able to produce %i threads.",i);
    warning(msg);
  };
  long double *ans=t.hessian_threaded(f,data,p,x);
  for(int j=0;j<l;j++){
    *(answer+j)+=*(ans+j);
  };
  ecode=0;
  for(int j=0;j<i;j++){
    //    cout<<"Trying to rejoin thread "<<j+1<<".\n";
    ecode=pthread_join(*(worker+j),(void**)&temp);
    if(ecode){
      char x[60];
      sprintf(x,"Threading error rejoining thread number %d",j);
      fatalError(x);
      //      cerr<<"Threading error rejoining thread number "<<j<<".\n";
      //      exit(1);
    };
    for(int k=0;k<l;k++){
      *(answer+k)+=*(temp+k);
    };
  };
  delete[] temp;
  delete[] ans;
  /*
  stop=-1;
  for(i=1;i<2&&!ecode;i++){
    ecode=pthread_create((worker+i),NULL,callhessthreaded,a+i);
  };//Now i stores the actual number of pthreads created.
  //  long double *ans=t.hessian_threaded(f,data,p);
  //  long double *temp;
  ecode=0;
  for(int j=1;j<i;j++){
    cout<<"Trying to rejoin thread "<<j+1<<".\n";
    ecode=pthread_join(*(worker+j),(void**)&temp);
    if(ecode){
      cerr<<"Threading error rejoining thread number "<<j<<".\n";
      exit(1);
    };
    for(int k=0;k<l;k++){
      cout<<"adding value "<<k<<".\n";
      *(ans+k)+=*(temp+k);
    };
    delete[] temp;
  };
  */

  for(i=0;i<numthreads-1;i++){
    (tcopy+i)->remove();
  };
  delete[] tcopy;
  delete[] worker;
  delete[] a;
  return answer;
};

long double *calchess(tree &t, const Factmatrix& f,const sequence *data,const params& p){
  int e=t.edges();
  int l=e+params::numpars+1;
  l=l*(l+1)/2;// add space for the hessian
  if(numthreads==0){
    numthreads=NUMTHREADS;
  };
  char msg[40];
  //  sprintf(msg,"Producing %i threads for computation.",numthreads);
  //  info(msg,msgcode(2,0));
  //  cout<<"Producing "<<numthreads<<" threads for computation.\n";
  if(numthreads==1){
    return t.hessian(f,data,p);
  };
  pthread_t *worker=new pthread_t[numthreads-1];
  tree *tcopy=t.clone(numthreads-1);
  int i=0;
  int ecode=0;
  alldata *a=new alldata[numthreads-1];
  precalc x(t,f,data,p);
  //  x.print();
  for(;i<numthreads-1;i++){
    (a+i)->assign(*(tcopy+i),f,data,p,x);
  };
  currentpos=0;
  for(i=0;i<numthreads-1&&!ecode;i++){
    //for(i=0;i<1&&!ecode;i++){
    ecode=pthread_create((worker+i),NULL,callhessthreaded,a+i);
  };//Now i stores the actual number of pthreads created.
  if(ecode){
    sprintf(msg,"only able to produce %i threads.",i);
    warning(msg);
  };
  long double *ans=t.hessian_threaded(f,data,p,x);
  long double *temp;
  ecode=0;
  for(int j=0;j<i;j++){
    //    cout<<"Trying to rejoin thread "<<j+1<<".\n";
    ecode=pthread_join(*(worker+j),(void**)&temp);
    if(ecode){
      char x[60];
      sprintf(x,"Threading error rejoining thread number %d",j);
      fatalError(x);
      //      cerr<<"Threading error rejoining thread number "<<j<<".\n";
      //      exit(1);
    };
    for(int k=0;k<l;k++){
      *(ans+k)+=*(temp+k);
    };
    delete[] temp;
  };
  for(i=0;i<numthreads-1;i++){
    (tcopy+i)->remove();
  };
  delete[] tcopy;
  delete[] worker;
  delete[] a;
  return ans;
};

long double *calchessandbi(tree &t, const Factmatrix& f,const sequence *data,const params& p){
  currentpos=0;
  int e=t.edges();
  int l=e+params::numpars+1;
  l=e*(l-1)+l*(l+1)/2;// add space for the hessian
  if(numthreads==0){
    numthreads=NUMTHREADS;
  };
  char msg[40];
  //  sprintf(msg,"Producing %i threads for computation.",numthreads);
  //  info(msg,msgcode(2,0));
  //  cout<<"Producing "<<numthreads<<" threads for computation.\n";
  precalc x(t,f,data,p);
  currentpos=0;
  if(numthreads==1){
    return t.hessian_threaded_With_branch_influences(f,data,p,x);
  };
  pthread_t *worker=new pthread_t[numthreads-1];
  tree *tcopy=t.clone(numthreads-1);
  int i=0;
  int ecode=0;
  alldata *a=new alldata[numthreads-1];
  //  x.print();
  for(;i<numthreads-1;i++){
    (a+i)->assign(*(tcopy+i),f,data,p,x);
  };
  for(i=0;i<numthreads-1&&!ecode;i++){
    //for(i=0;i<1&&!ecode;i++){
    ecode=pthread_create((worker+i),NULL,callhessthreadedWithbranchinfluences,a+i);
  };//Now i stores the actual number of pthreads created.
  if(ecode){
    sprintf(msg,"only able to produce %i threads.",i);
    warning(msg);
  };
  long double *ans=t.hessian_threaded_With_branch_influences(f,data,p,x);
  long double *temp;
  ecode=0;
  for(int j=0;j<i;j++){
    //    cout<<"Trying to rejoin thread "<<j+1<<".\n";
    ecode=pthread_join(*(worker+j),(void**)&temp);
    if(ecode){
      char x[60];
      sprintf(x,"Threading error rejoining thread number %d",j);
      fatalError(x);
      //      cerr<<"Threading error rejoining thread number "<<j<<".\n";
      //      exit(1);
    };
    for(int k=0;k<l;k++){
      *(ans+k)+=*(temp+k);
    };
    delete[] temp;
  };
  for(i=0;i<numthreads-1;i++){
    (tcopy+i)->remove();
  };
  delete[] tcopy;
  delete[] worker;
  delete[] a;
  return ans;
};


RealmatrixT CalculatePmatrix(const Realmatrix& Q,const Realmatrix& Q2,const Realmatrix& Q3,const Realmatrix& Q4,const Realmatrix& Q5,const Factmatrix& f,long double t){
  //A computation of the P matrix using a Taylor expansion to avoid negatives. 
  //Generally used when the usual calculation gives a negative site likelihood.
  Realmatrix P(Q.sz);
  for(int i=0;i<Q.sz;i++){
    *(P.entries+i*(Q.sz+1))=1;
    for(int j=0;j<Q.sz;j++){
      *(P.entries+i*Q.sz+j)+=*(Q.entries+i*Q.sz+j)*t;
      *(P.entries+i*Q.sz+j)+=*(Q2.entries+i*Q.sz+j)*t*t/2;
      *(P.entries+i*Q.sz+j)+=*(Q3.entries+i*Q.sz+j)*t*t*t/6;
      *(P.entries+i*Q.sz+j)+=*(Q4.entries+i*Q.sz+j)*t*t*t*t/24;
      *(P.entries+i*Q.sz+j)+=*(Q5.entries+i*Q.sz+j)*t*t*t*t*t/120;
    };
  };
  //  cout<<P<<"\n";
  Realmatrix P2=f.gamma;
  for(int i=0;i<Q.sz;i++){
    long double m=exp(*(f.D.entries+i)*t);
    for(int j=0;j<Q.sz;j++){
      *(P2.entries+j*Q.sz+i)*=m;
    };
  };
  P2.mult(f.gammainv);
  //  cout<<P2<<"\n";
  for(int i=0;i<Q.sz;i++){
    for(int j=0;j<Q.sz;j++){
      if(*(P2.entries+i*Q.sz+j)>1e-10){//Arbitrary cut-off maybe could be improved
	*(P.entries+i*Q.sz+j)=*(P2.entries+i*Q.sz+j);
      };
    };
  };
  return P;
};



long double tree::safeSiteLikelihood(const Factmatrix &f,const params& p){
  //Assumes base lists have been correctly computed
  Realmatrix Q=p.Rmatrix();
  for(unsigned int i=0;i<(unsigned int)Q.sz;i++){
    for(unsigned int j=0;j<(unsigned int)Q.sz;j++){
      *(Q.entries+i*Q.sz+j)*=*(p.pi+j);
    };
  };
  //  cout<<Q<<"\n";
  Realmatrix Q5=Q;
  Q5.mult(Q);
  Realmatrix Q2=Q5;
  Q5.mult(Q);
  Realmatrix Q3=Q5;
  Q5.mult(Q);
  Realmatrix Q4=Q5;
  Q5.mult(Q);
  this->makeLikelihoodlistsSafely(Q,Q2,Q3,Q4,Q5,f);
  long double ans=0;
  for(unsigned int i=0;i<NumCodons;i++){
    ans+=*(down+i)*(*p.pi+i);
  };
  return ans;
};

void tree::makeLikelihoodlistsSafely(const Realmatrix& Q,const Realmatrix& Q2,const Realmatrix& Q3,const Realmatrix& Q4,const Realmatrix& Q5,const Factmatrix& f){
  if(n>0){
    long double *temp=new long double[NumCodons];
    for(unsigned int i=0;i<(unsigned int)NumCodons;i++){
      *(down+i)=1;
    };
    for(unsigned int br=0;br<(unsigned int)n;br++){
      Realmatrix P=CalculatePmatrix(Q,Q2,Q3,Q4,Q5,f,*(length+br));
      (subtree+br)->makeLikelihoodlistsSafely(Q,Q2,Q3,Q4,Q5,f);
      for(unsigned int i=0;i<NumCodonsSq;i++){
	if(*(P.entries+i)<0){
	  *(P.entries+i)=0;//Deal with numerical problems with P.
	};
      };
      P.act((subtree+br)->down,temp);
      for(int i=0;i<(unsigned int)NumCodons;i++){
	*(down+i)*=*(temp+i);
      };
    };
    delete[] temp;
  };
};



void accumulate(const long double *siteliks,long double *ans,int e,int l,void *dbn=NULL){
  //Used to add the calculated likelihoods for the current site to the
  //cumulative totals.
  
  /*  pthread_mutex_lock(&posmut);
  for(int i=0;i<l;i++){
    cout<<*(siteliks+i)<<"  ";
  };
  cout<<"\n";
  pthread_mutex_unlock(&posmut);*/
  try{
    *ans+=logcheck(*(siteliks),dbn);
  }catch(int neg){
    //This shouldn't happen now.
    cerr<<"Thread "<<pthread_self()<<":\n";
    cerr<<"site likelihood "<<*(siteliks)<<"calculated. Aborting.\n";
    CurrentState->save();
    exit(1);
  };
  for(int j=1;j<1+e+params::numpars;j++){
    *(ans+j)+=(*(siteliks+j))/(*(siteliks));
  };
  int v=1+e+params::numpars;
  for(int j=0;j<e+params::numpars;j++){
    for(int k=j;k<e+params::numpars;k++){
      *(ans+v)+=(*(siteliks+v))/(*(siteliks));
      *(ans+v)-=(*(siteliks+j+1))*(*(siteliks+k+1))/(*(siteliks)*(*(siteliks)));
      v++;
    };
  };
};

long double *tree::hessian_threaded(const Factmatrix& f,const sequence *data,const params& p,const precalc &x,int st){
  int *shst=(int *)vars.seekval("showeverysite");
  int showeverysite=(shst==NULL)?0:*shst;

  //  precalc x(*this,f,data,p);
  int i=0;
  mspace mem(x.e);
  int sites=data->length;
  if(st!=-1){
    sites=st;
  };
  long double *ans=new long double[x.l];
  for(int j=0;j<x.l;j++){
    *(ans+j)=0;
  };
  long double *siteliks=new long double[x.l];
//Store values currently being calculated here, to avoid corrupting
//the state in case of interruption
  i=getnext();
  int stv1=CurrentState->addvar('i',1,&i);
  CurrentState->addvar('L',x.l,ans,"hessian");//And to protect the state file.
  void **dbn=new void*[3];
  *dbn=this;
  *(dbn+1)=&ans;
  *(dbn+2)=&i;
  for(;i<sites;){//for each site.
    if(!((i+1)%showeverysite)){//should make this depend on the number of sites
      cout<<"Working on site "<<i+1<<" of "<<sites<<":\n";
      //      cout<<"In thread \""<<pthread_self()<<"\"\n";
    };
    (*sthss)(*this,f,data,p,i,siteliks,x,mem);
    sigset_t all;
    sigset_t old;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
    if(*siteliks<=0){
      cout<<"Negative site likelihood found: "<<*siteliks<<"\ncalculating in a different way.\n";      
      *siteliks=this->safeSiteLikelihood(f,p);
      cout<<"New value: "<<*siteliks<<"\n";
    };
    accumulate(siteliks,ans,x.e,x.l,dbn);
    i=getnext();
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
  };
  delete[] dbn;
  CurrentState->remvar(stv1,"endhessian",1);
  delete[] siteliks;
  return ans;
};

long double *tree::hessian_threaded_With_branch_influences(const Factmatrix& f,const sequence *data,const params& p,const precalc &x,int st){
  int *shst=(int *)vars.seekval("showeverysite");
  int showeverysite=(shst==NULL)?0:*shst;

  //  precalc x(*this,f,data,p);
  int i=0;
  mspace mem(x.e);
  int sites=data->length;
  if(st!=-1){
    sites=st;
  };
  long double *ans=new long double[x.l+numed*(numed+params::numpars)];
  for(int j=0;j<x.l+numed*(numed+params::numpars);j++){
    *(ans+j)=0;
  };
  long double *siteliks=new long double[x.l];
//Store values currently being calculated here, to avoid corrupting
//the state in case of interruption
  i=getnext();
  int stv1=CurrentState->addvar('i',1,&i);
  CurrentState->addvar('L',x.l,ans,"hessian");//And to protect the state file.
  void **dbn=new void*[3];
  *dbn=this;
  *(dbn+1)=&ans;
  *(dbn+2)=&i;
  Realmatrix *lp=new Realmatrix[numed*(params::numpars+2)];
  Realmatrix *llp=lp;
  const long double *eex=x.ex;
  this->getlnp(llp,f,eex,x.dD);
  //  cout<<*lp<<"\n\n";
  //  cout<<"Printed first matrix.\n";
  for(;i<sites;){//for each site.
    if(!((i+1)%showeverysite)){//should make this depend on the number of sites
      cout<<"Working on site "<<i+1<<" of "<<sites<<":\n";
      //      cout<<"In thread \""<<pthread_self()<<"\"\n";
    };
    (*sthss)(*this,f,data,p,i,siteliks,x,mem);
    long double *stbrin=(*sbi)(*this,x.ex,x.dD,f,lp,p);
    sigset_t all;
    sigset_t old;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
    accumulate(siteliks,ans,x.e,x.l,dbn);
    for(int j=0;j<numed;j++){
      //	if(j==0){
      //      cout<<"\n"<<i<<"\t"<<j<<"\t"<<*(stbrin+j*(numed+params::numpars+1))/(*(siteliks))<<"\n";
      //	};
      //      cout<<j<<"\n";
      for(int k=0;k<(numed+params::numpars);k++){
	//if(j==16 && k==numed+2){
	//  	  if(k%3==0){
	//	  	    cout<<"\n";
	//	  	  };
	//	  cout<<"\t"<<*(stbrin+j*(numed+params::numpars+1)+k+1)/(*(siteliks))<<" "<<*(stbrin+j*(numed+params::numpars+1))/(*(siteliks))<<" "<<(*(siteliks+k+1))/(*(siteliks))<<" "<<*(stbrin+j*(numed+params::numpars+1))*(*(siteliks+k+1))/(*(siteliks)*(*(siteliks)))<<"\n";
	  //};
	*(ans+x.l+j*(numed+params::numpars)+k)+=*(stbrin+j*(numed+params::numpars+1)+k+1)/(*(siteliks));
	*(ans+x.l+j*(numed+params::numpars)+k)-=*(stbrin+j*(numed+params::numpars+1))*(*(siteliks+k+1))/(*(siteliks)*(*(siteliks)));
      };
      //	if(j==0){
      //              cout<<"\n\n";
      //	};
    };
    i=getnext();
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
    delete[] stbrin;
  };
  
  /*
    for(int b=0;b<numed;b++){
          cout<<b<<"\t";
    for(int j=0;j<params::numpars+numed;j++){
            cout<<"\t"<<*(ans+x.l+b*(numed+params::numpars)+j);
    };
        cout<<"\n";
	};*/
  delete[] dbn;
  CurrentState->remvar(stv1,"endhessian",1);
  delete[] siteliks;
  delete[] lp;
  return ans;
};

/*
long double *tree::branchInfluences(const Factmatrix& f,const sequence *data,const params& p,const precalc &x,int st){
  int *shst=(int *)vars.seekval("showeverysite");
  int showeverysite=(shst==NULL)?0:*shst;

  //  precalc x(*this,f,data,p);
  int i=0;
  mspace mem(x.e);
  int sites=data->length;
  if(st!=-1){
    sites=st;
  };
  long double *ans=new long double[numed*(numed+params::numpars)];
  for(int j=0;j<x.l;j++){
    *(ans+j)=0;
  };
  i=getnext();
  //  int stv1=CurrentState->addvar('i',1,&i);
  //  CurrentState->addvar('L',x.l,ans,"hessian");//And to protect the state file.
  //  void **dbn=new void*[3];
  //  *dbn=this;
  //  *(dbn+1)=&ans;
  //  *(dbn+2)=&i;
  for(;i<sites;){//for each site.
    if(!((i+1)%showeverysite)){//should make this depend on the number of sites
      cout<<"Working on site "<<i+1<<" of "<<sites<<":\n";
      //      cout<<"In thread \""<<pthread_self()<<"\"\n";
    };
    long double *stbrin=(*sbi)(*this,x,x.dD,f,data,p);
    sigset_t all;
    sigset_t old;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
    //    accumulate(siteliks,ans,x.e,x.l,dbn);
    i=getnext();
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
  };
  //  delete[] dbn;
  //  CurrentState->remvar(stv1,"endhessian",1);
  //  delete[] siteliks;
  return ans;
};
*/

long double *tree::derivs(const Factmatrix& f,const sequence *data,const params& p){
  int e=this->edges();
  int l=e+params::numpars+1;
  int i=0;
  int sites=data->length;
  long double *siteliks=new long double[l*sites];
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  const Realmatrix *D=p.Derivmats();
  for(i=0;i<sites;i++){//for each site.
    this->liklistdown(f,data,i,ex);
    this->liklistup(p,f,ex,NULL);
    //Start with likelihood
    *(siteliks+i*l)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks+i*l)+=*(p.pi+j)*(*(down+j));
    };
    for(int j=1+e;j<l;j++){
      *(siteliks+i*l+j)=0;
    };
    for(int j=0;j<e;j++){//for each edge
      long double len;
      const tree* curr=this->findedge(j,len);
      //      cout<<*curr<<"\n\n";
      *(siteliks+i*l+j+1)=dliketact2(f,curr->up2,curr->down3,len,p,ex+j*NumCodons);
    };
    for(int k=0;k<params::numpars;k++){
      //Calculate first derivatives with respect to parameters.
      *(siteliks+i*l+k+e+1)=0;
      for(int j=0;j<e;j++){
	long double len;
	const tree* curr=this->findedge(j,len);
	*(siteliks+i*l+e+k+1)+=dlikeqact2(f,curr->up2,curr->down3,len,p,*(D+k),ex+j*NumCodons);
      };
    };
  };
  delete[] ex;
  delete[] le;

  long double *ans=new long double[l];
  *ans=0;
  for(int j=0;j<sites;j++){
    *ans+=logcheck(*(siteliks+j*l));
  };
  for(int i=1;i<1+e+params::numpars;i++){
    *(ans+i)=0;
    for(int s=0;s<sites;s++){
      *(ans+i)+=(*(siteliks+s*l+i))/(*(siteliks+s*l));
    };
  };
  delete[] siteliks;
  return ans;
};

long double *tree::sitefirstders(const Factmatrix& f,const sequence *data,const params& p){
  int e=this->edges();
  int l=e+params::numpars+1;
  int i=0;
  int sites=data->length;
  long double *siteliks=new long double[l*sites];
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  const Realmatrix *D=p.Derivmats();
  for(i=0;i<sites;i++){//for each site.
    this->liklistdown(f,data,i,ex);
    this->liklistup(p,f,ex,NULL);
    //Start with likelihood
    *(siteliks+i*l)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks+i*l)+=*(p.pi+j)*(*(down+j));
    };
    if(*siteliks+i*l<=0){
      cout<<"Negative site likelihood found: "<<*(siteliks+i*l)<<"\ncalculating in a different way.\n";      
      *(siteliks+i*l)=this->safeSiteLikelihood(f,p);
      cout<<"New value: "<<*(siteliks+i*l)<<"\n";      
    };
    for(int j=1+e;j<l;j++){
      *(siteliks+i*l+j)=0;
    };
    for(int j=0;j<e;j++){//for each edge
      long double len;
      const tree* curr=this->findedge(j,len);
      //      cout<<*curr<<"\n\n";
      *(siteliks+i*l+j+1)=dliketact2(f,curr->up2,curr->down3,len,p,ex+j*NumCodons);
    };
    for(int k=0;k<params::numpars;k++){
      //Calculate first derivatives with respect to parameters.
      *(siteliks+i*l+k+e+1)=0;
      for(int j=0;j<e;j++){
	long double len;
	const tree* curr=this->findedge(j,len);
	*(siteliks+i*l+e+k+1)+=dlikeqact2(f,curr->up2,curr->down3,len,p,*(D+k),ex+j*NumCodons);
      };
    };
  };
  delete[] ex;
  delete[] le;
  for(int i=1;i<1+e+params::numpars;i++){
    for(int s=0;s<sites;s++){
      (*(siteliks+s*l+i))/=(*(siteliks+s*l));
    };
  };
  for(int j=0;j<sites;j++){
    *(siteliks+j*l)=logcheck(*(siteliks+j*l));
  };
  return siteliks;
};

long double *tree::approxHessian(const Factmatrix& f,const sequence *data,const params& p){
  int e=this->edges();
  int l=e+params::numpars+1;
  int i=0;
  int sites=data->length;
  long double *siteliks=new long double[l*sites];
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  const Realmatrix *D=p.Derivmats();
  for(i=0;i<sites;i++){//for each site.
    this->liklistdown(f,data,i,ex);
    this->liklistup(p,f,ex,NULL);
    //Start with likelihood
    *(siteliks+i*l)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks+i*l)+=*(p.pi+j)*(*(down+j));
    };
    for(int j=1+e;j<l;j++){
      *(siteliks+i*l+j)=0;
    };
    for(int j=0;j<e;j++){//for each edge
      long double len;
      const tree* curr=this->findedge(j,len);
      *(siteliks+i*l+j+1)=dliketact2(f,curr->up2,curr->down3,len,p,ex+j*NumCodons);
    };
    for(int k=0;k<params::numpars;k++){
      //Calculate first derivatives with respect to parameters.
      *(siteliks+i*l+k+e+1)=0;
      for(int j=0;j<e;j++){
	long double len;
	const tree* curr=this->findedge(j,len);
	*(siteliks+i*l+e+k+1)+=dlikeqact2(f,curr->up2,curr->down3,len,p,*(D+k),ex+j*NumCodons);
      };
    };
  };
  delete[] ex;
  delete[] le;

  long double *ans=new long double[l*(l+1)/2];
  *ans=0;
  for(int j=0;j<sites;j++){
    *ans+=logcheck(*(siteliks+j*l));
  };
  for(int i=1;i<1+e+params::numpars;i++){
    *(ans+i)=0;
    for(int s=0;s<sites;s++){
      *(ans+i)+=(*(siteliks+s*l+i))/(*(siteliks+s*l));
    };
  };
  int v=1+e+params::numpars;
  for(int j=0;j<e+params::numpars;j++){
    for(int k=j;k<e+params::numpars;k++){
      *(ans+v)=0;//*(ans+j+1)*(*(ans+k+1));
      for(int s=0;s<sites;s++){
	*(ans+v)-=(*(siteliks+s*l+j+1))*(*(siteliks+s*l+k+1))/(*(siteliks+s*l)*(*(siteliks+s*l)));
      };
      v++;
    };
  };
  delete[] siteliks;
  return ans;
};

long double tree::likelihood(const Factmatrix& f,const sequence *data,const params& p){
  int i=0;
  int sites=data->length;
  int e=(this->edges());
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  long double *siteliks=new long double[sites];
  for(i=0;i<sites;i++){//for each site.
    this->liklistdown(f,data,i,ex);
    *(siteliks+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks+i)+=*(p.pi+j)*(*(down+j));
    };
    if(*(siteliks+i)<=0){
      cout<<"Negative site likelihood found: "<<*(siteliks+i)<<"\ncalculating in a different way.\n";      
      *(siteliks+i)=this->safeSiteLikelihood(f,p);
      cout<<"New value: "<<*(siteliks+i)<<"\n";

      this->debugneg(*(siteliks+i),cout,i);
    };
  };
  long double ans=0;
  for(int j=0;j<sites;j++){
    ans+=logcheck(*(siteliks+j));
  };
  delete[] ex;
  delete[] le;
  delete[] siteliks;
  return ans;
};

long double tree::fastlikelihood(const Factmatrix& f,const sequence *data,const params& p){
  int i=0;
  int sites=data->length;
  int e=(this->edges());
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  Realmatrix gis(NumCodons);
  for(int i=0;i<NumCodonsSq;i++){
    *(gis.entries+i)=*(f.gamma.entries+i)*(*(f.gamma.entries+i));
  };
  long double *siteliks=new long double[sites];
  for(i=0;i<sites;i++){//for each site.
    this->liklistdownfast(f,data,i,ex,gis);
    *(siteliks+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks+i)+=*(p.pi+j)*(*(down+j));
    };
  };
  long double ans=0;
  for(int j=0;j<sites;j++){
    ans+=logcheck(*(siteliks+j));
  };
  delete[] ex;
  delete[] le;
  delete[] siteliks;
  return ans;
};

long double *tree::sitelikelihoods(const Factmatrix& f,const sequence *data,const params& p){
  //Outputs the log likelihood of each site.
  int i=0;
  int sites=data->length;
  long double *ans=new long double[sites];
  int e=(this->edges());
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  for(i=0;i<sites;i++){//for each site.
    this->liklistdown(f,data,i,ex);
    *(ans+i)=0;
    for(int j=0;j<NumCodons;j++){
      *(ans+i)+=*(p.pi+j)*(*(down+j));
    };
    if(*(ans+i)<=0){
      cout<<"Negative site likelihood found: "<<*(ans+i)<<"\ncalculating in a different way.\n";      
      *(ans+i)=this->safeSiteLikelihood(f,p);
      cout<<"New value: "<<*(ans+i)<<"\n";
      //      this->debugneg(*(ans+i),cout,i);
    };
    //    *(ans+i)=log(*(ans+i));
  };
  delete[] ex;
  delete[] le;
  return ans;
};

/*
long double *tree::directionalDerivs(const Factmatrix& f,const sequence *data,const params& p,const long double *dir){
  //Calculates the first and second directional derivatives in the
  //direction dir. 

  //Need to think about this.
  int e=this->edges();
  int i=0;
  int sites=data->length;
  long double *siteliks=new long double[3*sites];
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  long double *coeffs=NULL;
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp((*(le+i))*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  Realmatrix X(NumCodons);
  Realmatrix X2(NumCodons);
  for(int i=0;i<NumCodonsSq;i++){
    *(X.entries+i)=0;
    *(X2.entries+i)=0;
  };
  const Realmatrix *dD=p.Derivmats();
  for(int i=0;i<params::numpars;i++){
    for(int j=0;j<NumCodonsSq;j++){
      *(X.entries+j)+=*(dir+e+i)*(*((dD+i)->entries+j));
    };
  };
  for(int i=0;i<params::numpars;i++){
    for(int j=0;j<params::numpars;j++){
      const Realmatrix& O=p.d2D(i,j);
      for(int k=0;k<NumCodonsSq;k++){
	*(X2.entries+k)+=*(dir+e+i)*(*(dir+e+j))*(*(O.entries+k));
      };
    };
  };
  int *part=partition(NumCodons,f.D.entries);
  long double **mats=new long double*[4];
  *(mats)=new long double[NumCodonsSq];    
  *(mats+1)=new long double[NumCodonsSq];    
  *(mats+2)=new long double[NumCodonsSq];    
  *(mats+3)=new long double[NumCodonsSq];    
  makematricesdir(X,f.D.entries,part,*(mats),*(mats+1),*(mats+2),*(mats+3));
  long double *FIJ=new long double[NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(FIJ+i*NumCodons+j)=(*(part+i)==*(part+j))?0:1/(*(f.D.entries+i)-*(f.D.entries+j));
    };
  };
  for(i=0;i<sites;i++){//for each site.
    this->liklistdown(f,data,i,ex);
    this->liklistup(p,f,ex,NULL);
    //Start with likelihood
    *(siteliks+i*3)=0;
    *(siteliks+i*3+1)=0;
    *(siteliks+i*3+2)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks+i*3)+=*(p.pi+j)*(*(down+j));
    };
    for(int j=0;j<e;j++){//for each edge
      long double len;
      const tree* curr=this->findedge(j,len);
      *(siteliks+i*3+1)+=*(dir+e)*dliketact(f,curr->up2,curr->down3,len,p,ex+j*NumCodons);
    };
    for(int j=0;j<e;j++){
      long double len;
      const tree* curr=this->findedge(j,len);
      *(siteliks+i*3+1)+=dlikeqact2(f,curr->up2,curr->down3,len,p,X,ex+j*NumCodons);
    };
    this->liklistextradir(f,p,ex,X,dir);
    //Actually, the following few lines should be able to be run once for all parameters, saving time.
    long double *upvals=new long double[e*NumCodons]; 
    long double *downvals=new long double[e*NumCodons]; 
    //    const long double **tmp=this->getuplists();
    //    f.gamma.MultiTranspActProd(e,tmp,p.pi,upvals);//Actually, these can be replaced.
    //    delete[] tmp;
    //    tmp=this->getdownlists();
    //    f.gammainv.MultiAct(e,tmp,downvals);
    //    delete[] tmp;  
    this->getallup2lists(upvals);
    this->getalldown3lists(downvals);
  //Up to here, this can all be precalculated.
    const long double *ext=ex;
    *(siteliks+i*3+2)+=this->secderbldir(dir,p,f,ex,0);
    *(siteliks+i*3+2)+=this->secderblpdir(dir,p,f,ex,X,0,coeffs);
    *(siteliks+i*3+2)+=this->secderdir(p,f,0,X,ext,coeffs);
    *(siteliks+i*3+2)+=this->sdsamedir(f,p,X,X2,*(mats),*(mats+1),*(mats+2),*(mats+3),part,upvals,downvals,ex,le,FIJ);
    delete[] upvals;
    delete[] downvals;
  };
  delete[] ex;
  delete[] le;
  delete[] *mats;
  delete[] *(mats+1);
  delete[] *(mats+2);
  delete[] mats;
  delete[] part;
  delete[] FIJ;
  long double *ans=new long double[3];
  *ans=0;
  *(ans+1)=0;
  for(int j=0;j<sites;j++){
    *ans+=log(*(siteliks+j*3));
  };
  for(int s=0;s<sites;s++){
    *(ans+1)+=(*(siteliks+s*3+1))/(*(siteliks+s*3));
  };
  *(ans+2)=0;//*(ans+1)*(*(ans+1));
  for(int s=0;s<sites;s++){
    *(ans+2)+=(*(siteliks+s*3+2))/(*(siteliks+s*3));
    *(ans+2)-=(*(siteliks+s*3+1))*(*(siteliks+s*3+1))/(*(siteliks+s*3)*(*(siteliks+s*3)));
  };
  delete[] siteliks;
  return ans;
};
*/

void dneg(void *d){
  tree *t=(tree *)*(void **)d;
  long double val=*(long double *)(*((void **)d+1));
  int no=*(int *)(*((void **)d+2));
  t->debugneg(val,cout,no);
};


long double *tree::hessian(const Factmatrix& f,const sequence *data,const params& p){
  int *shst=(int *)vars.seekval("showeverysite");
  int showeverysite=(shst==NULL)?0:*shst;
  precalc x(*this,f,data,p);
  int i=0;
  mspace mem(x.e);

  /*  int e=this->edges();
  int l=e+params::numpars+1;
  l=l*(l+1)/2;// add space for the hessian
  int *part=partition(NumCodons,f.D.entries);
  const Realmatrix *dD=p.Derivmats();
  int i=0;
  long double **mats=new long double*[(params::numpars)*(params::numpars+1)*2];
  for(int j=0;j<params::numpars;j++){
    for(int k=j;k<params::numpars;k++){
      *(mats+4*i)=new long double[NumCodonsSq];    
      *(mats+4*i+1)=new long double[NumCodonsSq];    
      *(mats+4*i+2)=new long double[NumCodonsSq];    
      *(mats+4*i+3)=new long double[NumCodonsSq];    
      makematrices(*(dD+j),*(dD+k),f.D.entries,part,*(mats+4*i),*(mats+4*i+1),*(mats+4*i+2),*(mats+4*i+3));
      i++;
    };
  };
  long double *T=new long double[e*params::numpars*NumCodons];
  long double *U=new long double[e*params::numpars*NumCodons];
  long double *ex=new long double[NumCodons*e];
  long double *le=this->getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp(*(le+i)*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  long double *FIJ=new long double[NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(FIJ+i*NumCodons+j)=(*(part+i)==*(part+j))?0:1/(*(f.D.entries+i)-*(f.D.entries+j));
    };
  };
  long double *coeffs=new long double[e*NumCodonsSq];
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<NumCodons;k++){
      if(*(part+i)==*(part+k)){
	for(int ed=0;ed<e;ed++){
	  *(coeffs+ed*NumCodonsSq+i*NumCodons+k)=*(le+ed)*(*(ex+ed*NumCodons+i));
	};
      }else{
	for(int ed=0;ed<e;ed++){
	  *(coeffs+ed*NumCodonsSq+i*NumCodons+k)=*(FIJ+i*NumCodons+k)*(*(ex+ed*NumCodons+i)-(*(ex+ed*NumCodons+k)));
	};
      };
    };
  };
  long double *coeffsums=new long double[NumCodonsSq];
  long double *coeffsums2=new long double[NumCodonsSq];
  long double *coeffsums3=new long double[NumCodonsSq];
  long double *coeffsums4=new long double[NumCodonsSq];
  long double *coeffsums5=new long double[NumCodonsSq];
  long double *lsq=new long double[NumCodons];*/

  int sites=data->length;
  long double *ans=new long double[x.l];
  for(int i=0;i<x.l;i++){
    *(ans+i)=0;
  };
  long double *siteliks=new long double[x.l];
//Store values currently being calculated here, to avoid corrupting
//the state in case of interruption
  i=0;
  if(Recover!=NULL&&!strcmp(Recover->retid,"hessian")){//Trying to recover
    cout<<"Recovering from saved file.\n";
    Recover->load(2,1,&i,x.l,ans);
    cout<<"Starting from site "<<i<<".\n";
  };
  int stv1=CurrentState->addvar('i',1,&i);
  CurrentState->addvar('L',x.l,ans,"hessian");
  void **dbn=new void*[3];
  *dbn=this;
  *(dbn+1)=&ans;
  *(dbn+2)=&i;
  for(;i<sites;i++){//for each site.
    if(!((i+1)%showeverysite)){//should make this depend on the number of sites
      cout<<"Working on site "<<i+1<<" of "<<sites<<":\n";
    };
    (*sthss)(*this,f,data,p,i,siteliks,x,mem);
    sigset_t all;
    sigset_t old;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
    if(*siteliks<=0){
      cout<<"Negative site likelihood found: "<<*siteliks<<"\ncalculating in a different way.\n";      
      *siteliks=this->safeSiteLikelihood(f,p);
      cout<<"New value: "<<*siteliks<<"\n";
    };
    accumulate(siteliks,ans,x.e,x.l,dbn);
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
    /*
    this->liklistdown(f,data,i,ex);
    this->liklistup(p,f,ex,NULL);
    //Start with likelihood
    *(siteliks)=0;
    for(int j=0;j<NumCodons;j++){
      *(siteliks)+=*(p.pi+j)*(*(down+j));
    };
    for(int j=1+e;j<l;j++){
      *(siteliks+j)=0;
    };
    this->liklistextra(f,p,ex,coeffs,dD,T,U);
    //Actually, the following few lines should be able to be run once for all parameters, saving time.
    long double *upvals=new long double[e*NumCodons]; 
    long double *downvals=new long double[e*NumCodons]; 
    this->getallup2lists(upvals);
    this->getalldown3lists(downvals);
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	*(coeffsums+j*NumCodons+k)=0;
	*(coeffsums2+j*NumCodons+k)=0;
	*(coeffsums3+j*NumCodons+k)=0;
	*(coeffsums4+j*NumCodons+k)=0;
	*(coeffsums5+j*NumCodons+k)=0;
      };
      *(lsq+j)=0;
    };
    for(int ed=0;ed<e;ed++){	
      for(int j=0;j<NumCodons;j++){
	for(int k=0;k<NumCodons;k++){//These loops take up about 5% total time
	  long double w=(*(upvals+ed*NumCodons+j))*(*(downvals+ed*NumCodons+k));
	  *(coeffsums+j*NumCodons+k)+=*(coeffs+ed*NumCodonsSq+j*NumCodons+k)*w;
	  long double t=(*(ex+ed*NumCodons+j))*w;
	  *(coeffsums2+j*NumCodons+k)+=t;
	  *(coeffsums3+j*NumCodons+k)+=t*(*(le+ed));
	  long double u=(*(ex+ed*NumCodons+k))*w;
	  *(coeffsums4+j*NumCodons+k)+=u;
	  *(coeffsums5+j*NumCodons+k)+=u*(*(le+ed));
	  if(*(part+j)==*(part+k)){
	    *(lsq+j)+=*(le+ed)*(*(le+ed))*(*(ex+ed*NumCodons+j))*w;
	  };
	};
      };
    };
  //Up to here, this can all be precalculated.
    long double *jj=siteliks+1+e+params::numpars;
    for(int j=0;j<e;j++){
      //Second derivative with respect to branch j
      long double len=*(le+j);
      const tree *curr=this->findedge(j,len);
      *(jj++)=d2liketact(f,curr->up2,curr->down3,len,p,ex+j*NumCodons);

      this->secderbl(j,p,f,ex,jj,e,0);
      for(int k=0;k<params::numpars;k++){
	//Derivative with respect to branch j and parameter k
	*(jj++)=this->secderblp(j,k,p,f,ex,*(dD+k),0,upvals,coeffs);
      };
    };
    long double *acc=siteliks+1+e+params::numpars+e*params::numpars+e*(e+1)/2;
    int ii=0;
    for(int j=0;j<params::numpars;j++){
      for(int k=j;k<params::numpars;k++){
	const long double *ext=ex;
	const long double *cfs=coeffs;
	*(acc+ii)=this->secder(j,k,p,f,0,*(dD+j),*(dD+k),ext,cfs);
	*(acc+ii)+=this->sdsame(j,k,f,p,*(dD+j),*(dD+k),p.d2D(j,k),*(mats+4*ii),*(mats+4*ii+1),*(mats+4*ii+2),*(mats+4*ii+3),part,upvals,downvals,ex,le,FIJ,coeffs,coeffsums2,coeffsums3,coeffsums4,coeffsums5,lsq,T,U);
	long double *ent=p.d2D(j,k).entries;
	for(int jj=0;jj<NumCodonsSq;jj++){
	  *(acc+ii)+=*(ent+jj)*(*(coeffsums+jj));
	};
	ii++;
      };
    };//Need to take derivatives with respect to branch lengths.
    //    cout<<"Derivatives with respect to branchlengths are:\n";
    for(int j=0;j<e;j++){//for each edge
      long double len;
      this->findedge(j,len);
      *(siteliks+j+1)=dliketact2(f,upvals+j*NumCodons,downvals+j*NumCodons,len,p,ex+j*NumCodons);
      //      cout<<*(siteliks+j+1)<<"\t";
      //      *(siteliks+j+1)=dliketact(f,curr->down3,curr->up2,len,p,ex+j*NumCodons);
    };
    delete[] upvals;
    delete[] downvals;
    for(int k=0;k<params::numpars;k++){
      //Calculate first derivatives with respect to parameters.
      long double *lks=new long double[NumCodons];
      for(int kk=0;kk<NumCodons;kk++){
	*(lks+kk)=0;
      };
      for(int kk=0;kk<NumCodons;kk++){
	for(int ii=0;ii<n;ii++){
	  long double th=1;	  
	  for(int jj=0;jj<n;jj++){
	    if(jj==ii){	      
	      th*=*((subtree+ii)->extra+k*NumCodons+kk);
	    }else{
	      th*=*((subtree+jj)->down2+kk);
	    };
	  };
	  *(lks+kk)+=th;
	};
      };
      for(int kk=0;kk<NumCodons;kk++){
	*(siteliks+1+e+k)+=*(lks+kk)*(*(p.pi+kk));
      };
      delete[] lks;
    };
    //Block Signals
    sigset_t all;
    sigset_t old;
    sigfillset(&all);
    sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
    //Now update answer
    try{
      *ans+=log(*(siteliks));
    }catch(int neg){
      //Shouldn't happen now.
      cerr<<"site likelihood "<<*(siteliks)<<"calculated. Aborting.\n";
      CurrentState->save();
      exit(1);
    };
    for(int i=1;i<1+e+params::numpars;i++){
      *(ans+i)+=(*(siteliks+i))/(*(siteliks));
    };
    int v=1+e+params::numpars;
    for(int j=0;j<e+params::numpars;j++){
      for(int k=j;k<e+params::numpars;k++){
	*(ans+v)+=(*(siteliks+v))/(*(siteliks));
	*(ans+v)-=(*(siteliks+j+1))*(*(siteliks+k+1))/(*(siteliks)*(*(siteliks)));
	v++;
      };
    };
    //Restore Signals
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
    */
  };
  delete[] dbn;
  /*  delete[] ex;
  delete[] le;
  //Now combine sitewise results into overall likelihoods.
  for(i=0;i<(params::numpars)*(params::numpars+1)*2;i++){
    delete[] *(mats+i);
  };
  delete[] coeffs;
  delete[] coeffsums;
  delete[] coeffsums2;
  delete[] coeffsums3;
  delete[] coeffsums4;
  delete[] coeffsums5;
  delete[] lsq;
  delete[] mats;
  delete[] part;
  delete[] FIJ;
  delete[] T;
  delete[] U;
  //  CurrentState->addvar('L',l,ans);*/
  CurrentState->remvar(stv1,"endhessian",2);
  delete[] siteliks;
  return ans;
};


inline long double coeff(long double eit,long double ejt,long double i,long double j,long double t){
  if(NONZERO(i-j)){
    return((eit-ejt)/(i-j));
  }else{
    return eit*t;//teit
  };
};

void tree::getlnp(Realmatrix *&lp,const Factmatrix &f,const long double *&ex,const Realmatrix *DD) const{
  //Calculates the logarithms of entries of the P matrix to the array
  //of Realmatrix lp.
  //  cout<<f.gamma<<"\n\n";
  Realmatrix temp(NumCodons);
  for(int i=0;i<n;i++){
    *lp=f.gamma;
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	*(lp->entries+k*NumCodons+j)*=*ex;
      };      
      ex++;
    };
    lp->mult(f.gammainv);
    //    cout<<*lp<<"\n\n";
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	if(*(lp->entries+j*NumCodons+k)<=0){
	  //	  cerr<<"Oh dear - negative value: "<<*(lp->entries+j*NumCodons+k)<<"\n";
	  *(temp.entries+j*NumCodons+k)=-20;
	  *(lp->entries+j*NumCodons+k)=0;
	}else{
	  *(temp.entries+j*NumCodons+k)=logcheck(*(lp->entries+j*NumCodons+k));
	  *(lp->entries+j*NumCodons+k)*=*(temp.entries+j*NumCodons+k);
	};
      };      
    };  
    //    cout<<temp<<"\n\n";  
    //    cout<<*lp<<"\n\n";
    lp->mult(f.gamma);
    lp->premult(f.gammainv.entries);
    //    cout<<*lp<<"\n\n";
    lp++;
    ex-=NumCodons;
    *lp=f.gamma;
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	*(lp->entries+k*NumCodons+j)*=*ex*(*(f.D.entries+j));
      };      
      ex++;
    };
    lp->mult(f.gammainv);
    for(int j=0;j<NumCodons;j++){
      for(int k=0;k<NumCodons;k++){
	*(lp->entries+j*NumCodons+k)*=*(temp.entries+j*NumCodons+k)+1;
      };      
    };    
    lp->mult(f.gamma);
    lp->premult(f.gammainv.entries);
    //    cout<<*lp<<"\n\n";
    lp++;
    ex-=NumCodons;
    Realmatrix temp(NumCodons);
    for(int p=0;p<params::numpars;p++){
      *lp=f.gamma;
      for(int j=0;j<NumCodons;j++){
	for(int k=0;k<NumCodons;k++){
	  *(temp.entries+j*NumCodons+k)=coeff(*(ex+j),*(ex+k),*(f.D.entries+j),*(f.D.entries+k),*(length+i))*(*((DD+p)->entries+k*NumCodons+j));
	};      
      };
      lp->mult(temp);
      lp->mult(f.gammainv);
      for(int j=0;j<NumCodons;j++){
	for(int k=0;k<NumCodons;k++){
	  *(lp->entries+j*NumCodons+k)*=*(temp.entries+j*NumCodons+k)+1;
	};      
      };    
      //      lp->mult(f.gamma);
      //      lp->premult(f.gammainv.entries);
      lp++;
    };
    ex+=NumCodons;
    (subtree+i)->getlnp(lp,f,ex,DD);
  };
};



#include "Mixture.cpp"
