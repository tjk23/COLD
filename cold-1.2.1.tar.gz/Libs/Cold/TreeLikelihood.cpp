/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "TreeLikelihood.h"
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <sstream>
//#include <stdlib.h>
//#include <string>
#include <cmath>


#include "ErrorHandler.h"
#include "Macros.h"
#include "MiscellaneousFuns.h"
#include "CommandLine.h"
#include "Matrix.h"
#include "Sequence.h"
#include "Parameters.h"
#include "Optimisation.h"
#include "Tree.h"
using namespace std;
extern ostream& comm;//commentry;


extern int useapproxhessian;

// Code needed for optimisation.

void prcxt(void *x){
  if(x!=NULL){
    ((treelk*)x)->printall();
  };
};

void setcont(treelk *c){
  setContext(prcxt,c);
};

int treelikelihood::numsites(){
  return d->length;
};

void treelikelihood::setblfix(){
  fixbl=1;
};

void treelikelihood::empirical(int type){
  long double *epi=emppi(d,T.leaves(),type);
  p.setpi(epi);
  delete[] epi;
};

void treelikelihood::setpars(const Realmatrix& Q){
  if(p.numpars==0){
    dim=T.numed;
  };
  p.getpars(Q);
  f=p.fmatrix();
  vals=NULL;
  if(variablepars!=NULL){
    delete[] variablepars;
  };
  variablepars=new int[params::numpars+1];
  for(int i=0;i<params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  if(params::numpars>0){
    *(variablepars+params::numpars-1)=-1;
  };
};

void treelikelihood::setpars(std::ifstream& I){
  if(p.numpars==0){
    dim=T.numed;
  };
  p.readpars(I);
  f=p.fmatrix();
  vals=NULL;
  if(variablepars!=NULL){
    delete[] variablepars;
  };
  variablepars=new int[params::numpars+1];
  for(int i=0;i<params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  if(params::numpars>0){
    *(variablepars+params::numpars-1)=-1;
  };
};

void treelikelihood::setpars(const char* c){
  if(p.numpars==0){
    dim=T.numed;
  };
  std::istringstream in(c);
  p.readpars(in);
  f=p.fmatrix();
  vals=NULL;
  if(variablepars!=NULL){
    delete[] variablepars;
  };
  variablepars=new int[params::numpars+1];
  for(int i=0;i<params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  if(params::numpars>0){
    *(variablepars+params::numpars-1)=-1;
  };
};

void treelikelihood::setzeropars(){
  if(p.numpars==0){
    dim=T.numed;
  };
  long double *cf=new long double[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(cf+i)=0;
  };
  p.setCoeff(cf);
  f=p.fmatrix();
  vals=NULL;
  if(variablepars!=NULL){
    delete[] variablepars;
  };
  variablepars=new int[params::numpars+1];
  for(int i=0;i<params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  if(params::numpars>0){
    *(variablepars+params::numpars-1)=-1;
  };
};


treelikelihood::~treelikelihood(){
  delete[] d;
  T.up=NULL;
  T.remove();
  f.remove();
  delete[] lastval;
  if(vals!=NULL){
    delete[] vals;
  };
  delete[] variablepars;
};

void treelikelihood::printtreedev(const Realmatrix &oi,std::ostream& out){
  long double *std=new long double[T.numed];
  for(int i=0;i<T.numed;i++){
    *(std+i)=sqrt(*(oi.entries+i*(oi.sz+1)));
  };
  T.print(std,out);
  delete[] std;
};


treelikelihood::treelikelihood(const char *tr,const Realmatrix& Q,std::ifstream& data){
  fixbl=0;
  T=tree(tr);
  T.filledges();
  p.getpars(Q);
  f=p.fmatrix();
  d=getdata(data,T);
  dim=T.edges()+p.numpars-1;
  if(p.numpars==0){dim++;};
  lastval=new long double[dim];
  vals=NULL;
  variablepars=new int[params::numpars+1];
  for(int i=0;i<params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  *(variablepars+params::numpars-1)=-1;
  dir=0;
};

treelikelihood::treelikelihood(const char *tr,std::ifstream& data){
  fixbl=0;
  T=tree(tr);
  T.filledges();
  d=getdata(data,T);
  dim=T.edges()+p.numpars-1;
  if(p.numpars==0){
    dim++;
  };
  lastval=new long double[dim];
  vals=NULL;
  variablepars=new int[params::numpars+1];
  for(int i=0;i<params::numpars-1;i++){
    *(variablepars+i)=i+1;
  };
  *(variablepars+params::numpars-1)=-1;
  dir=0;
};

void treelikelihood::setfixedpars(long double *vls,int max){
  long double *y=new long double[params::numpars];
  int *vp=variablepars;
  int vlno=0;
  for(int i=0;i<params::numpars;i++){
    if(*vp==i){
      *(y+i)=p.coeff[i];
      vp++;
    }else{
      *(y+i)=*(vls+vlno);
      if(vlno<max-1){
	vlno++;
      };
    };
  };
  p.setCoeff(y);
  delete[] y;
};

RealmatrixT makeparsimonymatrix(const Factmatrix &f,int a){
  Realmatrix C(NumCodons);
  long double *temp=new long double[NumCodons*(NumCodons-a)];
  long double *temp2=new long double[NumCodons*(NumCodons-a)];
  //Should really chose the a most spread out entries of D.

  for(int i=0;i<NumCodons-a;i++){
    long double t=0;
    for(int j=0;j<a;j++){
      long double x=1;
      for(int k=0;k<a;k++){
	if(k!=j){
	  x*=(*(f.D.entries+i+a)-*(f.D.entries+k))/(*(f.D.entries+j)-*(f.D.entries+k));
	};
      };
      *(temp+i*NumCodons+j)=-x;
      t-=x;
    };
    for(int l=a;l<NumCodons;l++){
      *(temp+i*NumCodons+l)=0;
    };
    *(temp+i*NumCodons+i+a)=1;
    cout<<t+1<<"\n";
  };
  long double *s=new long double[NumCodons];
  for(int i=0;i<a;i++){
    *(s+i)=1;
    for(int j=0;j<a;j++){
      if(i!=j){
	*(s+i)*=(1-*(f.D.entries+j))/(*(f.D.entries+i)-*(f.D.entries+j));
      };
    };
  };
  for(int i=a;i<NumCodons;i++){
    *(s+i)=0;
  };
  long double *x=new long double[NumCodons];
  //  f.gammainv.act(x,Aones);
  long double *y=new long double[NumCodons];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons-a;j++){
      for(int k=0;k<NumCodons;k++){
	*(x+k)=*(temp+j*NumCodons+k)/(*(f.gamma.entries+i*NumCodons+k));
      };
      f.gamma.act(x,temp2+j*NumCodons);
    };
    for(int k=0;k<NumCodons;k++){
      *(x+k)=*(s+k)/(*(f.gamma.entries+i*NumCodons+k));
    };
    f.gamma.act(x,y);
    for(int j=0;j<NumCodons;j++){
      cout<<*(y+j)<<"  ";
    };
    cout<<"\n\n";
    for(int j=0;j<NumCodons-a;j++){
      for(int m=0;m<5;m++){
	for(int k=0;k<j;k++){
	  long double dot=0;
	  for(int l=0;l<NumCodons;l++){
	    dot+=*(temp2+j*NumCodons+l)*(*(temp2+k*NumCodons+l));
	  };
	  for(int l=0;l<NumCodons;l++){
	    *(temp2+j*NumCodons+l)-=*(temp2+k*NumCodons+l)*dot;
	  };
	};
      };
      long double dot=0;
      for(int l=0;l<NumCodons;l++){
	dot+=*(temp2+j*NumCodons+l)*(*(temp2+j*NumCodons+l));
      };
      dot=sqrt(dot);
      for(int k=0;k<NumCodons;k++){
	*(temp2+j*NumCodons+k)/=dot;
	cout<<*(temp2+j*NumCodons+k)<<"  ";
      };
    };
    for(int l=0;l<5;l++){
      for(int j=0;j<NumCodons;j++){
	*(x+j)=*(y+j)-1;//*(Aones+j)/(*(f.gamma.entries+i*NumCodons+j));
      };
      for(int j=0;j<NumCodons-a;j++){
	long double dot=0;
	for(int k=0;k<NumCodons;k++){
	  dot+=*(temp2+j*NumCodons+k)*(*(x+k));
	};
	cout<<dot<<"  ";
	for(int k=0;k<NumCodons;k++){
	  *(x+k)-=*(temp2+j*NumCodons+k)*dot;
	  *(y+k)-=*(temp2+j*NumCodons+k)*dot;
	};
      };
      cout<<"\n";
      for(int j=0;j<NumCodons;j++){
	cout<<*(y+j)<<"  ";
      };      
      cout<<"\n";
    };
    cout<<"\n\n";
    for(int k=0;k<NumCodons;k++){
      *(C.entries+i*NumCodons+k)=*(y+k);
    };
  };
  delete[] y;
  delete[] s;
  delete[] x;
  delete[] temp;
  delete[] temp2;
  return C;
};

void treelikelihood::parsimonybl(){
  //  this->parsimonypars();
  //Uses parsimony to seed the branch lengths.
  //  cout.precision(10);
  //  this->normalisejustpars();
  Factmatrix f=p.fmatrix();
  Realmatrix C;
  /*  variable *rec=vars.seektag("-parsimonyrows");
  if(rec==NULL){
    C=makeparsimonymatrix(f,6);
  }else{
    C=makeparsimonymatrix(f,atoi(*(char **)rec->value));
    };*/
  Realmatrix Q=p.Rmatrix();
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<NumCodons;j++){
      *(Q.entries+i*NumCodons+j)*=*(p.pi+j);
    };
  };
  C=Q.getresistance();
  for(int i=0;i<NumCodonsSq;i++){
      *(C.entries+i)-=1;
      if(*(C.entries+i)<0){
	*(C.entries+i)=0;
      };
  };
  //  cout<<C<<"\n\n";
  T.parsimonybl(C,d);//.transpose()
  f.remove();
  //  T.loglengths();
};

void treelikelihood::printall(ostream& out,int *valpars){
  //prints all coefficients, even fixed ones.
  T.up=NULL;
  out<<T;//.print(out);
  //T.print(out);
  out<<"\n\n";
  if(params::numpars>0){
    out<<"Parameter";
    out.width(25);
    out<<"Coefficient";
    out.width(40);
    out<<"Exponential of Coefficient\n\n";
    long double *tc=p.truepars();
    for(int j=0;j<params::numpars;j++){
      out.width(5);
      if(valpars!=NULL&&j>0){
	out<<*(valpars+j-1);
      }else{
	out<<j;
      };
      out.width(29);
      out<<*(tc+j);
      out.width(30);
      out<<exp(*(tc+j))<<"\n";
    };
    delete[] tc;
    out<<"\n\n";
  };
};

long double treelikelihood::quickEvaluate(const long double *x){
  if(dim>T.edges()){
    long double *y=new long double[params::numpars];
    for(int i=0;i<dim-T.edges();i++){
      for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	*(y+k)=p.coeff[k];
      };
      *(y+*(variablepars+i))=*(x+T.edges()+i);
    };
    p.setCoeff(y);
    f=p.fmatrix();
    delete[] y;
  };
  T.setedgelengths(x);
  return T.likelihood(f,d,p);
};

int treelikelihood::testlast(const long double *x){
  for(int i=0;i<dim;i++){
    if(NONZEROSTSQ(*(x+i)-*(lastval+i))){
      return 0;
    };
  };
  return 1;
};

long double treelikelihood::evaluate(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    //Need to change to new values x
    if(dim>T.edges()){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.edges();i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.edges()+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    /*
    Realmatrix Q=f.gamma;
    for(int i=0;i<NumCodons;i++){
      for(int j=0;j<NumCodons;j++){
	*(Q.entries+i*NumCodons+j)*=*(f.D.entries+j);
      };
    };
    Q.mult(f.gamma.inverse());
    cout<<Q<<"\n";*/
    //    cout<<f.gammainv;
    T.setedgelengths(x);
    if(useapproxhessian){
      vals=T.approxHessian(f,d,p);
    }else{
      vals=calchess(T,f,d,p);
    };
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  return *vals;
};


void treelikelihood::testderiv(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.edges()){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.edges();i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.edges()+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    if(useapproxhessian){
      vals=T.approxHessian(f,d,p);
    }else{
      vals=calchess(T,f,d,p);
    };
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  long double *test=T.derivs(f,d,p);
  for(int i=0;i<dim+2;i++){
    cout<<*(test+i)<<"  "<<*(vals+i)<<"  "<<*(test+i)-*(vals+i)<<"\n";
  };
  delete[] test;
  cout<<"\n";
};


void treelikelihood::deriv(const long double *x,long double *out){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.edges()){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.edges();i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.edges()+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    if(useapproxhessian){
      vals=T.approxHessian(f,d,p);
    }else{
      vals=calchess(T,f,d,p);
    };
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  for(int i=0;i<T.edges();i++){
    *(out+i)=*(vals+i+1);
  };
  for(int i=0;i<(dim-T.edges());i++){
    *(out+T.edges()+i)=*(vals+T.edges()+*(variablepars+i)+1);
  };
};

void treelikelihood::hessian(const long double *x,long double *out){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.numed){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.numed;i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.numed+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    if(useapproxhessian){
      vals=T.approxHessian(f,d,p);
    }else{
      vals=calchess(T,f,d,p);
    };
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  int acc=1+T.numed+params::numpars;
  for(int i=0;i<T.numed;i++){
    for(int j=i;j<T.numed;j++){
      *(out+i*dim+j)=*(vals+acc);
      *(out+j*dim+i)=*(vals+acc);
      acc++;
    };
    for(int j=0;j<dim-T.numed;j++){
      *(out+i*dim+T.numed+j)=*(vals+acc+*(variablepars+j));
      *(out+(j+T.numed)*dim+i)=*(vals+acc+*(variablepars+j));
    };
    acc+=params::numpars;
  };
  for(int i=0;i<dim-T.numed;i++){
    for(int k=(i>0)?*(variablepars+i-1):0;k<*(variablepars+i);k++){
      acc+=params::numpars-k;
    };
    for(int j=i;j<dim-T.numed;j++){
      *(out+(i+T.numed)*dim+j+T.numed)=*(vals+acc+*(variablepars+j)-*(variablepars+i));
      *(out+(j+T.numed)*dim+i+T.numed)=*(vals+acc+*(variablepars+j)-*(variablepars+i));
    };
  };
};

void treelikelihood::approxHessian(const long double *x,long double *out){
  if(dim>T.edges()){
    long double *y=new long double[params::numpars];
    for(int i=0;i<dim-T.edges();i++){
      for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	*(y+k)=p.coeff[k];
      };
      *(y+*(variablepars+i))=*(x+T.edges()+i);
    };
    p.setCoeff(y);
    f=p.fmatrix();
    delete[] y;
  };
  T.setedgelengths(x);
  long double *vv=T.approxHessian(f,d,p);
  int acc=1+T.edges()+params::numpars;
  for(int i=0;i<T.edges();i++){
    for(int j=i;j<T.edges();j++){
      *(out+i*dim+j)=*(vv+acc);
      *(out+j*dim+i)=*(vv+acc);
      acc++;
    };
    for(int j=0;j<dim-T.edges();j++){
      *(out+i*dim+T.numed+j)=*(vv+acc+*(variablepars+j));
      *(out+j*dim+T.numed+i)=*(vv+acc+*(variablepars+j));
    };
    acc+=params::numpars;
  };
  for(int i=0;i<dim-T.edges();i++){
    for(int k=(i>0)?*(variablepars+i-1):0;k<*(variablepars+i);k++){
      acc+=params::numpars-k;//*(variablepars+i);
    };
    for(int j=i;j<dim-T.edges();j++){
      *(out+(i+T.numed)*dim+j+T.numed)=*(vv+acc+*(variablepars+j)-*(variablepars+i));
      *(out+(j+T.numed)*dim+i+T.numed)=*(vv+acc+*(variablepars+j)-*(variablepars+i));
    };
  };
  delete[] vv;
};

void treelikelihood::tstat(const long double *x,ostream& out){
  out<<"Parameter";
  out.width(25);
  long double *tst=this->tstats(x);
  variable *rec=vars.seektag("-parameterselection");
  if(rec!=NULL){
    int *sel=selection(*(char **)rec->value);
    sortlist(sel);
    out<<"Number in file";
    out.width(25);
    out<<"T statistic\n";
    for(int j=0;j<params::numpars;j++){
      out.width(5);
      out<<j;
      out.width(29);
      out<<((j==0)?0:*(sel+j-1));
      out.width(29);
      out<<*(tst+j);
      out<<"\n";
    };
  }else{
    out<<"T statistic\n";
    for(int j=0;j<params::numpars;j++){
      out.width(5);
      out<<j;
      out.width(29);
      out<<*(tst+j);
      out<<"\n";
    };
  };
  delete[] tst;
};

long double db0dbi(const params &p,unsigned int i,const Realmatrix *XX){
  if(i==0||i>=params::numpars){
    fatalError("parameter number too large.");
  };
  Realmatrix R=p.Rmatrix();
  long double ans=0;
  for(int m=0;m<NumCodons;m++){
    for(int n=0;n<m;n++){
      ans-=*(R.entries+m*NumCodons+n)*(*((XX+i)->entries+m*NumCodons+n))*(*(p.pi+m))*(*(p.pi+n));
    };
    for(int n=m+1;n<NumCodons;n++){
      ans-=*(R.entries+m*NumCodons+n)*(*((XX+i)->entries+m*NumCodons+n))*(*(p.pi+m))*(*(p.pi+n));
    };
  };
  //  cout<<"i="<<i<<"\tdb0/dbi="<<ans<<"\n";
  return ans;
};


long double d2b0dbidbj(const params &p,unsigned int i,unsigned int j,const Realmatrix *XX){
  //This is only part of the value calculated - it needs to be
  //adjusted by adding db0dbi and db0dbj
  if(i==0||j==0||i>=params::numpars||j>=params::numpars){
    fatalError("parameter number too large.");
  };
  Realmatrix R=p.Rmatrix();
  long double ans=0;
  for(int m=0;m<NumCodons;m++){
    for(int n=0;n<m;n++){
      ans-=*(R.entries+m*NumCodons+n)*(*((XX+i)->entries+m*NumCodons+n))*(*((XX+j)->entries+m*NumCodons+n))*(*(p.pi+m))*(*(p.pi+n));
    };
    for(int n=m+1;n<NumCodons;n++){
      ans-=*(R.entries+m*NumCodons+n)*(*((XX+i)->entries+m*NumCodons+n))*(*((XX+j)->entries+m*NumCodons+n))*(*(p.pi+m))*(*(p.pi+n));
    };
  };
  return ans;
};

RealmatrixT adjust_hessian(const params &p,Realmatrix &h,int e,long double dldb0){
  //change from hessian in terms of transformed variables to hessian in true variables.
  Realmatrix h0(h.sz);
  Realmatrix *XX=new Realmatrix[params::numpars];
  Realmatrix lcorner(params::numpars);
  for(int i=0;i<params::numpars;i++){
    for(int j=0;j<params::numpars;j++){
      *(lcorner.entries+i*params::numpars+j)=*(h.entries+(e+i)*h.sz+e+j);
    };
  };
  Realmatrix Ai=params::A.inverse();
  Realmatrix AiT=Ai.transpose();
  lcorner.premult(AiT.entries);
  lcorner.mult(Ai);
  long double *sum=new long double[params::numpars];
  for(int i=0;i<e;i++){
    for(int k=0;k<params::numpars;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars;j++){
      for(int k=0;k<params::numpars;k++){
	*(sum+j)+=*(Ai.entries+k*params::numpars+j)*(*(h.entries+(e+k)*h.sz+i));
      };
    };
    for(int k=0;k<params::numpars;k++){
      *(h0.entries+(e+k)*h.sz+i)=*(sum+k);
    };
  };
  for(int i=0;i<e;i++){
    for(int k=0;k<params::numpars;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars;j++){
      for(int k=0;k<params::numpars;k++){
	*(sum+j)+=*(Ai.entries+k*params::numpars+j)*(*(h.entries+i*h.sz+e+k));
      };
    };
    for(int k=0;k<params::numpars;k++){
      *(h0.entries+i*h.sz+(e+k))=*(sum+k);
    };
  };
  delete[] sum;

  for(int i=0;i<params::numpars;i++){
    *(XX+i)=RealmatrixT(NumCodons);
    for(int m=0;m<NumCodonsSq;m++){
      *((XX+i)->entries+m)=0;
    };
    for(int j=0;j<params::numpars;j++){
      *(h0.entries+(e+i)*h.sz+e+j)=*(lcorner.entries+i*params::numpars+j);
      for(int m=0;m<NumCodonsSq;m++){
	*((XX+i)->entries+m)+=*(Ai.entries+i*params::numpars+j)*(*((params::XX+j)->entries+m));
      };
    };
  };

  //(XX+i) is the derivative of the Q-matrix with respect to true parameter i.

  //  cout<<h0<<"\n\n";

  //Now account for the effect of the scaling coefficient:
  for(int i=0;i<e;i++){
    for(int j=0;j<e;j++){
      *(h0.entries+i*h.sz+j)=*(h.entries+i*h.sz+j);
    };
    for(int j=1;j<params::numpars;j++){
      *(h0.entries+i*h.sz+e+j)+=*(h0.entries+i*h.sz+e)*db0dbi(p,j,XX);
    };
  };
  for(int i=1;i<params::numpars;i++){
    for(int j=0;j<e;j++){
      *(h0.entries+(i+e)*h.sz+j)+=*(h0.entries+e*h.sz+j)*db0dbi(p,i,XX);
    };
    for(int j=1;j<params::numpars;j++){
      *(h0.entries+(i+e)*h.sz+e+j)+=*(h0.entries+(i+e)*h.sz+e)*db0dbi(p,j,XX)+*(h0.entries+e*h.sz+j+e)*db0dbi(p,i,XX)+dldb0*d2b0dbidbj(p,i,j,XX)+dldb0*db0dbi(p,i,XX)*db0dbi(p,j,XX)+*(h0.entries+e*h.sz+e)*db0dbi(p,j,XX)*db0dbi(p,i,XX);
    };
  };
  delete[] XX;

  //  cout<<h0<<"\n\n";

  Realmatrix hmatsmall(h.sz-1);
  for(int i=0;i<e;i++){
    for(int j=0;j<e;j++){
      *(hmatsmall.entries+i*(h.sz-1)+j)=*(h0.entries+i*h.sz+j);
    };
    for(int j=e;j<h.sz-1;j++){
      *(hmatsmall.entries+i*(h.sz-1)+j)=*(h0.entries+i*h.sz+j+1);
    };
  };
  for(int i=e;i<h.sz-1;i++){
    for(int j=0;j<e;j++){
      *(hmatsmall.entries+i*(h.sz-1)+j)=*(h0.entries+(i+1)*h.sz+j);
    };
    for(int j=e;j<h.sz-1;j++){
      *(hmatsmall.entries+i*(h.sz-1)+j)=*(h0.entries+(i+1)*h.sz+j+1);
    };
  };
  return hmatsmall;
  //  cout<<hmat<<"\n";
};

void treelikelihood::truehessian(const long double *x,long double *out){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.numed){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.numed;i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.numed+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    vals=calchess(T,f,d,p);
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  //  long double *tc=p.truepars();
  Realmatrix hmat(T.numed+params::numpars);
  int acc=1+T.numed+params::numpars;
  for(int i=0;i<hmat.sz;i++){
    for(int j=i;j<hmat.sz;j++){
      *(hmat.entries+i*hmat.sz+j)=*(vals+acc);
      *(hmat.entries+j*hmat.sz+i)=*(vals+acc);
      acc++;
    };
  };
  Realmatrix ans=adjust_hessian(p,hmat,T.numed,*(vals+1+T.numed));
  for(int i=0;i<ans.sz*ans.sz;i++){
    *(out+i)=*(ans.entries+i);
  };
};

void treelikelihood::trueapproxHessian(const long double *x,long double *out){
  if(dim>T.numed){
    long double *y=new long double[params::numpars];
    for(int i=0;i<dim-T.numed;i++){
      for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	*(y+k)=p.coeff[k];
      };
      *(y+*(variablepars+i))=*(x+T.numed+i);
    };
    p.setCoeff(y);
    f=p.fmatrix();
    delete[] y;
  };
  T.setedgelengths(x);
  long double *vv=T.approxHessian(f,d,p);
  //  long double *tc=p.truepars();
  Realmatrix hmat(T.numed+params::numpars);
  int acc=1+T.numed+params::numpars;
  for(int i=0;i<hmat.sz;i++){
    for(int j=i;j<hmat.sz;j++){
      *(hmat.entries+i*hmat.sz+j)=*(vv+acc);
      *(hmat.entries+j*hmat.sz+i)=*(vv+acc);
      acc++;
    };
  };
  Realmatrix ans=adjust_hessian(p,hmat,T.numed,*(vals+1+T.numed));
  for(int i=0;i<ans.sz*ans.sz;i++){
    *(out+i)=*(ans.entries+i);
  };
};


RealmatrixT treelikelihood::oi(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.numed){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.numed;i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.numed+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    vals=calchess(T,f,d,p);
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  //  long double *tc=p.truepars();
  int acc=1+T.numed+params::numpars;
  Realmatrix hmat(T.numed+params::numpars);
  for(int i=0;i<hmat.sz;i++){
    for(int j=i;j<hmat.sz;j++){
      *(hmat.entries+i*hmat.sz+j)=*(vals+acc);
      *(hmat.entries+j*hmat.sz+i)=*(vals+acc);
      acc++;
    };
  };
  Realmatrix hmatsmall=adjust_hessian(p,hmat,T.numed,*(vals+1+T.numed));
  for(int i=0;i<hmatsmall.sz*hmatsmall.sz;i++){
    *(hmatsmall.entries+i)*=-1;
  };
  return hmatsmall;
  Realmatrix oi=hmatsmall.inverse();
  for(int i=0;i<oi.sz;i++){
    if(*(oi.entries+i*(oi.sz+1))>=0){//Should figure out a better way to deal with this.
      char msg[100];
      sprintf(msg,"Found positive diagonal element in inverse of hessian, for entry %d. Replacing by -1",i);
	info(msg,msgcode(1,0));
	//      *(oi.entries+i*(hmat.sz+1))=-1;
    };
  };
  return oi;
};

long double *treelikelihood::tstats(const long double *x){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.numed){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.numed;i++){
	for(int k=(i==0)?0:(*(variablepars+i-1)+1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.numed+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    vals=calchess(T,f,d,p);
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  long double *tc=p.truepars();
  int acc=1+T.numed+params::numpars;
  Realmatrix hmat(T.numed+params::numpars);
  for(int i=0;i<hmat.sz;i++){
    for(int j=i;j<hmat.sz;j++){
      *(hmat.entries+i*hmat.sz+j)=*(vals+acc);
      *(hmat.entries+j*hmat.sz+i)=*(vals+acc);
      acc++;
    };
  };
  Realmatrix lcorner(params::numpars);
  for(int i=0;i<params::numpars;i++){
    for(int j=0;j<params::numpars;j++){
      *(lcorner.entries+i*params::numpars+j)=*(hmat.entries+(T.numed+i)*hmat.sz+T.numed+j);
    };
  };
  Realmatrix Ai=params::A.inverse();
  Realmatrix AiT=Ai.transpose();
  lcorner.premult(AiT.entries);
  lcorner.mult(Ai);
  long double *sum=new long double[params::numpars];
  for(int i=0;i<T.numed;i++){
    for(int k=0;k<params::numpars;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars;j++){
      for(int k=0;k<params::numpars;k++){
	*(sum+j)+=*(Ai.entries+k*params::numpars+j)*(*(hmat.entries+(T.numed+k)*hmat.sz+i));
      };
    };
    for(int k=0;k<params::numpars;k++){
      *(hmat.entries+(T.numed+k)*hmat.sz+i)=*(sum+k);
    };
  };
  for(int i=0;i<T.numed;i++){
    for(int k=0;k<params::numpars;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars;j++){
      for(int k=0;k<params::numpars;k++){
	*(sum+j)+=*(Ai.entries+k*params::numpars+j)*(*(hmat.entries+i*hmat.sz+T.numed+k));
      };
    };
    for(int k=0;k<params::numpars;k++){
      *(hmat.entries+i*hmat.sz+(T.numed+k))=*(sum+k);
    };
  };

  delete[] sum;
  for(int i=0;i<params::numpars;i++){
    for(int j=0;j<params::numpars;j++){
      *(hmat.entries+(T.numed+i)*hmat.sz+T.numed+j)=*(lcorner.entries+i*params::numpars+j);
    };
  };
  for(int i=0;i<hmat.sz;i++){
    *(hmat.entries+i*(hmat.sz+1))-=0.1;//Does this make things too insignificant?
  };
  //  cout<<hmat<<"\n";
  Realmatrix oi=hmat.inverse();
  for(int i=0;i<hmat.sz;i++){
    if(*(oi.entries+i*(hmat.sz+1))>=0){//Should figure out a better way to deal with this.
      char msg[100];
      sprintf(msg,"Found positive diagonal element in inverse of hessian, for entry %d. Replacing by -1",i);
	info(msg,msgcode(1,0));
      *(oi.entries+i*(hmat.sz+1))=-1;
    };
  };
  /*  for(int i=0;i<oi.sz;i++){
    cout<<*(oi.entries+i*(oi.sz+1))<<"\n";
  };
  cout<<"\n";*/
  long double *ans=new long double[params::numpars];
  for(int j=0;j<params::numpars;j++){
    *(ans+j)=*(tc+j)/sqrt(-*(oi.entries+(T.numed+j)*(T.numed+params::numpars+1)));
  };
  delete[] tc;
  return ans;
};

int* treelikelihood::tstatsel(const long double *x,long double threshold){
  long double *tst=this->tstats(x);
  int num=0;
  for(int i=1;i<params::numpars;i++){
    if(*(tst+i)>threshold||*(tst+i)<-threshold){
      num++;
    };
  };
  int *ans=new int [num+1];
  num=0;
  for(int i=1;i<params::numpars;i++){
    if(*(tst+i)>threshold||*(tst+i)<-threshold){
      *(ans+num++)=i;
    };
  };
  *(ans+num)=-1;
  delete[] tst;
  return ans;
};

void treelikelihood::selectpars(int *sel){//assumes no fixed parameters
  long double *tc=p.truepars();
  params::selectpars(sel);
  dim=T.numed+params::numpars-1;
  for(int i=1;*(sel+i-1)>=0;i++){
    *(tc+i)=*(tc+*(sel+i-1));
  };
  ((Realmatrix)params::A.inverse()).act(tc,p.coeff);
  delete[] tc;
  *(variablepars+params::numpars-1)=-1;
};

void treelikelihood::undoselect(int *sel,int lastpars){//assumes no fixed parameters
  *(variablepars+params::numpars-1)=params::numpars;
  params::undoselect(sel,lastpars);
  dim=T.numed+params::numpars-1;
};


long double *treelikelihood::likelihoodDisplacement(int *params){
  //returns: a sxs matrix, a sxd matrix,
  long double *x=new long double[dim];
  this->getx(x);
  Realmatrix hess(dim);
  this->hessian(x,hess.entries);
  Realmatrix hi=hess.inverse();
  int ii=params::numpars;
  if(params!=NULL){
    ii=0;
    for(;*(params+ii)>=0;ii++);
    int i=dim-ii;
    Realmatrix hsub(i);
    int k=0;
    for(int l=0;l<i;l++){
      for(;*(params+k)==l+k;k++);
      int kk=0;
      for(int ll=0;ll<i;ll++){
	for(;*(params+kk)==ll+kk;kk++);
	*(hsub.entries+l*i+ll)=*(hess.entries+(l+k)*dim+ll+kk);
      };
    };
    Realmatrix hsi=hsub.inverse();
    k=0;
    for(int l=0;l<i;l++){
      for(;*(params+k)==l+k;k++);
      int kk=0;
      for(int ll=0;ll<i;ll++){
	for(;*(params+kk)==ll+kk;kk++);
	*(hi.entries+(l+k)*dim+ll+kk)-=*(hsi.entries+l*i+ll);
      };
    };
  };
  long double *delta=T.sitefirstders(f,d,p);
  int s=d->length;
  ii--;
  long double *ans=new long double[s*s+s*ii];
  long double *row=new long double[dim];
  int l=T.numed+params::numpars+1;
  for(int i=0;i<s;i++){
    int jj=0;
    for(int j=0;j<dim;j++){
      //      cout<<*(delta+i*l+j+1)<<"  ";
      *(row+j)=0;
      for(int k=0;k<T.numed;k++){
	*(row+j)+=*(delta+i*l+k+1)*(*(hi.entries+j*dim+k));
      };
      for(int k=0;k<dim-T.numed;k++){
	*(row+j)+=*(delta+i*l+T.numed+*(variablepars+k)+1)*(*(hi.entries+j*dim+k));
      };
      if(j==T.numed){//scaling coefficient.
	for(int kk=0;kk<jj;kk++){
	  *(ans+s*s+i*ii+kk)-=*(row+j)*(*(x+*(params+kk)));	  
	};
      };
      if((j==*(params+jj)&&j<T.numed)||((j==*(params+jj+1))&&j>T.numed)){
	*(ans+s*s+i*ii+jj)=*(row+j);
	jj++;
      };
    };
    for(int j=0;j<s;j++){
      *(ans+i*s+j)=0;
      for(int k=0;k<T.numed;k++){
	*(ans+i*s+j)+=*(row+k)*(*(delta+j*l+k+1));
      };
      for(int k=0;k<dim-T.numed;k++){
	*(ans+i*s+j)+=*(row+k)*(*(delta+j*l+T.numed+*(variablepars+k)+1));	
      };
    };
  };
  delete[] row;
  delete[] delta;
  delete[] x;
  return ans;
};

long double *treelikelihood::branchinfluences(int *params){
  long double *x=new long double[dim];
  this->getx(x);
  long double *sbi=calchessandbi(T,f,d,p);
  Realmatrix hess(dim);
  this->truehessian(x,hess.entries);
  //  cout<<"\n\n"<<hess<<"\n\n";
  int l=T.numed+params::numpars+1;  
  long double *delta=sbi+l*(l+1)/2;
  l=T.numed+params::numpars;  
  //We need to convert this to use the true variables.

  Realmatrix Ai=params::A.inverse();
  Realmatrix AiT=Ai.transpose();

  //  Realmatrix hess=adjust_hessian(transhess,T.numed);

  long double *sum=new long double[params::numpars];
  for(int i=0;i<T.numed;i++){
    for(int k=0;k<params::numpars;k++){
      *(sum+k)=0;
    };
    for(int j=0;j<params::numpars;j++){
      for(int k=0;k<params::numpars;k++){
	*(sum+j)+=*(Ai.entries+k*params::numpars+j)*(*(delta+i*l+T.numed+k));
      };
    };
    for(int k=0;k<params::numpars;k++){
      *(delta+i*l+T.numed+k)=*(sum+k);
    };
  };
  Realmatrix *XX=new Realmatrix[params::numpars];
  for(int i=0;i<params::numpars;i++){
    *(XX+i)=RealmatrixT(NumCodons);
    for(int m=0;m<NumCodonsSq;m++){
      *((XX+i)->entries+m)=0;
    };
    for(int j=0;j<params::numpars;j++){
      for(int m=0;m<NumCodonsSq;m++){
	*((XX+i)->entries+m)+=*(Ai.entries+i*params::numpars+j)*(*((params::XX+j)->entries+m));
      };
    };
  };

  for(int i=0;i<T.numed;i++){
    for(int k=1;k<params::numpars;k++){
      *(delta+i*l+T.numed+k)+=*(delta+i*l+T.numed)*db0dbi(p,k,XX);   
    };
  };

  /*
  for(int i=0;i<T.numed;i++){
    cout<<i<<"  ";
    for(int k=0;k<T.numed;k++){
      cout<<*(delta+i*l+k)<<"  ";
    };
    for(int k=1;k<params::numpars;k++){
      cout<<*(delta+i*l+T.numed+k)<<"  ";
    };
    cout<<"\n";
    };*/
  delete[] XX;
  delete[] sum;
  //
  Realmatrix hi=hess.inverse();
  int ii=params::numpars;
  if(params!=NULL){
    ii=0;
    for(;*(params+ii)>=0;ii++);
    /*
    int i=dim-ii;
    Realmatrix hsub(i);
    int k=0;
    for(int l=0;l<i;l++){
      for(;*(params+k)==l+k;k++);
      int kk=0;
      for(int ll=0;ll<i;ll++){
	for(;*(params+kk)==ll+kk;kk++);
	*(hsub.entries+l*i+ll)=*(hess.entries+(l+k)*dim+ll+kk);
      };
    };
    Realmatrix hsi=hsub.inverse();
    k=0;
    for(int l=0;l<i;l++){
      for(;*(params+k)==l+k;k++);
      int kk=0;
      for(int ll=0;ll<i;ll++){
	for(;*(params+kk)==ll+kk;kk++);
	//	*(hi.entries+(l+k)*dim+ll+kk)-=*(hsi.entries+l*i+ll);
      };
    };
    */
  };
  //  cout<<"\n"<<hi<<"\n\n";
  //  cout<<ii<<"\n\n";
  long double *ans=new long double[T.numed*ii];
  long double *row=new long double[dim];
  l=T.numed+params::numpars;
  for(int i=0;i<T.numed;i++){
    int jj=0;
    for(int j=0;j<dim;j++){
      //      cout<<*(delta+i*l+j+1)<<"  ";
      *(row+j)=0;
      for(int k=0;k<T.numed;k++){
	if(*(x+i)>1e-5){
	  *(row+j)-=*(delta+i*l+k)*(*(hi.entries+j*dim+k));
	};
      };
      for(int k=0;k<dim-T.numed;k++){
	//	cout<<*(delta+i*l+T.numed+*(variablepars+k))<<*(hi.entries+j*dim+T.numed+k)<<"\n";
	*(row+j)-=*(delta+i*l+T.numed+*(variablepars+k))*(*(hi.entries+j*dim+T.numed+k));
      };
      if(j==T.numed){//scaling coefficient.
	for(int kk=0;kk<jj;kk++){
	  *(ans+i*ii+kk)-=*(row+j)*(*(x+*(params+kk)));	  
	};
      };
      if(j==*(params+jj)){
	*(ans+i*ii+jj)=*(row+j);
	jj++;
      };
    };
  };
  delete[] x;
  delete[] row;
  delete[] sbi;
  return ans;
};


/*
long double treelikelihood::directionalDeriv(const long double *x,const long double *v){
  //Assumes all variables that shouldn't vary have been set to 0 in
  //v. This is useful in conjunction with linesearch.
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.edges()){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.edges();i++){
	for(int k=(i==0)?0:*(variablepars+i-1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.edges()+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    vals=T.directionalDerivs(f,d,p,v);
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  return *(vals+1);
};

long double treelikelihood::directionalSecDer(const long double *x,const long double *v){
  if(vals==NULL||!this->testlast(x)){//Need to recalculate
    if(vals!=NULL){
      delete[] vals;
    };
    if(dim>T.edges()){
      long double *y=new long double[params::numpars];
      for(int i=0;i<dim-T.edges();i++){
	for(int k=(i==0)?0:*(variablepars+i-1);k<*(variablepars+i);k++){
	  *(y+k)=p.coeff[k];
	};
	*(y+*(variablepars+i))=*(x+T.edges()+i);
      };
      p.setCoeff(y);
      f=p.fmatrix();
      delete[] y;
    };
    T.setedgelengths(x);
    vals=T.directionalDerivs(f,d,p,v);
    for(int i=0;i<dim;i++){
      *(lastval+i)=*(x+i);
    };
  };
  return *(vals+2);
};
*/

/*
int treelikelihood::LineSearch(long double *x,long double lastval,const long double *dir,int numpos){
  int maxsteps=10;
  long double val=lastval;
  long double der;
  long double sec;
  long double maxstep=-1;
  long double minstep=1;
  long double step=1;
  long double totstep=1;
  for(int i=0;i<numpos;i++){
    if(NONZEROST(*(dir+i))&&(maxstep<0||((*(x+i)/(*(dir+i))<maxstep)&&(*(x+i)/(*(dir+i))>0)))){
      maxstep=*(x+i)/(*(dir+i));
    };
    if(NONZEROST(*(dir+i))&&(minstep>0||((*(x+i)/(*(dir+i))>minstep&&(*(x+i)/(*(dir+i))<0))))){
      minstep=*(x+i)/(*(dir+i));
    };
  };
  //First make sure chosen directions are all valid changes.
  int e=T.edges();
  long double *v=new long double[e+params::numpars];
  for(int i=0;i<e;i++){
    *(v+i)=*(dir+i);
  };
  int j=0;
  for(int i=0;i<(dim-e);i++){
    for(;j<*(variablepars+i);j++){
      *(v+e+j)=0;
    };
    *(v+e+j++)=*(dir+e+i);
  };
  for(;j<params::numpars;j++){
    *(v+e+j)=0;
  };
  int i=0;
  for(;i<maxsteps;i++){
    lastval=val;
    sec=this->directionalSecDer(x,v);
    der=this->directionalDeriv(x,v);
    val=this->evaluate(x);
    long double fact=0.5;
    while(val<lastval&&NONZEROST(fact)){//Use interval bisection
      for(int i=0;i<dim;i++){
	*(x+i)-=step*(*(dir+i))*fact;
      };
      totstep-=step*fact;
      fact*=0.5;
      val=this->quickEvaluate(x);
    };
    if(sec>1e-12){//Moving away from minimum
      step=der/sec;
    }else if(sec<-1e-12){//Approaching maximum
      step=-der/sec;
    }else{
      step=der;
    };
    //    if(ZEROST(maxstep)&&step>0) break;
    //    if(ZEROST(minstep)&&step<0) break;
    if(maxstep>0){
      if(step>maxstep){
	step=maxstep;
      };
      maxstep-=step;
    };
    if(minstep<0){
      if(step<minstep){
	step=minstep;
      };
      minstep-=step;
    };
    if(ZEROST(step)) break;
    totstep+=step;
    for(int i=0;i<dim;i++){
      *(x+i)+=step*(*(dir+i));
    };
  };
  if(i==maxsteps){
    char x[60];
    sprintf(x,"Linesearch aborted after %d steps \nMoved a total of %Lg steps in chosen direction.\nLast step size was %Lg.",maxsteps,totstep,step);
    info(x);
    //    cout<<"Linesearch aborted after "<<maxsteps<<" steps.\n";
    //    cout<<"Moved a total of "<<totstep<<" steps in chosen direction.\n";
    //    cout<<"Last step size was "<<step<<".\n";
  };
  if(vals!=NULL){
    delete[] vals;
  };
  vals=NULL;
  delete[] v;
  return NONZEROST(totstep);
};
*/

//class logbllike
  
long double logbllike::evaluate(long double x){
  long double ex[NumCodons];
  for(int i=0;i<NumCodons;i++){
    ex[i]=exp(*(ev+i)*x);
  };
  long double ans=0;
  for(int s=0;s<sites;s++){
    long double st=0;
    for(int i=0;i<NumCodons;i++){
      st+=*(coeffs+s*NumCodons+i)*ex[i];
    };
    ans+=log(st);
  };
  return ans;
};

long double logbllike::deriv(long double x){
  long double ex[NumCodons];
  for(int i=0;i<NumCodons;i++){
    ex[i]=exp(*(ev+i)*x);
  };
  long double ans=0;
  for(int s=0;s<sites;s++){
    long double st=0;
    long double dst=0;
    for(int i=0;i<NumCodons;i++){
      long double y=*(coeffs+s*NumCodons+i)*ex[i];
      st+=y;
      dst+=*(ev+i)*y;
    };
    ans+=dst/st;
  };
  return ans;
};

long double logbllike::secder(long double x){
  long double ex[NumCodons];
  for(int i=0;i<NumCodons;i++){
    ex[i]=exp(*(ev+i)*x);
  };
  long double ans=0;
  for(int s=0;s<sites;s++){
    long double st=0;
    long double dst=0;
    long double d2st=0;
    for(int i=0;i<NumCodons;i++){
      long double y=*(coeffs+s*NumCodons+i)*ex[i];
      st+=y;
      dst+=*(ev+i)*y;
      d2st+=*(ev+i)*(*(ev+i))*y;
    };
    ans+=d2st/st-dst*dst/(st*st);
  };
  return ans;
};

logbllike treelikelihood::optbranchlength(int branch,int site1,int site2){
  int e=T.edges();
  long double *ex=new long double[NumCodons*e];
  long double *le=T.getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp(*(le+i)*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  delete[] le;
  logbllike ans(site2-site1);
  ans.setev(f.D.entries);
  long double len;
  long double *ins=new long double[NumCodons];
  for(int s=site1;s<site2;s++){
    T.liklistdown(f,d,s,ex);
    T.liklistup(p,f,ex);
    const tree* cur=T.findedge(branch,len);
    for(int i=0;i<NumCodons;i++){
      *(ins+i)=*(cur->up2+i)*(*(cur->down3+i));
    };
    ans.fillsite(s,ins);
  };
  return ans;
};

//class logplike

long double logplike::evaluate(long double x){
  *(y+pno)=x;
  p->setCoeff(y);
  Factmatrix f=p->fmatrix();
  long double ex[NumCodons];
  for(int i=0;i<NumCodons;i++){
    ex[i]=exp(*(f.D.entries+i)+len);
  };
  long double *l=new long double[NumCodons];
  long double *u=new long double[NumCodons];
  long double ans=0;
  for(int s=0;s<sites;s++){
    long double st=0;
    f.gammainv.act(coeffs+s*2*NumCodons,l);
    f.gamma.TranspAct(coeffs+(s*2+1)*NumCodons,u);
    for(int i=0;i<NumCodons;i++){
      st+=*(l+i)*(*(u+i))*ex[i];
    };
    ans+=log(st);
  };
  return ans;
};

long double logplike::deriv(long double x){
  *(y+pno)=x;
  p->setCoeff(y);
  Factmatrix f=p->fmatrix();
  long double ex[NumCodons];
  for(int i=0;i<NumCodons;i++){
    ex[i]=exp(*(f.D.entries+i)+len);
  };
  long double *l=new long double[NumCodons];
  long double *u=new long double[NumCodons];
  long double ans=0;
  for(int s=0;s<sites;s++){
    long double st=0;
    f.gammainv.act(coeffs+s*2*NumCodons,l);
    f.gamma.TranspAct(coeffs+(s*2+1)*NumCodons,u);
    for(int i=0;i<NumCodons;i++){
      st+=*(l+i)*(*(u+i))*ex[i];
    };
    ans+=log(st);
  };
  return ans;
};


long double logplike::secder(long double x){
  *(y+pno)=x;
  p->setCoeff(y);
  Factmatrix f=p->fmatrix();
  long double ex[NumCodons];
  for(int i=0;i<NumCodons;i++){
    ex[i]=exp(*(f.D.entries+i)+len);
  };
  long double *l=new long double[NumCodons];
  long double *u=new long double[NumCodons];
  long double ans=0;
  for(int s=0;s<sites;s++){
    long double st=0;
    f.gammainv.act(coeffs+s*2*NumCodons,l);
    f.gamma.TranspAct(coeffs+(s*2+1)*NumCodons,u);
    for(int i=0;i<NumCodons;i++){
      st+=*(l+i)*(*(u+i))*ex[i];
    };
    ans+=log(st);
  };
  return ans;
};


logplike treelikelihood::optpar(int par,int branch,int site1,int site2){
  int e=T.edges();
  long double *ex=new long double[NumCodons*e];
  long double *le=T.getlengths();
  for(int i=0;i<e;i++){
    for(int j=0;j<NumCodons;j++){
      *(ex+i*NumCodons+j)=exp(*(le+i)*(*(f.D.entries+j)));//Should only calculate this matrix once.
    };
  };
  delete[] le;
  logplike ans(&p,par,site2-site1);
  const tree* cur=T.findedge(branch,ans.len);
  for(int s=site1;s<site2;s++){
    T.liklistdown(f,d,s,ex);
    T.liklistup(p,f,ex);
    ans.fillsite(s,cur->up,cur->down);
  };
  return ans;
};
