/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#undef DIGIT4
#define DIGIT4 0
#include "innerloop1.cpp"
#undef DIGIT4
#define DIGIT4 1
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#endif
#undef DIGIT4
#define DIGIT4 2
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 3
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 4
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 5
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 6
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 7
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 8
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 9
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop1.cpp" 
#undef DIGIT4
#define DIGIT4 0
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
