/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */
#undef DIGIT3
#define DIGIT3 0
#include "innerloop2.cpp"
#undef DIGIT3
#define DIGIT3 1
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#endif
#undef DIGIT3
#define DIGIT3 2
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 3
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 4
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 5
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 6
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 7
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 8
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 9
#if CURRENTNUMBER < NUMLOOPS
#include "innerloop2.cpp" 
#undef DIGIT3
#define DIGIT3 0
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif



