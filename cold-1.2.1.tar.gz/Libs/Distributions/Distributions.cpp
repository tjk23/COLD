/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Distributions.h"

#include<math.h>
#include "Macros.h"
#include "Optimisation.h"

using namespace std;


/*
  Discretised distributions. These usually take 1 parameter and
  convert it to a set of values.

 */

#define TRUNCATE 30


long double dabeta(long double a,long double b);

long double dbbeta(long double a,long double b);

long double d2bincbeta(long double x,long double a,long double b);

long double d2abincbeta(long double x,long double a,long double b);

long double d2aincbeta(long double x,long double a,long double b);

long double d2abeta(long double a,long double b);

long double d2abbeta(long double a,long double b);

long double d2bbeta(long double a,long double b);


long double halfbeta(long double a,long double b){
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double bpr=1;
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      ans+=pow(0.5,a+n+j)*bpr*apr;
      apr*=(n-i);
    };
    bpr*=bfp+j;
    bpr/=j+1;
  };
  return ans;
};

long double fullbeta(long double a,long double b){
  return halfbeta(a,b)+halfbeta(b,a);
};

long double incbeta(long double x,long double a,long double b){
  if(x>0.5001){
    return(fullbeta(a,b)-incbeta(1-x,b,a));
  };
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double bpr=1;
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      ans+=pow(x,a+i+j)*pow(1-x,n-i)*bpr*apr;
      apr*=(n-i);
    };
    bpr*=bfp+j;
    bpr/=j+1;
  };
  return ans;
};

long double incbetasolve(long double v,long double a,long double b){
  if(v>0.5001){
    return 1-incbetasolve(1-v,b,a);
  };
  long double tot=fullbeta(a,b);
  long double actval=v*tot;
  long double x;
  if(actval<pow(0.5,a)/a){
    x=pow(actval*a,1/a);
  }else{
    x=1-pow((tot-actval)*b,1/b);
  };
  if(x<=0){
    x=0.0001;
  }else if(x>=1){
    x=0.9999;
  };
  long double ib=incbeta(x,a,b);
  int j=0;
  for(;(ib-actval<-1e-10||ib-actval>1e-10)&&j<200;j++){
    long double oldx=x;
    x+=(actval-ib)/(pow(x,a-1)*pow(1-x,b-1));
    while(x<1e-10||x>(1-1e-10)){
      x=(x+oldx)/2;
    };
    ib=incbeta(x,a,b);
  };
  if((ib-actval<-1e-10||ib-actval>1e-10)){//No solution, use interval bisection
    long double bot=0;
    long double top=1;
    while(top-bot>1e-10){
      x=(top+bot)/2;
      ib=incbeta(x,a,b);
      if(ib>actval){
	top=x;
      }else{
	bot=x;
      };
    };
  };
  return x;
};

long double dbhalfbeta(long double a,long double b){
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double p=1;
  long double q=0;
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      ans+=pow(0.5,a+n+j)*p*q*apr;
      apr*=(n-i);
    };
    p*=(bfp+j)/(j+1);
    q+=1/(bfp+j);//bad order of summation?
  };
  return -ans;  
};

long double daincbeta(long double x,long double a,long double b);

long double dbincbeta(long double x,long double a,long double b){
  if(x>0.5001){
    return dbbeta(a,b)-daincbeta(1-x,b,a);
  };
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double p=1;
  long double q=0;
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      ans+=pow(x,a+j+i)*pow(1-x,n-i)*p*q*apr;
      apr*=(n-i);
    };
    p*=(bfp+j)/(j+1);
    q+=1/(bfp+j);//bad order of summation?
  };
  return -ans;  
};


long double dahalfbeta(long double a,long double b){
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double bpr=1;
  long double lt=log(0.5);
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    long double asum=lt;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      asum-=1/(a+i+j);
      ans+=pow(0.5,a+n+j)*bpr*apr*asum;
      apr*=(n-i);
    };
    bpr*=bfp+j;
    bpr/=j+1;
  };
  return ans;  
};

long double daincbeta(long double x,long double a,long double b){
  if(x>0.5001){
    return dabeta(a,b)-dbincbeta(1-x,b,a);
  };
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double bpr=1;
  long double lt=log(x);
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    long double asum=lt;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      asum-=1/(a+i+j);
      ans+=pow(x,a+j+i)*pow(1-x,n-i)*bpr*asum*apr;
      apr*=(n-i);
    };
    bpr*=bfp+j;
    bpr/=j+1;
  };
  return ans;  
};


long double d2aincbeta(long double x,long double a,long double b){
  if(x>0.5001){
    return d2abeta(a,b)-d2bincbeta(1-x,b,a);
  };
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double bpr=1;
  long double lt=log(x);
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    long double s=lt;
    long double q=0;
    for(int i=0;i<=n;i++){
      s-=1/(a+i+j);
      q+=1/((a+i+j)*(a+i+j));
      apr/=a+i+j;
      ans+=pow(x,a+j+i)*pow(1-x,n-i)*bpr*apr*(s*s+q);//*lt-lt*2*s+(q+s*s));
      apr*=(n-i);
    };
    bpr*=bfp+j;
    bpr/=j+1;
  };
  return ans;  
};


long double d2abincbeta(long double x,long double a,long double b){
  if(x>0.5001){
    return d2abbeta(a,b)-d2abincbeta(1-x,b,a);
  };
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double p=1;
  long double q=0;
  long double lt=log(x);
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    long double asum=lt;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      asum-=1/(a+i+j);
      ans+=pow(x,a+j+i)*pow(1-x,n-i)*p*q*apr*asum;
      apr*=(n-i);
    };
    p*=(bfp+j)/(j+1);
    q+=1/(bfp+j);//bad order of summation?
  };
  return -ans;  
};

long double d2bincbeta(long double x,long double a,long double b){
  if(x>0.5001){
    return d2bbeta(a,b)-d2aincbeta(1-x,b,a);
  };
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double p=bfp;
  long double q=1/bfp;
  long double bpr=1;
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    for(int i=0;i<=n;i++){
      apr/=a+i+j+2;
      ans+=pow(x,a+j+i+2)*pow(1-x,n-i)*bpr*apr;
      apr*=(n-i);
    };
    p*=(bfp+j+1)/(j+3);
    bpr*=(bfp+j+2)/(j+3);
    q+=1/(bfp+j+1);//bad order of summation?
    bpr+=p*q;
  };
  return ans;  
};

long double d2ahalfbeta(long double a,long double b){
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double bpr=1;
  long double lt=log(0.5);
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    long double s=lt;
    long double q=0;
    for(int i=0;i<=n;i++){
      s-=1/(a+i+j);
      q+=1/((a+i+j)*(a+i+j));
      apr/=a+i+j;
      ans+=pow(0.5,a+j+n)*bpr*apr*(s*s+q);//*lt-lt*2*s+(q+s*s));
      apr*=(n-i);
    };
    bpr*=bfp+j;
    bpr/=j+1;
  };
  return ans;  
};


long double d2abhalfbeta(long double a,long double b){
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double p=1;
  long double q=0;
  long double lt=log(0.5);
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    long double asum=lt;
    for(int i=0;i<=n;i++){
      apr/=a+i+j;
      asum-=1/(a+i+j);
      ans+=pow(0.5,a+j+n)*p*q*apr*asum;
      apr*=(n-i);
    };
    p*=(bfp+j)/(j+1);
    q+=1/(bfp+j);//bad order of summation?
  };
  return -ans;  
};

long double d2bhalfbeta(long double a,long double b){
  int n=b;
  long double ans=0;
  long double bfp=n+1-b;
  long double p=bfp;
  long double q=1/bfp;
  long double bpr=1;
  for(int j=0;j<TRUNCATE;j++){
    long double apr=1;
    for(int i=0;i<=n;i++){
      apr/=a+i+j+2;
      ans+=pow(0.5,a+j+n+2)*bpr*apr;
      apr*=(n-i);
    };
    p*=(bfp+j+1)/(j+3);
    bpr*=(bfp+j+2)/(j+3);
    q+=1/(bfp+j+1);//bad order of summation?
    bpr+=p*q;
  };
  return ans;  
};

long double dabeta(long double a,long double b){
  return dahalfbeta(a,b)+dbhalfbeta(b,a);
};

long double dbbeta(long double a,long double b){
  return dbhalfbeta(a,b)+dahalfbeta(b,a);
};

long double d2abeta(long double a,long double b){
  return d2ahalfbeta(a,b)+d2bhalfbeta(b,a);
};

long double d2abbeta(long double a,long double b){
  return d2abhalfbeta(a,b)+d2abhalfbeta(b,a);
};

long double d2bbeta(long double a,long double b){
  return d2ahalfbeta(b,a)+d2bhalfbeta(a,b);
};

class Beta: public Distribution{
public:
  Beta(int i){num=i;pars=2;};
  long double *vals(const long double *p);
  long double *derivvals(const long double *p);
  long double *secdervals(const long double *p);
  void seed(const long double *seeds,long double *to);
  int numconstraints();
  void putconstraint(constraint *c,int firstpar);
};

int Beta::numconstraints(){
  return 2;
};

void Beta::putconstraint(constraint *c,int firstpar){
  long double one=-1;
  c->set(1,0,&firstpar,&one);
  firstpar++;
  (c+1)->set(1,0,&firstpar,&one);
};


void Beta::seed(const long double *seeds,long double *to){
  //Need to improve this.
  long double s=0;
  long double ss=0;
  for(int i=0;i<num;i++){
    long double e=exp(*(seeds+i));
    s+=e;
    ss+=e*e;
  };
  s/=num;
  ss/=num;
  ss-=s*s;
  if(ZEROST(ss)){
    *to=0.5;
    *(to+1)=0.5*(1-s)/s;
  }else{
    *to=s*(s*(1-s)/ss-1);
    *(to+1)=(1-s)*(s*(1-s)/ss-1); 
  };
};

long double *Beta::vals(const long double *p){
  long double *ans=new long double[num];
  long double a=*p;
  long double b=*(p+1);
  
  int i=0;
  for(long double target=1/((long double)(2*num));target<1;target+=1/((long double)(num))){
    long double bt=incbetasolve(target,a,b);
    *(ans+i++)=log(bt);
  };
  return ans;
};

long double *Beta::derivvals(const long double *p){
  long double a=*p;
  long double b=*(p+1);
  long double *ans=new long double[2*num];
  long double *v=this->vals(p);
  long double target=1/((long double)(2*num));
  for(int i=0;i<num;i++){
    long double x=exp(*(v+i));
    if(x<1){//Avoid problems where x=1.
      *(ans+2*i)=-(daincbeta(x,a,b)-target*dabeta(a,b))/(pow(x,a-1)*pow(1-x,b-1)*x);
      *(ans+2*i+1)=-(dbincbeta(x,a,b)-target*dbbeta(a,b))/(pow(x,a-1)*pow(1-x,b-1)*x);
    };
    target+=1/((long double)(num));
  };
  delete[] v;
  return ans;
};

long double *Beta::secdervals(const long double *p){
  long double a=*p;
  long double b=*(p+1);
  long double *ans=new long double[4*num];
  long double *v=this->vals(p);
  long double *w=this->derivvals(p);
  long double target=1/((long double)(2*num));
  for(int i=0;i<num;i++){
    long double x=exp(*(v+i));
    *(ans+4*i)=-((d2aincbeta(x,a,b)-target*d2abeta(a,b)-(daincbeta(x,a,b)-target*(dabeta(a,b)))*log(x))/(pow(x,a-1)*pow(1-x,b-1)*x))-(*(w+2*i)*(*(w+2*i)*(a-(b-1)*x/(1-x))+log(x)));
    long double dab=-(d2abincbeta(x,a,b)-target*d2abbeta(a,b)-(daincbeta(x,a,b)-target*(dabeta(a,b)))*log(1-x))/(pow(x,a-1)*pow(1-x,b-1)*x)-(*(w+2*i+1)*(*(w+2*i)*(a-(b-1)*x/(1-x))+log(x)));
    *(ans+4*i+1)=dab;
    *(ans+4*i+2)=dab;
    *(ans+4*i+3)=-(d2bincbeta(x,a,b)-target*d2bbeta(a,b)-(dbincbeta(x,a,b)-target*(dbbeta(a,b)))*log(1-x))/(pow(x,a-1)*pow(1-x,b-1)*x)-(*(w+2*i+1)*(*(w+2*i+1)*(a-(b-1)*x/(1-x))+log(1-x)));
    target+=1/((long double)(num));
  };
  delete[] v;
  delete[] w;
  return ans;
};


//Beta beta(3);

Distribution *getdistribution(const char *dname,int num){
  return new Beta(num);
};

void deletedistribution(Distribution *d){//in case change method of allocation.
  delete d;
};
