/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Classes and Routines for matrix manipulation */

#include "Matrix.h"
#include <stdlib.h>
#include <math.h>
#include <iostream>
using namespace std;

#include "Macros.h" 
#include "Miscellaneous.h"
#ifdef COMPLEX_NUMBERS
#include "NewAlgebra.cpp"
#endif

//static char tempfilenum[20]="0";

/*
void incfilenum(){
  int i=strlen(tempfilenum)-1;
  while(tempfilenum[i]=='9'&&i>=0){
    tempfilenum[i--]='0';
  };
  if(i>=0){
    tempfilenum[i]++;
  }else{//need to create a new digit.
    int i=strlen(tempfilenum);
    tempfilenum[0]='1';
    tempfilenum[i+1]='\0';
    for(;i>0;i--){
      tempfilenum[i]='0';    
    };
  };
};

FILE *mktempfile(char *name){
  strcpy(name,"tempfilenumber");
  strcat(name,tempfilenum);
  incfilenum();
  FILE *ans=fopen(name,"w+b");
  return ans;
};
*/

void displayMat(long double *ent, int sz=NumCodons);

Realmatrix::Realmatrix(RealmatrixT R){
  sz=R.sz;
  entries=R.ent;
};

Realmatrix testtrisym(Realmatrix Q,long double *v);

Realmatrix::Realmatrix(long double *a){
  sz=NumCodons;
  entries=new long double[sz*sz];
  for(long int i=0;i<sz*sz;i++){
    *(entries+i)=*(a+i);
  };
};

Realmatrix::Realmatrix(int s, const long double *a){
  sz=s;
  entries=new long double[sz*sz];
  for(long int i=0;i<sz*sz;i++){
    *(entries+i)=*(a+i);
  };
};

Realmatrix::Realmatrix(){
  sz=0;
  entries=NULL;
};
  
Realmatrix::Realmatrix(int s){
  sz=s;
  entries=new long double[sz*sz];
  for(int i=0;i<sz*sz;i++){
        *(entries+i)=0;//Maybe a bad idea to initialise to 0 - could be a waste of time.
    //Bad idea because it doesn't indicate failure to initialise entries.
  };
};

Realmatrix::Realmatrix(const Realmatrix &R){
  sz=R.sz;
  if(R.sz<=0){
    entries=NULL;
  }else{
    entries=new long double[sz*sz];
    for(int i=0;i<sz*sz;i++){
      *(entries+i)=*(R.entries+i);
    };
  };
};

void Realmatrix::operator =(const Realmatrix &R){
  sz=R.sz;
  if(entries!=NULL){//anything currently stored at entries would be deleted.
    delete[] entries;
  };
  entries=new long double[sz*sz];
  for(int i=0;i<sz*sz;i++){
    *(entries+i)=*(R.entries+i);
  };
};

void Realmatrix::operator =(RealmatrixT R){
  sz=R.sz;
  if(entries!=NULL){//anything currently stored at entries would be deleted.
    delete[] entries;
  };
  entries=R.ent;
};

void Realmatrix::copy(long double *T) const {
  for(int i=0;i<sz*sz;i++){
    *(T+i)=*(entries+i);
  };
};

Realmatrix::Realmatrix(char *s){
  char **a=&s;
  sz=NumCodons;
  entries=new long double[NumCodonsSq];
  for(int i=0;i<NumCodonsSq;i++){
    *(entries+i)=strtod(s,a);
  };
};

/*
void Realmatrix::save(ofstream& s) const {
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      s<<*(entries+i*sz+j)<<' ';
    };
    s<<'\n';
  };
};
*/

void Realmatrix::subtractid(long double l){
  for(int i=0;i<sz;i++){
    *(entries+i*(sz+1))-=l;
  };
};

void Realmatrix::divide(long double l){
  for(int i=0;i<sz*sz;i++){
    *(entries+i)/=l;
  };
};

void Realmatrix::minus(Realmatrix T){
  if(T.sz!=sz){
    //    cout<<"Attempt to subtract matrices of unequal size:\n"<<T<<"from\n"<<*this<<"\n";
    exit(1);
  };
  for(int i=0;i<sz*sz;i++){
    *(entries+i)-=*(T.entries+i);
  };
};

RealmatrixT Realmatrix::inverse() const {
  long double *Rent=new long double[sz*sz];
  long double *Qent=new long double[sz*sz];

  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(Rent+i*sz+j)=*(entries+i*sz+j);
      *(Qent+i*sz+j)=(i==j)?1:0;
    };
  };
  long double pivot;
  //  long double factor;
  for(int j=0;j<sz;j++){
    int i=j;
    long double big=(*(Rent+j*sz+i)>0)?*(Rent+j*sz+i):-*(Rent+j*sz+i);
    for(int k=j+1;k<sz;k++){
      long double b2=(*(Rent+k*sz+j)>0)?*(Rent+k*sz+j):-*(Rent+k*sz+j);
      if(b2>big){
	i=k;
	big=b2;
      };
    };//find pivot. i is the row with the largest element in column j.
    if(ZERO(big)){
      cout<<"Matrix is singular\n";
      this->display();
      cout<<'\n';
      return RealmatrixT(sz,Rent);
    };
    int p=i;
    pivot=*(Rent+i*sz+j);
    if(p!=j){//Want to swap rows
      long double tmp;
      for(int k=j;k<sz;k++){
	tmp=*(Rent+j*sz+k);
	*(Rent+j*sz+k)=*(Rent+p*sz+k);
	*(Rent+p*sz+k)=tmp;
      };
      for(int k=0;k<sz;k++){
	tmp=*(Qent+j*sz+k);
	*(Qent+j*sz+k)=*(Qent+p*sz+k);
	*(Qent+p*sz+k)=tmp;
      };
    };
    for(i=0;i<sz;i++){
      if(i!=j){//only need to do this for non-pivot positions
	long double factor=*(Rent+i*sz+j)/pivot;
	if(factor!=0){//need to cancel out
	  *(Rent+i*sz+j)=0;
	  for(int k=j+1;k<sz;k++){
	    *(Rent+i*sz+k)-=*(Rent+j*sz+k)*factor;
	  };
	  for(int k=0;k<sz;k++){
	    *(Qent+i*sz+k)-=*(Qent+j*sz+k)*factor;
	  };
	};
      };
    };
  };//Need to rescale columns of Q
  for(int i=0;i<sz;i++){
    long double factor=*(Rent+i*(sz+1));
    if(ZERO(factor)){
      cout<<"Matrix is singular!\n";
      this->display();
      cout<<"\n\n";
      displayMat(Rent);
      cout<<"\n\n";
      displayMat(Qent);
      return RealmatrixT(sz,Qent);
    };
    for(int j=0;j<sz;j++){
      *(Qent+i*sz+j)/=factor;
    };
  };
  delete[] Rent;
  return RealmatrixT(sz,Qent);
};

void Realmatrix::mult(long double *ent){
  long double *temp2=new long double[sz];
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(temp2+j)=0;
      for(int k=0;k<sz;k++){
	*(temp2+j)+=*(entries+i*sz+k)*(*(ent+k*sz+j));
      };
    };
    for(int j=0;j<sz;j++){
      *(entries+i*sz+j)=*(temp2+j);
    };
  };
  delete[] temp2;
};

void Realmatrix::mult(const Realmatrix &X){
  if(sz!=X.sz){
    cout<<"Cannot multiply matrices of different sizes.\n";
  }else{
    long double *temp=new long double[sz];
    for(int i=0;i<sz;i++){
      for(int j=0;j<sz;j++){
	*(temp+j)=0;
      };
      for(int j=0;j<sz;j++){
	for(int k=0;k<sz;k++){
	  *(temp+k)+=*(entries+i*sz+j)*(*(X.entries+j*sz+k));
	};
      };
      for(int j=0;j<sz;j++){
	*(entries+i*sz+j)=*(temp+j);
      }
    };
    delete[] temp;
  };
};

void Realmatrix::premult(long double *ent1){
  long double *temp=new long double[sz];
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(temp+j)=0;
      for(int k=0;k<sz;k++){
	*(temp+j)+=*(ent1+j*sz+k)*(*(entries+k*sz+i));
      };
    };
    for(int j=0;j<sz;j++){
      *(entries+j*sz+i)=*(temp+j);
    };
  };
  delete[] temp;
};

void Realmatrix::TranspAct(const long double *vect,long double *ans) const {
  //result of the transpose matrix acting on vect.
  for(int i=0;i<sz;i++){
    *(ans+i)=0;
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(ans+j)+=*(vect+i)*(*(entries+i*sz+j));
    };
  };
};

void Realmatrix::MultiAct(int n,const long double *const *vect,long double *ans) const {
  for(int i=0;i<sz*n;i++){
    *(ans+i)=0;
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      for(int k=0;k<n;k++){
	*(ans+i+sz*k)+=*(*(vect+k)+j)*(*(entries+i*sz+j));
      };
    };
  };
};

void Realmatrix::MultiActLin(int n,const long double *vect,long double *ans) const{
  for(int i=0;i<sz*n;i++){
    *(ans+i)=0;
  };
  for(int k=0;k<n;k++){
    for(int i=0;i<sz;i++){
      for(int j=0;j<sz;j++){
	*(ans+i+sz*k)+=*(vect+k*sz+j)*(*(entries+i*sz+j));
      };
    };
  };
};

void Realmatrix::MultiTranspAct(int n,const long double *const *vect,long double *ans) const {
  for(int i=0;i<n*sz;i++){
    *(ans+i)=0;
  };
  //result of the transpose matrix acting on vect.
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      for(int k=0;k<n;k++){
	*(ans+k*sz+j)+=*(*(vect+k)+i)*(*(entries+i*sz+j));
      };
    };
  };
};

void Realmatrix::MultiTranspActProd(int n,const long double *const*vect,const long double *prod, long double *ans) const {
  for(int i=0;i<n*sz;i++){
    *(ans+i)=0;
  };
  //result of the transpose matrix acting on vect.
  for(int i=0;i<sz;i++){
    for(int k=0;k<n;k++){
      for(int j=0;j<sz;j++){
	*(ans+k*sz+j)+=*(*(vect+k)+i)*(*(prod+i))*(*(entries+i*sz+j));
      };
    };
  };
};

long double Realmatrix::actNorm(long double *vect,long double *ans) const {
  //ans should not be the same as vect, even if we wish to overwrite the original vector.
  long double norm=0;
  for(int i=0;i<sz;i++){
    long double acc=0;
    for(int j=0;j<sz;j++){
      acc+=*(vect+j)*(*(entries+i*sz+j));
    };
    *(ans+i)=acc;
    norm+=acc*acc;
  };
  return sqrt(norm);
};

RealmatrixT Realmatrix::transpose() const {
  Realmatrix out;
  out.sz=sz;
  out.entries=new long double[sz*sz];
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(out.entries+i*sz+j)=*(entries+j*sz+i);
    };
  };
  return out;
};

RealmatrixT Realmatrix::transinverse() const {
  //should make this more efficient in future.
  RealmatrixT T=this->transpose();
  return Realmatrix(T).inverse();
};

ostream &operator <<(ostream &o,const Diagmatrix &D){
  for(int i=0;i<D.sz;i++){
    for(int j=0;j<D.sz;j++){
      o<<((i==j)?*(D.entries+i):0)<<' ';
    };
    o<<"\n";
  };
  o<<"\n";
  return o;
};

Factmatrix::Factmatrix(const Factmatrix& f){
  sz=f.sz;
  gamma=f.gamma;
  gammainv=f.gammainv;
  D=f.D;
  A=f.A;
};

void Factmatrix::operator=(const Factmatrix& f){
  sz=f.sz;
  gamma=f.gamma;
  gammainv=f.gammainv;
  D=f.D;
  if(A!=NULL){
    delete[] A;
  };
  A=f.A;
};

/*
void Factmatrix::save(ofstream& s) const {
  gamma.save(s);
  for(int i=0;i<sz;i++){
    s<<*(D.entries+i)<<' ';
  };
};
*/

void Realmatrix::applyHouseholder(long double *v){
  //first apply on the right. In the meantime, calculate the
  //coefficients for the downwards application.
  long double *col=new long double[sz];
  for(int i=0;i<sz;i++){
    *(col+i)=0;
  };
  for(int i=0;i<sz;i++){
    long double dot=0;
    for(int j=0;j<sz;j++){
      dot+=*(entries+i*sz+j)*(*(v+j));
    };
    for(int j=0;j<sz;j++){
      *(entries+i*sz+j)-=2*dot*(*(v+j));
      *(col+j)+=*(entries+i*sz+j)*(*(v+i));
    };
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(entries+i*sz+j)-=2*(*(col+j))*(*(v+i));
    };
  };
  delete[] col;
};

void Realmatrix::applyHouseholder(long double *v,int n){
  //first apply on the right. In the meantime, calculate the
  //coefficients for the downwards application. We assume all but n
  //elements are zero.
  long double *col=new long double[sz];
  for(int i=0;i<sz;i++){
    *(col+i)=0;
  };
  for(int i=0;i<sz;i++){//For every row of the matrix    
    long double dot=0;
    for(int j=0;j<n;j++){
      dot+=*(entries+i*sz+sz-n+j)*(*(v+j));
    };
    for(int j=0;j<sz;j++){
      if(j>=sz-n){
	*(entries+i*sz+j)-=2*dot*(*(v+j+n-sz));
      };
      if(i>=sz-n){
	*(col+j)+=*(entries+i*sz+j)*(*(v+i+n-sz));
      };
    };
  };
  for(int i=0;i<n;i++){
    for(int j=0;j<sz;j++){
      *(entries+(i+sz-n)*sz+j)-=2*(*(col+j))*(*(v+i));
    };
  };
  delete[] col;
};

RealmatrixT Realmatrix::applyHouseholderto(long double *v) const {
  //Like applyHouseholder, but makes a new matrix to store the result.
  long double *col=new long double[sz];
  Realmatrix answer(sz);
  for(int i=0;i<sz;i++){
    *(col+i)=0;
  };
  for(int i=0;i<sz;i++){
    long double dot=0;
    for(int j=0;j<sz;j++){
      dot+=*(entries+i*sz+j)*(*(v+j));
    };
    for(int j=0;j<sz;j++){
      *(answer.entries+i*sz+j)=*(entries+i*sz+j)-2*dot*(*(v+j));
      *(col+j)+=*(answer.entries+i*sz+j)*(*(v+i));
    };
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(answer.entries+i*sz+j)-=2*(*(col+j))*(*(v+i));
    };
  };
  delete[] col;
  return answer;
};

Realmatrix testtrisym(Realmatrix Q,long double *v1,long double *v2);

RealmatrixT Realmatrix::tridiagonalisesymmetric(long double *output) const {
  //Uses Householder transformations to reduce a symmetric matrix to
  //tridiagonal form. It returns the tridiagonal form in the array
  //output, which should have 2sz elements (one of which is only used
  //for convenience of coding). It returns the Householder
  //transformation matrix in its return value.

  //Need to improve this to deal with case where matrix is already diagonal.
  ldlist trans;
  long double mod=0;
  long double *v=new long double[sz];//first Householder vector.
  for(int i=1;i<sz;i++){
    mod+=*(entries+i)*(*(entries+i));
  };
  mod=sqrt(mod);
  *v=0;
  long double m=(*(entries+1)>0)?mod:-mod;
  *(v+1)=*(entries+1)+m;
  mod=*(v+1)*(*(v+1));
  for(int i=2;i<sz;i++){
    *(v+i)=*(entries+i);
    mod+=*(v+i)*(*(v+i));
  };
  mod=sqrt(mod);
  if(mod==0){
    mod=1;
  };
  for(int i=1;i<sz;i++){
    *(v+i)/=mod;
  };
  Realmatrix temp=this->applyHouseholderto(v);
  trans.insert(sz-1,v+1);
  for(int i=1;i<sz-2;i++){
    mod=0;
    for(int j=0;j<sz-i-1;j++){
      mod+=*(temp.entries+sz*i+i+1+j)*(*(temp.entries+sz*i+i+1+j));
    };
    mod=sqrt(mod);
    *v=(*(temp.entries+sz*i+i+1)>0)?(*(temp.entries+sz*i+i+1)+mod):(*(temp.entries+sz*i+i+1)-mod);
    mod=*v*(*v);
    for(int j=1;j<sz-i-1;j++){
      *(v+j)=*(temp.entries+sz*i+i+1+j);
      mod+=*(v+j)*(*(v+j));
    };
    mod=sqrt(mod);
    if(mod==0){
      mod=1;
    };
    for(int j=0;j<sz-i-1;j++){
      *(v+j)/=mod;
    };
    temp.applyHouseholder(v,sz-i-1);
    trans.insert(sz-i-1,v);
  };
  /* Now temp should be a tridiagonal symmetric matrix, and trans
     should contain a list of the necessary Householder matrices.
   */
  *output=*temp.entries;
  for(int i=1;i<sz;i++){
    *(output+sz+i-1)=*(temp.entries+i*sz+i-1);
    *(output+i)=*(temp.entries+i*(sz+1));
  };
  /* Now we need to form the Householder matrix.
   */
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(temp.entries+i*sz+j)=(i==j)?1:0;
    };
  };
  delete[] v;
  int j=0;
  for(int i=2;i<sz;i++){
    v=trans.getnum(j);
    j+=i;
    for(int j=sz-i;j<sz;j++){
      long double w=0;
      for(int k=0;k<i;k++){
	w+=*(temp.entries+(sz+k-i)*sz+j)*(*(v+k));
      };
      for(int k=0;k<i;k++){
	*(temp.entries+(sz+k-i)*sz+j)-=2*w*(*(v+k));
      };
    };
  };
  trans.remove();
  return temp;
};

void QRtrisym(long double *in,long double *in2, long double *HT, long double *R,int n){
  /*Uses Householder reflections to turn the nxn tridiagonal symmetric
    matrix to upper triangular form. HT stores a sequence of
    Householder vectors, rather than the actual matrix.*/
  //Do the first step manually.
  long double mod=sqrt(*in*(*in)+*(in2)*(*(in2)));
  long double m=(*in>0)?mod:-mod;
  long double v1=*in+m;
  *HT=*(in2)/v1;//this is enough information to recover the vector.
  long double mod2=sqrt(v1*v1+*(in2)*(*(in2)));
  v1/=mod2;
  long double v2=*(in2)/mod2;
  long double d2=v1*(*(in2))+v2*(*(in+1));
  long double d3;
  *R=-m;
  *(R+1)=*(in2)-2*d2*v1;
  if(n>2){
    d3=v2*(*(in2+1));
    *(R+2)=-2*d3*v1;
    *(R+3)=*(in+1)-2*d2*v2;
    *(R+4)=*(in2+1)-2*d3*v2;
  }else{
    *(R+2)=*(in+1)-2*d2*v2;
    return;
  };
  for(int i=1;i<n-2;i++){
    mod=sqrt(*(R+3*i)*(*(R+3*i))+*(in2+i)*(*(in2+i)));
    m=(*(R+3*i)>0)?mod:-mod;
    v1=*(R+3*i)+m;
    *(HT+i)=*(in2+i)/v1;//this is enough information to recover the vector.
    mod2=sqrt(v1*v1+*(in2+i)*(*(in2+i)));
    v1/=mod2;
    v2=*(in2+i)/mod2;
    d2=v1*(*(R+3*i+1))+v2*(*(in+i+1));
    d3=v2*(*(in2+i+1));
    *(R+3*i)=-m;
    *(R+3*i+1)-=2*d2*v1;
    *(R+3*i+2)=-2*d3*v1;
    *(R+3*i+3)=*(in+i+1)-2*d2*v2;
    *(R+3*i+4)=*(in2+i+1)-2*d3*v2;
  };
  mod=sqrt(*(R+3*n-6)*(*(R+3*n-6))+*(in2+n-2)*(*(in2+n-2)));
  m=(*(R+3*n-6)>0)?mod:-mod;
  v1=*(R+3*n-6)+m;
  *(HT+n-2)=*(in2+n-2)/v1;//this is enough information to recover the vector.
  mod2=sqrt(v1*v1+*(in2+n-2)*(*(in2+n-2)));
  v1/=mod2;
  v2=*(in2+n-2)/mod2;
  d2=v1*(*(R+3*n-5))+v2*(*(in+n-1));
  *(R+3*n-6)=-m;
  *(R+3*n-5)-=2*d2*v1;
  *(R+3*n-4)=*(in+n-1)-2*d2*v2;
};

void diagtrisym(long double *in,long double *in2,int n,long double *ans, int step){
  /*Diagonalise a tridiagonal symmetric matrix. The matrix ans
    receives the right-hand multiplier, so would be gammainv in a
    Factmatrix. It is more efficient to call by reference instead of
    returning a matrix, which means copying the data.
*/
  if(n==1){
    *ans=1;
    return;
  };
  long double shift=0; //shift the values by a multiple of the identity.
  long double *HT=new long double[n-1];
  long double *R=new long double[3*n-3];
  ldlist House;
  long double err=1;
  int l=0;
  int index;
  for(;err>1e-24;l++){	     //Should change this to be relative to
			     //the size of the matrix elements    
    long double s=(*(in+n-2)+*(in+n-1))/2;
    long double s2=sqrt((*(in+n-2)-*(in+n-1))*(*(in+n-2)-*(in+n-1))+4*(*(in2+n-2))*(*(in2+n-2)))/2;
    s+=s2;
    shift+=s;
    //s is an eigenvalue of the bottom-right 2x2 matrix.
    for(int i=0;i<n;i++){
      *(in+i)-=s;
    };
    index=0;
    err=1;
    QRtrisym(in,in2,HT,R,n);
    //now we multiply in the other order.
    House.insert(n-1,HT);
    for(int i=0;i<n-2;i++){//apply the Householder transformations
      //on the right.
      long double mod=sqrt(1+*(HT+i)*(*(HT+i)));
      long double v1=1/mod;
      long double v2=*(HT+i)/mod;
      long double m11=(1-2*v1*v1);
      long double m12=-2*v1*v2;
      long double m22=(1-2*v2*v2);
      *(in+i)=*(R+3*i)*m11+*(R+3*i+1)*m12;
      *(in2+i)=*(R+3*i+3)*m12;
      long double sq=*(in2+i)*(*(in2+i));
      if(sq<err){
	err=sq;
	index=i;
      };
      *(R+3*i+3)*=m22;
    };
    //Now for the last transformations.
    long double mod=sqrt(1+*(HT+n-2)*(*(HT+n-2)));
    long double v1=1/mod;
    long double v2=*(HT+n-2)/mod;
    long double m11=(1-2*v1*v1);
    long double m12=-2*v1*v2;
    long double m22=(1-2*v2*v2);
    *(in+n-2)=*(R+3*n-6)*m11+*(R+3*n-5)*m12;
    *(in2+n-2)=*(R+3*n-4)*m12;
    *(in+n-1)=*(R+3*n-4)*m22;
    long double sq=*(in2+n-2)*(*(in2+n-2));
    if(sq<err){
      err=sq;
      index=n-2;
    };
  };
  /*Now we recursively apply the algorithm to the part before and
    after the break. */
  diagtrisym(in,in2,index+1,ans,step);
  diagtrisym(in+index+1,in2+index+1,n-index-1,ans+(index+1)*(step+1),step);
  for(int i=0;i<n;i++){
    *(in+i)+=shift;//undo the shifts.
  };
  /*Now we need to extract the matrix from the sequence of vectors. */
  long double *row3=new long double[n*n];
  for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
      *(row3+i*n+j)=(i==j)?1:0;
    };
  };
  //Now row3 is the identity matrix.
  delete[] HT;
  for(int m=l-1;m>=0;m--){//For each sweep of Householder transformations
    HT=House.getnum((l-1-m)*(n-1));
    for(int i=n-2;i>=0;i--){
      long double mod=sqrt(1+*(HT+i)*(*(HT+i)));
      long double v1=1/mod;
      long double v2=*(HT+i)/mod;
      for(int j=0;j<n;j++){
	long double f=v1*(*(row3+i*n+j))+v2*(*(row3+(i+1)*n+j));//f=v^TA
	*(row3+i*n+j)-=2*v1*f;
	*(row3+(i+1)*n+j)-=2*v2*f;
      };
    };
  };
  long double *col=new long double[n];
  int j;
  for(j=0;j<index+1;j++){
    for(int i=0;i<n;i++){
      *(col+i)=0;
      for(int k=0;k<index+1;k++){
	*(col+i)+=*(row3+i*n+k)*(*(ans+k*step+j));
      };
    };
    for(int i=0;i<n;i++){
      *(ans+i*step+j)=*(col+i);
    };
  };
  for(;j<n;j++){
    for(int i=0;i<n;i++){
      *(col+i)=0;
      for(int k=index+1;k<n;k++){
	*(col+i)+=*(row3+i*n+k)*(*(ans+k*step+j));
      };
    };
    for(int i=0;i<n;i++){
      *(ans+i*step+j)=*(col+i);
    };
  };  
  House.remove();
  /*Now we need to compose ans and the two factorisations. */
  delete[] col;
  delete[] row3;
  delete[] R;
};


RealmatrixT Realmatrix::diagonalisesymmetric(long double *ev) const {
  long double *v=new long double[2*sz];
  Realmatrix S=this->tridiagonalisesymmetric(v);
  Realmatrix T(sz);
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(T.entries+i*sz+j)=(i==j)?1:0;
    };
  };
  diagtrisym(v,v+sz,sz,T.entries,sz);
  S.mult(T);
  for(int i=0;i<sz;i++){
    *(ev+i)=*(v+i);
  };
  delete[] v;
  return S;
};

void Realmatrix::swaprows(int i,int j){
  if((i<0) || (j<0) || (i>=sz) || (j>=sz) || (i==j)){
    return;
  };
  long double tmp;
  for(int k=0;k<sz;k++){
    tmp=*(entries+i*sz+k);
    *(entries+i*sz+k)=*(entries+j*sz+k);
    *(entries+j*sz+k)=tmp;
  };
};

RealmatrixT Realmatrix::getresistance(){
  //Takes the entries of the matrix as the values of the conductance
  //of resistors, and returns a realmatrix whose entries give the
  //overall resistance between any two points.

  //Assumes all rows & columns of the matrix sum to 0.

  long double *Rent=new long double[sz*sz];
  long double *Qent=new long double[sz*(sz-1)];
  long double *lam=new long double[sz];
  long double *cs=new long double[sz];
  for(int i=0;i<sz;i++){
    *(cs+i)=0;
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(Rent+i*sz+j)=*(entries+i*sz+j);
      *(cs+j)+=*(Rent+i*sz+j);
    };
  };
  for(int i=0;i<sz-1;i++){
    for(int j=0;j<sz-1;j++){
      *(Qent+i*(sz-1)+j)=(i==j)?1:0;
    };
  };
  for(int j=0;j<sz-1;j++){
    *(Qent+(sz-1)*(sz-1)+j)=-1;
  };
  long double pivot;
  for(int j=0;j<sz-1;j++){
    int i=j;
    long double big=(*(Rent+j*sz+i)>0)?*(Rent+j*sz+i):-*(Rent+j*sz+i);
    for(int k=j+1;k<sz;k++){
      long double b2=(*(Rent+k*sz+j)>0)?*(Rent+k*sz+j):-*(Rent+k*sz+j);
      if(b2>big){
	i=k;
	big=b2;
      };
    };//find pivot. i is the row with the largest element in column j.
    if(ZERO(big)){
      cout<<"Matrix is singular\n";
      this->display();
      cout<<'\n';
      return RealmatrixT(sz,Rent);
    };
    int p=i;
    pivot=*(Rent+i*sz+j);
    if(p!=j){//Want to swap rows
      long double tmp;
      for(int k=j;k<sz;k++){
	tmp=*(Rent+j*sz+k);
	*(Rent+j*sz+k)=*(Rent+p*sz+k);
	*(Rent+p*sz+k)=tmp;
      };
      for(int k=0;k<sz-1;k++){
	tmp=*(Qent+j*(sz-1)+k);
	*(Qent+j*(sz-1)+k)=*(Qent+p*(sz-1)+k);
	*(Qent+p*(sz-1)+k)=tmp;
      };
    };
    for(i=0;i<sz;i++){
      if(i!=j){//only need to do this for non-pivot positions
	long double factor=*(Rent+i*sz+j)/pivot;
	if(factor!=0){//need to cancel out
	  *(Rent+i*sz+j)=0;
	  for(int k=j+1;k<sz;k++){
	    *(Rent+i*sz+k)-=*(Rent+j*sz+k)*factor;
	  };
	  for(int k=0;k<sz-1;k++){
	    *(Qent+i*(sz-1)+k)-=*(Qent+j*(sz-1)+k)*factor;
	  };
	};
      };
    };
  };//Need to rescale columns of Q
  for(int i=0;i<sz-1;i++){
    long double factor=*(Rent+i*(sz+1));
    if(ZERO(factor)){
      cout<<"Matrix is singular!\n";
      this->display();
      cout<<"\n\n";
      displayMat(Rent);
      cout<<"\n\n";
      displayMat(Qent);
      return RealmatrixT(sz,Qent);
    };
    for(int j=0;j<sz-1;j++){
      *(Qent+i*(sz-1)+j)/=factor;
    };
  };
  for(int j=0;j<sz-1;j++){
    for(int i=0;i<sz-1;i++){
      *(Qent+i*(sz-1)+j)-=*(Qent+(sz-1)*(sz-1)+j);
    };
    *(Qent+(sz-1)*(sz-1)+j)=0;
  };
  for(int i=0;i<sz-1;i++){
    *(lam+i)=-1/(*(Qent+i*sz));
    for(int j=0;j<sz-1;j++){
      *(Qent+j*(sz-1)+i)*=-*(lam+i);
    };
  };
  RealmatrixT ans(sz);
  for(int i=0;i<sz-1;i++){
    for(int j=0;j<sz-1;j++){
      if(j==i){
	*(ans.ent+i*(sz+1))=0;
      }else{
	long double x=*(lam+j)*(1-*(Qent+j*(sz-1)+i))+*(lam+i)*(1-*(Qent+i*(sz-1)+j));
	*(ans.ent+i*sz+j)=(x>0)?(x/(*(lam+i)*(*(lam+j)))):(-x/(*(lam+i)*(*(lam+j))));
      };
    };
    *(ans.ent+i*sz+sz-1)=1/(*(lam+i));
    *(ans.ent+(sz-1)*sz+i)=1/(*(lam+i));
  };
  *(ans.ent+sz*sz-1)=0;
  delete[] Rent;
  delete[] Qent;
  delete[] lam;
  delete[] cs;
  return ans;
};

RealmatrixT getsym(const Realmatrix& Q,long double *pi){
  //Assume Q=Rpi for a diagonal matrix pi. and symmetric R.
  long double *temp=new long double[Q.sz*Q.sz];
  long double *temp2=new long double[Q.sz*Q.sz];
  long double *normsq=new long double[Q.sz];
  long double *norm2sq=new long double[Q.sz];
  for(int i=0;i<Q.sz;i++){
    *(normsq+i)=0;
    *(norm2sq+i)=0;
  };
  for(int i=0;i<Q.sz*Q.sz;i++){
    *(temp+i)=*(Q.entries+i);
  };
  for(int i=0;i<Q.sz;i++){
    *(pi+i)=0;
    for(int j=0;j<Q.sz;j++){
      if(NONZEROST(*(temp+j*Q.sz+i))){
	*(pi+i)+=*(temp+i*Q.sz+j)/(*(temp+j*Q.sz+i));//Should do something to deal better with zero values.
      };
    };
  };
  long double s=0;
  for(int i=0;i<Q.sz;i++){
    for(int j=0;j<Q.sz;j++){
      *(temp2+i*Q.sz+j)=*(temp+i*Q.sz+j)*(*(pi+j))-*(temp+j*Q.sz+i)*(*(pi+i));
      *(norm2sq+j)+=*(temp2+i*Q.sz+j)*(*(temp2+i*Q.sz+j));
      *(normsq+j)+=*(temp+i*Q.sz+j)*(*(temp+i*Q.sz+j));
    };
  };
  for(int i=0;i<Q.sz;i++){
    s+=*(norm2sq+i);
  };           //Now temp2 should store the antisymmetric part of the
	       //matrix, and s should store its size.
  for(int i=0;i<100&&NONZEROSTSQ(s);i++){
    s=0;
    for(int j=0;j<Q.sz;j++){
      long double d=0;
      for(int k=0;k<Q.sz;k++){
	d+=*(temp2+k*Q.sz+j)*(*(temp+k*Q.sz+j));
      };
      long double lam=d/(*(normsq+j));
      *(pi+j)-=lam;
      for(int k=0;k<Q.sz;k++){
	long double l=lam*(*(temp+k*Q.sz+j));
	*(temp2+k*Q.sz+j)-=l;
	if(k!=j){
	  *(norm2sq+k)+=2*(*(temp2+j*Q.sz+k)*l)+l*l;
	};
	*(temp2+j*Q.sz+k)+=l;
      };
      *(norm2sq+j)-=lam*d;
    };
    for(int j=0;j<Q.sz;j++){
      s+=*(norm2sq+j);
    };
  };    
  for(int i=0;i<Q.sz;i++){
    for(int j=0;j<Q.sz;j++){
      *(temp+i*Q.sz+j)*=*(pi+j);
    };
  };
  Realmatrix R(Q.sz);
  for(int i=0;i<Q.sz*Q.sz;i++){
    *(R.entries+i)=*(temp+i);
  };
  R.sz=Q.sz;
  for(int i=0;i<Q.sz;i++){
    *(pi+i)=1/(*(pi+i));
  };
  delete[] temp;
  delete[] temp2;
  delete[] norm2sq;
  delete[] normsq;
  return R;
};

void Realmatrix::resortrows(const int *p){
  long double *q=new long double[sz*sz];
  for(int i=0;i<sz*sz;i++){
    *(q+i)=*(entries+i);
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(entries+*(p+i)*sz+j)=*(q+i*sz+j);
    };
  };
  delete[] q;
};

void Realmatrix::resortcols(const int *p){
  long double *q=new long double[sz*sz];
  for(int i=0;i<sz*sz;i++){
    *(q+i)=*(entries+i);
  };
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      *(entries+*(p+i)+sz*j)=*(q+i+sz*j);
    };
  };
  delete[] q;
};

#ifdef COMPLEX_NUMBERS

void Realmatrix::copy(complex *T) const {
  long double *U=new long double[sz];
  for(int i=0;i<sz;i++){
    fread(U,sizeof(long double),sz,entries);
    for(int j=0;j<sz;j++){
      *(T+j+i*sz)=complex(*(U+j));
    };
  };
  rewind(entries);
  delete[] U;
};

void Realmatrix::act(complex *vect,complex *ans) const {
  long double *tmp=new long double[sz];
  for(int i=0;i<sz;i++){
    complex acc(0);
    fread(tmp,sizeof(long double),sz,entries);
    for(int j=0;j<sz;j++){
      acc+=*(vect+j)*complex(*(tmp+j));
    };
    *(ans+i)=acc;
  };
  rewind(entries);
  delete[] tmp;
};

#endif

