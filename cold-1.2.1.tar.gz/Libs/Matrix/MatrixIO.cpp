/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include<iostream>
#include<fstream>
#include <string.h>
#include <stdlib.h>
#include "Miscellaneous.h"
#include "Macros.h"
#include "Matrix.h"
using namespace std;

void displayMat(long double *ent, int sz){
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      cout<<(ZERO(*(ent+i*sz+j))?0:*(ent+i*sz+j))<<' ';
    };
    cout<<'\n';
    if(DBLSPACE){
      cout<<'\n';
    };
  };
};

void Realmatrix::display() const {
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      cout<<(ZERO(*(entries+i*sz+j))?0:*(entries+i*sz+j))<<' ';
    };
    cout<<'\n';
  };
};


void Realmatrix::save(ofstream& s) const {
  for(int i=0;i<sz;i++){
    for(int j=0;j<sz;j++){
      s<<*(entries+i*sz+j)<<' ';
    };
    s<<'\n';
  };
};

Realmatrix::Realmatrix(ifstream& s){//Need to rewrite this. It's still buggy.
  //hangs if bad character in stream.
  long double *ent=new long double[BUFFERSIZE];
  long double *ents=NULL;
  int index=0;
  char a[151];//extra space in case end isn't a new line.
  char *b=a;
  char st[2];
  st[1]='\0';
  sz=0;
  int number=0;
  linklist tmp;
  for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\n'||s.peek()=='\r')&&!s.eof();s.get());
  while(sz==0||number<sz*sz){
    if(s.eof()){
      return;
    };
    int pos=0;
    for(;(isdigit(s.peek())||s.peek()=='.'||s.peek()=='e'||s.peek()=='-'||s.peek()=='E'||s.peek()=='+')&&!s.eof()&&pos<150;s.get(a[pos++]));
    a[pos]='\0';
    *(ent+index++)=strtod(a,&b);
    number++;
    if(index>=BUFFERSIZE){
      if(sz==0){
	tmp.insert(ent);
	ent=new long double[BUFFERSIZE];
      }else{
	for(int i=0;i<BUFFERSIZE;i++){
	  *(ents++)=*(ent+i);
	};
      };
      index=0;
    };
    for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r')&&!s.eof();s.get());
    if(s.peek()=='\n'){
      for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r'||s.peek()=='\n')&&!s.eof();s.get());
      if(sz==0){
        sz=number;
	entries=new long double[sz*sz];
	ents=entries;
	if(number>=BUFFERSIZE){//some data already stored in a temporary list.
	  linklist *t=&tmp;
	  long double *temp=(long double *)t->data;
	  while(temp!=NULL){
	    for(int i=0;i<BUFFERSIZE;i++){
	      *ents++=*(temp+i);
	    };
	    t=t->next;
	    delete[] temp;
	    temp=(t==NULL)?NULL:(long double *)t->data;
	  };
	  tmp.unlink();
	};
      };
    };
  };
  for(int i=0;ents+i<entries+sz*sz;i++){
    *(ents+i)=*(ent+i);
  };
  delete[] ent;
};

RealmatrixT::RealmatrixT(ifstream& s){
  long double *en=new long double[BUFFERSIZE];
  long double *ents=NULL;
  int index=0;
  char a[151];//extra space in case end isn't a new line.
  char *b=a;
  char st[2];
  st[1]='\0';
  sz=0;
  int number=0;
  linklist tmp;
  for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\n'||s.peek()=='\r')&&!s.eof();s.get());
  while(sz==0||number<sz*sz){
    if(s.eof()){
      return;
    };
    int pos=0;
    for(;(isdigit(s.peek())||s.peek()=='.'||s.peek()=='e'||s.peek()=='-'||s.peek()=='E'||s.peek()=='+')&&!s.eof()&&pos<150;s.get(a[pos++]));
    a[pos]='\0';
    *(en+index++)=strtod(a,&b);
    number++;
    if(index>=BUFFERSIZE){
      if(sz==0){
	tmp.insert(en);
	en=new long double[BUFFERSIZE];
      }else{
	for(int i=0;i<BUFFERSIZE;i++){
	  *(ents++)=*(en+i);
	};
      };
      index=0;
    };
    for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r')&&!s.eof();s.get());
    if(s.peek()=='\n'){
      for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r'||s.peek()=='\n')&&!s.eof();s.get());
      if(sz==0){
        sz=number;
	ent=new long double[sz*sz];
	ents=ent;
	if(number>=BUFFERSIZE){//some data already stored in a temporary list.
	  linklist *t=&tmp;
	  long double *temp=(long double *)t->data;
	  while(temp!=NULL){
	    for(int i=0;i<BUFFERSIZE;i++){
	      *ents++=*(temp+i);
	    };
	    t=t->next;
	    delete[] temp;
	    temp=(t==NULL)?NULL:(long double *)t->data;
	  };
	  tmp.unlink();
	};
      };
    };
  };
  for(int i=0;ents+i<ent+sz*sz;i++){
    *(ents+i)=*(en+i);
  };
  delete[] en;
};

/*
RealmatrixT::RealmatrixT(ifstream& s){
  long double *en=new long double[BUFFERSIZE];
  long double *ents=NULL;
  int index=0;
  char a[151];//extra space in case end isn't a new line.
  char *b=a;
  char *bold;
  char st[2];
  st[1]='\0';
  sz=0;
  int number=0;
  linklist tmp;
  while(sz==0||number<sz*sz){
    char c=' ';
    while((c==' '||c=='\n')&&s.good()){
      s.get(c);
    };
    *a=c;
    s.get(a+1,100);
    s.get(c);//newline character.
    st[0]=c;
    strcat(a,st);
    if(c!='\n'&&c!=' '&&c!='\0'){//in middle of a number
      s.get(a+strlen(a),40,' ');//not sure if strlen(a) is the correct value.
      if(s.fail()){
	s.clear();
      };
      s.get(c);//newline character.
      if(!s.good()){
	if(s.bad()){
	  cout<<"Stream is bad!\n";
	}else if(s.fail()){
	  s.clear();
	};
	if(s.eof()){
	  cout<<"Stream at end of file!\n";
	  exit(1); // Should probably write a better error handler for this.
	};
      };
      st[0]=c;
      strcat(a,st);
    };
    b=a;
    bold=NULL;
    while(b-a<150&&*b!='\n'&&*b!='\0'&&bold!=b){
      bold=b;
      *(en+index++)=strtod(b,&b);
      if(bold==b){
        index--;
      }else{
        number++;
      };
      if(index>=BUFFERSIZE){
	if(sz==0){
	  tmp.insert(en);
	  en=new long double[BUFFERSIZE];
	}else{
	  for(int i=0;i<BUFFERSIZE;i++){
	    *(ents++)=*(en+i);
	  };
	};
        index=0;
      };
    };
    while(*b==' '){
      b++;
    };
    if(*b=='\n'){
      if(sz==0){
        sz=number;
	ent=new long double[sz*sz];
	ents=ent;
	if(number>BUFFERSIZE){//some data already stored in a temporary list.
	  linklist *t=&tmp;
	  long double *temp=(long double *)t->data;
	  while(temp!=NULL){
	    for(int i=0;i<BUFFERSIZE;i++){
	      *ents++=*(temp+i);
	    };
	    t=t->next;
	    delete[] temp;
	    temp=(t==NULL)?NULL:(long double *)t->data;
	  };
	  tmp.unlink();
	};
      };
    };
  };
  for(int i=0;ents+i<ent+sz*sz;i++){
    *(ents+i)=*(en+i);
  };
  delete[] en;
};
*/

void dummyreadmatrix(istream& s){
  int index=0;
  char a[151];//extra space in case end isn't a new line.
  char *b=a;
  char st[2];
  st[1]='\0';
  int sz=0;
  int number=0;
  for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\n'||s.peek()=='\r')&&!s.eof();s.get());
  while(sz==0||number<sz*sz){
    if(s.eof()){
      return;
    };
    int pos=0;
    for(;(isdigit(s.peek())||s.peek()=='.'||s.peek()=='e'||s.peek()=='-'||s.peek()=='E'||s.peek()=='+')&&!s.eof()&&pos<150;s.get(a[pos++]));
    a[pos]='\0';
    number++;
    for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r')&&!s.eof();s.get());
    if(s.peek()=='\n'){
      for(;(s.peek()==' '||s.peek()=='\t'||s.peek()=='\r'||s.peek()=='\n')&&!s.eof();s.get());
      if(sz==0){
        sz=number;
      };
    };
  };
}

/*
void dummyreadmatrix(istream& s){
  char a[151];//extra space in case end isn't a new line.
  char *b=a;
  char *bold;
  char st[2];
  st[1]='\0';
  int sz=0;
  int number=0;
  while(sz==0||number<sz*sz){
    char c=' ';
    while(c==' '||c=='\n'){
      s.get(c);
    };
    *a=c;
    s.get(a+1,100);
    s.get(c);//newline character.
    st[0]=c;
    strcat(a,st);
    if(c!='\n'&&c!=' '&&c!='\0'){//in middle of a number
      s.get(a+strlen(a),40,' ');
      if(s.fail()){
	s.clear();
      };
      s.get(c);//newline character.
      if(!s.good()){
	if(s.bad()){
	  cout<<"Stream is bad!\n";
	}else if(s.fail()){
	  s.clear();
	};
	if(s.eof()){
	  cout<<"Stream at end of file!\n";
	  exit(1); // Should probably write a better error handler for this.
	};
      };
      st[0]=c;
      strcat(a,st);
    };
    b=a;
    bold=NULL;
    while(b-a<150&&*b!='\n'&&*b!='\0'&&bold!=b){
      bold=b;
      double uselessvariable=strtod(b,&b);
      (void) uselessvariable;
      if(bold!=b){
        number++;
      };
    };
    while(*b==' '){
      b++;
    };
    if(*b=='\n'){
      if(sz==0){
        sz=number;
	//	cout<<sz;
      };
    };
  };
};
*/

ostream &operator <<(ostream &o,const Realmatrix &R){
  for(int i=0;i<R.sz;i++){
    for(int j=0;j<R.sz;j++){
      o<<(ZEROM(*(R.entries+i*R.sz+j))?0:*(R.entries+i*R.sz+j))<<' ';
    };
    o<<'\n';
    if(DBLSPACE){
      o<<'\n';
    };
  };
  return (o);
};

