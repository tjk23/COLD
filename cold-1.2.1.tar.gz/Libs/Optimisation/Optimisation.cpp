/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Optimisation.h"
#include <iostream>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <math.h>
//using namespace std;

#include "ErrorHandler.h"
#include "Macros.h"
#include "Miscellaneous.h"
#include "State.h"
#include "Matrix.h"
#include "CommandLine.h"

using std::cout;
using std::cerr;


int useapproxhessian=0; //used by external functions to control hessian calculation.

long double testfunction(function& f,long double *x,long double eps,long double signif){
  //tests the accuracy of the calculated hessian and gradient for the
  //function.
  long double* H=new long double[f.dim*f.dim];
  long double* G=new long double[f.dim];
  long double* G2=new long double[f.dim];
  long double v=f.evaluate(x);
  f.hessian(x,H);
  f.deriv(x,G);
  long double maxerr=0;
  int epos=0;
  for(int i=0;i<f.dim;i++){
    *(x+i)+=eps;
    f.deriv(x,G2);
    long double err=(f.evaluate(x)-v)/(eps*(*(G+i)))-1;
    if(-err>signif||err>signif){
      cout<<"in variable "<<i<<", error is "<<err<<".\n";
      cout<<f.evaluate(x)<<" "<<v<<" "<<(f.evaluate(x)-v)/eps<<" "<<*(G+i)<<"\n";
    };
    *(x+i)-=eps;
    if(-err>maxerr){
      maxerr=-err;
      epos=i;
    };
    if(err>maxerr){
      maxerr=err;
      epos=i;
    };
    for(int j=0;j<f.dim;j++){
      err=(*(G2+j)-*(G+j))/(eps*(*(H+i*f.dim+j)))-1;
      if(err>maxerr){
	maxerr=err;
	epos=(i+1)*f.dim+j;
      };
      if(-err>maxerr){
	maxerr=-err;
	epos=(i+1)*f.dim+j;
      };
      if(err>signif||-err>signif){
	cout<<"in position ("<<i<<","<<j<<"), error is "<<err<<".\n";
	cout<<*(G2+j)<<" "<<*(G+j)<<" "<<(*(G2+j)-*(G+j))/eps<<" "<<*(H+i*f.dim+j)<<"\n";
      };
    };
  };
  if(epos<f.dim){
    cout<<"epos="<<epos<<"\n";
  }else{
    cout<<"epos=("<<epos/f.dim-1<<","<<epos%f.dim<<")\n";
  };
  delete[] H;
  delete[] G;
  delete[] G2;
  return maxerr;
};

long double constraint::slack(const long double *vals) const {
  long double ans=lt;
  for(int i=0;i<numterms;i++){
    ans-=*(coeff+i)*(*(vals+*(varnum+i)));
  };
  return ans;
};

int constraint::correct(long double *vals) const {
  long double s=this->slack(vals);
  if(s<0){
    *(vals+*varnum)+=(s-1e-5)/(*coeff);
    return *varnum;
  };
  return -1;
};

char *constraint::prnt() const {
  unsigned int len=0;
  char *test=new char[100];
  for(int i=0;i<numterms;i++){
    sprintf(test,"%d%Lg",*(varnum+i),*(coeff+i));
    len+=strlen(test)+5;
  };
  sprintf(test,"%Lg",lt);
  len+=strlen(test);
  delete[] test;
  char *ans=new char[len+1];
  char *a=ans;
  for(int i=0;i<numterms;i++){
    if(i>0&&*(coeff+i)>0){
      *(a++)='+';
    };
    sprintf(a,"%LgX_%d",*(coeff+i),*(varnum+i));
    a+=strlen(a);
  };
  sprintf(a,"<%Lg",lt);
  return ans;
};

long double testfunctionplus(functionplus& f,long double *x,long double *dir, long double eps){
  //tests the accuracy of the calculated directional derivatives for
  //the function.


  long double H=f.directionalSecDer(x,dir);
  long double G=f.directionalDeriv(x,dir);
  long double v=f.evaluate(x);
  for(int i=0;i<f.dim;i++){
    *(x+i)+=*(dir+i)*eps;
  };
  long double G2=f.directionalDeriv(x,dir);
  long double v2=f.evaluate(x);

  return max((v2-v)/(G*eps),(G2-G)/(H*eps));
};


void subsolve(const long double *M,const long double *v,long double *w,int dim,const int* omit){
  //Solves a subsystem of the given equations and variables omitting
  //rows and columns in the the list omit, which is terminated by a
  //number outside the range -- eg a negative number.
  //Throws an integer exception with value 0 in the event of a singular matrix.
  int numom=0;
  for(;*(omit+numom)>=0&&*(omit+numom)<dim;numom++);
  Realmatrix H(dim-numom);
  const int *om=omit;
  int ii=0;
  for(int i=0;i<dim;i++){
    if(*om==i){
      om++;
    }else{
      const int *om2=omit;
      int jj=0;
      for(int j=0;j<dim;j++){
	if(*om2==j){
	  om2++;
	}else{
	  *(H.entries+ii*H.sz+jj)=*(M+i*dim+j);
	  jj++;
	};
      };
      ii++;
    };
  };
  long double *d=new long double[H.sz];
  Realmatrix Ai=H.diagonalisesymmetric(d);
  Realmatrix A=Ai.transpose();
  long double *t1=new long double[H.sz];
  long double *t2=new long double[H.sz];
  const int *om2=omit;
  int jj=0;
  for(int j=0;j<dim;j++){
    if(*om2==j){
      om2++;
    }else{
      *(t1+jj)=*(v+j);
      jj++;
    };
  };
  A.act(t1,t2);
  for(int i=0;i<H.sz;i++){
    if(*(d+i)>0.1){
      *(t2+i)/=-*(d+i);
    }else if(*(d+i)<-0.1){
      *(t2+i)/=*(d+i);
    }else if(*(d+i)>0){
      *(t2+i)*=-10;
    }else{
      *(t2+i)*=10;
    };
  };
  Ai.act(t2,t1);
  om2=omit;
  jj=0;
  for(int j=0;j<dim;j++){
    if(*om2==j){
      *(w+j)=*(v+j);
      om2++;
    }else{
      *(w+j)=*(t1+jj);
      jj++;
    };
  };
  delete[] t1;
  delete[] t2;
  delete[] d;
};


void solve(const long double *M,long double *v,long double *w,int dim){
  //Uses Gaussian elimination to solve Mw=v. Doesn't resolve case for
  //singular M.
  Realmatrix m(dim,M);
  long double *v0=new long double[dim];
  for(int i=0;i<dim;i++){
    *(v0+i)=*(v+i);
  };
  long double scale=*M;
  for(int r=0;r<dim;r++){
    if(fabs(*(M+r*dim))>scale){
      scale=fabs(*(M+r*dim));
    };
  };
  for(int c=1;c<dim;c++){
    long double mx=*(M+c);
    for(int r=0;r<dim;r++){
      if(fabs(*(M+r*dim+c))>mx){
	mx=fabs(*(M+r*dim+c));
      };
    };
    if(mx<scale){
      scale=mx;
    };
  };
  for(int i=0;i<dim-1;i++){
    long double mmod=0;
    int mxrw=i;
    for(int j=i;j<dim;j++){
      long double e=(*(m.entries+j*dim+i)<0)?-*(m.entries+j*dim+i):*(m.entries+j*dim+i);
      if(mmod<e){
	mmod=e;
	mxrw=j;
      };
    };
    if(ZEROST(mmod/scale)){
      throw(0);//singular matrix
    };
    if(mxrw!=i){
      mmod=*(v0+i);
      *(v0+i)=*(v0+mxrw);
      *(v0+mxrw)=mmod;
      m.swaprows(i,mxrw);
    };
    for(int j=i+1;j<dim;j++){
      long double pivot=*(m.entries+j*dim+i)/(*(m.entries+i*dim+i));
      *(m.entries+j*dim+i)=0;
      for(int k=i+1;k<dim;k++){
	*(m.entries+j*dim+k)-=*(m.entries+i*dim+k)*pivot;
      };
      *(v0+j)-=*(v0+i)*pivot;
    };
  };
  if(ZEROST(*(m.entries+dim*dim-1)/scale)){
    throw(0); //Matrix is singular;
  };
  for(int i=dim-1;i>=0;i--){
    *(w+i)=*(v0+i)/(*(m.entries+i*(dim+1)));
    for(int j=0;j<i;j++){
      *(v0+j)-=*(w+i)*(*(m.entries+j*dim+i));
    };
  };
  Realmatrix n(dim,M);
  n.act(w,v0);
  long double err=0;
  for(int i=0;i<dim;i++){
    err+=(*(v+i)-*(v0+i))*(*(v+i)-*(v0+i));
  };
  err=sqrt(err);
  delete[] v0;
};



long double *satisfyconstraints(int numposvals,int dim,const long double *max,const long double *hess,int numcon, const constraint *con){
  //Performs constrained optimisation for quadratic functions.
  //max is  the position that would maximise an unconstrained quadratic. 
  //hess is the hessian matrix. con is the list of constraints to satisfy.
  int nm=numcon+numposvals;
  long double *sol=new long double[dim*nm];
  long double *ans=new long double[dim];
  long double *cst=new long double[dim*nm];
  for(int i=0;i<dim;i++){
    *(ans+i)=*(max+i);
  };
  for(int i=0;i<numposvals;i++){
    for(int j=0;j<dim;j++){
      *(cst+i*dim+j)=(i==j)?1:0;
    };
    solve(hess,cst+i*dim,sol+i*dim,dim);//Slow - should speed it up.
  };
  for(int i=0;i<numcon;i++){
    //    if((con+i)->slack(ans)<0){
    for(int j=0;j<dim;j++){
      *(cst+(numposvals+i)*dim+j)=0;
    };
    for(int j=0;j<(con+i)->numterms;j++){
      *(cst+(numposvals+i)*dim+*((con+i)->varnum+j))=*((con+i)->coeff+j);
    };
    solve(hess,cst+(numposvals+i)*dim,sol+(numposvals+i)*dim,dim);//Slow - should speed it up.
    
      
      //      (con+i)->lt
  };

  cout<<"\n";
    for(int i=0;i<nm;i++){
    for(int j=0;j<dim;j++){
      cout<<*(sol+i*dim+j)<<" ";
    };
    cout<<"\n";
  };
  cout<<"\n";

  cout<<"\n";
    for(int i=0;i<nm;i++){
    for(int j=0;j<dim;j++){
      cout<<*(cst+i*dim+j)<<" ";
    };
    cout<<"\n";
  };
  cout<<"\n";
  long double *M=new long double[nm*nm];
  for(int i=0;i<nm;i++){
    for(int j=0;j<nm;j++){
      *(M+i*nm+j)=0;
      for(int k=0;k<dim;k++){
	*(M+i*nm+j)+=*(cst+i*dim+k)*(*(sol+j*dim+k));	
      };
      cout<<*(M+i*nm+j)<<" ";
    };
    cout<<"\n";
  };
  long double *k=new long double[nm];
  for(int i=0;i<numposvals;i++){
    *(k+i)=-*(max+i);
    /*    if(*(k+i)<0){
      *(k+i)=0;
      };*/
  };
  for(int j=0;j<numcon;j++){
    *(k+j+numposvals)=-(con+j)->slack(max);
    if(*(k+j+numposvals)<0){
      *(k+j+numposvals)=0;
    };
  };
  cout<<"\n";
  long double *lam=new long double[nm];
  int *omit=new int[nm+1];
  int *q=new int[nm+1];
  for(int i=0;i<=nm;i++){
    *(omit+i)=-1;
  };
  for(int numneg=1;numneg>0;){
    int *qe=q;
    int *qp=q;
    *qp=-1;
    numneg=0;
    subsolve(M,k,lam,nm,omit);
    for(int i=0;i<nm;i++){
      cout<<*(k+i)<<"\t"<<*(lam+i)<<"\n";
    };
    cout<<"\n";
    int *om=omit;
    for(int i=0;i<nm;i++){
      if(*(lam+i)<0){
	*(lam+i)=0;
	numneg++;
	for(;*qp>=0&&i<*qp;){
	  *(qe++)=*om;
	  *(om++)=*(qp++);
	};
	for(;*om>=0&&*om<i;om++);
	*(qe++)=*om;
	*(om++)=i;
      };
    };
    for(;*qp>=0;qp++){
      *(qe++)=*om;
      *(om++)=*qp;
    };
    for(int i=0;i<nm+1;i++){
      cout<<*(omit+i)<<" ";
    };
    cout<<"\n";
  };
  delete[] omit;
  delete[] q;
  for(int i=0;i<nm;i++){
    for(int j=0;j<dim;j++){
      *(ans+j)+=*(lam+i)*(*(sol+i*dim+j));
    };
  };

  delete[] sol;
  delete[] cst;
  delete[] M;
  delete[] k;
  delete[] lam;
  return ans;
};


inline long double getlength(long double *v,int num){
  long double len=0;
  for(int i=0;i<num;i++){
    len+=*(v+i)*(*(v+i));
  };
  return(sqrt(len));
};

char *prntvec(int nm,long double *vals){
  unsigned int len=0;
  char *test=new char[100];
  for(int i=0;i<nm;i++){
    sprintf(test,"%Lg",*(vals+i));
    len+=strlen(test)+2;
  };
  delete[] test;
  char *ans=new char[len+1];
  char *a=ans;
  for(int i=0;i<nm;i++){
    if(i>0){
      *(a++)=',';
    };
    sprintf(a,"%Lg",*(vals+i));
    a+=strlen(a);
  };
  return ans;
};


long double *optimiseQuadraticWithConstraints(const long double *hess,const long double *der,const long double *offset,const long double *pos,int dim,int numpos,int numcon,const constraint *cst){
  //A wrapper for the constrainedOptimisation function.
  //hess is the hessian matrix 
  //der is the first derivative
  //offset is the unconstrained maximum of the quadratic
  //pos is the current position (which satisfies the constraints)
  //numpos is the number of positive values
  //numcon is the number of other constraints
  //cst is a list of other constraints.
  Realmatrix h(dim,hess);
  long double *d=new long double[dim];
  Realmatrix Ai=h.diagonalisesymmetric(d);//This will be A inverse
  Realmatrix A=Ai.transpose();
  for(int i=0;i<dim;i++){
    long double sd=*(d+i)>0?sqrt(*(d+i)):sqrt(-*(d+i));
    for(int j=0;j<dim;j++){
      *(A.entries+i*dim+j)*=sd;
      *(Ai.entries+j*dim+i)/=sd;
    };
  };
  //  cout<<A<<"\n\n"<<Ai<<"\n\n";
  delete[] d;
  long double *st=new long double[dim];
  long double *start=new long double[dim];
  for(int i=0;i<dim;i++){
    *(st+i)=*(pos+i)-*(offset+i);
  };
  A.act(st,start);
  delete[] st;
  long double* cons=new long double[numcon*dim];
  long double*l=new long double[numcon+numpos];
  for(int i=0;i<numcon*dim;i++){
    *(cons+i)=0;
  };
  for(int i=0;i<numcon;i++){
    for(int j=0;j<(cst+i)->numterms;j++){
      long double cf=*((cst+i)->coeff+j);
      for(int k=0;k<dim;k++){
	*(cons+i*dim+k)-=*(Ai.entries+*((cst+i)->varnum+j)*dim+k)*cf;
      };
    };
    *(l+numpos+i)=-((cst+i)->slack(offset));
  };
  long double **c=new long double*[numpos+numcon];
  for(int i=0;i<numpos;i++){
    *(c+i)=Ai.entries+i*dim;
  };
  for(int i=0;i<numcon;i++){
    *(c+numpos+i)=cons+i*dim;
  };
  for(int i=0;i<numpos;i++){
    *(l+i)=-*(offset+i);
  };
  /*  for(int i=0;i<numpos+numcon;i++){
    for(int j=0;j<dim;j++){
      //      cout<<*(*(c+i)+j)<<" ";
    };
    cout<<*(l+i)<<"\n";
    };*/
  char msg[80];
  sprintf(msg,"Performing constrained optimisation with %d constraints in %d dimensions",numpos+numcon,dim);
  info(msg,msgcode(2,0));
  long double *tmp=constrainedOptimum(numpos+numcon,dim,c,l,start);
  long double *ans=new long double[dim];
  ((Realmatrix)A.inverse()).act(tmp,ans);
  delete[] tmp;
  delete[] l;
  delete[] c;
  delete[] cons;
  delete[] start;
  for(int i=0;i<dim;i++){
    *(ans+i)+=*(offset+i);
  };
  info("Completed constrained optimisation.",msgcode(2,0));
  return ans;
};


int NewtonRaphson(function& f,long double *start,long unsigned steps,int op,int stv,int numposvals,int numconstraints,const constraint *cst,long double tolerance,long double initpen){//All positive values are required to be first.
  //Check constraints
  for(int i=0;i<numconstraints;i++){
    if((cst+i)->slack(start)<0){
      char *ct=(cst+i)->prnt();
      char *sta=prntvec(f.dim,start);
      char *msg=new char[strlen(ct)+strlen(sta)+60];
      strcpy(msg,"Constraint: ");
      strcat(msg,ct);
      strcat(msg," Not satisfied by start point: (");
      strcat(msg,sta);
      strcat(msg,")");
      recoverableError(msg);
    };
  };
  long double *t=new long double[f.dim];
  long double *t2=new long double[f.dim];
  long double *hess=new long double[f.dim*f.dim];
  long double *last=new long double[f.dim];
  long double *best=new long double[f.dim];
  int *omit=new int[numposvals+1];
  long double oldlen=100;
  long unsigned int s;
  long double maxstep=10;
  long double *excessmoves=new long double[numposvals];
  long double pen=initpen;
  long double bestval=0;
  long double numfac=1;
  long double maimp=1;
  long double lastexpect=100;
  long double machange=1;
  int badpeaks=0;
  long double lastval=0;
  long double startingpenalty=1e-7;
  long double penalty=startingpenalty;
  long double penaltyfactor=0.8;
  int lineback=0;
  long double validlength=0;
  for(s=0;s<steps;s++){
    inputcheck();//check for any updates to options.
    char msg[80];
    sprintf(msg,"Started step number %ld.",s+1);
    info(msg);
    long double modulus=0;
    for(int i=0;i<f.dim;i++){
      modulus+=*(start+i)*(*(start+i));
    };
    sprintf(msg,"Modulus=%lg.",(double)sqrt(modulus));
    info(msg,msgcode(2,0));
    long double val=f.evaluate(start);
    printContext(2);
    if(s>0&&((val<lastval-1&&op==MAXIMISE)||(val>lastval+1&&op==MINIMISE))){//overstep. Should improve this
      for(int i=0;i<f.dim;i++){
	*(last+i)/=2;
	*(start+i)-=*(last+i);
      };
      oldlen/=2;
    }else{
      long double change=val-lastval;
      if(change>lastexpect*0.6){
	penalty*=penaltyfactor;
	sprintf(msg,"new penalty: %Lg",penalty);
	info(msg,msgcode(1,0));
      }else if(penalty<1){
	penalty=startingpenalty;
	sprintf(msg,"new penalty: %Lg",penalty);
	info(msg,msgcode(1,0));
      };
      if(0>change){
	change=-change;
      };	
      machange=machange*2/3+change/3;      
      sprintf(msg,"Value=%Lg.",val);
      info(msg,msgcode(0,0));
      lastval=val;
      if(s==0||(val>bestval&&op==MAXIMISE)||(val<bestval&&op==MINIMISE)){
	bestval=val;
	for(unsigned int i=0;i<(unsigned)f.dim;i++){
	  *(best+i)=*(start+i);
	};
      };
      sprintf(msg,"Best Value=%Lg",bestval);
      info(msg,msgcode(1,0));
      f.hessian(start,hess);
      f.deriv(start,t);
      long double l2=0;
      for(int i=0;i<f.dim;i++){
	l2+=*(t+i)*(*(t+i));
      };
      l2=sqrt(l2);
      int numomit=0;
      for(int i=0;i<numposvals;i++){
	if(*(start+i)<1e-6){
	  if((op==MAXIMISE && *(t+i)<0)||(op==MINIMISE && *(t+i)>0)){
	    *(omit+numomit++)=i;
	    *(t2+i)=0;
	  };
	};
      };
      *(omit+numomit)=-1;
      for(int i=0;i<f.dim;i++){
	*(t+i)-=pen;
      };
      if(numomit>1){
	sprintf(msg,"Omited %d variables from search.",numomit);
	info(msg,msgcode(1,1));
      };
      sprintf(msg,"Penalty=%Lg.",penalty);
      info(msg,msgcode(1,1));
      if(op==MAXIMISE){
	for(int i=0;i<f.dim;i++){
	  *(hess+i*(f.dim+1))-=penalty;//*l2;
	};
      }else{
	for(int i=0;i<f.dim;i++){
	  *(hess+i*(f.dim+1))+=penalty;//*l2;
	};
      };
      //NEW CODE
      //Diagonalise hessian and change sign of negative values
      Realmatrix HH(f.dim,hess);
      long double *diag=new long double[f.dim];
      Realmatrix A=HH.diagonalisesymmetric(diag);
      for(unsigned int i=0;i<(unsigned)f.dim;i++){
	if((*(diag+i)>0&&op==MAXIMISE)||(*(diag+i)<0&&op==MINIMISE)){
	  *(diag+i)*=-1;
	};
      };
      for(unsigned int i=0;i<(unsigned)f.dim*f.dim;i++){
	*(hess+i)=0;
      };
      for(unsigned int i=0;i<(unsigned)f.dim;i++){
	for(unsigned int j=0;j<(unsigned)f.dim;j++){
	  for(unsigned int k=0;k<(unsigned)f.dim;k++){
	    *(hess+i*f.dim+k)+=*(A.entries+i*f.dim+j)*(*(diag+j))*(*(A.entries+k*f.dim+j));
	  };
	};
      };
      try{
	subsolve(hess,t,t2,f.dim,omit);
      }catch(int slv){
	if(slv==0){//matrix singular
	  info("Singular Hessian matrix, using steepest descent instead.",msgcode(1,1));
	  for(int i=0;i<f.dim;i++){
	    *(t2+i)=*(t+i)/(val*100);
	    maxstep=1;
	  };
	}else{//Shouldn't get here.
	  throw;
	};
      };
      for(int i=0;i<numomit;i++){
	*(t2+*(omit+i))=0;
      };
      long double len=0;
      for(int i=0;i<f.dim;i++){
	len+=*(t2+i)*(*(t2+i));
      };
      len=sqrt(len);
      sprintf(msg,"Attempted step size=%Lg",len);
      info(msg,msgcode(1,0));
      long double dot=0;
      for(int i=0;i<f.dim;i++){
	dot+=*(t+i)*(*(t2+i));//This is twice the expected gain from the step
      };
      sprintf(msg,"Expected improvement=%Lg",dot/2);//This is if the step is fully taken.
      info(msg);
      long double dt6=dot/6;
      lastexpect=dot/2;
      if(lastexpect<0&&lastexpect>-0.05){
	useapproxhessian=0;
      };
      if(ZERO(dot)||maimp<tolerance||machange<1e-5){//Rounding errors make closer approximations impossible.
	if(ZEROWEAK(val-bestval)){//Converged to best so far
	  break;
	}else{//Converged to suboptimal peak;
	  sprintf(msg,"Converged to value %Lg less than best value so far.",bestval-val);
	  info(msg);
	  lastval=-1e10;//Should make this better.
	  *start+=maxstep*++badpeaks;
	};
      };
      dot/=(len*l2);
      sprintf(msg,"Angle between steepest and actual ascent=%Lg",-dot);
      info(msg,msgcode(2,0));
      long double sn=((dot>0&&op==MAXIMISE)||(dot<0&&op==MINIMISE))?1:-1;//move faster away from minima.
      for(int i=0;i<f.dim;i++){
	*(t2+i)*=sn;
      };
      if(sn==3){
	len*=3;
      };
      if(dot<1e-3&&dot>-1e-3){
	sn=1000000*sqrt(dot*sn)/len;//Only for MAXIMISE
	sn=(sn>1)?1:sn;
	sprintf(msg,"Adjusting step size by a factor %Lg\n",sn);
	info(msg);
	long double *dirsec=new long double[f.dim];
	Realmatrix(f.dim,hess).act(t,dirsec);
	long double scdr=0;
	for(int i=0;i<f.dim;i++){
	  scdr+=*(t+i)*(*(dirsec+i));
	};
	delete[] dirsec;
	sprintf(msg,"scdr=%Lg\n",scdr);
	info(msg);
	if(scdr<0){
	  scdr=-scdr;
	};
	for(int i=0;i<f.dim;i++){
	  *(t2+i)*=sn;
	};
      };
      int j=0;
      long double fact=0;//(1-dot*dot)/200;
      for(int i=0;i<f.dim;i++){
	if(*(omit+j)==i){
	  j++;
	}else{
	  *(t2+i)+=(*(t+i))*fact*len/l2;
	};
      };
      len=0;
      for(int i=0;i<f.dim;i++){
	len+=*(t2+i)*(*(t2+i));
      };
      len=sqrt(len);
	//      maxstep=10;
      if(len>maxstep){//too big a step
	for(int i=0;i<f.dim;i++){
	*(t2+i)*=maxstep/len;
	};
	len=maxstep;
      };
      long double fac=1;
      long double excessmove=0;
      for(int i=0;i<numposvals;i++){
	if(*(t2+i)!=0){
	  *(excessmoves+i)=(*(t2+i)+*(start+i))/(*(t2+i));
	  if(*(t2+i)<0&&*(excessmoves+i)>excessmove){//move would result in a negative value
	    if(*(t+i)>0){//wrong direction
	      *(t2+i)*=-1;
	    }else{
	      excessmove=*(excessmoves+i);
	      long double faci=(-*(start+i))/(*(t2+i));
	      if(faci<fac){
		fac=faci;
	      };
	    };
	  };
	};
      };
      long double *next=new long double [f.dim];
      for(int i=0;i<f.dim;i++){
	*(next+i)=*(start+i)+*(t2+i);
      };
      for(int i=0;i<numconstraints;i++){
	long double slk=(cst+i)->slack(next);
	if(slk<0){
	  long double em=slk/(slk-(cst+i)->slack(start));
	  if(em>excessmove){
	    excessmove=em;
	  };
	  long double faci=1-em;
	  if(faci<fac){
	    fac=faci;
	  };
	};
      };
      fac*=0.99;
      if(excessmove>0){
	sprintf(msg,"Excess move=%Lg.",excessmove);
	info(msg,msgcode(2,0));
	//      long double fac=(1-excessmove)*(1-1e-10);
	for(int i=0;i<numposvals;i++){
	  if(*(t2+i)<0&&*(excessmoves+i)>0){
	    sprintf(msg,"For variable %d, current value=%Lg, attempted move=%Lg.",i,*(start+i),*(t2+i));
	    info(msg,msgcode(2,0));
	  };
	};
	long double *target=optimiseQuadraticWithConstraints(hess,t,next,start,f.dim,numposvals,numconstraints,cst);
	long double *b=new long double[f.dim];
	long double ei=0;
	for(int i=0;i<f.dim;i++){
	  *(b+i)=*(target+i)-*(next+i);
	  *(t2+i)=*(target+i)-*(start+i);
	  ei+=*(t2+i)*(*(t+i));
	  *(t2+i)*=0.99;
	};
	for(int i=0;i<f.dim;i++){
	  for(int j=0;j<f.dim;j++){
	    ei+=*(t2+i)*(*(b+j))*(*(hess+i*f.dim+j));
	  };
	};	  
	delete[] b;
	delete[] target;
	sprintf(msg,"Expected improvement=%Lg",ei/2);
	info(msg);
	dt6=ei/4;
	if(ZERO(ei/2)||maimp<tolerance||machange<1e-5){//Rounding errors make closer approximations impossible.
	  if(ZEROWEAK(val-bestval)){//Converged to best so far
	    break;
	  }else{//Converged to suboptimal peak;
	    sprintf(msg,"Converged to value %Lg less than best value so far.",bestval-val);
	    info(msg);
	    lastval=-1e10;//Should make this better.
	    *start+=maxstep*++badpeaks;
	  };
	};
	len=getlength(t2,f.dim);
	sprintf(msg,"Adjusted step size=%Lg",len);
	info(msg);//msgcode(2,0)
	//sprintf(msg,"Expected improvement=%Lg",ei/2);
	//	info(msg);//msgcode(2,0)
      };
      delete[] next;
      if(dt6<0){
	dt6=-dt6;
      };
      maimp=maimp/2+dt6;
      sprintf(msg,"Moving average of expected improvement=%Lg",maimp);
      info(msg,msgcode(2,0));
      dot=0;
      for(int i=0;i<f.dim;i++){
	dot+=*(t2+i)*(*(t+i));
      };
      if(s>0&&NONZEROST(len)){
	long double comp=0;
	for(int i=0;i<f.dim;i++){
	  comp+=*(last+i)*(*(t2+i));
	};
	comp/=(len*oldlen);//Now comp is the change in direction.
	sprintf(msg,"Change in direction is %Lg.",comp);
	info(msg,msgcode(2,0));
	sprintf(msg,"step length %Lg.",len);
	info(msg,msgcode(2,0));
	if(comp<-.99){
	  lineback=1;
	  if(len>oldlen/1.3){
	    penalty+=1;
	    continue;
	    long double factor=2*len/oldlen*numfac;
	    numfac*=2.0;
	    for(int i=0;i<f.dim;i++){
	      *(t2+i)/=factor;
	    };
	    len/=factor;
	  };
	  validlength=oldlen-len;
	}else{
	  if(lineback==1&&comp>0.99){
	    if(len>validlength/1.3){
	      penalty+=1;
	      continue;
	      long double factor=len*2/validlength;
	      len=validlength/2;	   
	      for(int i=0;i<f.dim;i++){
		*(t2+i)/=factor;
	      };
	    };
	    validlength-=len;
	  }else{
	    lineback=0;
	    penalty=1e-7;
	    numfac/=1.3;
	    if(numfac<1){
	      numfac=1;
	    };
	  };
	};
	long double mxstep=len*(1+comp/2)*(1+comp/2);      
	if((1+comp/2)*(1+comp/2)<1){
	  maxstep*=(1+comp/2)*(1+comp/2);
	};
	if(mxstep>maxstep||maxstep>10){
	  maxstep=mxstep;	
	};
	sprintf(msg,"New maximum step size=%Lg",maxstep);
	info(msg,msgcode(2,0));
      };
      /*      if(lineback==1){
	long double *dirsec=new long double[f.dim];
	Realmatrix(f.dim,hess).act(t,dirsec);
	long double scdr=0;
	for(int i=0;i<f.dim;i++){
	  scdr+=*(t+i)*(*(dirsec+i));
	};
	delete[] dirsec;
	sprintf(msg,"scdr=%Lg\n",scdr);
	info(msg);
	if(scdr<0){
	  scdr=-scdr;
	};
	int j=0;
	for(int i=0;i<f.dim;i++){
	  if(*(omit+j)==i){
	    j++;
	  }else{
	    *(t2+i)+=(*(t+i)/scdr)*2;
	  };
	};
	len=0;
	for(int i=0;i<f.dim;i++){
	  len+=*(t2+i)*(*(t2+i));
	};
	len=sqrt(len);
	};*/
      sprintf(msg,"Step size=%Lg",len);
      info(msg);//This should almost be output even in quiet mode.
      //      if(ZERO(len)){
      //	break;
      //      };
      for(int i=0;i<f.dim;i++){
	*(start+i)+=*(t2+i);
      };
      if(!vars.seektag("-noautobackup")){//Backup current state.
	CurrentState->clear(stv);
	sigset_t all;
	sigset_t old;
	sigfillset(&all);
	sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
	CurrentState->save();
	sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
      };
      for(int i=0;i<f.dim;i++){
	*(last+i)=*(t2+i);
      };
      oldlen=len;
      if(s<steps/2){
	pen-=initpen*2/steps;
      };
    };
  };
  for(unsigned int i=0;i<(unsigned)f.dim;i++){
    *(start+i)=*(best+i);//Revert to best solution found.
  };
  delete[] best;    
  delete[] hess;
  delete[] t2;
  delete[] t;
  delete[] last;
  delete[] omit;
  delete[] excessmoves;    
  return (s<steps);
};

int NewtonRaphsonExp(function& f,long double *start,long unsigned steps,int op,int numposvals){
  //All positive values are required to be first. Positive values are
  //regarded as exponentials of general values.
  //Doesn't seem to work very well.
  long double *t=new long double[f.dim];
  long double *t2=new long double[f.dim];
  long double *hess=new long double[f.dim*f.dim];
  long double *last=new long double[f.dim];
  long double oldlen=0;
  long unsigned int s;
  long double maxstep=100;
  for(s=0;s<steps;s++){
    cout<<"Started step number "<<s+1<<".\n";
    cout<<"Value="<<f.evaluate(start)<<".\n";
    f.hessian(start,hess);
    f.deriv(start,t);
    for(int i=0;i<numposvals;i++){
      *(t+i)*=*(start+i);
      for(int j=0;j<f.dim;j++){
	*(hess+i*f.dim+j)*=*(start+i);
	*(hess+j*f.dim+i)*=*(start+i);
      };
    };
    long double l2=0;
    for(int i=0;i<f.dim;i++){
      l2+=*(t+i)*(*(t+i));
    };
    l2=sqrt(l2);
    try{
      solve(hess,t,t2,f.dim);
    }catch(int slv){
      if(slv==0){//matrix singular
	cout<<"Singular Hessian matrix, using steepest descent instead.\n";
	for(int i=0;i<f.dim;i++){
	  *(t2+i)=*(t+i);
	};
      }else{
	throw;
      };
    };
    long double len=0;
    for(int i=0;i<f.dim;i++){
      len+=*(t2+i)*(*(t2+i));
    };
    cout<<"Square of attempted step size is "<<len<<".\n";
    len=sqrt(len);
    if(ZEROST(len)){
      break;
    };
    cout<<"Attempted step size="<<len<<"\n";
    long double dot=0;
    for(int i=0;i<f.dim;i++){
      dot+=*(t+i)*(*(t2+i));
    };
    dot/=(len*l2);
    cout<<"Angle between steepest and actual descent="<<dot<<"\n";
    //Small values here tend to indicate a problem with convergence.
    if(len>maxstep){//too big a step
      for(int i=0;i<f.dim;i++){
	*(t2+i)*=maxstep/len;
      };
      cout<<"Step size="<<maxstep<<"\n";
    }else{
      cout<<"Step size="<<len<<"\n";
    };
    if(op==MAXIMISE){
      for(int i=0;i<numposvals;i++){
	*(start+i)*=exp(*(t2+i));
      };
      for(int i=numposvals;i<f.dim;i++){
	*(start+i)+=*(t2+i);
      };
    }else if(op==MINIMISE){
      for(int i=0;i<numposvals;i++){
	*(start+i)/=exp(*(t2+i));
      };
      for(int i=numposvals;i<f.dim;i++){
	*(start+i)-=*(t2+i);
      };
    }else{
      cerr<<"Operation "<<op<<" not currently supported for Newton-Raphson";
      cerr<<" method.\nTry one of the macros \"MAXIMISE\" or \"MINIMISE\".\n";
      return -1;
      //Possibly could input an operation, but maybe this isn't sensible.
    };
    if(s>0&&NONZEROST(len)){
      long double comp=0;
      for(int i=0;i<f.dim;i++){
	comp+=*(last+i)*(*(t2+i));
      };
      comp/=(len*oldlen);//Now comp is the change in direction.
      cout<<"Change in direction is "<<comp<<".\n";
      maxstep*=(1+comp/2)*(1+comp/2);
      cout<<"New maximum step size is "<<maxstep<<".\n";
    };
    for(int i=0;i<f.dim;i++){
      *(last+i)=*(t2+i);
      oldlen=len;
    };
  };
  delete[] hess;
  delete[] t2;
  delete[] t;
  delete[] last;
  return (s<steps);
};

int Gradient(function& f,long double *start,long unsigned steps,int op,int numposvals){//All positive values are required to be first.
  //applies the method of steepest ascent/descent.

  long double *t=new long double[f.dim];
  long double *last=new long double[f.dim];
  long double oldlen=0;
  long unsigned int s;
  long double stepfact=1;
  long double lastv=0;
  long double maxstep=1;
  long double lastlen=0;
  for(s=0;s<steps;s++){
    cout<<"Started step number "<<s+1<<".\n";
    long double currval=f.evaluate(start);
    cout<<"Value="<<currval<<".\n";
    f.deriv(start,t);
    long double len=0;
    for(int i=0;i<f.dim;i++){
      len+=*(t+i)*(*(t+i));
    };
    len=sqrt(len);
    if(s>0){
      if(currval>=lastv){
	stepfact=min(10*(currval-lastv)/lastlen,1/currval);
      }else{
	cout<<"Last step decreased value.\n";
	stepfact*=max(sqrt((lastv-currval)/(len*10)),0.5);
      };
    }else{
      stepfact=(1/currval);
    };
    len*=stepfact;
    for(int i=0;i<f.dim;i++){
      *(t+i)*=stepfact;
    };
    if(ZEROST(len)){
      //      cout<<"Attempted step size: "<<len<<". Terminating.\n";
      break;
    };
    cout<<"Attempted step size="<<len<<"\n";
    if(len>maxstep){//too big a step
      for(int i=0;i<f.dim;i++){
	*(t+i)*=maxstep/len;
      };
      cout<<"Step size="<<maxstep<<"\n";
    }else{
      cout<<"Step size="<<len<<"\n";
    };
    long double *excessmoves=new long double[numposvals];
    if(op==MAXIMISE){
      //positivity test
      long double excessmove=0;
      for(int i=0;i<numposvals;i++){
	*(excessmoves+i)=(*(t+i)+*(start+i))/(*(t+i));
	if(*(t+i)<0&&*(excessmoves+i)>excessmove){//move would result in a negative value
	  excessmove=*(excessmoves+i);
	};
      };
      if(excessmove>0){
	cout<<"Excess move="<<excessmove<<".\n";
	for(int i=0;i<numposvals;i++){
	  if(*(t+i)<0&&*(excessmoves+i)>0){
	    cout<<"For variable "<<i<<", current value="<<*(start+i)<<", attempted move="<<*(t+i)<<".\n";
	    long double fac=-1;//(1-*(excessmoves+i))*(1-1e-16);
	    *(t+i)*=fac;
	  };
	};
	len=getlength(t,f.dim);
	cout<<"Adjusted step size="<<len<<".\n";
      };
      for(int i=0;i<f.dim;i++){
	*(start+i)+=*(t+i);
      };
    }else if(op==MINIMISE){
      //positivity test
      long double excessmove=0;
      for(int i=0;i<numposvals;i++){
	*(excessmoves+i)=(*(t+i)-*(start+i))/(*(t+i));
	if(*(t+i)>0&&*(excessmoves+i)>excessmove){//move would result in a negative value
	  excessmove=*(excessmoves+i);
	};
      };
      if(excessmove>0){
	for(int i=0;i<numposvals;i++){
	  if(*(t+i)>0&&*(excessmoves+i)>0){
	    long double fac=(1-*(excessmoves+i))*(1-1e-16);
	    *(t+i)*=fac;
	  };
	};
	len=getlength(t,f.dim);
	cout<<"Adjusted step size="<<len<<".\n";
      };
      for(int i=0;i<f.dim;i++){
	*(start+i)-=*(t+i);
      };
    }else{
      cerr<<"Operation "<<op<<" not currently supported for Newton-Raphson";
      cerr<<" method.\nTry one of the macros \"MAXIMISE\" or \"MINIMISE\".\n";
      return -1;
      //Possibly could input an operation, but maybe this isn't sensible.
    };
    if(s>0&&NONZEROST(len)){
      long double comp=0;
      for(int i=0;i<f.dim;i++){
	comp+=*(last+i)*(*(t+i));
      };
      comp/=(len*oldlen);//Now comp is the change in direction.
      cout<<"Change in direction is "<<comp<<".\n";
      maxstep*=(1+comp/2)*(1+comp/2);
      cout<<"New maximum step size is "<<maxstep<<".\n";
    };
    for(int i=0;i<f.dim;i++){
      *(last+i)=*(t+i);
    };
    oldlen=len;
    lastv=currval;
    lastlen=len;
  };
  delete[] t;
  delete[] last;

  return(s<steps);

};

long double firstmax(onedfunction& f,long double lb, long double ub,int op){
  //Finds the first maximum or minimum of the function in the interval
  //between lb and ub. 
#define MAXTIMES 100
#define SMALLVAL 1e-10
  long double d=f.deriv(lb);
  long double x=lb;
  long double h=f.secder(lb);
  if((d<=SMALLVAL&&op==MAXIMISE)||(d>=-SMALLVAL&&op==MINIMISE)){
    if(NONZERO(d)){
      cout<<"x="<<lb<<"\td="<<d<<"\n";
      return lb;
    }else{
      if((h<0&&op==MAXIMISE)||(h>0&&op==MINIMISE)){
	//      cout<<"d=0, h="<<h<<"\n";
	return lb;
      }else{
	x+=1e-6;
      };
    };
  };
  long double l=lb;
  if(h*d>0){
    x+=d/h;
  }else{
    x-=d/h;
  };
  for(int i=0;i<MAXTIMES;i++){
    if(x>ub){
      x=ub;
    };
    d=f.deriv(x);
    if(x==ub&&((d>0&&op==MAXIMISE)||(d<0&&op==MINIMISE))){
      return x;
    };
    if(ZERO(d)){
      return x;
    };
    long double h=f.secder(x);
    if((d<0&&op==MINIMISE)||(d>0&&op==MAXIMISE)){
      l=x;
    };
    if((h>-SMALLVAL&&op==MAXIMISE)||(h<SMALLVAL&&op==MINIMISE)){
      x=(x+l)/2;
    }else{
      x-=d/h;
    };
  };
  return lb-1;
};

long double *maxima(onedfunction& f,long double lb, long double ub,int op){
  //Finds the maxima of the function in the interval between lb and
  //ub. Return value is an array of maxima, terminated by a value
  //below the lower bound lb.
  ldlist ans;
  long double epsilon=1;
  long double *buff=new long double[BUFFERSIZE];
  long double x=lb;
  long double xl=lb;
  int i=0;
  for(;x<ub;){
    x=firstmax(f,x,ub,op);
    if(x<xl)break;
    *(buff+i++)=x;
    if(i==BUFFERSIZE){
      ans.insert(BUFFERSIZE,buff);
      i=0;
    };
    x=firstmax(f,x+epsilon,ub,OTHEROP(op));
    if(x<xl)break;
    xl=x;
  };
  int s=ans.size();
  long double *an=new long double[s+i+1];
  ans.extract(an);
  for(int j=0;j<i;j++){
    *(an+s+j)=*(buff+j);
  };
  *(an+s+i)=lb-1;
  ans.remove();
  delete[] buff;
  return an;
};

long double *constrainedOptimum(int m,int n,long double **constraints,long double * vals,long double *start){
  //Finds the nearest point to the origin subject to the constraints
  //start is the initial point - it should be a point satisfying the
  //constraints.

  //m is the number of constraints, n is the number of dimensions
  //constraints is the matrix of slopes of constraints
  //vals is the distance of the coefficients from the origin
  //start is the start point.


  long double **cns=new long double *[m+1];
  long double *coeffs=new long double[n];
  for(int i=0;i<n;i++){
    *(coeffs+i)=0;
  };
  long double *cfs=new long double[n*n];
  int *T=new int[m];
  for(int i=0;i<m;i++){
    *(T+i)=0;
  };
  long double *x=new long double[n];
  long double *GS=new long double[n*n];
  *cns=x;
  for(int i=0;i<n;i++){
    *(x+i)=0;
  }; 
  int numcon=0;
  long double sl;
  for(int fc=1;fc!=-1&&numcon<n;){
    long double violate=2;
    fc=-1;
    for(int i=0;i<m;i++){
      if(*(T+i)==0){
	long double slk1=0;
	long double slk2=0;
	for(int j=0;j<n;j++){
	  slk1+=*(*(constraints+i)+j)*(*(start+j));
	  slk2-=*(*(constraints+i)+j)*(*(x+j));
	};
	if(slk2<*(vals+i)){
	  long double v=(slk1-*(vals+i))/(slk1-slk2);
	  if(v<violate){
	    violate=v;
	    fc=i;
	    sl=slk2;
	  };
	};
      };
    };
    //Now fc is the condition which first gets violated on the path
    //from start to the target.
    if(violate<1.5 && numcon<n){//Some condition unsatisfied by x
      for(int i=0;i<n;i++){
	*(start+i)*=(1-violate);
	*(start+i)-=*(x+i)*violate;
      };
      //Move start towards x until it becomes constrained.
      *(T+fc)=1;
      for(int i=0;i<n;i++){
	*(GS+numcon*n+i)=*(*(constraints+fc)+i);
      };
      for(int i=0;i<numcon;i++){
	long double dt=0;
	for(int j=0;j<n;j++){
	  dt+=*(GS+i*n+j)*(*(GS+numcon*n+j));
	};
	*(cfs+numcon*n+i)=-dt;
	for(int j=0;j<n;j++){
	  *(GS+numcon*n+j)-=*(GS+i*n+j)*dt;
	};
      };
      *(cfs+numcon*(n+1))=1;
      long double dt=0;
      for(int j=0;j<n;j++){
	dt+=*(GS+numcon*n+j)*(*(GS+numcon*n+j));
      };
      if(dt>1e-20){
	dt=sqrt(dt);
	for(int j=0;j<n;j++){
	  *(GS+numcon*n+j)/=dt;
	};
	for(int j=0;j<=numcon;j++){
	  *(cfs+numcon*n+j)/=dt;
	};
      };
      long double xs=0;
      long double ys=0;
      for(int i=0;i<n;i++){
	xs-=*(x+i)*(*(*(constraints+fc)+i));//*(x+i));
	ys+=*(GS+numcon*n+i)*(*(*(constraints+fc)+i));
      };
      long double lam=(*(vals+fc)-xs)/ys;
      for(int j=0;j<=numcon;j++){
	*(coeffs+j)+=*(cfs+numcon*n+j)*lam;
      };
      for(int i=0;i<n;i++){
	*(x+i)-=*(GS+numcon*n+i)*lam;
      };
      long double modx=0;
      long double mods=0;
      for(int i=0;i<n;i++){
	modx+=*(x+i)*(*(x+i));
	mods+=*(start+i)*(*(start+i));
      };
      //      cout<<modx<<"  "<<mods<<"\n\n";
      //Now x should be the optimum where the constraints ... hold exactly.
      numcon++;
    };
  };
  //Now -x is a feasible solution. (modulo rounding errors)
  //  for(int i=0;i<n;i++){
  //    *(x+i)*=-1;
  //  };
  //  return x;

  int numiter=1;
  while(true){
    int npos=0;
    int *pl=T;
    for(;pl-T<m&&*pl==0;pl++);
    for(int i=0;i<numcon;i++){      
      if(*(coeffs+i)<-1e-5){
	*pl=0;
	npos++;
      };
      for(pl++;pl-T<m&&*pl==0;pl++);
    };
    if(npos==0){//This is optimal
      delete[] coeffs;
      delete[] cfs;
      delete[] cns;
      delete[] GS;
      delete[] T;
      for(int i=0;i<n;i++){
	*(x+i)*=-1;
      };
      return x;
    };
    int fc=-1;
    long double *nx=new long double[n];
    do{
      for(int i=0;i<n;i++){
	*(nx+i)=0;
      };
      numcon=0;
      for(int i=0;i<n;i++){
	*(coeffs+i)=0;
      };
      for(int i=0;i<m;i++){
	for(;i<m&&*(T+i)==0;i++);
	if(i==m){
	  break;
	};
	for(int j=0;j<n;j++){
	  *(GS+numcon*n+j)=*(*(constraints+i)+j);
	};
	for(int j=0;j<numcon;j++){
	  long double dt=0;
	  for(int k=0;k<n;k++){
	    dt+=*(GS+j*n+k)*(*(GS+numcon*n+k));
	  };
	  *(cfs+numcon*n+j)=-*(cfs+j*(n+1))*dt;
	  for(int k=0;k<j;k++){
	    *(cfs+numcon*n+k)-=*(cfs+j*n+k)*dt;
	  };
	  for(int k=0;k<n;k++){
	    *(GS+numcon*n+k)-=*(GS+j*n+k)*dt;
	  };
	};
	*(cfs+numcon*(n+1))=1;
	long double dt=0;
	for(int k=0;k<n;k++){
	  dt+=*(GS+numcon*n+k)*(*(GS+numcon*n+k));
	};
	if(dt>1e-20){
	  dt=sqrt(dt);
	  for(int k=0;k<n;k++){
	    *(GS+numcon*n+k)/=dt;
	  };
	  for(int k=0;k<=numcon;k++){
	    *(cfs+numcon*n+k)/=dt;
	  };
	};
	long double xs=0;
	long double ys=0;
	for(int j=0;j<n;j++){
	  xs-=*(nx+j)*(*(*(constraints+i)+j));//*(x+i));
	  ys+=*(GS+numcon*n+j)*(*(*(constraints+i)+j));
	};
	long double lam=(*(vals+i)-xs)/ys;
	for(int j=0;j<=numcon;j++){
	  *(coeffs+j)+=*(cfs+numcon*n+j)*lam;
	};
	for(int j=0;j<n;j++){
	  *(nx+j)-=*(GS+numcon*n+j)*lam;
	};
	numcon++;
      };	
      numiter++;	
      //Check other constraints
      long double violate=2;
      fc=-1;
      if(numcon<n){
	for(int i=0;i<m;i++){
	  if(*(T+i)==0){
	    long double slk1=0;
	    long double slk2=0;
	    for(int j=0;j<n;j++){
	      slk1-=*(*(constraints+i)+j)*(*(x+j));
	      slk2-=*(*(constraints+i)+j)*(*(nx+j));
	    };
	    if(slk2<*(vals+i)-1e-5){
	      long double v=(slk1-*(vals+i))/(slk1-slk2);
	      if(v<violate){
		violate=v;
		fc=i;
		sl=slk2;
	      };
	    };
	  };
	};
	if(fc>-1){
	  *(T+fc)=1;
	  numcon++;
	  for(int i=0;i<n;i++){
	    *(x+i)*=1-violate;
	    *(x+i)+=*(nx+i)*violate;
	  };
	}else{
	  for(int i=0;i<n;i++){
	    *(x+i)=*(nx+i);
	  };
	};
      };
    }while(fc>-1);
    delete[] nx;
  };
};


/*
void subsolve(const long double *M,const long double *v,long double *w,int dim,const int* omit){
  //Solves a subsystem of the given equations and variables omitting
  //rows and columns in the the list omit, which is terminated by a
  //number outside the range -- eg a negative number.
  //Throws an integer exception with value 0 in the event of a singular matrix.
  const int *om=omit;
  Realmatrix m(dim,M);
  long double *v0=new long double[dim];
  for(int i=0;i<dim;i++){
    *(v0+i)=*(v+i);
  };
  long double scale=*M;//This gives an idea of the typical matrix
		       //entry size, to give some indication of
		       //whether the matrix is close to being singular
		       //(which will introduce numerical errors).
  for(int r=0;r<dim;r++){
    if(fabs(*(M+r*dim))>scale){
      scale=fabs(*(M+r*dim));
    };
  };
  for(int c=1;c<dim;c++){
    long double mx=*(M+c);
    for(int r=0;r<dim;r++){
      if(fabs(*(M+r*dim+c))>mx){
	mx=fabs(*(M+r*dim+c));
      };
    };
    if(mx<scale){
      scale=mx;
    };
  };
  for(int i=0;i<dim-1;i++){
    try{
      if(*om==i){//ignore this row.
	om++;
	continue;
      };
      long double mmod=0;
      int mxrw=i;
      const int* o=om;
      for(int j=i;j<dim;j++){
	if(*o==j){
	  o++;
	  continue;//ignore this row
	};
	long double e=(*(m.entries+j*dim+i)<0)?-*(m.entries+j*dim+i):*(m.entries+j*dim+i);
	if(mmod<e){
	  mmod=e;
	  mxrw=j;
	};
      };
      if(ZEROST(mmod/scale)){
	throw(0);//singular matrix
      };
      if(mxrw!=i){
	mmod=*(v0+i);
	*(v0+i)=*(v0+mxrw);
	*(v0+mxrw)=mmod;
	m.swaprows(i,mxrw);
      };
      //      cout<<*(v0+i)<<" ";
      for(int j=i+1;j<dim;j++){
	long double pivot=*(m.entries+j*dim+i)/(*(m.entries+i*dim+i));
	*(m.entries+j*dim+i)=0;
	for(int k=i+1;k<dim;k++){
	  *(m.entries+j*dim+k)-=*(m.entries+i*dim+k)*pivot;
	};
	*(v0+j)-=*(v0+i)*pivot;
	//	cout<<*(v0+j)<<" ";
      };
      //      cout<<"\n";
    }catch(int fpe){
      throw;
    };
  };
  //  cout<<"\n";
  //  for(int i=0;i<dim;i++){
  //    cout<<*(v0+i)<<"\n";
  //  };
  //  cout<<"\n";
  if(ZEROST(*(m.entries+dim*dim-1)/scale)){
    throw(0); //Matrix is singular;
  };
  //  cout<<m;
  if(*om!=dim-1){
    om--;
  };
  for(int i=dim-1;i>=0;i--){
    if(om>=omit && *om==i){
      //      cout<<"omitting row "<<i<<"\n";
      om--;
    }else{      
      *(w+i)=*(v0+i)/(*(m.entries+i*(dim+1)));
      for(int j=0;j<i;j++){
	*(v0+j)-=*(w+i)*(*(m.entries+j*dim+i));
      };
    };
  };
  delete[] v0;
};

*/
