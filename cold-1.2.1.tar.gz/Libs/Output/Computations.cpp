/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Computations.h"
#include "ErrorHandler.h"
#include <iostream>
using namespace std;

/*
class intcomp{//A computation to produce an integer
  const int *ans;
  const int *(*getval)();
public:
  intcomp(const int *(*gv)()){ans=NULL;getval=gv;};
  intcomp(const long double *(*gv)());
  intcomp(void (*gv)(ostream& out));
  int lookup(int i);
};
*/

intcomp::intcomp(const long double *(*gv)()){
  fatalError("Compilation error: Mismatched type in .placeholders file");
};

intcomp::intcomp(void (*gv)(ostream& out)){
  fatalError("Compilation error: Mismatched type in .placeholders file");
};

int intcomp::lookup(int i){
  if(i==-1){
    throw(0);
  };
  if(ans==NULL){
    ans=(*getval)();
  };
  return *(ans+i);
};

/*
class ldcomp{//A computation to produce a long double
  const long double *ans;
  const long double *(*getval)();
public:
  ldcomp(const long double *(*gv)());
  ldcomp(const int *(*gv)());
  ldcomp(void (*gv)(ostream& out));
  ldcomp(const long double *a);
  long double lookup(int i);
};
*/

ldcomp::ldcomp(const long double *(*gv)()){
  ans=NULL;
  getval=gv;
};

ldcomp::ldcomp(const long double *a){
  ans=a;
  getval=NULL;
};

ldcomp::ldcomp(const int *(*gv)()){
  fatalError("Compilation error: Mismatched type in .placeholders file");
};

ldcomp::ldcomp(void (*gv)(ostream& out)){
  fatalError("Compilation error: Mismatched type in .placeholders file");
};


long double ldcomp::lookup(int i){
  if(i==-1){
    throw(0);
  };
  if(ans==NULL){
    ans=(*getval)();
  };
  return *(ans+i);
};

/*
class strcomp{//A computation to produce a string
  void (*getval)(ostream&);
public:
  strcomp(void (*gv)(ostream&)){getval=gv;};
  strcomp(const int *(*gv)());
  strcomp(const long double *(*gv)());
  void lookup(ostream&out);
};
*/

strcomp::strcomp(const int *(*gv)()){
  fatalError("Compilation error: Mismatched type in .placeholders file");
};

strcomp::strcomp(const long double *(*gv)()){
  fatalError("Compilation error: Mismatched type in .placeholders file");
};

void strcomp::lookup(ostream &out){
  (*getval)(out);
};
