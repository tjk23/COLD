/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include<string.h>
#include<iostream>
#include<stdlib.h>
using namespace std;
#include "Miscellaneous.h"

class indexentry{
public:
  indexentry(const char *l,int j);
  char c;
  int i;
  indexentry *match;
  indexentry *next;
  indexentry *prev;
  void remove();
  void print();
  void print(char *k);
};

void indexentry::print(){
  char k[100];
  *k='\0';
  this->print(k);
};

void indexentry::print(char *k){
  if(prev!=NULL){
    prev->print(k);
  };
  if(match==NULL){
    cout<<k<<c<<"\n";
  }else{
    char *ke=k+strlen(k);
    *ke=c;
    *(ke+1)='\0';
    match->print(k);
    *ke='\0';
  };
  if(next!=NULL){
    next->print(k);
  };
};

void indexentry::remove(){
  if(match!=NULL){
    match->remove();
    delete match;
  };
  if(prev!=NULL){
    prev->remove();
    delete prev;
  };
  if(next!=NULL){
    next->remove();
    delete next;
  };
};

indexentry::indexentry(const char *l,int j){
  c=*l;
  prev=NULL;
  next=NULL;
  if(*(l+1)=='\0' || *(l+1)==' ' || *(l+1)=='\t' || *(l+1)=='\r' || *(l+1)=='\n'){
    match=NULL;
    i=j;
  }else{
    i=-1;
    match=new indexentry(l+1,j);
  };
};

class Index{
  indexentry *start;
public:
  Index(){start=NULL;};
  int lookup(istream &s);
  int lookup(const char *s);
  void insert(const char *ent,int i);
  void insert(istream& s);
  void insert(int num,const char *data[]);
  void print();
  ~Index();
};

void Index::print(){
  start->print();
};

Index::~Index(){
  if(start!=NULL){
    start->remove();
    delete start;
  };
};

void Index::insert(istream& s){
  while(s.good()&&!s.eof()){
    char* ent=readnonemptystring(s," \t\r\n");
    char* num=readnonemptystring(s,"\n");
    int i=atoi(num);
    this->insert(ent,i);
    delete[] ent;
    delete[] num;
  };
};

void Index::insert(int num,const char *data[]){
  for(int i=0;i<num;i++){
    int j=0;
    for(;*(data[i]+j)==' '&&*(data[i]+j)=='\t'&&*(data[i]+j)=='\r';j++);
    int k=j;
    for(;*(data[i]+j)!=' '&&*(data[i]+j)!='\t'&&*(data[i]+j)!='\r';j++);
    char *temp=new char[j-k+1];
    for(int l=0;l<j-k;l++){
      *(temp+l)=*(data[i]+k+l);
    };
    *(temp+j-k)='\0';
    int ii=atoi(data[i]+j);
    this->insert(temp,ii);
    delete[] temp;
  };
};

void Index::insert(const char *ent,int i){
  //  cout<<ent<<" "<<i<<"\n";
  if(start==NULL){
    start=new indexentry(ent,i);
    return;
  };
  const char *l=ent;
  indexentry* current=start;
  for(;*l&&*l!=' '&&*l!='\t'&&*l!='\r'&&*l!='\n';){
    if(*l==current->c){
      l++;
      if(*l=='\0'||*l==' '||*l=='\t'||*l=='\r'||*l=='\n'){
	current->i=i;
	return;
      };
      if(current->match==NULL){
	current->match=new indexentry(l,i);
	return;
      }else{
	current=current->match;
      };
    }else if(*l<current->c){
      if(current->prev==NULL){
	current->prev=new indexentry(l,i);
	return;
      }else{
	current=current->prev;
      };
    }else{
      if(current->next==NULL){
	current->next=new indexentry(l,i);
	return;
      }else{
	current=current->next;
      };
    };
  };
};

int Index::lookup(istream &s){
  indexentry* current=start;
  for(char c=s.get();s.good()&&!s.eof()&&c!=' '&&c!='\t'&&c!='\r'&&c!='\n';){
    if(c==current->c){
      c=s.get();
      if(!s.good()||s.eof()||c==' '||c=='\t'||c=='\r'||c=='\n'){
	return current->i;
      };
      if(current->match==NULL){
	return -1;
      }else{
	current=current->match;
      };
    }else if(c<current->c){
      if(current->prev==NULL){
	return -1;
      }else{
	current=current->prev;
      };
    }else{
      if(current->next==NULL){
	return -1;
      }else{
	current=current->next;
      };
    };
  };
  return -1;
};

int Index::lookup(const char *s){
  indexentry* current=start;
  for(char c=*s;c&&c!=' '&&c!='\t'&&c!='\r'&&c!='\n';){
    if(c==current->c){
      c=*(++s);
      if(c=='\0'||c==' '||c=='\t'||c=='\r'||c=='\n'){
	return current->i;
      };
      if(current->match==NULL){
	return -1;
      }else{
	current=current->match;
      };
    }else if(c<current->c){
      if(current->prev==NULL){
	return -1;
      }else{
	current=current->prev;
      };
    }else{
      if(current->next==NULL){
	return -1;
      }else{
	current=current->next;
      };
    };
  };
  return -1;
};

/*
class MarkupCommands{//A set of possible markup commands.
  Index commandnumbers;
  ostream *out;
public:
  MarkupCommands(const char *filename){ifstream in(filename);commandnumbers.insert(in);};
  MarkupCommands(int num=NUMMARKUPCOMMANDS,const char *data[]=markupcommands){commandnumbers.insert(num,data);};
  void setstream(ostream &o){out=o;};
  int find(istream& s);//checks whether the given option is a valid markup command
  int find(const char *s);
  void apply(int i,char c);
  void end(int i);
  void begin(int i);
};

int MarkupCommands::find(istream &s){
  return commandnumbers.lookup(s);
};

int MarkupCommands::find(const char *s){
  return commandnumbers.lookup(s);
};
*/
//#include "Markup.cpp"
