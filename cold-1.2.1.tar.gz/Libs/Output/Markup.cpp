/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <stdlib.h>
#include <sstream>
#include <fstream>
#include <string.h>
#include <ctype.h>
#include <math.h>
using namespace std;

const char *mode=NULL;

void setoutputmode(const char *md){
  mode=md;
};

const char *getoutputmode(){
  return mode;
};



class MarkupElement{
public:
  int priority;

  virtual void setup(istream &in){};
  virtual void process(const char *in,char *out)=0;
  virtual void end(ostream &out){};
  virtual void start(ostream &out){};
};

class HTML: public MarkupElement{
  static int parmode;
  const char *oldmode;
public:
  HTML(){priority=150;parmode=-1;};
  void process(const char *in,char *out);
  void end(ostream &out);
  void start(ostream &out);
  static void setparmode(int i){parmode=i;};
};

int HTML::parmode;

void HTML::start(ostream &out){
  oldmode=getoutputmode();
  setoutputmode("html");
  out<<"<html><head><title>Cold output</title>\n</head><BODY TEXT=\"#000000\" LINK=\"#0000FF\" VLINK=\"#4F006F\" BGCOLOR=\"#FFFFFF\">\n";

};

void HTML::end(ostream &out){
  out<<"</body></html>\n";
  setoutputmode(oldmode);
};


void HTML::process(const char *in,char *out){
  int i=0;
  int j=0;
  for(;*(in+i);i++){
    if(parmode==-1){
      *(out+i+j++)='<';
      *(out+i+j++)='p';
      *(out+i+j++)='>';
      parmode=0;      
    };
    if(*(in+i)=='\n'&&parmode==0){
      *(out+i+j++)='<';
      *(out+i+j++)='/';
      *(out+i+j++)='p';
      *(out+i+j++)='>';
      parmode=-1;
    };
    *(out+i+j)=*(in+i);
  };
  *(out+i+j)=0;
};



class Uppercase: public MarkupElement{
public:
  Uppercase(){priority=0;};
  void process(const char *in,char *out){int i=0;for(;*(in+i);i++){*(out+i)=toupper(*(in+i));};*(out+i)=0;};
};

class Underline: public MarkupElement{
public:
  Underline(){priority=2;};
  void process(const char *in,char *out){int i=0;for(;*(in+i);i++){*(out+2*i)=*(in+i);*(out+2*i+1)='_';};*(out+2*i)=0;};
};

class UnderlineHTML: public MarkupElement{
public:
  UnderlineHTML(){priority=2;};
  void start(ostream &out){out<<"<u>";};
  void end(ostream &out){out<<"</u>";};
  void process(const char *in,char *out){int i=0;for(;*(in+i);i++){*(out+i)=*(in+i);};*(out+i)=0;};
};


class Striplower: public MarkupElement{
public:
  Striplower(){priority=1;};
  void process(const char *in,char *out){int j=0;for(int i=0;*(in+i);i++){if(isupper(*(in+i))){*(out+j++)=*(in+i);};};*(out+j)=0;};
};



class Table: public MarkupElement{
  int numcols;
  int colnum;
  int *widths;
  char *formats;
  char *colbuff;
  int colbufflen;
  int numspace;
  void putcol(char *&o);
public:
  void setup(istream& in);
  void process(const char *in,char *out);
  Table(){colnum=0;priority=100;widths=NULL;formats=NULL;numspace=0;colbufflen=0;};//Table formatting should be left to last.
  void end(ostream &out){if(colnum<numcols){char *x=new char[colbufflen+*(widths+colnum)+2];char *c=x;this->putcol(c);*c='\0';out<<x;delete[] x;};delete[] colbuff;delete[] formats;delete[] widths;};
};

void Table::setup(istream& in){
  streampos s=in.tellg();
  //first just count columns
  numcols=1;
  for(char c='\0';in.good()&&in.peek()!='\n';c=in.get()){
    if(c=='&'||c=='\t'){
      numcols++;
    };
  };
  in.seekg(s);
  formats=new char[numcols];
  widths=new int[numcols];
  int maxwid=0;
  for(int i=0;i<numcols;i++){
    *(widths+i)=0;
    *(formats+i)='c';
    for(;in.good()&&in.peek()!='&'&&in.peek()!='\r'&&in.peek()!='\n'&&in.peek()!='\t';in.get()){
      if(in.peek()>='0'&&in.peek()<='9'&&*(widths+i)==0){
	for(;in.peek()>='0'&&in.peek()<='9';in.get()){
	  *(widths+i)*=10;
	  *(widths+i)+=in.peek()-'0';
	};
      };
      if(in.good()&&(in.peek()=='c'||in.peek()=='r'||in.peek()=='l')){
	*(formats+i)=in.peek();
      };
      if(in.peek()=='&'){
	break;
      };
    };
    in.get();
    if(*(widths+i)>maxwid){
      maxwid=*(widths+i);
    };
  };
  colbuff=new char[maxwid+2];
};

void Table::putcol(char *&o){
  if(colnum<numcols){
    switch(*(formats+colnum)){
    case 'l':
      for(int k=0;k<colbufflen;k++){
	*(o++)=*(colbuff+k);
      };
      for(int k=colbufflen;k<=*(widths+colnum);k++){
	*(o++)=' ';
      };
      break;
    case 'r':
      for(int k=*(widths+colnum)-colbufflen;k>0;k--){
	*(o++)=' ';
      };
      for(int k=0;k<colbufflen;k++){
	*(o++)=*(colbuff+k);
      };
      *(o++)=' ';
      break;
    case 'c':
      for(int k=*(widths+colnum)-colbufflen;k>0;k-=2){
	*(o++)=' ';
      };
      for(int k=0;k<colbufflen;k++){
	*(o++)=*(colbuff+k);
      };
      for(int k=*(widths+colnum)-colbufflen;k>-1;k-=2){
	*(o++)=' ';
      };
      break;
    };
    //    *(o++)='|';
    colbufflen=0;
    numspace=0;
    colnum++;
  };
};

void Table::process(const char *in,char *out){  
  char *o=out;
  *o='\0';
  for(const char *i=in;*i;i++){
    switch(*i){
    case '\n':
      this->putcol(o);
      *(o++)='\n';
      colnum=0;
      break;
    case '&':
      //    case '\t':
      this->putcol(o);
      break;
    case ' ':
      numspace++;
      break;
    default:
      if(colnum<numcols&&colbufflen+numspace<*(widths+colnum)){
	for(;numspace>0;numspace--){
	  *(colbuff+colbufflen++)=' ';
	};
	*(colbuff+colbufflen++)=*i;
      };
    };  
    *o='\0';
  };
};

class TableHTML: public MarkupElement{
  int numcols;
  int colnum;
  int *widths;
  char *formats;
  int tropen;
  int tdopen;

  //  char *colbuff;
  //  int colbufflen;
  //  int numspace;
  void endrow(char *&o);
  void endcol(char *&o);
public:
  void setup(istream& in);
  void process(const char *in,char *out);
  TableHTML();
  void start(ostream &out){HTML::setparmode(-2);out<<"<table><tr>";};
  void end(ostream &out);
};

void TableHTML::end(ostream &out){
  if(tdopen){
    out<<"</td>";
  };
  if(tropen){
    out<<"</tr>";
  };
  out<<"</table>";
  HTML::setparmode(-1);
};


TableHTML::TableHTML(){
  priority=100;
  widths=NULL;
  formats=NULL;
  colnum=0;
  tropen=0;
  tdopen=0;
};//Table formatting should be left to last.

void TableHTML::setup(istream& in){
  streampos s=in.tellg();
  //first just count columns
  numcols=1;
  for(char c='\0';in.good()&&in.peek()!='\n';c=in.get()){
    if(c=='&'||c=='\t'){
      numcols++;
    };
  };
  in.seekg(s);
  formats=new char[numcols];
  int totwidth=0;
  widths=new int[numcols];
  for(int i=0;i<numcols;i++){
    *(widths+i)=0;
    *(formats+i)='c';
    for(;in.good()&&in.peek()!='&'&&in.peek()!='\r'&&in.peek()!='\n'&&in.peek()!='\t';in.get()){
      if(in.peek()>='0'&&in.peek()<='9'&&*(widths+i)==0){
	for(;in.peek()>='0'&&in.peek()<='9';in.get()){
	  *(widths+i)*=10;
	  *(widths+i)+=in.peek()-'0';
	};
      };
      totwidth+=*(widths+i);
      if(in.good()&&(in.peek()=='c'||in.peek()=='r'||in.peek()=='l')){
	*(formats+i)=in.peek();
      };
      if(in.peek()=='&'){
	break;
      };
    };
    in.get();
  };
  for(int i=0;i<numcols;i++){
    *(widths+i)*=100;
    *(widths+i)/=totwidth;
  };
};

void TableHTML::endcol(char *&o){
  if(colnum<numcols&&tdopen){
    *(o++)='<';
    *(o++)='/';
    *(o++)='t';
    *(o++)='d';
    *(o++)='>';
    colnum++;
    tdopen=0;
  };
};

void TableHTML::endrow(char *&o){
  if(tropen){
    if(tdopen){
      *(o++)='<';
      *(o++)='/';
      *(o++)='t';
      *(o++)='d';
      *(o++)='>';
      tdopen=0;
    };
    *(o++)='<';
    *(o++)='/';
    *(o++)='t';
    *(o++)='r';
    *(o++)='>';
    tropen=0;
  };
};


void TableHTML::process(const char *in,char *out){  
  char *o=out;
  *o='\0';
  for(const char *i=in;*i;i++){
    switch(*i){
    case '\n':
      this->endrow(o);
      colnum=0;
      break;
    case '&':
      //    case '\t':
      this->endcol(o);
      break;
    default:
      if(colnum<numcols){
	if(!tropen){
	  *(o++)='<';
	  *(o++)='t';
	  *(o++)='r';
	  *(o++)='>';
	  tropen=1;
	};
	if(!tdopen){
	  switch(*(formats+colnum)){
	  case 'l':
	    sprintf(o,"<td width=\"%d%%\">",*(widths+colnum));
	    break;
	  case 'r':
	    sprintf(o,"<td width=\"%d%%\" align=\"right\">",*(widths+colnum));
	    break;
	  case 'c':
	    sprintf(o,"<td width=\"%d%%\" align=\"center\">",*(widths+colnum));
	  };
	  o+=strlen(o);
	  tdopen=1;
	};
	*(o++)=*i;
      };
    };  
    *o='\0';
  };
};

#define LONGESTMARKUPNAME 40
MarkupElement *getMarkupElement(istream& in){
  //Reads a markup Element from its input stream:
  char temp[LONGESTMARKUPNAME];
  for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\n'||in.peek()=='\r');in.get());//Strip whitespace characters.
  int i=0;
  for(char c=in.get();(i<LONGESTMARKUPNAME-1)&&in.good()&&c!=' '&&c!='\t'&&c!='\n'&&c!='\r';i++){
    temp[i]=c;
    c=in.get();
  };
  temp[i]=0;
  if(mode!=NULL){
    temp[i]='_';
    temp[i+1]='\0';
    strcat(temp,mode);
  };
  for(;in.good()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\n'||in.peek()=='\r');in.get());//Strip whitespace characters.
  //Now compare temp to possible MarkupElements
  MarkupElement *ans;
  if(!strcmp(temp,"upper")){
    ans=new Uppercase();
  }else if(!strcmp(temp,"underline")){
    ans=new Underline();
  }else if(!strcmp(temp,"striplower")){
    ans=new Striplower();
  }else if(!strcmp(temp,"table")){
    ans=new Table();
  }else if(!strcmp(temp,"underline_html")){
    ans=new UnderlineHTML();
  }else if(!strcmp(temp,"upper_html")){
    ans=new Uppercase();
  }else if(!strcmp(temp,"table_html")){
    ans=new TableHTML();
  }else if(!strcmp(temp,"html")){
    ans=new HTML();
  }else if(!strcmp(temp,"upper")){
    ans=new Uppercase();
  }else if(!strcmp(temp,"upper")){
    ans=new Uppercase();
  }else{
    cout<<"\n\n"<<temp<<"\n\n";
    ans=NULL;
  };
  if(ans!=NULL){
    ans->setup(in);
  };
  return ans;
};


#define MARKUPSTACKSIZE 100

class MarkupStack{
  MarkupElement * stack[MARKUPSTACKSIZE];
  int numelts;
  MarkupStack *overflow;
  void apply(int i,const char *in,char *out);
  int getpriority(int i){if(i<MARKUPSTACKSIZE){return stack[i]->priority;}else{return overflow->getpriority(i-MARKUPSTACKSIZE);};};
public:
  ostream &out;
  MarkupStack(ostream &o):out(o){numelts=0;overflow=NULL;};
  ~MarkupStack(){if(numelts>=MARKUPSTACKSIZE){delete overflow;numelts=MARKUPSTACKSIZE;};for(int i=0;i<numelts;i++){delete stack[i];};};
  void apply(const char *in,char *out);
  void push(MarkupElement *mkup);
  void pop();
};

void MarkupStack::apply(int i,const char *in,char *out){
  if(i<MARKUPSTACKSIZE){stack[i]->process(in,out);}else{overflow->apply(i-MARKUPSTACKSIZE,in,out);};
};

#define BUFFERSIZE 10000

void MarkupStack::apply(const char *in,char *out){
  if(numelts>0){
    int maxpri=0;
    for(int i=0;i<numelts;i++){
      if(getpriority(i)>maxpri){
	maxpri=getpriority(i);
      };
    };
    int *count=new int[maxpri+1];
    int *queue=new int[maxpri+1];
    for(int i=0;i<=maxpri;i++){
      *(count+i)=0;
    };
    for(int i=0;i<numelts;i++){
      (*(count+getpriority(i)))++;
    }; 
    int tmp=0;
    for(int i=0;i<maxpri;i++){
      int tmp2=tmp;
      tmp+=*(count+i);    
      *(count+i)=tmp2;
    };
    *(count+maxpri)=tmp;
    for(int i=numelts-1;i>=0;i--){    
      *(queue+(*(count+getpriority(i)))++)=i;
    };
    delete[] count;
    //Now queue is the order in which markup commands need to be applied.
    char temp[BUFFERSIZE];
    const char *current=in;
    char *next=(numelts%2)?out:temp;
    for(int i=0;i<numelts;i++){
      this->apply(*(queue+i),current,next);
      current=next;
      next=(next==temp)?out:temp;
    };
    delete[] queue;
  }else{
    strcpy(out,in);
  };
};

void MarkupStack::push(MarkupElement *mkup){
  if(numelts<MARKUPSTACKSIZE-1){
    stack[numelts]=mkup;
    mkup->start(out);
  }else if(numelts==MARKUPSTACKSIZE-1){
    overflow=new MarkupStack(out);
    overflow->push(mkup);
  }else{
    overflow->push(mkup);
  };
  numelts++;
};

void MarkupStack::pop(){
  numelts--;
  if(numelts<0){
    throw(0);
  };
  if(numelts<MARKUPSTACKSIZE){
    stack[numelts]->end(out);
    delete stack[numelts];
  }else if(numelts==MARKUPSTACKSIZE){
    delete overflow;
  }else{
    overflow->pop();
  };
};

#define READERBUFFERSIZE 200
#define OUTPUTBUFFERSIZE 10000
#define FLUSHLIMIT 180
class MarkupReader{
  istream &in;
  ostream &out;
  MarkupStack ms;
  char openmarkup;
  char closemarkup;  
  char escape;  
  char newline;  
  char buffer[READERBUFFERSIZE];
  int nextpos;
public:
  MarkupReader(istream &i,ostream& o):in(i),out(o),ms(o){openmarkup='<';closemarkup='>';escape='\\';nextpos=0;newline='\n';};
  void getchar();
  void flush(){if(nextpos){*(buffer+nextpos)='\0';char output[OUTPUTBUFFERSIZE];ms.apply(buffer,output);out<<output;nextpos=0;};};
  void read();
  ~MarkupReader();
};

MarkupReader::~MarkupReader(){
   if(mode!=NULL&&!strcmp(mode,"html")){
     ms.pop();
   };
};

void MarkupReader::read(){
  try{
    for(;in.good();this->getchar());
    if(in.bad()){
      cerr<<"Input Stream is Corrupted.\n";
    };
    this->flush();
  }catch(int i){
    switch(i){
    case 0:
      cerr<<"\n\nToo many \'"<<closemarkup<<"\' characters\n";
      break;
    case 1:
      cerr<<"Unrecognised markup command.\n";
      break;
    default:
      cerr<<"Unspecified error in processing file\n";
    };
  };
};

void MarkupReader::getchar(){
  char c=in.get();
  if(!in.eof()){
    if(c==openmarkup){
      this->flush();
      MarkupElement *mk=getMarkupElement(in);
      if(mk==NULL){
	throw 1;//Bad markup element.
      }else{
	ms.push(mk);
      };
    }else if(c==closemarkup){
      this->flush();
      ms.pop();
    }else{
      if(c==escape){
	c=in.get();
      }else if(c==newline){
	c='\n';
      };    
      *(buffer+nextpos++)=c;
      if(nextpos>FLUSHLIMIT){
	this->flush();
      };
    };
  };
};



void markup(istream &in,ostream &out){
  MarkupReader mr(in,out);
  mr.read();
};

