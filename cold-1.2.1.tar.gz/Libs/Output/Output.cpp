/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <stdlib.h>
#include <sstream>
#include <fstream>
#include <math.h>
#include <dlfcn.h>
using namespace std;
#include "Computations.h"
#include "Index.h"

void substitute(istream &in,ostream& out);

const char **Placeholders;
//const char **modifiers;
//extern const
int numplaceholders;
void (*assignfunctions)(void**,int (**)(int),const char *);
static void *lib=NULL;


void closelib(){
  if(lib!=NULL){
    void *addr=dlsym(lib,"clnp");
    if(dlerror()){
      cerr<<"Could not open resolve symbol \"clnp\". Aborting!\n";
      exit(1);
    };
    void (*cleanup)()=*(void (*)())addr;
    (*cleanup)();
    dlclose(lib);
    lib=NULL;
  };
};

void* setPlaceHolders(const char *libname){
  if(lib!=NULL){
    dlclose(lib);
  };
  lib=dlopen(libname,RTLD_NOW);

  if(!lib){
    cerr<<dlerror()<<"\n";
    cerr<<"\'"<<libname<<"\':\n";
    cerr<<"Could not open placeholder library. Aborting!\n";
    exit(1);
  };
  atexit(closelib);
  void *addr=dlsym(lib,"assignfunctions");
  if(dlerror()){
    cerr<<"Could not open resolve symbol \"assignfunctions\". Aborting!\n";
    exit(1);
  };
  assignfunctions=*(void(**)(void**,int(**)(int),const char*))addr;
  addr=dlsym(lib,"nplaceholders");
  if(dlerror()){
    cerr<<"Could not resolve symbol \"numplaceholders\". Aborting!\n";
    exit(1);
  };
  numplaceholders=*(int *)addr;
  addr=dlsym(lib,"placeholderarray");
  if(dlerror()){
    cerr<<"Could not resolve symbol \"placeholders\". Aborting!\n";
    exit(1);
  };
  Placeholders=*(const char ***)addr;
  addr=dlsym(lib,"stp");
  if(dlerror()){
    addr=NULL;
  };
  return addr;
  /*  addr=dlsym(lib,"nummodifiers");
  if(dlerror()){
    cerr<<"Could not open resolve symbol \"nummodifiers\". Aborting!\n";
    exit(1);
  };
  nummodifiers=*(int *)addr;*/
};


#include "ErrorHandler.h"
#include "modifiers.h"
#include "modifiers2.h"

int nummodifiers=NUMMODIFIERS;

int NumCodons=61;
int NumCodonsSq=61*61;

class forloopcounter{//counters for for loop
  int max;
  streampos start;
public:
  int counter;
  forloopcounter(){counter=0;max=1;start=0;};
  forloopcounter(istream &in){counter=0;max=1;start=in.tellg();};
  int closeloop(istream& in){counter++;if(counter<max){in.seekg(start);return 0;}else{return 1;};};
  void reset(istream &in){counter=0;max=1;start=in.tellg();};
  void setmax(int i){if(i>max){max=i;};};
};


#define MAXFORLOOPS 100 //shouldn't need more than 100 nested loops.
class forloopstack{
  forloopcounter loops[MAXFORLOOPS];
public:
  int numloops;
  forloopstack(){numloops=-1;};
  void openloop(istream &in){numloops++;if(numloops<MAXFORLOOPS){loops[numloops].reset(in);}else{throw(MAXFORLOOPS);};};
  void closeloop(istream &in){if(numloops==-1){throw(-1);};if(loops[numloops].closeloop(in)){numloops--;};}
  void setmax(int i){if(numloops>=0){loops[numloops].setmax(i);};};
  void setmax(int i,int j){if(numloops>=j){loops[j].setmax(i);};};
  int getcounter(int i){if(i>numloops){throw(numloops);};return loops[i].counter;};
};

forloopstack loops;

class PlaceHolders{//The possible variables to be included in the output
  void **computations;//These either compute the answer, or lookup a saved answer.
  int (**dims)(int);
  Index names;
  Index mods;
  char *type;//Gives the type of each number.
  char *modparams;//Gives the type of parameters for each modifier.
  /*

    i   int
    e   enum
    d   long double
    s   string
    I   int list
    E   enum list
    D   long double list
    S   string list  

   */
public:
  PlaceHolders(int y=-1,const char *phdata[]=Placeholders,int z=nummodifiers,const char *mddata[]=modifiers);
  ~PlaceHolders();
  int find(istream& i){return names.lookup(i);};
  int find(char *&i){return names.lookup(i);};
  char gettype(int i){return *(type+i);};
  int getmod(istream &i){return mods.lookup(i);};
  int getmod(const char *i){return mods.lookup(i);};
  int getintval(int i);
  long double getdoubval(int i);
  void getstrval(int i,ostream&out);
  int getdim(int i,int d){return (*(dims+i))(d);};//Returns -1 if array has fewer than d dimensions.
  int getnum(int i);
};

PlaceHolders::~PlaceHolders(){
  for(int i=0;i<numplaceholders;i++){
    switch(*(type+i)){
    case 'i':
    case 'I':
    case 'e':
    case 'E':
      delete (intcomp *)*(computations+i);
      break;
    case 'd':
    case 'D':
      delete (ldcomp *)*(computations+i);
      break;
    default:
      delete (strcomp *)*(computations+i);
    };
  };
  delete[] dims;
  delete[] computations;
  delete[] type;
  delete[] modparams;
};
  
int PlaceHolders::getnum(int i){
  //Calculates the current number based on the loop counters
  int j=0;
  int klast=0;
  int k=0;
  do{
    klast=k;
    k=this->getdim(i,j);
    j++;
  }while(k>=0);  
  j--;
  //  loops.setmax(klast);
  int ans=0;
  int offset=loops.numloops+1-j;
  k=1;
  for(int l=j-1;l>=0&&l+offset>=0;l--){
    int gc=loops.getcounter(l+offset);
    int gd=this->getdim(i,l);     
    loops.setmax(gd,l+offset);
    if(gc>=gd){
      return -1;
    };
    ans+=gc*k;
    k*=gd;
  };
  return ans;
};

int PlaceHolders::getintval(int i){
  if(*(type+i)!='i'&&*(type+i)!='I'&&*(type+i)!='e'&&*(type+i)!='E'){
    return -1;//Hopefully an error value.
  };
  return ((intcomp *)*(computations+i))->lookup(this->getnum(i));
};

long double PlaceHolders::getdoubval(int i){
  if(*(type+i)!='d'&&*(type+i)!='D'){
    return -1;//Hopefully an error value.
  };
  return ((ldcomp *)*(computations+i))->lookup(this->getnum(i));
};

void PlaceHolders::getstrval(int i,ostream&out){
  if(*(type+i)!='s'&&*(type+i)!='S'){
    return;
  };
  ((strcomp *)*(computations+i))->lookup(out);
};


PlaceHolders::PlaceHolders(int y,const char *phdata[],int z,const char *mddata[]){
  if(y==-1){
    y=numplaceholders;
  };
  type=new char[y];
  for(int i=0;i<y;i++){
    *(type+i)=*phdata[i];
    int j=1;
    for(;*(phdata[i]+j)==' '||*(phdata[i]+j)=='\t'||*(phdata[i]+j)=='\r'||*(phdata[i]+j)=='\n';j++);
    names.insert(phdata[i]+j,i);
  };
  modparams=new char[z];
  for(int i=0;i<z;i++){
    *(modparams+i)=*mddata[i];
    int j=1;
    for(;*(mddata[i]+j)==' '||*(mddata[i]+j)=='\t'||*(mddata[i]+j)=='\r'||*(mddata[i]+j)=='\n';j++);
    mods.insert(mddata[i]+j,i);
  };
  computations=new void*[numplaceholders];
  typedef int(*dimensionfunctionpointer)(int);
  dims=new dimensionfunctionpointer[numplaceholders];
  (*assignfunctions)(computations,dims,type);
};

class PlaceholderSubstitution{
  const static char openplaceholder='{';
  const static char closeplaceholder='}';
  const static char separate='|';
  const static char endrow=';';
  const static char escape='\\';
  const static char openloop='[';
  const static char closeloop=']';
  const static char* const specialesc;//="t";
  const static char* const specialescout;//="\t";
  PlaceHolders p;
  istream& t;
  ostream& out;
  unsigned int level;//number of levels of conditional statements.
  //  unsigned int markup;//collection of flags indicating various markup formats.
public:
  PlaceholderSubstitution(istream &tmp): t(tmp), out(cout){level=0;};
  PlaceholderSubstitution(istream &tmp,ostream&o): t(tmp), out(o){level=0;};
  PlaceholderSubstitution(const char *otf): t(*new ifstream(otf)), out(cout){level=0;};
  int readchar();//Reads a character in normal mode, and decides what to do with it. Returns 1 if read OK, and 0 if EOF or other error.
  void readplaceholder();//Deals with a placeholder **********
  void closecondition();//reads to the end of the placeholder that started the condition.
  void gotocase(const char *val);
  void start(){while(this->readchar());};
};

const char* const PlaceholderSubstitution::specialesc="t";
const char* const PlaceholderSubstitution::specialescout="\t";

int compare(const char *val,istream &t){
  //returns 1 if the first non-whitespace characters of t up to a : match val;
  const char *v=val;
  for(;t.good()&&(t.peek()==' '||t.peek()=='\t'||t.peek()=='\n'||t.peek()=='\r');t.get());  
  for(;*v==' '||*v=='\t'||*v=='\n'||*v=='\r';v++);
  for(;t.good()&&*v&&*v==t.peek();t.get(),v++);
  if(t.peek()=='*'){
    while(t.good()&&t.get()!=':');
    return 1;
  };
  for(;*v==' '||*v=='\t'||*v=='\n'||*v=='\r';v++);
  for(;t.good()&&(t.peek()==' '||t.peek()=='\t'||t.peek()=='\n'||t.peek()=='\r');t.get());
  return(*v=='\0'&&t.peek()==':');
};

void PlaceholderSubstitution::gotocase(const char *val){  
  for(char c=' ';t.good()&&c!='}'&&!compare(val,t);c=t.get()){
    for(;t.good()&&c&&c!='|'&&c!='}';c=t.peek()){
      if(c==t.peek()){
	t.get();
      };
      if(c=='{'){
	int lev=1;
	for(c=t.get();t.good()&&lev>0;c=t.get()){
	  //	  cout<<c;
	  if(c=='{'){
	    lev++;
	  }else if(c=='}'){
	    lev--;
	  }else if(c=='\\'){
	    t.get();
	  };
	};
	if(lev>0){
	  throw(lev);
	};
      }else if(c=='\\'){
	t.get();
      };
    };
  };//Add default cases, ranges, etc.
  if(t.peek()==':'){
    t.get();
  };
};

void PlaceholderSubstitution::readplaceholder(){
//Should probably rewrite this to use automatically generated code so
//that we can easily extend the available modifiers.
  int i=p.find(t);
  if(i==-1){//No match. Exit.
    this->closecondition();
    return;
  };
  char ty=p.gettype(i);
  try{
    switch(ty){
    case 'i':
    case 'I':
    case 'e':
    case 'E':
      {    
	int v=p.getintval(i);	
	int j=p.getmod(t);
	//      int prec=out.precision();
	switch(j){
	case MODIFIERS_CASES:
	  {
	    char c[100];
	    sprintf(c,"%d",v);//Should update this for enumeration types.
	    gotocase(c);
	    break;
	  };
	default:
	  out<<v;
	};
      };
      break;
    case 'd':
    case 'D':
      //possible modifier "precision" - Note that the number may not be as accurate as the precision, so this may be meaningless.
      {    
	long double val=p.getdoubval(i);
	int j=p.getmod(t);
	int prec=out.precision();
	switch(j){
	case MODIFIERS_PRECISION://Need to improve this to eat the '='
	  for(;t.good()&&!(isdigit(t.peek()))&&t.peek()!='}';t.get());	  
	  t>>prec;
	};
	int oldprec=out.precision(prec);
	out<<val;
	out.precision(oldprec);
	break;
      };
    case 's':
    case 'S':
      {    
	int j=p.getmod(t);
	int prec=out.precision();
	switch(j){
	case MODIFIERS_PRECISION:
	  t>>prec;
	};
	int oldprec=out.precision(prec);
	p.getstrval(i,out);
	out.precision(oldprec);
	break;
      };
    };
  }catch(int err){
    //    cout<<"\n\nerr="<<err<<"\n";
    if(err==0){
      this->closecondition();
      //      return;
    }else{
      throw;
    };
  };
};

void PlaceholderSubstitution::closecondition(){//reads to the end of the placeholder that started the condition.
  unsigned int l=0;
  for(char a=t.get();!t.eof();a=t.get()){
    switch(a){
    case escape:
      t.get();
      break;
    case openplaceholder:
      l++;
      break;
    case closeplaceholder:
      if(l==0){
	level--;
	return;
      };
      l--;
      break;
    };
  };
  //Only get here if condition is badly formated.
  fatalError("Corrupted Output Template file - missing }");
};

int PlaceholderSubstitution::readchar(){
  char a=t.get();
  if(t.eof()){
    return 0;
  };
  switch(a){
  case openplaceholder:
    this->readplaceholder();
    level++;
    break;
  case closeplaceholder:
    if(level==0){
      fatalError("Corrupted Output Template file - missing {");
    };
    level--;
    break;
  case endrow:
    out<<'\n';
    break;
  case openloop:
    loops.openloop(t);
  case '\n':
    break;
  case closeloop:
    loops.closeloop(t);
    break;
  case separate:
    if(level==0){
      out<<a;
    }else{
      this->closecondition();
    };
  case escape:
    {
      a=t.get();
      int i=0;
      for(;*(specialesc+i)&&*(specialesc+i)!=a;i++);
      if(*(specialesc+i)){
	out<<*(specialescout+i);
	break;
      };
    };
  default:
    out<<a;
  };
  return 1;
};

void substitute(istream &in,ostream& out){
  PlaceholderSubstitution p(in,out);
  p.start();
};
