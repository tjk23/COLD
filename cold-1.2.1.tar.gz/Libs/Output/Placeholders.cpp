/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include<iostream>
using namespace std;
//#include "ErrorHandler.h"
#include "Computations.h"

extern "C"{

#include "placeholders.h"
#include "placeholders2.h"
#include "placeholders3.h"

  int nplaceholders=NUMPLACEHOLDERS;
  const char **placeholderarray=placeholders;

}


#define MAKESTRING(a) MKSTR(a)
#define MKSTR(a) #a


#ifndef PLACEHOLDERINCLUDEFILE
#define PLACEHOLDERINCLUDEFILE "PlaceholdersCold.cpp"
#endif


//#include PLACEHOLDERINCLUDEFILE

long double pival=3.14159265358979328462643383;

const long double *pi(){
  return &pival;
};

const int oneval=1;

const int *one(){
  return &oneval;
}

int count[]={0,1,2,3,4,5,6,7,8,9};

const int *ident(){
  return count;
};

int ident_dim(int i){
  if(i==0){
    return 5;
  }else if(i==1){
    return 2;
  }else{
    return -1;
  };
};


int count2[]={0,1,2,3};

const int *ident2(){
  return count2;
};

int ident2_dim(int i){
  if(i==0){
    return 4;
  }else{
    return -1;
  };
};

int pi_dim(int i){
  return -1;
};

int one_dim(int i){
  return -1;
}


void assignfuns(void** array,int (**dims)(int),const char *type){
#define FUNCTIONNAMEIND2(a) PLACEHOLDER##a
#define FUNCTIONNAMEIND(a) FUNCTIONNAMEIND2(a)
#define FUNCTIONNAME(a) FUNCTIONNAMEIND(a)
#define NUMLOOPS NUMPLACEHOLDERS
#define LOOPINCLUDEFILE "OutputFunctionassign.cpp"
#include "preprocessorloop.cpp"
};

extern "C"{
  void (*assignfunctions)(void** array,int (**dims)(int),const char *type)=assignfuns;
}
