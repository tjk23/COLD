/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//Code for dealing with command-line options

#include "CommandLine.h"
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "Macros.h"
#include "Miscellaneous.h"
#include "filesearch.cpp"
#include "flags.h"
#include "validcommands.h"

#define CONCATENATEDIRS(A,B) A/B
#define VARIABLEFILE MAKESTRING(CONCATENATEDIRS(ROOTDIR,DEFAULTVARIABLES))
#define INPUTFILE MAKESTRING(CONCATENATEDIRS(ROOTDIR,coldinputs))
#define ENVIRONMENTFILE "environmentvars"
#define COMMANDLINEMACROS "commandlinemacros"

//INPUTFILE is the file used for passing instructions to a running version of cold.


//Functions to use as function pointers

void noprnt(ostream &o,void *address){
};

void prntstr(ostream &o,void *address){
  o<<*(const char **)address;
};

void prntint(ostream &o,void *address){
  o<<*(int *)address;
};

void prntld(ostream &o,void *address){
  o<<*(long double*)address;
};

void prntdbl(ostream &o,void *address){
  o<<*(double*)address;
};

void prntflt(ostream &o,void *address){
  o<<*(float*)address;
};

int setflag(const char *val,void *address){
  return 0;
};

int setstr(const char *val,void *address){
  if(val==NULL){
    *(const char **)address=NULL;
  }else{
    //    cout<<val<<"\n";
    char *cpy=new char[strlen(val)+1];
    strcpy(cpy,val);
    *(const char **)address=cpy;
    //    cout<<*(const char **)address<<"\n";
  };
  return 1;
};

void prntpth(ostream &o,void *address){
  for(int n=0;*(*(char ***)address+n);n++){
    o<<*(*(char ***)address+n)<<"\n";
  };
};

int setint(const char *val,void *address){//Should allow macros.
  *(int*)address=atoi(val);
  return 1;
};

int setflt(const char *val,void *address){
  *(float*)address=atof(val);
  return 1;
};

int setdbl(const char *val,void *address){
  *(double*)address=atof(val);
  return 1;
};

int setld(const char *val,void *address){
  *(long double*)address=atof(val);
  return 1;
};

int brkstr(const char *val, void *address){
  //Reads something like a path variable, and converts it to a list of
  //strings, by separating on the character : (if not escaped)
  int n=1;
  for(int i=0;*(val+i);i++){
    if(*(val+i)==':'){
      n++;
    };
    if(*(val+i)=='\\'){
      i++;
      if(!*(val+i)){//Can't escape null character.
	break;
      };
    };
  };
  *(char ***)address=new char *[n+1];
  const char *v=val;
  for(int j=0;j<n;j++){
    int i=0;
    for(;*(v+i)&&*(v+i)!=':';i++){
      if(*(v+i)=='\\'){
	i++;
	if(!*(v+i)){//Can't escape null character.
	  break;
	};
      };
    };
    *(*(char ***)address+j)=new char[i+1];
    int kk=0;
    for(int k=0;k<i;k++){
      if(*(v+k)=='\\'){
	k++;
      };								\
      *(*(*(char ***)address+j)+kk)=*(v+k);
      kk++;
    };
    *(*(*(char ***)address+j)+kk)='\0';
    v+=i+1;
  };
  *(*(char ***)address+n)=NULL;
  //  prntpth(cout,address);
  return 1;
};

void delpth(void *address){
  for(int n=0;*(*(char ***)address+n);n++){
    delete[] *(*(char ***)address+n);
  };
  delete[] *(char ***)address;
  delete[] (char ***)address;
};

void delstr(void *address){
  delete[] *(char **)address;
  delete[] (char **)address;
};

void delint(void *address){
  delete[] (int *)address;
};

void delld(void *address){
  delete[] (long double *)address;
};

void delflt(void *address){
  delete[] (float *)address;
};

void deldbl(void *address){
  delete[] (double *)address;
};

void *makevar(char *type);

// ---------------------------------------------------------------------------

variable::variable(const char *n, const char *t,void* address,int (*set)(const char *val,void *address),void (*print)(std::ostream& o,void *address),void (*del)(void *add)){
  name=new char[strlen(n)+1];
  tag=new char[strlen(t)+1];
  strcpy(name,n);
  strcpy(tag,t);
  value=address;
  setv=set;
  prnt=print;
  delv=del;
};

varlist vars;

void removevarlist(){
  vars.remove();
};

ostream &operator <<(ostream &o,variable& v){
  o<<v.name<<"=\"";
  if(v.value==NULL){
    o<<"undefined";
  }else{
    (*v.prnt)(o,v.value);
  };
  o<<"\"\n";
  return o;
};


ostream &operator <<(ostream &o,varlist &v){
  if(v.x!=NULL){
    o<<*v.x;
  };
  if(v.next!=NULL){
    o<<*v.next;
  };
  return o;
};

class fnptrs{
public:
  int (*setv)(const char *,void *);
  void (*prnt)(ostream&,void*);
  void (*delv)(void *);
};

fnptrs getfuns(const char *type);

void *varlist::seekval(const char *vname){
  if(!strcmp(vname,x->name)){
    return x->value;
  }else if(next==NULL){
    return NULL;
  }else{
    return next->seekval(vname);
  };
};

variable *varlist::seektag(const char *tg){
  if(!strcmp(tg,x->tag)){
    return x;
  }else if(next==NULL){
    return NULL;
  }else{
    return next->seektag(tg);
  };
};

void varlist::addvars(ifstream& in){
  char *tag;
  char *type;
  char *init;
  fnptrs f;
  void *address;
  while(in.good()){
    char *line=readstring(in,"\n",'\\');
    //Format: variable name, [variable tag], variable type, initial value
    //Should add escape character.
    int i;
    for(i=0;*(line+i)&&*(line+i)!=' ';i++);
    for(;*(line+i)==' ';i++){
      *(line+i)='\0';
    };
    if(!*(line+i)){//Just a name, make it a string variable with tag equal to name plus -
      tag=new char[strlen(line)+2];
      *tag='-';
      for(unsigned int j=0;j<strlen(line)+1;j++){
	*(tag+j+1)=*(line+j);
      };
      this->addvar(line,tag,new char[20],setstr,"",noprnt,delstr);
    }else{
      int j=i;
      if(*(line+j)=='-'){//tag
	tag=line+j+1;
	for(;*(line+j)&&*(line+j)!=' ';j++);
	for(;*(line+j)==' ';j++){
	  *(line+j)='\0';
	};
	if(!*(line+j)){//Just name and tag
	  this->addvar(line,line+i,new char[20],setstr,"",noprnt,delstr);
	  continue;
	};
      }else{
	tag=new char[strlen(line)+2];
	*tag='-';
	for(unsigned int j=0;j<strlen(line)+1;j++){
	  *(tag+j+1)=*(line+j);
	};
      };
      type=line+j;
      for(;*(line+j)&&*(line+j)!=' ';j++);
      for(;*(line+j)==' ';j++){
	*(line+j)='\0';
      };
      init=line+j;
      f=getfuns(type);
      address=makevar(type);
      this->addvar(line,tag,address,f.setv,init,f.prnt,f.delv);
    };
    for(char c='\n';(char) in.peek()=='\n';in.get(c));
    delete[] line;
  };
};

void varlist::addvar(const char *name,const char *tag,void *address,int (*setv)(const char *val,void *address),const char *init,void (*prnt)(ostream& o,void *address),void (*delv)(void *add)){
  //add the variable in second place, for simplicity.
  if(x==NULL){
    x=new variable(name,tag,address,setv,prnt,delv);    
    x->setval(init);
  }else{
    varlist *tmp=new varlist;
    tmp->x=new variable(name,tag,address,setv,prnt,delv);    
    tmp->x->setval(init);
    tmp->next=next;
    next=tmp;
  };
};

void varlist::setupvars(){
  info("Setting up default variables.",msgcode(1,0));
  const char *envvars=getenv("COLD__VARIABLEFILE");
  ifstream vbls;
  if(envvars==NULL){
    vbls.open(VARIABLEFILE);
    if(!vbls.is_open()){//Try current directory
      vbls.open(MAKESTRING(DEFAULTVARIABLES));
    };
    this->addvars(vbls);
  }else{
    vbls.open(envvars);
    if(!vbls.is_open()){
      cerr<<"Unable to open variable file \""<<envvars<<"\"\n";
    };
  };
  vbls.close();
  envgetopts();
};

int setifstream(const char *val,void *address);

void varlist::setvals(int argc,char *argv[]){
  //Add default variables file ".variables"
  strlist flags;
  for(int i=0;i<NUMFLAG;i++){
    int j=0;
    for(;*(flag[i]+j)==' '&&*(flag[i]+j)=='\t'&&*(flag[i]+j)=='\r';j++);
    int k=j;
    for(;*(flag[i]+j)&&*(flag[i]+j)!=' '&&*(flag[i]+j)!='\t'&&*(flag[i]+j)!='\r';j++);
    char *temp=new char[j-k+1];
    for(int l=0;l<j-k;l++){
      *(temp+l)=*(flag[i]+k+l);
    };
    *(temp+j-k)='\0';
    flags.insert(temp);
    delete[] temp;
  };  
  char *tg;
  const char *val;
  for(int i=1;i<argc;i++){
    variable *v;
    if(*(argv[i])=='-'){//option file
      if(*(argv[i]+1)=='-'){//long option name terminated by space
	int l=2;
	for(;*(argv[i]+l);l++);
	tg=new char[l];
	strcpy(tg,(argv[i]+1));
	if(i<argc-1){
	  val=argv[++i];
	}else{
	  val=NULL;
	  i++;
	};
      }else{//single character option name
	tg=new char[2];
	*tg=*(argv[i]+1);
	*(tg+1)='\0';
	if(*(argv[i]+2)){//value included in this argument
	  val=(argv[i]+2);
	}else{
	  if(i<argc-1){
	    val=argv[++i];
	  }else{
	    val=NULL;
	    i++;
	  };
	}
      };
    }else{
      tg=new char[1];
      *tg='\0';
      val=argv[i];
    };
    if(i<argc){
      ifstream macros;
      for(setifstream(COMMANDLINEMACROS,&macros);macros.good()&&!macros.eof();){
	int i=0;
	for(;*(val+i)&&*(val+i)==macros.peek();i++){
	  macros.get();
	};
	char mg=macros.get();
	if(*(val+i)=='\0'&&(mg==' '||mg=='\t'||mg=='\n'||mg=='\r')){//match
	  for(;macros.peek()==' '||macros.peek()=='\t'||macros.peek()=='\n'||macros.peek()=='\r';macros.get());
	  i=0;
	  for(;*(tg+i)&&*(tg+i)==macros.peek();i++){macros.get();};
	  mg=macros.get();
	  if(*(tg+i)=='\0'&&(mg==' '||mg=='\t'||mg=='\n'||mg=='\r')){//match
	    for(;macros.good()&&!macros.eof()&&(macros.peek()==' '||macros.peek()=='\t'||macros.peek()=='\n'||macros.peek()=='\r');macros.get());
	    //Replace val with value read from file.
	    val=readstring(macros,"\n");
	    //This leaks memory, but is difficult to tidy up.
	    break;
	  };
	};
	for(;macros.good()&&!macros.eof()&&macros.get()!='\n';);      
	for(;macros.good()&&!macros.eof()&&(macros.peek()=='\n'||macros.peek()=='\t'||macros.peek()=='\r'||macros.peek()==' ');macros.get());
      };
      macros.close();
    };
    v=this->seektag(tg);
    if(v==NULL){
      if(!strcmp(tg,"-variables")){//Read more command line options and
				  //variables from a file.
	ifstream vbls(val);
	this->addvars(vbls);
	vbls.close();
      }else if(flags.search(tg)!=-1){
	this->addvar("",tg,NULL,setflag,val,NULL,NULL);	
	i--;
      }else{
	this->addvar("",tg,new const char *[1],setstr,val,prntstr,delstr);
      };
    }else{
      if(!v->setval(val)){//no value for tag --- just on-off
	i--;
      };
    };
    delete[] tg;
  };
  flags.remove();
  checkvars();
};

int threematch(const char *a,const char *b){
  //returns 1 if first three characters match
  for(int i=0;i<3&&*(a+i)&&*(b+i);i++){
    if(*(a+i)!=*(b+i)){
      return 0;
    };
  };
  return 1;
};

int substring(const char *a,int la,const char *b,int lb){
  //tests if string at a is a substring of string at b;
  int *cs=new int[la];
  *cs=0;
  for(int i=0;i<la-1;i++){
    if(*(a+i)==*a&&i>0){
      *(cs+i+1)=1;
    }else{
      *(cs+i+1)=0;
    };
    for(int j=*(cs+i);j>0;j=*(cs+j)){
      if(*(a+i)==*(a+j)){
	*(cs+i+1)=j+1;
	break;
      };
    };    
  };
  int j=0;
  for(int i=0;i<lb;i++){
    for(;j>0;j=*(cs+j)){
      if(*(b+i)==*(a+j)){
	j++;
	if(j==la){
	  return 1;
	};
	break;
      };
    };
    if(j==0&&*(b+i)==*a){
      j=1;
    };
  };
  return 0;
};

int matches(const char *a,const char *b){
//if first three letters match, or if a and b have common substring of
//length at least 5 (or len a or len b if one is shorter than 5
//characters) 
  if(threematch(a,b)){
    return 1;
  };
  int testlen=5;
  int la=strlen(a);
  int lb=strlen(b);
  int ml=(la<lb)?la:lb;
  if(ml<6){
    testlen=ml-1;
  };
  for(int i=0;i<=la-testlen;i++){
    if(substring(a+i,testlen,b,lb)){
      return 1;
    };
  };
  return 0;
};


int findgoodmatch(int start,const char *f,const char* const *in,int max){
  for(int i=start;i<max;i++){
    if(matches(f,in[i])){
      return i;
    };
  };
  return max;
};

void varlist::checkvars(){
  const char *t=x->tag;
  int i=0;
  for(;i<NUMVALIDCOMMAND;i++){
    if(!strcmp(t,validcommand[i])){
      break;
    };
  };
  if(i==NUMVALIDCOMMAND){
    char *msg=new char[400+strlen(t)];
    strcpy(msg,"Unknown command line option: \"-");
    strcat(msg,t);
    strcat(msg,"\" ignored.\nPossible alternatives:\n");
    for(int j=findgoodmatch(0,t,validcommand,NUMVALIDCOMMAND);j<NUMVALIDCOMMAND;j=findgoodmatch(j+1,t,validcommand,NUMVALIDCOMMAND)){
      strcat(msg,"\n-");
      strcat(msg,validcommand[j]);
    };
    warning(msg,msgcode(0,1));
  };
  if(next!=NULL){
    next->checkvars();
  };
};

int stlen(const char **pt){
  int l=0;
  for(int i=0;*(pt+i);i++){
    l+=strlen(*(pt+i))+2;
  };
  return l;
};

void pathtostr(const char **pt, char *out){
  for(int i=0;*(pt+i);i++){
    strcat(out,*(pt+i));
    strcat(out,"\n");
  };
};

int setifstreamthrow(const char *val,void *address){
  //Like setifstream, but throws an exception on failure
  ifstream *str=(ifstream *)address;
  void *pt=vars.seekval("path");
  if(pt==NULL){
    ifstream test(val);
    if(!test.good()){
      throw val;
    }else{
      test.close();
    };
    if(str->is_open()){
      str->close();
    };
    str->open(val);
    if(!str->good()){
      char *x=new char[30+strlen(val)];
      strcpy(x,"IO error openning file \"");
      strcat(x,val);
      strcat(x,"\"");
      recoverableError(x);//Should add a new file menu.      
    };
  }else{
    if(!search(*(const char ***)pt,val,*str)||!str->good()){
      throw val;
    };
  };
  return 0;
};

int setifstream(const char *val,void *address){
  ifstream *str=(ifstream *)address;
  void *pt=vars.seekval("path");
  if(pt==NULL){
    ifstream test(val);
    if(!test.good()){
      //      cout<<"Could not open file: \""<<val<<"\"\n";
      char *x=new char[30+strlen(val)];
      strcpy(x,"Could not open file \"");
      strcat(x,val);
      strcat(x,"\"");
      recoverableError(x);//Should add a new file menu.
    }else{
      test.close();
    };
    if(str->is_open()){
      str->close();
    };
    str->open(val);
    if(!str->good()){
      char *x=new char[30+strlen(val)];
      strcpy(x,"IO error openning file \"");
      strcat(x,val);
      strcat(x,"\"");
      recoverableError(x);//Should add a new file menu.      
    };
  }else{
    if(!search(*(const char ***)pt,val,*str)||!str->good()){
      /*      if(str->bad()){
	cout<<"Stream is bad.\n";
      };
      if(str->eof()){
	cout<<"End of file.\n";
      };
      if(str->fail()){
	cout<<"Stream operation failed.\n";
	};*/
      char *x=new char[90+strlen(MAKESTRING(ROOTDIR))+strlen(val)+stlen(* (const char ***)pt)];//
      strcpy(x,"Could not open file: \"");
      strcat(x,val);
      strcat(x,"\"\n\n");
      strcat(x,"search path=\n");
      pathtostr(*(const char ***)pt,x);
      strcat(x,"root search directory=");
      strcat(x,MAKESTRING(ROOTDIR));
      recoverableError(x);//Should add a new file menu.      
    };
  };
  return 1;
};

int *match(int i,int j,int *graph){
  //finds a matching in the bipartite graph if one exists.  That is,
  //for every element less than i, it attempts to find a different
  //element less than j, which is joined to it.

  //primitive algorithm, might need to improve on it later.

  for(int k=0;k<i;k++){
    int l=0;
    for(;l<j&&*(graph+k*j+l)!=1;l++);
    if(l==j){//need to backtrack.
      if(k==0){
	return NULL;
      };
      int jj=0;
      for(int ii=0;ii<i;ii++){
	if(*(graph+k*j+ii)==-1){
	  *(graph+k*j+ii)=1;
	};
      };
      k--;
      for(;*(graph+k*j+jj)!=k;jj++);
      for(int kk=0;kk<i;kk++){
	if(*(graph+kk*j+jj)==k){
	  *(graph+kk*j+jj)=1;
	};
      };
      *(graph+k*j+jj)=-1;
      k--;
    }else{//try this matching;
      for(int kk=0;kk<i;kk++){
	if(*(graph+kk*j+l)==1){
	  *(graph+kk*j+l)=k;
	};
      };
    };
  };
  int *ans=new int[i];
  for(int ii=0;ii<i;ii++){
    int jj=0;
    for(;*(graph+ii*j+jj)!=ii;jj++);
    *(ans+ii)=jj;
  };
  return ans;
};

int chooseifstreams(char *basename,int n,...){
  //n is the number of streams. The remaining arguments begin with lists of extensions
  va_list argptr;
  va_start(argptr,n);
  void *pt=vars.seekval("path");
  const char *const*path;
  if(pt==NULL){
    char **pth=new char*[1];
    *pth=new char[1];
    **pth='\0';
    path=pth;
  }else{
    path=*(const char ***)pt;
  };
  char **found=new char*[n];
  for(int i=0;i<n;i++){
    const char *const*ex=va_arg(argptr,const char*const*);
    *(found+i)=searchall(path,basename,ex);
  };
  int num=0;
  for(int i=0;i<n;i++){
    for(char *fnd=*(found+i);strlen(fnd);fnd+=strlen(fnd)+1){
      int j=0;
      for(;j<i;j++){
	char *fnd2=*(found+j);
	for(;strlen(fnd2)&&strcmp(fnd,fnd2);fnd2+=strlen(fnd2)+1);
	if(strlen(fnd2)){
	  break;
	};
      };
      if(j==i){
	num++;
      };
    };
  };
  char **allfnd=new char*[num];
  int *graph=new int[num*n];
  for(int x=0;x<num*n;x++){
    *(graph+x)=0;
  };
  int nm=0;
  for(int i=0;i<n;i++){
    for(char *fnd=*(found+i);strlen(fnd);fnd+=strlen(fnd)+1){
      int j=0;
      for(;j<i;j++){
	char *fnd2=*(found+j);
	int ps=0;
	for(;strlen(fnd2)&&strcmp(fnd,fnd2);fnd2+=strlen(fnd2)+1){
	  ps++;
	};
	if(strlen(fnd2)){
	  int ii=0;
	  for(int jj=0;jj<=ps;jj++){
	    for(;*(graph+j*num+ii)==0;ii++);
	    ii++;
	  };
	  *(graph+i*num+ii-1)=1;
	  break;
	};
      };
      if(j==i){
	*(allfnd+nm)=new char[strlen(fnd)+2];
	strcpy(*(allfnd+nm),fnd);
	*(graph+i*num+nm)=1;
	nm++;
      };
    };
  };
  /*  cout<<"Possible files:\n";
  for(int i=0;i<num;i++){
    cout<<*(allfnd+i)<<"\n";
  };
  for(int i=0;i<n;i++){
    for(int j=0;j<num;j++){
      cout<<*(graph+i*num+j)<<" ";
    };
    cout<<"\n";
    };*/
  int *mt=match(n,num,graph);
  if(mt==NULL){
    va_end(argptr);
    return 0;
  };
  /*  for(int i=0;i<n;i++){
    cout<<*(mt+i)<<" ";
  };
  cout<<"\n";*/
  for(int i=0;i<n;i++){
    ifstream *in=va_arg(argptr,ifstream*);
    //    cout<<"Openning file \""<<*(allfnd+*(mt+i))<<"\"\n";
    if(in->is_open()){
      in->close();
    };
    in->open(*(allfnd+*(mt+i)));
    if(!in->is_open()||!in->good()){
      char *x=new char[30+strlen(*(allfnd+*(mt+i)))];
      strcpy(x,"IO error openning file \"");
      strcat(x,*(allfnd+*(mt+i)));
      strcat(x,"\"");
      recoverableError(x);//Should add a new file menu.      
    };
  };
  for(int i=0;i<n;i++){
    delete[] *(found+i);
  };
  delete[] found;
  delete[] mt;
  for(int i=0;i<num;i++){
    delete[] *(allfnd+i);
  };
  delete[] allfnd;
  delete[] graph;
  if(pt==NULL){
    delete[] path;
  };
  va_end(argptr);
  return 1;
};

fnptrs getfuns(const char *type){
  fnptrs f;
  if(!strcmp(type,"string")){
    f.setv=setstr;
    f.prnt=prntstr;
    f.delv=delstr;
  }else if(!strcmp(type,"int")){
    f.setv=setint;
    f.prnt=prntint;
    f.delv=delint;
  }else if(!strcmp(type,"float")){
    f.setv=setflt;
    f.prnt=prntflt;
    f.delv=delflt;
  }else if(!strcmp(type,"dbl")){
    f.setv=setdbl;
    f.prnt=prntdbl;
    f.delv=deldbl;
  }else if(!strcmp(type,"ld")){
    f.setv=setld;
    f.prnt=prntld;
    f.delv=delld;
  }else if(!strcmp(type,"path")){
    f.setv=brkstr;
    f.prnt=prntpth;
    f.delv=delpth;
  }else if(!strcmp(type,"flag")){
    f.setv=setflag;
    f.prnt=NULL;
    f.delv=NULL;
  }else{
    f.setv=NULL;
    f.prnt=NULL;
    f.delv=NULL;
  };
  return f;
};

void *makevar(char *type){
  if(!strcmp(type,"string")){
    return new char* [1];
  }else if(!strcmp(type,"int")){
    return new int [1];
  }else if(!strcmp(type,"float")){
    return new float [1];
  }else if(!strcmp(type,"dbl")){
    return new double [1];
  }else if(!strcmp(type,"ld")){
    return new long double [1];
  }else if(!strcmp(type,"path")){
    return new char**[1];
  }else{
    return NULL;
  };
};

inline int is_flag(const char *opt){
  for(int i=0;i<NUMFLAG;i++){
    if(!strcmp(opt,flag[i])){
      return 1;
    };
  };
  return 0;
};

void (*rereadcommandline)();

void setupdatecommandline(void (*rrcl)()){
  rereadcommandline=rrcl;
};

int inputcheck(){
  //Checks to see whether input has been added to the input file.
  int retval=0;
  const char *inputfilename=getenv("COLD__INPUTFILE");
  ifstream input;
  if(inputfilename==NULL){
    input.open(INPUTFILE);
  }else{
    input.open(inputfilename);
  };
  if(input.is_open()){
    //Format of input file:
    //
    //option [value]

    //Currently only works for string inputs
    do{
      char *varname=readnonemptystring(input," \t\r\n");
      //      cout<<varname<<"\n";
      switch(*varname){
      case '-':	    
	{
	  char *opt=varname+1;
	  if(is_flag(opt)){
	    for(;input.good()&&(input.peek()==' '||input.peek()=='\t'||input.peek()=='\r');input.get());
	    int on=1;
	    if(input.good()){
	      if(input.peek()=='0'){
		on=0;
	      }else if(input.peek()=='O'||input.peek()=='o'){
		input.get();
		if(input.good()&&(input.peek()=='F'||input.peek()=='f')){
		  input.get();
		  if(input.good()&&(input.peek()=='F'||input.peek()=='f')){
		    on=0;
		  };		
		};
	      };
	    };
	    if(on==0){
	      //turn off commandline option.
	      for(variable *rec=vars.seektag(opt);rec!=NULL;rec=vars.seektag(opt)){
		*(rec->tag)='\0';
		retval=1;
	      };
	    }else{
	      if(vars.seektag(opt)==NULL){
		vars.addvar("",opt,NULL,setflag,NULL,NULL,NULL);
		retval=1;
	      };
	    };
	  }else{
	    char *val=readnonemptystring(input," \t\r\n");
	    variable *rec=vars.seektag(opt);
	    if(rec==NULL){
	      vars.addvar("",opt,new const char*[1],setstr,val,prntstr,delstr);
	      //	      cout<<"Changed "<<opt<<"  to \""<<val<<"\"\n";
	      retval=1;
	    }else{
	      rec->setval(val);
	    };
	    delete[] val;
	  };
	  break;
	}
      case '#':
	for(char c=input.get();input.good()&&c!='\n';c=input.get());//go to next line.
      };
      delete[] varname;
    }while(input.good());
    input.close();
  };
  if(inputfilename==NULL){
    remove(INPUTFILE);
  }else{
    remove(inputfilename);
  };
  (*rereadcommandline)();
  return retval;
};



int envgetopts(){
  //Reads environment variables, and changes commandline options
  //according to the settings in the environmentvars file.  If
  //environment variables are changed during the program, the new
  //values will only take effect the next time commandline options are
  //checked (Which may be never).
  int retval=0;
  ifstream envfile;
  setifstream(ENVIRONMENTFILE,&envfile);
  if(envfile.is_open()){
    //ENVIRONMENT FILE FORMAT: 
    //ENVIRONMENTVARIABLENAME option
    //Lines starting with # are comments. (Not yet implemented)
    while(envfile.good()){
      char *varname=readnonemptystring(envfile," \t\r\n");
      if(*varname!='#'){
	const char *val=getenv(varname);
	if(val!=NULL){
	  //	  cout<<varname<<"="<<val<<"\n";
	  while(envfile.good()&&envfile.get()!='-');
	  char *opt=readnonemptystring(envfile," \t\r\n");
	  if(is_flag(opt)){
	    if(strcmp(val,"0")&&strcmp(val,"OFF")&&strcmp(val,"off")){
	      //turn off commandline option.
	      for(variable *rec=vars.seektag(opt);rec!=NULL;*(rec->tag)='\0');
	    }else{
	      if(vars.seektag(opt)==NULL){
		vars.addvar("",opt,NULL,setflag,NULL,NULL,NULL);
		retval=1;
	      };
	    };
	  }else{
	    variable *rec=vars.seektag(opt);
	    if(rec==NULL||strcmp(*(char **)rec->value,val)){
	      vars.addvar("",opt,new const char*[1],setstr,val,prntstr,delstr);
	      //	      cout<<"Changed "<<opt<<"  to \""<<val<<"\"\n";
	      retval=1;
	    };
	  };
	};
      };
    };
    envfile.close();
  };
  return retval;
};

