/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */


/* 

   Routines for dealing with errors. The global variables in this file allow control over how errors, information and warnings are handled. For example, should warnings give a prompt for the user to confirm.

*/
#include "ErrorHandler.h"
#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<stdarg.h>
#include<pthread.h>
#include<string.h>
using namespace std;

pthread_mutex_t IOlock=PTHREAD_MUTEX_INITIALIZER;

//class menu;

menu::~menu(){
  delete[] options;
};

int info(const char *message,int type,menu *choices);
int warning(const char *message,int type,menu *choices);
int recoverableError(const char *message,int type,menu *choices);
void fatalError(const char *message,int type,menu *choices);

//extern ostream& comm;

void (*printcon)(void *)=NULL;
void *cont;

void setContext(void (*pc)(void *),void *c){
  cont=c;
  printcon=pc;
};

void setContext(void *c){
  cont=c;
};


ofstream *logfile=NULL;

void closelog(){
  logfile->close();
};

int interactivity=1; 
// Indicates whether the user should be prompted for confirmations.
/*

  0  - Away, no interactivity. Messages displayed on screen.  

  -1 - No interactivity. Messages sent to log file if it exists. Otherwise no
       messages.

  1  - Only prompt for vital messages.

  2  - Prompt for messages where appropriate.

  3  - Prompt for all messages

  32 - Prompt for all messages until main part of program execution begins, then switch to AWAY.

  33 - Prompt for all messages until main part of program execution begins, prompt for confirmation once main part of program starts, then switch to AWAY.

 */

#define AWAY 0
#define LOGFILE -1
#define VITAL 1
#define PRESENT 2
#define ALL 3
#define START 32
#define STARTCHECK 33

#define MAXINTERACT 3

int debug=0;
// Indicates whether debugging information should be output with error
// messages.

/*
  -1 - Complete silence

  0  - No debugging information.

  1  - Basic debugging information.

  2  - Full debugging information.

*/

void printContext(int i){
  if(printcon!=NULL&&debug>=i){
    (*printcon)(cont);
  };
};

#define NODEBUG 0
#define BASICDEBUG 1
#define FULLDEBUG 2

void quit(void *p){//Could modify this to give a more informative exit code.
  exit(1);
};

void inputnewfilename(void *p){
  if(p==NULL){//Bad
    cout<<"Menu not properly implemented. Unable to input new filename.\n\n";
  }else{
    char fn[80];
    cout<<"Name of file to open:\n";
    cin>>fn;
    ifstream *in=(ifstream *)p;
    in->open(fn);
    if(!in->is_open()){
      cout<<"Unable to open file.\n\n";
      //      info("Unable to open file.");
    }else{
      cout<<"file opened successfully.\n\n";
    };
  };
};

menuitem::menuitem(const menuitem& m){
  text=new char[strlen(m.text)+1];
  strcpy(text,m.text);
  perform=m.perform;
};

menuitem::menuitem(const char *t,void (*p)(void *)){
  text=new char[strlen(t)+1];
  strcpy(text,t);
  perform=p;
};

void menuitem::operator =(const menuitem& m){
  text=new char[strlen(m.text)+1];
  strcpy(text,m.text);
  perform=m.perform;
};

menuitem stop("Abort.",quit);
menuitem openfile("Input another filename.",inputnewfilename);

menu::menu(int num,menuitem& first,menuitem& second,...){//pars must be set later. All menu items must
			//be included.
  n=num;
  va_list argptr;
  va_start(argptr,second);
  options=new menuitem[num];
  *options=first;
  *(options+1)=second;
  for(int i=2;i<num;i++){
    *(options+i)=*(va_arg(argptr,menuitem*));
  };
  pars=NULL;
  va_end(argptr);
};

menu::menu(const menu& base,int num){
  //Copies menu from base, but adds space for num extra menuitems.
  n=base.n+num;
  options=new menuitem[n];
  for(int i=0;i<base.n;i++){
    *(options+i)=*(base.options+i);
  };
  pars=base.pars;
};

void menu::display(){
  int choice=0;
  while(choice<1||choice>n||(!(options+choice-1)->enabled())){
    for(int i=0;i<n;i++){
      if((options+i)->enabled()){
	cout<<i+1<<".\t"<<*(options+i)<<"\n\n";
      };
    };
    char a[10];
    cin>>a;
    choice=atoi(a);
  };
  choice-=1;
  (options+choice)->choose(pars);
};

inline std::ostream& operator<<(std::ostream& out,menuitem m){
  return(out<<m.text);
};

int menu::displayno(const char* message){
  int choice=0;
  while(choice<1||choice>n+1||(choice<n&&(!(options+choice-1)->enabled()))){
    for(int i=0;i<n;i++){
      if((options+i)->enabled()){
	cout<<i+1<<".\t"<<*(options+i)<<"\n\n";
      };
    };
    cout<<n+1<<".\t"<<message<<"\n\n";
    char a[10];
    cin>>a;
    choice=atoi(a);
  };
  choice-=1;
  if(choice<n){
    (options+choice)->choose(pars);
  };
  return(choice==n);
};

menu stopcont(1,&stop);
//menu filemenu(stopcont);
menu filemenu(2,stop,openfile);

void setinteractive(int i){interactivity=i;};
void interactivestarted(){
  switch(interactivity){
  case STARTCHECK:
    {    
      char yn=' ';
      cout<<"Initialisation successfully completed.\nEnter non-interactive mode? (y/n)\t";
      while(yn!='y'&&yn!='Y'&&yn!='n'&&yn!='N'){
	cin>>yn;
      };
      if(yn=='n'||yn=='N'){
	return;
      };
    };
  case START:
    interactivity=AWAY;
  };
};

void setdebug(int i){debug=i;};
void setlogfile(ofstream& out){logfile=&out;atexit(closelog);};
void setlogfile(const char *name){
  logfile=new ofstream(name);
  if(!logfile->is_open()){throw 0;};
};//Not really good.

int info(const char *message,int type,menu *choices){
  pthread_mutex_lock(&IOlock);
  if(type/32>debug){
    pthread_mutex_unlock(&IOlock);
    return 0;
  };
  if(interactivity==LOGFILE){
    if(logfile==NULL||!logfile->is_open()){//no logfile.
      pthread_mutex_unlock(&IOlock);
      return 0;
    }else{
      (*logfile)<<message<<"\n\n";
      pthread_mutex_unlock(&IOlock);
      return 1;
    };
  }else{
    cout<<message<<"\n\n";
    if(MAXINTERACT-(type%32)<interactivity&&choices!=NULL){
      //Give a menu if one is offered.
      int cont=0;
      int i=-1;
      while(!cont){
	cont=choices->displayno();
	i++;
      };
      pthread_mutex_unlock(&IOlock);
      return i?3:2;
    }else{
      pthread_mutex_unlock(&IOlock);
      return 1;
    };
  };
  pthread_mutex_unlock(&IOlock);
};
//information for the user.
//returns 0 if message not displayed.
//        1 if message printed or logged,
//        2 if user prompted continuation 
//        3 if user did something before continuation


int warning(const char *message,int type,menu *choices){
  pthread_mutex_lock(&IOlock);  
  if(type/32>debug){
    pthread_mutex_unlock(&IOlock);
    return 0;
  };
  if(interactivity==LOGFILE){
    if(logfile==NULL||!logfile->is_open()){//no logfile.
      pthread_mutex_unlock(&IOlock);
      return 0;
    }else{
      (*logfile)<<"Warning:\t"<<message<<"\n\n";
      pthread_mutex_unlock(&IOlock);
      return 1;
    };
  }else{
    cout<<"Warning:\t"<<message<<"\n\n";
    if(MAXINTERACT-(type%32)<=interactivity){
      if(choices==NULL){
	stopcont.displayno();
	pthread_mutex_unlock(&IOlock);
	return 2;
      }else{
      //Give a menu if one is offered.
	int cont=0;
	while(!cont){
	  cont=choices->displayno();
	};
	pthread_mutex_unlock(&IOlock);
	return 2;
      };
    }else{
      pthread_mutex_unlock(&IOlock);
      return 1;
    };
  };
  pthread_mutex_unlock(&IOlock);
};
//warning about unusual, probably wrong behaviour, but theoretically
//OK. Similar to info, but if no menu offered, give a default
//continue/abort menu. Return values: 0 - message not given, 1 -
//message given, no menu given, 2- menu given, user elected to
//continue.

int recoverableError(const char *message,int type,menu *choices){
  pthread_mutex_lock(&IOlock);
  if(interactivity==LOGFILE){
    cerr<<"Error:\t"<<message<<"\n\n";
    if(logfile==NULL||!logfile->is_open()){//no logfile.
      exit(1);
    }else{
      (*logfile)<<"Error:\t"<<message<<"\n\n";
      exit(1);
    };
  }else{
    cerr<<"Error:\t"<<message<<"\n\n";
    if(choices==NULL||interactivity==AWAY){
      exit(1);
    }else{
      //Give a menu if one is offered.
      int cont=0;
      while(!cont){
	choices->display();
	//cont=testrecovery.//Need to work out whether recovery is successful
      };
    };
  };
  pthread_mutex_unlock(&IOlock);
  return 0;//Should modify this to give more information.
};
//an error that could be recovered from with user input.  Like a
//warning, but can't just continue. If menu offered is NULL, this will
//exit, just like fatalError. 


void fatalError(const char *message,int type,menu *choices){
  pthread_mutex_lock(&IOlock);
  if(interactivity==LOGFILE){
    cerr<<"Error:\t"<<message<<"\n\n";
    if(logfile==NULL||!logfile->is_open()){//no logfile.
      exit(1);
    }else{
      (*logfile)<<"Error:\t"<<message<<"\n\n";
      exit(1);
    };
  }else{
    cerr<<"Error:\t"<<message<<"\n\n";
    if(choices==NULL||interactivity==AWAY){
      exit(1);
    }else{
      //Give a menu if one is offered.
      int cont=0;
      while(!cont){
	choices->display();//One of the options should be to exit.
      };
    };
  };
  pthread_mutex_unlock(&IOlock);
};
//an error that can't be recovered from. Possibly some damage
//limitation can be achieved, and some debugging can be performed
//interactively.
