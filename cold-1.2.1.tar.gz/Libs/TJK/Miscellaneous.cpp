/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

/* Routines for various necessary functions */
#include "Miscellaneous.h"
#include <iostream>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
using namespace std;

//#define MISCELLANEOUS 1

class charll{
public:
  char *info;
  int len;
  charll *next;
  charll(){info=NULL;next=NULL;len=0;};
  void readto(char *a){for(int i=len-1;i>=0;i--){*a--=*(info+i);};if(next!=NULL){next->readto(a);};};
  void remove();
  //  ~charll(){this->remove();};
  void insert();
  friend ostream& operator <<(ostream& out,charll s);
};

ostream& operator <<(ostream& out,charll s){
  if(s.info!=NULL){
    out<<s.info<<"\n";
    if(s.next!=NULL){
      out<<*(s.next);
    };
  }else{
    out<<"NULL POINTER\n";
    if(s.next!=NULL){
      out<<*(s.next);
    };
  };
  return out;
};

void charll::remove(){
  if(next!=NULL){
    next->remove();
    delete[] next;
  };
  if(info!=NULL){
    delete[] info;
  };
};

void charll::insert(){
  charll *n=new charll[1];
  n->info=info;
  n->next=next;
  n->len=len;
  next=n;
  info=NULL;
  len=0;
};

char* readstring(istream &s,const char *term){
  //reads a string of arbitrary length terminated by any of the
  //characters in the string term.
  int bufsize=100;
  charll ans;
  int len=0;
  for(int i=1;i>0&&s.good();){
    ans.info=new char[bufsize];
    for(int j=0;j<bufsize;j++){
      char x;
      s.get(x);
      for(int k=0;*(term+k)!='\0';k++){
	if(x==*(term+k)||x=='\0'){
	  i=0;
	  j=bufsize;
	  break;//break out of all loops
	};
      };
      if(j<bufsize){
	*(ans.info+j)=x;
	len++;
	ans.len++;
      };
      //      cout<<"info=\""<<ans.info<<"\"\n";
    };
    ans.insert();
  };
  char *r=new char[len+1];
  ans.readto(r+len-1);
  ans.remove();
  *(r+len)='\0';
  //  cout<<"len="<<len<<"\n";
  //  cout<<*(r+len-1);
  return r;
};

inline int iswhitespace(char t){
  return (t==' '||t=='\t'||t=='\n'||t=='\r');
};

void skipblanklines(istream &s){
  //removes all blank lines from the stream. Also removes all other
  //white characters, so it removes leading spaces from the next
  //non-blank line.
  for(;s.good()&&iswhitespace(s.peek());s.get());
};

char* readnonemptystring(istream &s,const char *term){
  //reads a string of arbitrary length terminated by any of the
  //characters in the string term, skips over leading terminators.
  int bufsize=100;
  charll ans;
  int len=1;
  char y='0';
  for(int i=0;i==0&&s.good();){
    i=1;
    s.get(y);
    for(int k=0;*(term+k);k++){
      if(y==*(term+k)){
	i=0;
      };
    };
  };
  ans.len=1;
  for(int i=1;i>0;){
    ans.info=new char[bufsize];
    for(int j=0;j<bufsize;j++){
      if(y!='\0'){
	*ans.info=y;
	y='\0';
	j++;
      };
      char x='\0';
      s.get(x);
      for(int k=0;*(term+k)!='\0';k++){
	if(x==*(term+k)||x=='\0'){
	  i=0;
	  j=bufsize;
	  break;//break out of all loops
	};
      };
      if(j<bufsize){
	*(ans.info+j)=x;
	len++;
	ans.len++;
      };
      //      cout<<"info=\""<<ans.info<<"\"\n";
    };
    ans.insert();
  };
  char *r=new char[len+1];
  ans.readto(r+len-1);
  ans.remove();
  *(r+len)='\0';
  //  cout<<"len="<<len<<"\n";
  //  cout<<*(r+len-1);
  return r;
};

char* readstring(istream &s,char &t,const char *term){
  //reads a string of arbitrary length terminated by any of the
  //characters in the string term. sets t to give the terminating character.
  int bufsize=100;
  charll ans;
  int len=0;
  for(int i=1;i>0;){
    ans.info=new char[bufsize];
    for(int j=0;j<bufsize;j++){
      char x;
      s.get(x);
      for(int k=0;*(term+k)!='\0';k++){
	if(x==*(term+k)||x=='\0'){
	  i=0;
	  j=bufsize;
	  t=*(term+k);
	  break;//break out of all loops
	};
      };
      if(j<bufsize){
	*(ans.info+j)=x;
	len++;
	ans.len++;
      };
      //      cout<<"info=\""<<ans.info<<"\"\n";
    };
    ans.insert();
  };
  char *r=new char[len+1];
  ans.readto(r+len-1);
  ans.remove();
  *(r+len)='\0';
  //  cout<<"len="<<len<<"\n";
  //  cout<<*(r+len-1);
  return r;
};

char* readstring(istream &s,const char *term,const char esc){
  //reads a string of arbitrary length terminated by any of the
  //characters in the string term.
  int bufsize=100;
  charll ans;
  int len=0;
  int es=0;
  for(int i=1;i>0;){
    ans.info=new char[bufsize];
    for(int j=0;j<bufsize;j++){
      char x;
      s.get(x);
      if(s.bad()){
	i=0;
	break;
      };
      if(x==esc){
	es=1;
	s.get(x);
      };
      len++;
      ans.len++;
      if(es){
	es=0;
      }else{
	for(int k=0;*(term+k)!='\0';k++){
	  if(x==*(term+k)||x=='\0'){
	    i=0;
	    *(ans.info+j)='\0';
	    j=bufsize;
	    break;//break out of all loops
	  };
	};
      };
      if(j<bufsize){
	*(ans.info+j)=x;
      };
      //      cout<<"info=\""<<ans.info<<"\"\n";
    };
    ans.insert();
  };
  char *r=new char[len];
  ans.readto(r+len-1);
  ans.remove();
  *(r+len-1)='\0';
  return r;
};

char* readmatchedstring(istream &s,char up,char down,char esc,const char *term){
  //reads a string of arbitrary length terminated by any of the
  //characters in the string term.
  int bufsize=100;
  charll ans;
  int len=0;
  int level=0;
  for(int i=1;i>0&&s.good();){
    ans.info=new char[bufsize+1];
    for(int j=0;j<bufsize;j++){
      char x;
      s.get(x);
      if(x=='\0'){//Always terminate on null, even if mismatched.
	if(level!=0){
	  throw level;
	};
	i=0;
	break;
      };      
      if(level==0){ 
	for(int k=0;*(term+k)!='\0';k++){
	  if(x==*(term+k)){
	    i=0;
	    j=bufsize;
	    break;//break out of all loops
	  };
	};
      };
      if(j<bufsize){
	*(ans.info+j)=x;
	len++;
	ans.len++;
	if(x==up){
	  level++;
	}else if(x==down){
	  level--;
	  if(level<0){//mismatched
	    throw -1;
	  };
	}else if(x==esc){
	  s.get(x);
	  if(x=='\0'){//Always terminate on null, even if escaped
	    throw '\\';
	  };
	  *(ans.info+(++j))=x;
	  len++;
	  ans.len++;	  
	};
      };
      if(s.eof()){
	i=0;
	j=bufsize;
	break;
      };
      //      cout<<"info=\""<<ans.info<<"\"\n";
    };
    ans.insert();
  };
  char *r=new char[len+1];
  ans.readto(r+len-1);
  ans.remove();
  *(r+len)='\0';
  //  cout<<"len="<<len<<"\n";
  //  cout<<*(r+len-1);
  return r;
};

inline int countwords(const char* s){
  int t=0;
  const char* r=s;
  for(;*r==' '||*r=='\n'||*r=='\t'||*r=='\r';r++);
  for(;*r;t++){
    for(;*r&&*r!=' '&&*r!='\n'&&*r!='\t'&&*r!='\r';r++);
    for(;*r==' '||*r=='\n'||*r=='\t'||*r=='\r';r++);
  };
  return t;
};

inline void nextword(const char*& s){
  for(;*s==' '||*s=='\n'||*s=='\t'||*s=='\r';s++);
  for(;*s&&*s!=' '&&*s!='\n'&&*s!='\t'&&*s!='\r';s++);
  for(;*s==' '||*s=='\n'||*s=='\t'||*s=='\r';s++);
};

void puttypes(const char* s,char *ty){
  const char* r=s;
  for(;*r==' '||*r=='\n'||*r=='\t'||*r=='\r';r++);
  for(int i=0;*r;i++){
    char t='u';
    int de=0;
    for(;*r&&*r!=' '&&*r!='\n'&&*r!='\t'&&*r!='\r';r++){
      if(!isdigit(*r)){
	if(*r!='-'){
	  if(*r!='.'&&*r!='e'&&*r!='E'){
	    t='s';
	  }else{
	    if(*r=='.'){
	      if(de){
		t='s';
	      }else{
		de+=1;
	      };
	    }else{
	      if(de&2){
		t='s';
	      }else{
		de+=2;
	      };
	    };
	    if(t=='u'||t=='i'){
	      t='f';
	    };
	  };
	}else{
	  if(t=='u'){
	    t='i';
	  }else if(t=='i'){
	    t='s';
	  };
	  if(t=='f'&&*(r-1)!='e'&&*(r-1)!='E'){
	    t='s';
	  };
	};
      };
    };
    *(ty+i)=t;
    for(;*r==' '||*r=='\n'||*r=='\t'||*r=='\r';r++);
  };
};

inline int cast(char a,char b){//Not totally consistent. Used for
			       //selecting the maximum.
  switch(a){
  case 'u':
    return 1;
  case 'i':
    return(b!='u'&&b!='U');
  case 'f':
    return(b!='u'&&b!='U'&&b!='i'&&b!='I');
  case 's':
    return(b=='\0'||b=='s'||b=='S');
  default:
    return(b=='\0');
  };
};

void readline(const char* s, const char *fmt, ...){
  //Reads variables from a fixed line. The variable fmt gives a
  //list of types of variables. The remaining arguments are pointers
  //to the variables where the data should be stored, and default
  //values where appropriate. In the format string fmt, upper case
  //letters represent mandatory variables, while lower case ones
  //represent optional variables.
  va_list argptr;
  va_start(argptr,fmt);
  const char* pos=s;

  int w=countwords(s);
  char *wf=new char[w];
  puttypes(s,wf);
  char *wfp=wf;
  int l=strlen(fmt);
  for(int i=0;i<l;i++){
    switch(*(fmt+i)){
    case 'u':
    case 'U': //Unsigned integer
      {
	unsigned *u=va_arg(argptr,unsigned*);
	if(*(fmt+i)=='U'){//mandatory
	  if(*wfp!='u'){
	    va_end(argptr);
	    delete[] wf;
	    throw('u');//Unable to match argument.
	  };
	  *u=atoi(pos);
	  nextword(pos);
	  wfp++;
	}else{//optional
	  unsigned def=va_arg(argptr,unsigned);
	  //is the argument included?
	  if(*wfp!='u'){//No match - use default
	    *u=def;
	  }else{//could use this up.
	    int j=1;
	    char x='\0';
	    for(;*(fmt+i+j)&&islower(*(fmt+i+j));j++){
	      if(cast(*(wfp+j),x)){
		x=*(wfp+j);
	      };
	    };
	    if(cast(x,*(fmt+i+j))||cast(*(wfp+j),*(fmt+i+j))){//OK
	      *u=atoi(pos);
	      nextword(pos);
	      wfp++;
	    }else{//can't match if we use this up
	      *u=def;
	    };
	  };
	};
      };
      break;
    case 'i':
    case 'I': //Integer
      {
	int *ii=va_arg(argptr,int*);
	if(*(fmt+i)=='I'){//mandatory
	  if(!cast(*wfp,'i')){
	    va_end(argptr);
	    delete[] wf;
	    throw('i');//Unable to match argument.
	  };
	  *ii=atoi(pos);
	  nextword(pos);
	  wfp++;
	}else{//optional
	  int def=va_arg(argptr,int);
	  //is the argument included?
	  if(!cast(*wfp,'i')){//No match - use default
	    *ii=def;
	  }else{//could use this up.
	    int j=1;
	    char x='\0';
	    for(;*(fmt+i+j)&&islower(*(fmt+i+j));j++){
	      if(cast(*(wfp+j),x)){
		x=*(wfp+j);
	      };
	    };
	    if(cast(x,*(fmt+i+j))||cast(*(wfp+j),*(fmt+i+j))){//OK
	      *ii=atoi(pos);
	      nextword(pos);
	      wfp++;
	    }else{//can't match if we use this up
	      *ii=def;
	    };
	  };
	};
      };
      break;
    case 'f':
    case 'F': //float
      {
	float *f=va_arg(argptr,float*);
	if(*(fmt+i)=='F'){//mandatory
	  if(!cast(*wfp,'f')){
	    va_end(argptr);
	    delete[] wf;
	    throw('f');//Unable to match argument.
	  };
	  *f=atof(pos);
	  nextword(pos);
	  wfp++;
	}else{//optional
	  double def=va_arg(argptr,double);
	  //is the argument included?
	  if(!cast(*wfp,'f')){//No match - use default
	    *f=def;
	  }else{//could use this up.
	    int j=1;
	    char x='\0';
	    for(;*(fmt+i+j)&&islower(*(fmt+i+j));j++){
	      if(cast(*(wfp+j),x)){
		x=*(wfp+j);
	      };
	    };
	    if(cast(x,*(fmt+i+j))||cast(*(wfp+j),*(fmt+i+j))){//OK
	      *f=atof(pos);
	      nextword(pos);
	      wfp++;
	    }else{//can't match if we use this up
	      *f=def;
	    };
	  };
	};
      };
      break;
    case 'd':
    case 'D': //double
      {
	double *d=va_arg(argptr,double*);
	if(*(fmt+i)=='D'){//mandatory
	  if(!cast(*wfp,'d')){
	    va_end(argptr);
	    delete[] wf;
	    throw('d');//Unable to match argument.
	  };
	  *d=atof(pos);
	  nextword(pos);
	  wfp++;
	}else{//optional
	  double def=va_arg(argptr,double);
	  //is the argument included?
	  if(!cast(*wfp,'f')){//No match - use default
	    *d=def;
	  }else{//could use this up.
	    int j=1;
	    char x='\0';
	    for(;*(fmt+i+j)&&islower(*(fmt+i+j));j++){
	      if(cast(*(wfp+j),x)){
		x=*(wfp+j);
	      };
	    };
	    if(cast(x,*(fmt+i+j))||cast(*(wfp+j),*(fmt+i+j))){//OK
	      *d=atof(pos);
	      nextword(pos);
	      wfp++;
	    }else{//can't match if we use this up
	      *d=def;
	    };
	  };
	};
      };
      break;
    case 'l':
    case 'L': //long double
      {
	long double *l=va_arg(argptr,long double*);
	if(*(fmt+i)=='L'){//mandatory
	  if(!cast(*wfp,'l')){
	    va_end(argptr);
	    delete[] wf;
	    throw('l');//Unable to match argument.
	  };
	  *l=atof(pos);
	  nextword(pos);
	  wfp++;
	}else{//optional
	  long double def=va_arg(argptr,long double);
	  //is the argument included?
	  if(!cast(*wfp,'f')){//No match - use default
	    *l=def;
	  }else{//could use this up.
	    int j=1;
	    char x='\0';
	    for(;*(fmt+i+j)&&islower(*(fmt+i+j));j++){
	      if(cast(*(wfp+j),x)){
		x=*(wfp+j);
	      };
	    };
	    if(cast(x,*(fmt+i+j))||cast(*(wfp+j),*(fmt+i+j))){//OK
	      *l=atof(pos);
	      nextword(pos);
	      wfp++;
	    }else{//can't match if we use this up
	      *l=def;
	    };
	  };
	};
      };
      break;
    case 's':
    case 'S': //string
      {
	char* s=va_arg(argptr,char*);
	if(*(fmt+i)=='S'){//mandatory
	  if(*wfp=='\0'){
	    va_end(argptr);
	    delete[] wf;
	    throw('s');
	  };
	  int j=0;
	  for(;*pos&&*pos!=' '&&*pos!='\n'&&*pos!='\t'&&*pos!='\r';pos++){
	    *(s+j++)=*pos;
	  };
	  for(;*pos==' '||*pos=='\n'||*pos=='\t'||*pos=='\r';pos++);	  
	  wfp++;
	}else{//optional
	  const char* def=va_arg(argptr,const char *);
	  //is the argument included?
	  int j=1;
	  char x='\0';
	  for(;*(fmt+i+j)&&islower(*(fmt+i+j));j++){
	    if(cast(*(wfp+j),x)){
	      x=*(wfp+j);
	    };
	  };
	  if(cast(x,*(fmt+i+j))||cast(*(wfp+j),*(fmt+i+j))){//OK
	    j=0;
	    for(;*pos&&*pos!=' '&&*pos!='\n'&&*pos!='\t'&&*pos!='\r';pos++){
	      *(s+j++)=*pos;
	    };
	    for(;*pos==' '||*pos=='\n'||*pos=='\t'||*pos=='\r';pos++);
	    wfp++;
	  }else{//can't match if we use this up
	    strcpy(s,def);
	  };
	};
      };
      break;
    };
  };
  delete[] wf;
  va_end(argptr);
};

int *partition(int n,const void *p,int (*relate)(int i,int j,const void *p)){
  //partitions a set into classes, based on the function relate.
  int *ans=new int[n];
  int clno=0;
  for(int i=0;i<n;i++){
    int cl=clno;
    for(int j=0;j<i;j++){
      if((*relate)(i,j,p)){//assume the relate function is symmetric.
	if(*(ans+j)<cl){
	  cl=*(ans+j);
	}else{
	  *(ans+j)=cl;
	};
      };
    };
    if(cl==clno){
      clno++;
    };
  };
  return ans;
};

#define ZEROPART(a) (((a)>-0.0000001) && ((a)<0.0000001))

int *partition(int n,const long double *p){
  //partitions a set into classes, based on equal values in the array
  int *ans=new int[n];
  int clno=0;
  for(int i=0;i<n;i++){
    int cl=clno;
    for(int j=0;j<i;j++){
      if((*(p+i)+*(p+j))==0){
	if(*(p+i)==0){
	  if(*(ans+j)<cl){
	    cl=*(ans+j);
	  }else{
	    *(ans+j)=cl;
	  };
	};
      }else if(ZEROPART((*(p+i)-*(p+j))/(*(p+i)+*(p+j)))){//assume the relate function is symmetric.
	if(*(ans+j)<cl){
	  cl=*(ans+j);
	}else{
	  *(ans+j)=cl;
	};
      };
    };
    *(ans+i)=cl;
    if(cl==clno){
      clno++;
    };
  };
  return ans;
};


ostream& operator <<(ostream& out,strlist s){
  if(s.str!=NULL){
    out<<s.str<<"\n";
    if(s.next!=NULL){
      out<<*(s.next);
    };
  }else{
    out<<"NULL POINTER\n";
    if(s.next!=NULL){
      out<<*(s.next);
    };
  };
  return out;
};

strlist::strlist(const char *s){
  if(s==NULL){
    str=NULL;
  }else{
    str=new char[strlen(s)+1];
    strcpy(str,s);
  };
  next=NULL;
};

int strlist::search(const char *s,int n) const {
  if(str!=NULL&&strcmp(s,str)==0){
    return n;
  }else if(next==NULL){
    return -1;
  }else{
    return next->search(s,n+1);
  };
};

void strlist::remove(){
  if(next!=NULL){
    next->remove();
    delete[] next;
  };
  if(str!=NULL){
    delete[] str;
  };
};

void strlist::insert(const char *s){
  strlist *n=new strlist[1];
  n->str=str;
  n->next=next;
  next=n;
  str=new char[strlen(s)+1];
  strcpy(str,s);
};

void strlist::insert(const char *s,unsigned int n){
  strlist *ne=new strlist[1];
  ne->str=str;
  ne->next=next;
  next=ne;
  str=new char[n+1];
  for(unsigned int i=0;i<n;i++){
    *(str+i)=*(s+i);
  };
  *(str+n)='\0';
};


ostream& operator <<(ostream& out,numlist s){
  out<<s.n<<"\n";
  if(s.next!=NULL){
    out<<*(s.next);
  };
  return out;
};

void numlist::remove(){
  if(next!=NULL){
    next->remove();
    delete[] next;
  };
};

void numlist::insert(int i){
  numlist *ne=new numlist[1];
  ne->n=n;
  ne->next=next;
  next=ne;
  n=i;
};


void linklist::reverse(linklist *app,linklist *start,void *dat){
  if(next==NULL){
    if(start!=NULL){
      start->data=data;
      data=dat;
      start->next=this;
      next=(app==start)?NULL:app;
    };
  }else{
    if(app!=NULL){
      next->reverse(this,start,data);
      data=dat;
      next=app;
      if(app==start){
	next=NULL;
      }else{
	cout<<"app="<<app<<"\tstart="<<start<<"\n";
      };
    }else{
      next->reverse(this,this,data);
    };
  };
};

ostream& operator <<(ostream& out,linklist s){
  out<<s.data<<"\n";
  if(s.next!=NULL){
    out<<*(s.next);
  };
  return out;
};

int linklist::del(unsigned int n,void (*de)(void *x)){
  if(n==0){
    if(next==NULL){
      if(data!=NULL){
	(*de)(data);
      };
      data=NULL;
      return 0;
    }else{
      if(data!=NULL){
	(*de)(data);
      };
      data=next->data;
      linklist *temp=next->next;
      delete[] next;
      next=temp;
      return 1;
    };
  }else{
    if(next==NULL){
      return -1;
    }else{
      return next->del(n-1,de);
    };
  };
};

int linklist::delto(unsigned int n,void (*de)(void *x)){//inclusive
  linklist *f=this;
  for(unsigned int i=0;i<n;i++){
    f=f->next;
    if(f==NULL){//delete all data
      this->remove(de);
      return 0;
    };
  };
  linklist *temp=f->next;
  if(temp==NULL){//delete all data
    this->remove(de);
    return 0;
  };
  f->next=NULL;
  this->remove(de);
  data=temp->data;
  next=temp->next;
  delete[] temp;
  return 1;
};

void linklist::remove(void (*de)(void *x)){
  if(next!=NULL){
    next->remove(de);
    delete[] next;
    next=NULL;
  };
  if(data!=NULL){
    (*de)(data);
    data=NULL;
  };
};

void linklist::unlink(){
  if(next!=NULL){
    next->unlink();
    delete[] next;
    next=NULL;
  };
};

void linklist::insert(void *s){
  linklist *n=new linklist[1];
  n->data=data;
  n->next=next;
  next=n;
  data=s;
};

void linklist::insert(linklist &l){
  void *dat=data;
  linklist *n=next;
  next=l.next;
  data=l.data;
  if(dat==NULL){
    return;
  };
  l.data=dat;
  l.next=n;
  linklist *end=this;
  for(;end->next!=NULL;end=end->next);
  end->next=&l;
};

void linklist::insertcplst(const linklist &l){
  linklist *to=this;
  const linklist *from=&l;
  for(;from!=NULL;from=from->next){
    to->insert(from->data);
    to=to->next;
  };
};

ostream& operator <<(ostream& out,stackelt s){
  out<<s.data<<"\n";
  if(s.next!=NULL){
    out<<*(s.next);
  };
  return out;
};

ostream& operator <<(ostream& out,stack s){
  if(s.top!=NULL){
    out<<*(s.top);
  }else{
    out<<"Empty stack.\n";
  };
  return out;
};


ostream& operator <<(ostream& out,ldlist s){
  for(unsigned int i=0;i<s.sz;i++){
    out<<*(s.l+i)<<"\n";
  };
  if(s.next!=NULL){
    out<<*(s.next);
  };
  return out;
};

void ldlist::remove(){
  if(l!=NULL){
    delete[] l;
  };
  if(next!=NULL){
    next->remove();
    delete[] next;
  };
};

void ldlist::insert(int n,long double *i){
  if(l!=NULL){
    ldlist *ne=new ldlist[1];
    ne->l=l;
    ne->next=next;
    ne->sz=sz;
    next=ne;
  }else{
    next=NULL;
  };
  sz=n;
  l=new long double[n];
  for(int j=0;j<n;j++){
    *(l+j)=*(i+j);
  };
};


int* selection(const char* s){
  //Reads a selection of numbers, and returns an array of all numbers
  //selected, terminated by -1.

  const char *p=s;
  numlist sel(-1);
  while(*p){
    for(;*p==' '||*p=='\t'||*p=='\n'||*p=='\r';p++);//skip spaces.
    int i=0;
    for(;isdigit(*(p+i));i++);
    char *tmp=new char[i+1];
    for(int j=0;j<i;j++){
      *(tmp+j)=*(p+j);
    };
    *(tmp+i)='\0';
    p+=i;
    int n=atoi(tmp);
    delete[] tmp;
    if(sel.n==-1){
      sel.n=n;
    }else{
      sel.insert(n);
    };
    for(;*p==' '||*p=='\t'||*p=='\n'||*p=='\r';p++);//skip spaces.
    if(*p=='-'){//range.
      p++;
      i=0;
      for(;isdigit(*(p+i));i++);
      char *tmp=new char[i+1];
      for(int j=0;j<i;j++){
	*(tmp+j)=*(p+j);
      };
      *(tmp+i)='\0';
      p+=i;
      for(;*p==' '||*p=='\t'||*p=='\n'||*p=='\r';p++);//skip spaces.
      int m=atoi(tmp);
      delete[] tmp;
      if(m<n){//invalid range - delete last entry.
	if(sel.next==NULL){
	  sel.n=-1;
	}else{
	  sel.cutfirst();
	};
      }else{
	for(int i=n+1;i<=m;i++){
	  sel.insert(i);
	};
      };
    };
    if(*p==','){
      p++;
    };
  };
  numlist *se=&sel;
  int i=0;
  for(;se->next!=NULL;i++){
    se=se->next;
  };
  int *ans=new int[i+2];
  *(ans+i+1)=-1;
  se=&sel;
  for(;i>=0;i--){
    *(ans+i)=se->n;
    se=se->next;
  };
  sel.remove();
  return ans;
};

void sortlist(int *l){
  //Sorts the list l of natural numbers, terminated with a negative
  //number.  Uses an insertion sort, since the list will usually be
  //short, and almost ordered.
  if(*l<0){
    return;
  };
  for(int i=1;*(l+i)>=0;i++){
    if(*(l+i)<=*(l+i-1)){//Need to rearrange.
      int j=0;
      for(;*(l+j)<*(l+i);j++);
      if(*(l+j)>*(l+i)){
	int tmp=*(l+i);
	for(int k=i;k>j;k--){
	  *(l+k)=*(l+k-1);
	};
	*(l+j)=tmp;
      }else{//equal values, discard.
	for(int j=i;*(l+j)>=0;j++){
	  *(l+j)=*(l+j+1);
	};
	i--;
      };
    };
  };
};
