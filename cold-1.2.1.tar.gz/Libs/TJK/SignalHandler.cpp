/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "SignalHandler.h"
//#include <execinfo.h>
#include <fstream>
#include <iostream>
#include <errno.h>
#include <signal.h>
#include <stdarg.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
using namespace std;
#define BACKTRACESIZE 20
#include "ErrorHandler.h"
#include "Macros.h"

char* readstring(std::istream &s,const char *term);
char* readstring(std::istream &s,char &t,const char *term);



void recover(char *filename){
  Recover=new recoverState(filename);
  if(Recover->retid==NULL){
    delete Recover;
    Recover=NULL;
  };
};

pthread_mutex_t lockstate=PTHREAD_MUTEX_INITIALIZER;

class flushlock{
  //For something like the state, threads notify the lock while
  //accessing data. When one thread wants to save, all other threads
  //are stopped. The saving thread must first wait until all other
  //threads have finished with the relevant data.
  pthread_mutex_t stoplock;
  int numacc;
  pthread_mutex_t acclock;
  pthread_cond_t convar;
public:
  flushlock();
  void access();
  void access_finished();
  void flush();
  void flush_finished();
  ~flushlock();
};

flushlock flushstate;

void accessState(){
  flushstate.access();
};

void accessStateFinished(){
  flushstate.access_finished();
};

flushlock::flushlock(){
  pthread_mutex_init(&stoplock,NULL);//=PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_init(&acclock,NULL);//=PTHREAD_MUTEX_INITIALIZER;
  numacc=0;
  pthread_cond_init(&convar,NULL);//=PTHREAD_COND_INITIALIZER;
};
  
flushlock::~flushlock(){
  pthread_mutex_destroy(&stoplock);
  pthread_mutex_destroy(&acclock);
  pthread_cond_destroy(&convar);
};

void flushlock::access(){
  pthread_mutex_lock(&stoplock);
  pthread_mutex_lock(&acclock);
  numacc++;
  pthread_mutex_unlock(&acclock);
  pthread_mutex_unlock(&stoplock);
};

void flushlock::access_finished(){
  pthread_mutex_lock(&acclock);
  numacc--;
  pthread_mutex_unlock(&acclock);
  pthread_cond_broadcast(&convar);
};

void flushlock::flush(){
  pthread_mutex_lock(&stoplock);
  pthread_mutex_lock(&acclock);
  while(numacc>0){
    pthread_cond_wait(&convar,&acclock);
  };
  pthread_mutex_unlock(&acclock);
};

void flushlock::flush_finished(){
  pthread_mutex_unlock(&stoplock);
};

state::state(const char* pos){
  filename=NULL;
  data=NULL;
  type=NULL;
  numitems=NULL;
  retid=pos;
  no=NULL;
  next=0;
  command=NULL;
};

state::state(const char* pos,const char *comm){
  filename=NULL;
  data=NULL;
  type=NULL;
  numitems=NULL;
  retid=pos;
  no=NULL;
  next=0;
  command=new char[strlen(comm)+1];
  strcpy(command,comm);
};

state::~state(){
  this->clear();
  if(command!=NULL){
    delete[] command;
  };
  if(filename!=NULL){
    delete[] filename;
  };
};

void state::setfile(const char* name){
  if(filename!=NULL){
    delete[] filename;
  };
  filename=new char[strlen(name)+1];
  strcpy(filename,name);
};

void state::remvar(int num,const char *pos,int nv){
  pthread_mutex_lock(&lockstate);
  if(pos==NULL){
    pos=retid;
  };
  sigset_t all;
  sigset_t old;
  sigfillset(&all);
  sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
  retid=pos;// Do this whether the variable is removed or not.
  if(num>=0&&num<next){//valid removal.
    unsigned int i=0;
    for(;i<strlen(type)&&*(no+i)<num;i++);
    if(i==strlen(type)||*(no+i)!=num){
      pthread_mutex_unlock(&lockstate);
      sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
      //cerr<<"No variable number "<<num<<" in current state.\n";
      throw 'f';
    };
    if(i+nv>strlen(type)){
      *(type+i)='\0';
    };
    for(;i+nv<strlen(type);i++){
      *(data+i)=*(data+i+nv);
      *(type+i)=*(type+i+nv);
      *(numitems+i)=*(numitems+i+nv);
      *(no+i)=*(no+i+nv);
    };
  };
  pthread_mutex_unlock(&lockstate);
  sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
};

void state::resizedata(int n,unsigned long int sz,const char *pos){
  pthread_mutex_lock(&lockstate);
  unsigned int i=0;
  for(;i<strlen(type)&&*(no+i)<n;i++);
  if(i==strlen(type)||*(no+i)!=n){
    pthread_mutex_unlock(&lockstate);
    throw 'f';
  };
  *(numitems+i)=sz;
  retid=pos;
  pthread_mutex_unlock(&lockstate);
};

void write(char type,long unsigned int num,const void *data,ostream& out){
  //General function for writing data to a text stream.
  switch(type){
  case 'c':{//character
    char *x=(char *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j);
    };
  };
    break;
  case 's':{//short int
    short int *x=(short int *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j)<<'\t';
    };
  };
    break;
  case 'i':{//int
    int *x=(int *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j)<<'\t';
    };
  };
    break;
  case 'l':{//long int
    long int *x=(long int *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j)<<'\t';
    };
  };
    break;
  case 'f':{//float
    float *x=(float *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j)<<'\t';
    };
  };
    break;
  case 'd':{//double
    double *x=(double *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j)<<'\t';
    };
  };
    break;
  case 'L':{//Long double
    long double *x=(long double *)data;
    for(long unsigned int j=0;j<num;j++){
      out<<*(x+j)<<'\t';
    };
  };
    break;
  default://Should allow user to provide a set of routines for saving
	  //other types.
    cerr<<"Invalid data type. Unable to save.\n";
  };
};

void read(char type,long unsigned int num,void *address,istream& in){
  //General function for reading data from a text stream.
  switch(type){
  case 'c':{//character
    char *x=(char *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  case 's':{//short int
    short int *x=(short int *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  case 'i':{//int
    int *x=(int *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  case 'l':{//long int
    long int *x=(long int *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  case 'f':{//float
    float *x=(float *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  case 'd':{//double
    double *x=(double *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  case 'L':{//Long double
    long double *x=(long double *)address;
    for(long unsigned int j=0;j<num;j++){
      in>>*(x+j);
    };
  };
    break;
  default://Should allow user to provide a set of routines for saving
	  //other types.
    cerr<<"Invalid data type. Unable to load.\n";
  };
};

void readall(char type,long unsigned int max,void *address,istream& in){
  //General function for reading data from a text stream.  Need to
  //improve this to allow checking for newline, so that we stop
  //appropriately.
  const char *r=" ";
  char t='\t';
  switch(type){
  case 'c':{//character
    char *x=(char *)address;
    r=readstring(in,"\t\n");
    for(long unsigned int j=0;j<max&&*(r+j);j++){
      *(x+j)=*(r+j);
    };
    delete[] r;
  };
    break;
  case 's':{//short int
    short int *x=(short int *)address;
    for(long unsigned int j=0;j<max;j++){
      r=readstring(in,t,"\t\n");
      if(!*r)break;
      *(x+j)=atoi(r);
      delete[] r;
      if(t=='\n')break;
    };
  };
    break;
  case 'i':{//int
    int *x=(int *)address;
    for(long unsigned int j=0;j<max;j++){
      r=readstring(in,t,"\t\n");
      if(!*r)break;
      *(x+j)=atoi(r);
      delete[] r;
      if(t=='\n')break;
    };
  };
    break;
  case 'l':{//long int
    long int *x=(long int *)address;
    for(long unsigned int j=0;j<max;j++){
      r=readstring(in,t,"\t\n");
      if(!*r)break;
      *(x+j)=atol(r);
      delete[] r;
      if(t=='\n')break;
    };
  };
    break;
  case 'f':{//float
    float *x=(float *)address;
    for(long unsigned int j=0;j<max;j++){
      r=readstring(in,t,"\t\n");
      if(!*r)break;
      *(x+j)=atof(r);
      delete[] r;
      if(t=='\n')break;
    };
  };
    break;
  case 'd':{//double
    double *x=(double *)address;
    for(long unsigned int j=0;j<max;j++){
      r=readstring(in,t,"\t\n");
      if(!*r)break;
      *(x+j)=atof(r);
      delete[] r;
      if(t=='\n')break;
    };
  };
    break;
  case 'L':{//Long double
    long double *x=(long double *)address;
    for(long unsigned int j=0;j<max;j++){
      r=readstring(in,t,"\t\n");
      if(!*r)break;
      *(x+j)=atof(r);
      delete[] r;
      if(t=='\n')break;
    };
  };
    break;
  default://Should allow user to provide a set of routines for saving
	  //other types.
    cerr<<"Invalid data type. Unable to load.\n";
  };
  if(t!='\n'){//proceed to next line
    r=readstring(in,"\n");
    delete[] r;
  };
};

void state::save(){
  flushstate.flush();
  pthread_mutex_lock(&lockstate);
  if(filename!=NULL){
    ofstream out(filename,ios::out);
    if(!out.is_open()){
      cerr<<"Could not open file "<<filename<<" unable to save current state.\n";
      return;
    };
    if(command!=NULL){
      out<<command<<"\n\n";
    }
    if(retid!=NULL){
      out<<retid<<"\n";
    };
    if(type!=NULL){
      out<<type<<"\n";
      int numdata=strlen(type);
      out.precision(100);
      for(int i=0;i<numdata;i++){//for each piece of data to be saved
	write(*(type+i),*(numitems+i),*(data+i),out);
	out<<'\n';
      };
    };
  };
  pthread_mutex_unlock(&lockstate);
  flushstate.flush_finished();
};

void state::clear(){
  //Should only be called in single-threaded mode.
  if(type!=NULL){
    delete[] data;
    delete[] type;
    delete[] numitems;
    delete[] no;
    type=NULL;
    data=NULL;
    numitems=NULL;
    no=NULL;
  };
};

void state::clear(int k){
  //Should only be called in single-threaded mode.
  pthread_mutex_lock(&lockstate);
  //  if(pos==NULL){
  //    pos=retid;
  //  };
  sigset_t all;
  sigset_t old;
  sigfillset(&all);
  sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
  //  retid=pos;// Do this whether the variable is removed or not.
  unsigned int i=0;
  if(k>=0&&k<next){//valid keep.
    for(;i<strlen(type)&&*(no+i)<k;i++);
    if(i==strlen(type)||*(no+i)!=k){
      pthread_mutex_unlock(&lockstate);
      sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
      //cerr<<"No variable number "<<num<<" in current state.\n";
      throw 'f';
    };
  }else{
    pthread_mutex_unlock(&lockstate);
    sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
    cerr<<"variable "<<k<<" is not between 0 and "<<next<<"\n";
    throw 'f';
  };
  const void *d=*(data+i);
  char t=*(type+i);
  long unsigned int num=*(numitems+i);
  if(type!=NULL){
    delete[] data;
    delete[] type;
    delete[] numitems;
    delete[] no;
    type=new char[2];
    data=new const void*[1];
    numitems=new long unsigned int[1];
    no=new int[1];
    *type=t;
    *(type+1)='\0';
    *data=d;
    *numitems=num;
    *no=k;
  };
  pthread_mutex_unlock(&lockstate);
  sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
};

int state::addvar(char ty,long unsigned int sz,const void *add,const char *pos){
  pthread_mutex_lock(&lockstate);
  sigset_t all;
  sigset_t old;
  sigfillset(&all);
  sigprocmask(SIG_BLOCK,&all,&old);//Block signals while doing this
  retid=pos;
  int numtypes=0;
  if(type!=NULL){
    numtypes=strlen(type);
  };
  const void**ndata=new const void*[numtypes+1];
  char *ntypes=new char[numtypes+2];
  long unsigned int *nsizes=new long unsigned int[numtypes+1];
  int *nno=new int[numtypes+1];
  for(int i=0;i<numtypes;i++){
    *(ndata+i)=*(data+i);
    *(ntypes+i)=*(type+i);
    *(nsizes+i)=*(numitems+i);
    *(nno+i)=*(no+i);
  };
  *(ndata+numtypes)=add;
  *(ntypes+numtypes)=ty;
  *(nsizes+numtypes)=sz;
  *(ntypes+numtypes+1)='\0';
  *(nno+numtypes)=next++;
  if(type!=NULL){
    delete[] data;
    delete[] type;
    delete[] numitems;
    delete[] no;
  };
  data=ndata;
  type=ntypes;
  numitems=nsizes;
  no=nno;
  sigprocmask(SIG_SETMASK,&old,NULL);//Unblock signals again
  int ans=*(no+numtypes);
  pthread_mutex_unlock(&lockstate);
  return ans;
};

recoverState::recoverState(char *filename){
  cout<<"Trying to open file \""<<filename<<"\".\n";
  read.open(filename);
  if(!read.is_open()){
    char *x=new char[50+strlen(filename)];
    strcpy(x,"Unable to open recovery file: \"");
    strcat(x,filename);
    strcat(x,"\"");
    filemenu.setpars(&read);
    warning(x,0,&filemenu);
    delete[] x;
  };
  if(read.is_open()){
    command=readstring(read,"\n");
    read.get();
    retid=readstring(read,"\n");
    type=readstring(read,"\n");
    pos=0;//at first variable
  }else{
    retid=NULL;
    type=NULL;
    pos=0;
  };
};

void endrecover();

void recoverState::load(int n,long unsigned int* max,void **address){
  //used for resumption after process interruption.
  for(int i=0;i<n&&*(type+pos);i++){
    readall(*(type+pos++),*(max+i),*(address+i),read);
  };
  if(!*(type+pos)){//loaded whole state
    this->remove();
    endrecover();
  };
};

void recoverState::load(int n,...){
  va_list argptr;

  va_start(argptr,n);

  for(int i=0;i<n&&*(type+pos);i++){
    long unsigned int mx=va_arg(argptr,long unsigned int);
    readall(*(type+pos++),mx,va_arg(argptr,void *),read);
  };
  va_end(argptr);
  if(!*(type+pos)){//loaded whole state
    this->remove();
    endrecover();
  };
};//used for resumption after process interruption.



state* CurrentState=NULL; //This stores the current state of the program,
		     //so that if the program is interrupted, the
		     //signal handler can save the state
		     //appropriately.

void setstate(state *st){
  state *oldst=CurrentState;
  CurrentState=st;
  if(oldst!=NULL){
    oldst->clear();
  };
};

void clearstate(){
  if(CurrentState!=NULL){
    CurrentState->clear();
  };
};

recoverState* Recover=NULL;//If recovery is required, this will
				//store the necessary recovery
				//variable.

void TerminatingSignalHandler(int sig,int sigtype){
  if(sig==SIGINT){
    cerr<<"Program interrupted by user.\n";
  };
  if(sig==SIGFPE){//Identify the type of floating point error.
    switch(errno){//Still not always working
#ifdef EOVERFLOW
    case EOVERFLOW:
      cerr<<"Overflow.\n";
      break;
#endif
      /*    case :
      cerr<<"integer divide by 0 error.\n";
      break;*/
    case EDOM:
      cerr<<"Domain error.\n";
      break;
    case ERANGE:
      cerr<<"Range error.\n";
      break;
      /*    case :
      cerr<<"floating point overflow error.\n";
      break;
    case :
      cerr<<"floating point division by 0 error.\n";
      break;
    case :
      cerr<<"floating point underflow error.\n";
      break;*/
#ifdef EINVAL
    case EINVAL:
      cerr<<"Invalid floating point operation error.\n";
      break;
#endif
    default:
      cerr<<"Unspecified floating point error.\n";
      cerr<<"Error number="<<errno<<"\n";
      break;
    };
  };
  errno=0;
  //  if(errno==ENOMEM){
  //    cerr<<"Out of Memory. Aborting.\n";
  //  };
  //  perror(NULL);
  cerr<<"\n";
  printContext();
  cerr<<"\n";
  //  cerr<<"At backtrace:\n";
  //  void** bt=new void*[BACKTRACESIZE];
  //  int b=backtrace(bt,BACKTRACESIZE);
  //  backtrace_symbols_fd(bt,b,2);
  //  delete[] bt;
  if(CurrentState!=NULL){
    cerr<<"Saving current state ...\n";//This can take a while, best to let the user know.
    CurrentState->save(); //Save the current state for debugging and
			  //resumption.
  };
  signal(sig,SIG_DFL);
  raise(sig);
};

#if (defined __GLIBC__ || defined __GNU_LIBRARY__)
#include <fenv.h>
#endif

int SetUpSignalHandlers(const void *variables){
  //Sets up some signal handlers. The list of variables can influence
  //the way the signal handlers are set up. If this is NULL, then
  //default handlers are set up.
#if (defined __GLIBC__ || defined __GNU_LIBRARY__)
  feenableexcept(FE_DIVBYZERO|FE_INVALID);
#else
#warning "GNU Not Defined - floating point exceptions not enabled."
#endif
  struct sigaction shandler;
  struct sigaction oldShandler;
  shandler.sa_handler=(void(*)(int))TerminatingSignalHandler;
  sigfillset(&shandler.sa_mask);
  shandler.sa_flags=0;
  sigaction(SIGFPE,&shandler,&oldShandler);
  sigaction(SIGINT,&shandler,&oldShandler);
  sigaction(SIGTERM,&shandler,&oldShandler);
  //  atexit(clearstate);
  return 0;
};
