/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

//Routines for searching for files. Not sure how portable these are.

#include <iostream>
#include <fstream>
#include <string>
using namespace std;
#include "ErrorHandler.h"

const char *rootsearchdir=MAKESTRING(ROOTDIR);

int search(const char *const*path,const char *filename,ifstream& in){
  //Searches for the file filename in any of the directories labelled
  //in path
  int ml=0;
  for(int i=0;*(path+i);i++){
    int l=strlen(*(path+i));
    if(l>ml){
      ml=l;
    };
  };
  char *fullname=new char[ml+strlen(rootsearchdir)+strlen(filename)+3];
  ifstream test(filename);
  if(test.is_open()){
    test.close();
    if(in.is_open()){
      in.close();
    };
    in.open(filename);
    if(!in.is_open()){
      char *x=new char[30+strlen(filename)];
      strcpy(x,"IO error openning file \"");
      strcat(x,filename);
      strcat(x,"\"");
      recoverableError(x);//Should add a new file menu.      
    };
    in.clear();
    delete[] fullname;
    return 1;
  };
  strcpy(fullname,rootsearchdir);
  strcat(fullname,"/");
  strcat(fullname,filename);
  test.open(fullname);
  if(test.is_open()){
    test.close();
    if(in.is_open()){
      in.close();
    };
    in.clear();
    in.open(fullname);
    if(!in.is_open()){
      char *x=new char[30+strlen(filename)];
      strcpy(x,"IO error openning file \"");
      strcat(x,fullname);
      strcat(x,"\"");
      recoverableError(x);//Should add a new file menu.      
    };
    delete[] fullname;
    return 1;
  };
  for(int i=0;!test.is_open();i++){
    if(*(path+i)==NULL){//Not found
      delete[] fullname;
      return 0;
    };
    strcpy(fullname,*(path+i));
    strcat(fullname,"/");
    strcat(fullname,filename);
    test.open(fullname);
    if(test.is_open()){
      if(in.is_open()){
	in.close();
      };
      in.open(fullname);
      if(!in.is_open()){
	char *x=new char[30+strlen(fullname)];
	strcpy(x,"IO error openning file \"");
	strcat(x,fullname);
	strcat(x,"\"");
	recoverableError(x);//Should add a new file menu.      
      };
      break;
    };
    strcpy(fullname,rootsearchdir);
    strcat(fullname,"/");
    strcat(fullname,*(path+i));
    strcat(fullname,"/");
    strcat(fullname,filename);
    test.open(fullname);
    if(test.is_open()){
      if(in.is_open()){
	in.close();
      };
      in.open(fullname);
      if(!in.is_open()){
	char *x=new char[30+strlen(fullname)];
	strcpy(x,"IO error openning file \"");
	strcat(x,fullname);
	strcat(x,"\"");
	recoverableError(x);//Should add a new file menu.      
      };
      break;
    };
  };
  test.close();
  delete[] fullname;
  return 1;
};

char* searchall(const char *const*path,const char *filename,const char* const extensions[]){
  //Searches for the file filename in any of the directories labelled
  //in path. Failing that, it attempts to append extensions to the
  //filename.
  int ml=0;
  int i=0;
  for(;*(path+i);i++){
    int l=strlen(*(path+i));
    if(l>ml){
      ml=l;
    };
  };
  int me=0;
  int j=0;
  for(;strlen(extensions[j]);j++){
    int l=strlen(extensions[j]);
    if(l>me){
      me=l;
    };
  };
  int totaltest=2*(i+1)*(j+1);
  char *fullname=new char[ml+strlen(rootsearchdir)+strlen(filename)+10+me];
  char *fullname2=new char[ml+strlen(rootsearchdir)+strlen(filename)+10+me];
  char *answers=new char[(ml+strlen(rootsearchdir)+strlen(filename)+10+me)*totaltest];
  *answers='\0';
  *(answers+1)='\0';
  char *cpos=answers;
  ifstream test(filename);
  if(test.is_open()){
    test.close();
    strcpy(cpos,filename);
    cpos+=strlen(cpos)+1;
    *cpos='\0';
  };
  for(int i=0;strlen(extensions[i]);i++){
    strcpy(fullname,filename);
    strcat(fullname,".");
    strcat(fullname,extensions[i]);
    test.open(fullname);
    if(test.is_open()){
      test.close();
      strcpy(cpos,fullname);
      cpos+=strlen(cpos)+1;
      *cpos='\0';
    };
  };
  strcpy(fullname,rootsearchdir);
  strcat(fullname,"/");
  strcat(fullname,filename);
  test.open(fullname);
  if(test.is_open()){
    test.close();
    strcpy(cpos,fullname);
    cpos+=strlen(cpos)+1;
    *cpos='\0';
  };
  for(int i=0;strlen(extensions[i]);i++){
    strcpy(fullname2,fullname);
    strcat(fullname2,".");
    strcat(fullname2,extensions[i]);
    test.open(fullname2);
    if(test.is_open()){
      test.close();
      strcpy(cpos,fullname2);
      cpos+=strlen(cpos)+1;
      *cpos='\0';
    };
  };
  for(int i=0;!test.is_open();i++){
    if(*(path+i)==NULL){//Not found
      delete[] fullname;
      delete[] fullname2;
      return answers;
    };
    strcpy(fullname,*(path+i));
    strcat(fullname,"/");
    strcat(fullname,filename);
    test.open(fullname);
    if(test.is_open()){
      test.close();
      strcpy(cpos,fullname);
      cpos+=strlen(cpos)+1;
      *cpos='\0';
    };
    for(int j=0;strlen(extensions[j]);j++){
      strcpy(fullname2,fullname);
      strcat(fullname2,".");
      strcat(fullname2,extensions[j]);
      test.open(fullname2);
      if(test.is_open()){
	test.close();
	strcpy(cpos,fullname2);
	cpos+=strlen(cpos)+1;
	*cpos='\0';
      };
    };
    strcpy(fullname,rootsearchdir);
    strcat(fullname,"/");
    strcat(fullname,*(path+i));
    strcat(fullname,"/");
    strcat(fullname,filename);
    test.open(fullname);
    if(test.is_open()){
      test.close();
      strcpy(cpos,fullname);
      cpos+=strlen(cpos)+1;
      *cpos='\0';
    };
    for(int j=0;strlen(extensions[j]);j++){
      strcpy(fullname2,fullname);
      strcat(fullname2,".");
      strcat(fullname2,extensions[j]);
      test.open(fullname2);
      if(test.is_open()){
	test.close();
	strcpy(cpos,fullname2);
	cpos+=strlen(cpos)+1;
	*cpos='\0';
      };
    };
  };
  delete[] fullname;
  delete[] fullname2;
  return answers;
};
