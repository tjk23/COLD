/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <stdlib.h>


#include "ErrorHandler.h"
#include "SignalHandler.h"
#include "CommandLine.h"
#include "Matrix.h"
#include "Parameters.h"
#include "Optimisation.h"
#include "Tree.h"
#include "TreeLikelihood_base.h"
#include "Miscellaneous.h"
#include "Macros.h"
#include "fileExtensions.h"
#include "Testing.h"
#include "Output.h"


using namespace std;

//ofstream commentry ("/dev/null");
ostream& comm=cout;//commentry;


int NumCodons=61;
int NumCodonsSq=3721;

void simulate(const char* basefilename,long unsigned int numfiles, long unsigned int seqlength,const tree &t,params *p,int num=1,long double *pr=NULL);

void simulateheterotachy(const char* basefilename,long unsigned int numfiles, long unsigned int seqlength,const tree &t,params *p,int *pno);


void endrecover();

//int SetUpSignalHandlers(const void *variables=NULL);

void recover(char *filename);

void setmodels();

void checkformask();

void setglobals(ifstream &Qmat,const char *command);

treelk* maketreelikelihood(char *a,ifstream& data,ifstream& Qmat,int skip);

inline int getskip(char *ret){
  //changes return point into a suitable number, allowing certain
  //calculations to be skipped when resuming from a partial calculation.
  if(!strcmp(ret,"newx")){
    return 1;
  }else if(!strcmp(ret,"hessian")){
    return 2;
  }else if(!strcmp(ret,"endhessian")){
    return 3;
  }else if(!strcmp(ret,"newx")){
    return 1;
  }else if(!strcmp(ret,"newx")){
    return 1;
  }else if(!strcmp(ret,"newx")){
    return 1;
  }else if(!strcmp(ret,"newx")){
    return 1;
  }else{
    warning("Unable to identify saved state - recovery file may be incorrect or corrupted.");
    endrecover();
    return 0;
  };
};

void runsimulation(const char* basefilename,long unsigned int numfiles, long unsigned int seqlength,const tree &t,ifstream &Qmat){
  params *p;
  variable *rec=vars.seektag("-branchparameters");
  int numparsets=1;
  int *bp=NULL;
  if(rec!=NULL){
    bp=selection(*(char **)rec->value);
    for(int *bpp=bp;*bpp>=0;bpp++){
      if(*bpp+1>numparsets){
	numparsets=*bpp+1;
      };
    };
  };
  p=new params[numparsets];
  rec=vars.seektag("-freqs");
  if(rec!=NULL){
    char *x=new char[50+strlen(*(char **)rec->value)];
    sprintf(x,"Reading frequencies from file \"%s\".",*(char**)rec->value);
    info(x,msgcode(1,0));
    ifstream in;
    setifstream(*(char**)rec->value,&in);
    if(!in.good()){
      sprintf(x,"Could not open frequency file \"%s\"",*(char**)rec->value);
      recoverableError(x);//should give file menu.
    };
    p->readpi(in);
    in.close();
    for(int i=1;i<numparsets;i++){
      (p+i)->setpi(p->pi);
    };
    delete[] x;
  }; 
  rec=vars.seektag("-usematrix");
  if(rec!=NULL){
    Realmatrix Q(Qmat);
    params::usematrix(Q);
  }else{
    rec=vars.seektag("-initparsfile");
    if(rec!=NULL){
      char *x=new char[50+strlen(*(char **)rec->value)];
      sprintf(x,"Reading parameters from file \"%s\".",*(char**)rec->value);
      info(x,msgcode(1,0));
      ifstream in;
      setifstream(*(char**)rec->value,&in);
      if(!in.good()){
	sprintf(x,"Could not open initial parameter file \"%s\"",*(char**)rec->value);
	recoverableError(x);//should give file menu.
      };
      for(int i=0;i<numparsets;i++){
	(p+i)->readpars(in);
      };
      in.close();
      delete[] x;
    }else{
      rec=vars.seektag("-initpars");
      if(rec!=NULL){
	const char *initpars=*(char**)rec->value;
	long double *ps=new long double[params::numpars];
	const char *a=initpars;
	for(int j=0;j<numparsets;j++){
	  for(int i=0;i<params::numpars;i++){
	    *(ps+i)=atof(a);    
	    for(;*a&&*a!=','&&*a!=' '&&*a!='\t'&&*a!='\n'&&*a!='\r';a++);
	    for(;*a==','||*a==' '||*a=='\t'||*a=='\n'||*a=='\r';a++);
	  };
	  (p+j)->setTrueCoeff(ps);
	};
	delete[] ps;
      }else{
	Realmatrix Q(Qmat);
	p->getpars(Q);
      };
    };
  };
  /*  SHOULD IMPLEMENT THIS FOR MIXTURE MODELS
      NEED A GOOD WAY TO INPUT MIXTURE PARAMETERS.
  rec=vars.seektag("-mixfile");
  if(rec!=NULL&&num>1){
    const char* mf=*(const char **)rec->value;
    rec=vars.seektag("-path");
    const char **pt;
    if(rec==NULL){
      pt=NULL;
    }else{
      pt=*(const char ***)rec->value;
    };
    ((Mixtreelikelihood *)ff)->setmixfile(mf,pt);
  };
  rec=vars.seektag("-mixstring");
  if(rec!=NULL&&num>1){
    const char* mf=*(const char **)rec->value;
    ((Mixtreelikelihood *)ff)->setmix(mf);
    };*/
  if(vars.seektag("-unnormalised")==NULL){
    for(int i=0;i<numparsets;i++){
      (p+i)->normalise();
    };
  };
  if(bp==NULL){
    simulate(basefilename,numfiles,seqlength,t,p);
  }else{
    simulateheterotachy(basefilename,numfiles,seqlength,t,p,bp);
    delete[] bp;
  };
  delete[] p;
};

int lratsignif(long double ll,int n,long double lll,int m){
  static long double chisq[]={0,3.84,5.99,7.82,9.49,11.07,12.59,14.07,15.51,16.92,18.31,19.68,21.03,22.36,23.69,25.00,26.30,27.59,28.87,30.14,31.41,32.67,33.92,35.17,36.42,37.65,38.89,40.11,41.34,42.56,43.77,44.99,46.19,47.40,48.60,49.80,51.00,52.19,53.38,54.57,55.76,56.94,58.12,59.30,60.48,61.66,62.83,64.00,65.17,66.34,67.51,68.67,69.83,70.99,72.15,73.31,74.47,75.62,76.78,77.93,79.08,80.23,81.38,82.53,83.68,84.82,85.97,87.11,88.25,89.39,90.53,91.67,92.81,93.95,95.08,96.22,97.35,98.49,99.62,100.75,101.88,103.01,104.14,105.27,106.40,107.52,108.65,109.77,110.90,112.02,113.15,114.27,115.39,116.51,117.63,118.75,119.87,120.99,122.11,123.23,124.34};
  if(n-m<100){
    //    cout<<n-m<<" degrees of freedom.\n";
    //    cout<<"chi-squared value="<<ll-lll<<" compared to "<<chisq[n-m]<<"\n";
    return (ll-lll>chisq[n-m]);//Should improve this.
  }else{
    return (ll-lll>((n-m)*1.01+23.34));//Should improve this.
  };
};

int debuglevel;

void setdebugoutput(ostream& comm);

void setNumCodons(int n);

void replacemodeloptions(const char *command,ifstream &tr,ifstream &data);

int main(int argc,char *argv[]){
  //setvbuf(stdout,(char *)NULL,_IOLBF,1024);
  setNumCodons(61);
  int op=MAXIMISE;
  int numtimes=3;
  long double eps=1e-6;
  int b=0;

  ifstream tr;
  ifstream data;
  ifstream Qmat;

  //get arguments using a more flexible input scheme.  
  //  getargs(argc,argv,op,numtimes,parfile,treefile,datafile,matrixfile,eps);
  vars.setupvars();
  vars.addvar("treefile","t",&tr,setifstream,MAKESTRING(DEFAULTTREE),noprnt);
  //  vars.addvar("parfile","p",&(params::in),setifstream,MAKESTRING(DEFAULTPARAMS),noprnt);
  vars.addvar("datafile","d",&data,setifstream,MAKESTRING(DEFAULTDATA),noprnt);
  //  vars.addvar("matrixfile","m",&Qmat,setifstream,MAKESTRING(DEFAULTMATRIX),noprnt);
  vars.addvar("numtimes","n",&numtimes,setint,MAKESTRING(DEFAULTNUMTIMES),prntint);
  vars.addvar("operation","o",&op,setint,"1",prntint);//MAXIMISE
  vars.addvar("epsilon","e",&eps,setld,"1e-6",prntld);
  vars.setvals(argc,argv);
  SetUpSignalHandlers(&vars);

  atexit(removevarlist);

  if(vars.seektag("-unbufferedstdout")!=NULL){
    setvbuf(stdout,(char *)NULL,_IONBF,0);
    setvbuf(stderr,(char *)NULL,_IONBF,0);
  };

  unsigned int len=0;
  for(int i=0;i<argc;i++){
    len+=strlen(argv[i])+4;
  };
  char *command=new char[len];
  strcpy(command,argv[0]);
  for(int i=1;i<argc;i++){
    strcat(command," \'");
    strcat(command,argv[i]);
    strcat(command,"\'");
  }
  int skip=0;
  variable *rec=vars.seektag("-recover");
  if(rec!=NULL){
    try{
      recover(*((char**)rec->value));
    }catch(int e){
      if(e==0){
	cerr<<"Unable to open recovery file \""<<(char*)rec->value<<"\"\n";
	exit(1);//Could change this to prompt whether to continue.
      }else{
	cerr<<"Unspecified error opening recovery file \""<<(char*)rec->value<<"\"\n";
	exit(1);//Could change this to prompt whether to continue.
      };
    };
    if(Recover!=NULL){
      delete[] command;
      command=new char[strlen(Recover->command)+2];
      strcpy(command,Recover->command);
      replacemodeloptions(Recover->command,tr,data);
      skip=getskip(Recover->retid);
    };
  };

  rec=vars.seektag("f");
  if(rec!=NULL){
    char *basefname=*(char **)rec->value;
    chooseifstreams(basefname,2,treeextensions,seqextensions,&tr,&data);
  };
  setdebugoutput(comm);
  setmodels();
  setglobals(Qmat,command);
  delete[] command;
  checkformask();
  rec=vars.seektag("b");
  if(rec!=NULL){
    b=atoi(*(char**)rec->value);
  };
  int pa=0;
  rec=vars.seektag("P");
  if(rec!=NULL){
    pa=atoi(*(char**)rec->value);
  };
  rec=vars.seektag("-testparunselect");
  if(rec!=NULL){
    int *sel=selection(*(char **)rec->value);
    testundopars(sel,Qmat);
    exit(0);
  };
  try{
    rec=vars.seektag("-treenumber");
    if(rec!=NULL){
      int tn=atoi(*(char**)rec->value)-1;
      //      cout<<"Selecting tree number "<<tn<<"\n";
      for(int i=0;i<tn;i++){
	delete[] readstring(tr,"\n");//Should improve checking
					     //for blank lines.
	skipblanklines(tr);
      };
    };
    char *a=readstring(tr,"\n");
    tr.close();

    rec=vars.seektag("-simulate");
    if(rec!=NULL){
      data.close();
      char *nsim=*(char **)rec->value;
      int i=0;
      long unsigned int numfiles=1;
      long unsigned int seqlength=0;
      for(;*(nsim+i)&&*(nsim+i)!=','&&*(nsim+i)!=':';i++);
      if(*(nsim+i)==','){
	numfiles=atol(nsim);
	seqlength=atol(nsim+i+1);
      }else{
	seqlength=atol(nsim);
      };
      for(;*(nsim+i)&&*(nsim+i)!=':';i++);
      if(*(nsim+i)==':'){
	srand(atol(nsim+i+1));
      };
      const char *basefilename;
      rec=vars.seektag("-output");
      if(rec!=NULL){
	basefilename=*(char **)rec->value;
      }else{
	basefilename="simulation-output";
      };
      tree t(a);
      delete[] a;
      runsimulation(basefilename,numfiles,seqlength,t,Qmat);
      t.remove();
      Qmat.close();
      exit(0);
    };
    treelk *ff=maketreelikelihood(a,data,Qmat,skip);
    info("Set up starting values.");
    long double *x=new long double[ff->dim];
    if(skip==0){
      ff->getx(x);
    }else{
      Recover->load(1,ff->dim,x);
      ff->quickEvaluate(x);//To set the x values for better debugging.
      //      ff->normalisejustpars();//Otherwise, scaling coefficient will be wrong.
    };
    Qmat.close();
    delete[] a;
    data.close();
    long double initpen=0;
    rec=vars.seektag("-initpen");
    if(rec!=NULL){
      initpen=atof(*(char**)rec->value);
    };
    setcont(ff);
    if(vars.seektag("-testderivs")){
      info("Testing derivatives at position.");
      ff->printall();
      long double significant=5e-3;
      rec=vars.seektag("-significant");
      if(rec!=NULL){
	significant=atof(*(const char * const*)rec->value);
      };
      testfunction(*ff,x,eps,significant);
      exit(0);
    };
    int stv=CurrentState->addvar('L',ff->dim,x,"newx");
    info("Starting from position:\n");
    if(debuglevel>=0){
      ff->printall();
    };
    info("Beginning optimisation.");
    info("Trying Newton-Raphson Method:");
    interactivestarted();
    if(vars.seektag("-variableselect")){
      int *valpars=new int[params::numpars];
      int *oldvalpars=new int[params::numpars];
      for(int i=0;i<params::numpars-1;i++){
	*(valpars+i)=i+1;
      };
      *(valpars+params::numpars-1)=-1;
      long double thresh[]={TSTAT10,TSTAT5,TSTAT25,TSTAT1,TSTAT05,TSTAT01};
      int thr=0;
      int maxthr=6;
      long double *oldx=new long double[ff->dim];
      int *tselold=NULL;
      long double lastlike=1;
      int lastnum=params::numpars;
      long double tolerance=0.02;
      for(;thr<maxthr;){
	if(!NewtonRaphson(*ff,x,numtimes,op,stv,ff->posvals(),ff->constraints(),ff->cst(),tolerance,initpen)){
	  outputnoconverge(numtimes,ff,x,argc,argv,valpars);
	};
	tolerance=1e-4;
	long double val=ff->evaluate(x);
	if(lastlike<=0&&lratsignif(lastlike,lastnum,val,params::numpars)){
	  ff->undoselect(tselold,lastnum);
	  outputconverge(ff,oldx,argc,argv,oldvalpars);
	};
	int nochange;
	printconverge(ff,oldx,valpars);
	ff->normalise();
	ff->getx(x);
	do{
	  nochange=0;
	  //	  cout<<"Threshold="<<thresh[thr]<<"\n";
	  int *tsel=ff->tstatsel(x,thresh[thr]);
	  int i=0;
	  for(int i=0;i<params::numpars-1;i++){
	    *(oldvalpars+i)=*(valpars+i);
	  };
	  *(oldvalpars+params::numpars-1)=-1;
	  for(;*(tsel+i)>0;i++){
	    *(valpars+i)=*(valpars+*(tsel+i)-1);
	  };
	  *(valpars+i)=-1;//*(valpars+*(tsel+i)-1);
	  //	  for(int j=0;*(valpars+j)>0;j++){
	  //	    cout<<*(valpars+j)<<"  ";
	  //	  };
	  //	  cout<<"\n\n";
	  if(i==params::numpars-1){//No change
	    thr++;
	    nochange=1;
	  }else{
	    lastnum=params::numpars;
	    for(int j=0;j<ff->dim;j++){
	      *(oldx+j)=*(x+j);
	    };
	    ff->normalise();
	    ff->selectpars(tsel);
	    ff->normalisejustpars();
	    ff->getx(x);
	    if(debuglevel>=0){
	      for(int i=0;*(tsel+i)>=0;i++){
		cout<<*(tsel+i)<<"  ";
	      };
	      cout<<"\n";
	      ff->printall();
	    };
	  };
	  if(tselold!=NULL){
	    delete[] tselold;
	  };
	  tselold=tsel;
	}while(nochange&&thr<maxthr);
	lastlike=val;
      };
      outputconverge(ff,x,argc,argv,valpars);
    }else{
      long double tolerance=1e-5;
      if(NewtonRaphson(*ff,x,numtimes,op,stv,ff->posvals(),ff->constraints(),ff->cst(),tolerance,initpen)){
	outputconverge(ff,x,argc,argv);
      }else{
	if(vars.seektag("-converge")!=NULL){
	  outputconverge(ff,x,argc,argv);
	}else{
	  outputnoconverge(numtimes,ff,x,argc,argv);
	};
      };
    };
    delete[] x;
  }catch(int u){
    cerr<<"Badly formatted tree file.\n"<<u<<" left brackets not closed.";
    exit(1);
  };
};
