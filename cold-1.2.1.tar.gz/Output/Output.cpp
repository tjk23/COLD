/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <math.h>


//General headers
#include "CommandLine.h"
#include "ErrorHandler.h"
#include "Miscellaneous.h"
#include "State.h"

//COLD-specific headers
#include "TreeLikelihood.h"
#include "MixTreeLikelihood.h"

using namespace std;

void substitute(istream &in,ostream& out);
void markup(istream &in,ostream &out);
void *setPlaceHolders(const char *libname);

void outputconverge(treelk *ff,long double *x,int argc,char* argv[],int *valpars){
  ff->normalise();
  ff->getx(x);
  int numout=1;//number of output files to be produced
  ostream **out;//=&cout;
  ifstream *in=NULL;
  variable *rec=vars.seektag("-output");
  if(rec!=NULL){
    //Count number of output files to be produced:
    const char *c=*(char **)rec->value;
    for(const char *t=c;*t;t++){
      if(*t==','){
	numout++;
      };
    };
    int maxlen=0;
    int curlen=0;
    for(const char *t=c;*t;t++){
      curlen++;
      if(*t==','||*t==':'){
	curlen=0;
      };
      if(curlen>maxlen){
	maxlen=curlen;
      };
    };
    char *fn=new char[maxlen+2];
    out=new ostream*[numout];
    in=new ifstream[numout];
    const char *t=c;
    for(int i=0;i<numout;i++){      
      char *f=fn;
      for(;*t&&*t!=':'&&*t!=',';t++){
	*(f++)=*t;
      };
      *f='\0';
      if(strcmp(fn,"-")){
	*(out+i)=new ofstream(fn);
	if(!(((ofstream *)(*(out+i)))->is_open())){
	  cout<<"Could not open file "<<fn<<"\n";
	};
      }else{
	*(out+i)=&cout;
      };
      if(*t==':'){
	t++;
	char *f=fn;
	for(;*t&&*t!=',';t++){
	  *(f++)=*t;
	};
	*f='\0';
	setifstream(fn,in+i);
      }else if(*t=='\0'){
	rec=vars.seektag("-outputtemplate");
	if(rec!=NULL){
	  setifstream(*(char **)rec->value,in+i);
	};
      }else{
	fatalError("Badly formatted output file name.");
      };
      if(!(in+i)->is_open()){
	cout<<"Could not open file "<<fn<<"\n";
      };
      if(*t&&*t!=','){
	fatalError("Badly formatted output file.");	
      };
      t++;
      /*      **(out+i)<<CurrentState->getcommand()<<"\n\n";
      for(int j=0;j<argc;j++){
	**(out+i)<<argv[j]<<" ";
      };
      **(out+i)<<"\n\n";*/
    };
    delete[] fn;
  }else{
    out=new ostream*[1];
    *out=&cout;
    rec=vars.seektag("-outputtemplate");
    if(rec!=NULL && in==NULL){
      in=new ifstream[1];
      setifstream(*(char **)rec->value,in);
    };
  };  
  const char *tempfilename="tempfile";
  rec=vars.seektag("-tempfile");
  if(rec!=NULL){
    tempfilename=*(const char **)rec->value;
  };

  void *addr=setPlaceHolders("libColdOutput.so.1.0.0");
  void (*stp)(int,treelk *,const long double *,const int *,int,const int *,const char *)=*(void (**)(int,treelk *,const long double *,const int *,int,const int *,const char *))addr;
  int num=1;
  rec=vars.seektag("-mixture");
  if(rec!=NULL){
    num=atoi(*(char **)rec->value);
  };
  (*stp)(num,ff,x,NULL,1,valpars,CurrentState->getcommand());

  for(int i=0;i<numout;i++){
    ofstream temp(tempfilename);
    substitute(*((ifstream *)in+i),temp);
    temp.close();
    ifstream temp2(tempfilename);
    markup(temp2,**(out+i));
    temp2.close();
    ((ifstream *)in+i)->close();
    ((ofstream *)*(out+i))->close();
  };
  remove(tempfilename);
  delete ff;
  delete[] (ifstream *)in;
  if(vars.seektag("-output")!=NULL){
    for(int i=0;i<numout;i++){
      if(*(out+i)!=&cout){
	delete *(out+i);
      };
    };
  };
  delete[] out;
  if(vars.seektag("-keepstate")==NULL){
    rec=vars.seektag("-state");
    if(rec!=NULL){
      remove(*(char **)rec->value);
    }else{
      remove("statefile");
    };
  };
};




void outputnoconverge(int numtimes,treelk *ff,long double *x,int argc,char* argv[],int *valpars=NULL){
  ostream *out=&cout;
  variable *rec=vars.seektag("-output");
  if(rec!=NULL){
    out=new ofstream(*(char **)rec->value);
    if(!((ofstream *)out)->is_open()){
      cout<<"Could not open file "<<*(char **)rec->value<<"\n";
      out=&cout;
    };
  };
  for(int i=0;i<argc;i++){
    *(out)<<argv[i]<<" ";
  };
  *(out)<<"\n\n";
  if(valpars!=NULL){
    *(out)<<"Parameters selected:\n";
    for(int i=0;*(valpars+i)>0;i++){
      *(out)<<*(valpars+i)<<"  ";
    };
    *(out)<<"\n\n";
  };
  *(out)<<"Failed to converge after "<<numtimes<<" steps. Currently at:\n\n";
  out->precision(10);
  long double val=ff->quickEvaluate(x);
  ff->normalise();
  ff->printall(*out);
  *(out)<<"\n\n Log likelihood="<<val<<"\n\n";
  int dm=ff->edges()+params::numpars-1;
  if(vars.seektag("-approximatehessian")){
    long double *ah=new long double[dm*dm];
    ff->trueapproxHessian(x,ah);
    (*out)<<"Approximate hessian:\n\n";
    for(int i=0;i<dm;i++){
      for(int j=0;j<dm;j++){
	*(out)<<*(ah+i*dm+j)<<" ";
      };
      (*out)<<"\n";
    };
    (*out)<<"\n";
  };
  if(vars.seektag("-hessian")){
    long double *h=new long double[dm*dm];
    ff->truehessian(x,h);
    (*out)<<"Hessian:\n\n";
    for(int i=0;i<dm;i++){
      for(int j=0;j<dm;j++){
	*(out)<<*(h+i*dm+j)<<" ";
      };
      (*out)<<"\n";
    };
    (*out)<<"\n";
  };
  //  delete[] x;
  delete ff;
  if(rec!=NULL){
    ((ofstream *)out)->close();
    delete out;
  };
};

void printconverge(treelk *ff,long double *x,int *valpars=NULL){
  if(valpars!=NULL){
    cout<<"Parameters selected:\n";
    for(int i=0;*(valpars+i)>0;i++){
      cout<<*(valpars+i)<<"  ";
    };
    cout<<"\n\n";
  };
  cout<<"Converged to:\n\n";
  cout.precision(10);
  ff->normalise();
  ff->printall(cout,valpars);
  ff->getx(x);
  long double val=ff->quickEvaluate(x);
  cout<<"\n\n Log Likelihood="<<val<<"\n\n";
  if(vars.seektag("-printsitelikes")){
    long double *sl=ff->sitelikes();
    cout<<"Site\t\tLikelihood\n\n";
    int sites=ff->numsites();
    for(int i=0;i<sites;i++){
      cout<<i+1<<"\t\t"<<*(sl+i)<<"\n";
    };
    delete[] sl;
  };
  if(vars.seektag("-tstats")){
    ff->tstat(x,cout);
  };
};


