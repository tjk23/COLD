#!/bin/bash

#   Copyright 2011 Toby Kenney
#
#   This file is part of Cold.
#
#   Cold is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   Cold is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

echo $2
cd $2
pwd
if [ -e LastMake ]
then
libdir=`grep libdir LastMake |cut -f2 -d'='`
possiblesizes=`grep POSSIBLESIZES LastMake |cut -f2 -d'='`
for size in $possiblesizes
do
if test $1 -eq $size
then
echo Library for size $1 is already installed.
exit 0
fi
done
make POSSIBLESIZES="$possiblesizes $1"
echo Libraries must be installed in $libdir
if [ -w $libdir ]
then
make updatelibCode$1
else
sudo make updatelibCode$1
fi
else
echo Cannot detect installation information for COLD. Unable to update libraries.
fi