#!/bin/bash

#   Copyright 2011 Toby Kenney
#
#   This file is part of Cold.
#
#   Cold is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   Cold is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with Cold.  If not, see <http://www.gnu.org/licenses/>.


#reads text files into header files for the software COLD. These
#header files can then be included in the relevant c++ files. This
#means that compile-time data is compiled into the program.

thisdir=`echo "$0" | sed 's+/[^/]*$++'`

if test $# -eq 3
then

headerfile=$1
dataname=$2
datafile=$3

else if test $# -eq 2
then

headerfile=$1
dataname=`echo $headerfile |  sed 's/.[^.]*$//' | sed 's=.*/==' `
datafile=$2

else if test $# -eq 1
then

datafile=$1
dataname=`echo $datafile | sed 's/.[^.]*$//' | sed 's=.*/==' `
headerfile=$dataname.h


fi
fi
fi

includeguard=`echo $headerfile | sed 's=.*/==' | tr a-z. A-Z_`
lines=`wc -l $datafile | awk '{print $1}'`
countname=NUM`echo $dataname | tr a-z A-Z`

$thisdir/autogenmessage $headerfile $0 $datafile

echo "#ifndef $includeguard" >> $headerfile
echo "#define $includeguard" >> $headerfile
echo "const char *$dataname[]={" >> $headerfile
awk 'a==1{ORS="\n";print ","};{ORS="";print "\""$0"\"";a=1}' $datafile >> $headerfile
echo "};" >> $headerfile
echo "#define $countname $lines" >> $headerfile
echo "#endif" >> $headerfile
