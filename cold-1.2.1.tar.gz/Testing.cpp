/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include<iostream>
#include<fstream>

#include "Matrix.h"
#include "Parameters.h"
#include "CommandLine.h"
#include "ErrorHandler.h"

using namespace std;

void testundopars(int *sel,ifstream& Qmat){
  params p;
  params::orthmats();
  variable *rec=vars.seektag("-initpars");
  if(rec!=NULL){
    char *x=new char[50+strlen(*(char **)rec->value)];
    sprintf(x,"Reading parameters from file \"%s\".",*(char**)rec->value);
    info(x,msgcode(1,0));
    ifstream in;
    setifstream(*(char**)rec->value,&in);
    if(!in.good()){
      sprintf(x,"Could not open initial parameter file \"%s\"",*(char**)rec->value);
      recoverableError(x);//should give file menu.
    };
    p.readpars(in);
    in.close();
    delete[] x;
  }else{
    Realmatrix Q(Qmat);
    p.getpars(Q);
  };
  p.normalise();
  long double *tc=p.truepars();
  for(int i=0;i<params::numpars;i++){
    cout<<*(tc+i)<<" ";
  };
  cout<<"\n\n";
  int np=params::numpars;
  Realmatrix *oldx=new Realmatrix[np];
  for(int i=0;i<np;i++){
    *(oldx+i)=*(params::XX+i);
  };
  p.selectpars(sel);
  p.undoselect(sel,np);
  tc=p.truepars();
  for(int i=0;i<params::numpars;i++){
    cout<<*(tc+i)<<" ";
  };
  cout<<"\n\n";
  for(int i=0;i<np;i++){
    long double err=0;
    for(int j=0;j<NumCodonsSq;j++){
      long double df=*((oldx+i)->entries+j)-*((params::XX+i)->entries+j);
      if(df<0){
	df=-df;
      };
      if(df>err){
	err=df;
      };
    };
    cout<<err<<"\n";
  };
};
