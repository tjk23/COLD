/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>

#include "Matrix.h"
#include "Miscellaneous.h"
using namespace std;

int NumCodons=64;
int NumCodonsSq=4096;


const char nucleotides[]="TCAG";

inline int getAAno(char a){
  switch(a){
  case 'A':
    return 0;
  case 'C':
    return 1;
  case 'D':
    return 2;
  case 'E':
    return 3;
  case 'F':
    return 4;
  case 'G':
    return 5;
  case 'H':
    return 6;
  case 'I':
    return 7;
  case 'K':
    return 8;
  case 'L':
    return 9;
  case 'M':
    return 10;
  case 'N':
    return 11;
  case 'P':
    return 12;
  case 'Q':
    return 13;
  case 'R':
    return 14;
  case 'S':
    return 15;
  case 'T':
    return 16;
  case 'V':
    return 17;
  case 'W':
    return 18;
  case 'Y':
    return 19;
  default:
    return 30;
  };
};

void addcode(const char *name, const char *AA,const char *codesfile){//,const char *AAmatfile,const char *parameterfilebasename){
  //Adds a genetic code to the codefile, and produces the parameter
  //matrices for the code. Currently only works for codon length 3.
  NumCodons=64;
  ofstream out(codesfile,ios_base::app);
  out<<name<<" ";
  int i=0;
  for(;*(AA+i);i++){
    if(*(AA+i)=='-'){//stop codon
      out<<nucleotides[(i/4)%4]<<nucleotides[i/16]<<nucleotides[i%4]<<" ";
      NumCodons--;
    };
  };
  for(;i<64;i++){
    out<<nucleotides[(i/4)%4]<<nucleotides[i/16]<<nucleotides[i%4]<<" ";
    NumCodons--;
  };
  out<<"  :  "<<AA<<"\n";
  out.close();
  /*
  ifstream AAstream(AAmatfile);
  char *mttflnm=new char[strlen(parameterfilebasename)+strlen(name)+5];
  strcpy(mttflnm,parameterfilebasename);
  strcat(mttflnm,"-");
  strcat(mttflnm,name);
  ofstream matout(mttflnm);
  delete[] mttflnm;
  Realmatrix CD(NumCodons);
  Realmatrix AAmat;
  for(AAmat=Realmatrix(AAstream);AAmat.sz>1;){
    int ii=0;
    for(int i=0;i<NumCodons;i++){
      int AAnoi;
      for(AAnoi=getAAno(*(AA+ii++));AAnoi==30;AAnoi=getAAno(*(AA+ii++)));
      int jj=0;
      for(int j=0;j<NumCodons;j++){
	int AAno;
	for(AAno=getAAno(*(AA+jj++));AAno==30;AAno=getAAno(*(AA+jj++)));
	*(CD.entries+i*NumCodons+j)=*(AAmat.entries+AAnoi*AAmat.sz+AAno);
      };    
    };    
    matout<<CD<<"\n\n";
    if(AAstream.good()&&!AAstream.eof()){
      AAmat=Realmatrix(AAstream);
    }else{
      break;
    };
  };
  matout.close();
  AAstream.close();
  */
};

void inline skipblanks(istream &in){
  for(;in.good()&&!in.eof()&&(in.peek()=='\n'||in.peek()=='\t'||in.peek()=='\r'||in.peek()==' ');in.get());
};

void makematrices(const char *name, const char *AA,const char *parameterfilebasename){
  int i=0;
  /*  for(;*(AA+i);i++){
    if(*(AA+i)=='-'){//stop codon
      NumCodons--;
    };
    };*/
  Realmatrix ans(NumCodons);
  Realmatrix M;
  ifstream in(parameterfilebasename);
  if(!(in.is_open())){
    throw 0;
  };
  ifstream matstr;
  char *mttflnm=new char[strlen(parameterfilebasename)+strlen(name)+5];
  strcpy(mttflnm,parameterfilebasename);
  strcat(mttflnm,"-");
  strcat(mttflnm,name);
  ofstream matout(mttflnm);
  delete[] mttflnm;
  int *inM=new int[NumCodons];
  for(;in.good()&&!in.eof();){
    skipblanks(in);
    if(!in.good()||in.eof()){
      break;
    };
    char *name=readstring(in,":");  
    if(in.eof()){
      break;
    };
    skipblanks(in);
    char *style=readstring(in," \t\r");
    skipblanks(in);
    char *file=readstring(in," \t\r");
    skipblanks(in);
    char *num=readstring(in," \t\r\n");
    int nm=atoi(num);
    matstr.open(file);
    if(!matstr.is_open()){
      cerr<<"Could not open file \""<<file<<"\"\n";
      exit(1);
    };
    for(int i=1;i<nm;i++){
      dummyreadmatrix(matstr);
    };
    M=RealmatrixT(matstr);
    matstr.close();
    if(!strcmp(style,"DNA_med")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  if(a1<a2){
	    if(a2<a3){
	      *(ans.entries+i*NumCodons+j)=a2;
	    }else if(a1<a3){
	      *(ans.entries+i*NumCodons+j)=a3;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a1;
	    };
	  }else{
	    if(a3<a2){
	      *(ans.entries+i*NumCodons+j)=a2;
	    }else if(a1<a3){
	      *(ans.entries+i*NumCodons+j)=a1;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a3;
	    };
	  };
	};
      };
    }else if(!strcmp(style,"DNA_max")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  if(a1<a2){
	    if(a2<a3){
	      *(ans.entries+i*NumCodons+j)=a3;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a2;
	    };
	  }else{
	    if(a3<a1){
	      *(ans.entries+i*NumCodons+j)=a1;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a3;
	    };
	  };
	};
      };
    }else if(!strcmp(style,"DNA_min")){
      int j=0;
      for(int i=0;i<64;i++){
	if(i<strlen(AA)&&*(AA+i)!='-'){
	  *(inM+j++)=i;
	};
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  long double a1=*(M.entries+(*(inM+i)/16)*M.sz+*(inM+j)/16);
	  long double a2=*(M.entries+((*(inM+i)/4)%4)*M.sz+((*(inM+j)/4)%4));
	  long double a3=*(M.entries+(*(inM+i)%4)*M.sz+(*(inM+j)%4));
	  if(a1<a2){
	    if(a1<a3){
	      *(ans.entries+i*NumCodons+j)=a1;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a3;
	    };
	  }else{
	    if(a3<a2){
	      *(ans.entries+i*NumCodons+j)=a3;
	    }else{
	      *(ans.entries+i*NumCodons+j)=a2;
	    };
	  };
	};
      };
    }else{
      if(!strcmp(style,"DNA_1")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=i/16;
	  };
	};
      }else if(!strcmp(style,"DNA_2")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=(i/4)%4;
	  };
	};
      }else if(!strcmp(style,"DNA_3")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=i%4;
	  };
	};
      }else if(!strcmp(style,"AA")){
	int j=0;
	for(int i=0;i<64;i++){
	  if(i<strlen(AA)&&*(AA+i)!='-'){
	    *(inM+j++)=getAAno(*(AA+i));
	  };
	};
      }else{
	cerr<<"Unknown matrix style: \""<<style<<"\"\n";
	exit(1);
      };
      for(int i=0;i<NumCodons;i++){
	for(int j=0;j<NumCodons;j++){
	  *(ans.entries+i*NumCodons+j)=*(M.entries+*(inM+i)*M.sz+*(inM+j));
	};
      };
    };
    delete[] file;
    delete[] style;
    delete[] name;
    delete[] num;
    matout<<ans<<"\n\n";
  };
  delete[] inM;
  in.close();
  matout.close();
};

int main(int argc,char *argv[]){
  if(argc<4){
    cout<<"Usage: \""<<argv[0]<<" CODENAME AMINOACIDS CODESFILE PARAMETERFILENAMES\"\n";
    exit(1);
  };
  addcode(argv[1],argv[2],argv[3]);
  for(int i=4;i<argc;i++){
    makematrices(argv[1],argv[2],argv[i]);
  };//,argv[4],argv[5]);
};
