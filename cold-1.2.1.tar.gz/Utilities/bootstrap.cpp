/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include<iostream>
#include<fstream>
#include"MiscellaneousFuns.h"
#include<stdlib.h>
using namespace std;

void bootstrapCodon(unsigned int *r,const char *seq,ostream &out){
  char tmp[3];
  for(int i=0;*seq;i++){
    tmp[0]=*seq;
    for(seq++;*seq==' '||*seq=='\t'||*seq=='\r';seq++);
    if(*seq=='\0'){
      break;
    };
    tmp[1]=*seq;
    for(seq++;*seq==' '||*seq=='\t'||*seq=='\r';seq++);
    if(*seq=='\0'){
      break;
    };
    tmp[2]=*seq;
    for(seq++;*seq==' '||*seq=='\t'||*seq=='\r';seq++);
    for(unsigned int j=0;j<*(r+i);j++){
      out<<tmp[0]<<tmp[1]<<tmp[2];
    };
  };
};

unsigned int* getBootstrapSequence(unsigned int a){
  unsigned int *ans=new unsigned int[a];
  for(unsigned int i=0;i<a;i++){
    *(ans+i)=0;
  };
  for(unsigned int i=0;i<a;i++){
    (*(ans+(rand()+i)%a))++;
  };
  return ans;
};

void Bootstrap(ifstream &in,ostream &out,int len=-1){
  streampos st=in.tellg();
  int numseq;
  char rd;
  char *firstline=readstring(in,"\n");
  try{
    readline(firstline,"uU",&numseq,-1,&len);
    out<<firstline<<"\n";
  }catch(char x){//firstline doesn't give general information
    in.seekg(st);
    numseq=-1;
  };
  if(len==-1){
    throw(-1);//
  };
  unsigned int *r=getBootstrapSequence(len/3);
  //  f.clear();
  while(in.good()){
    for(in.get(rd);in.good()&&(rd==' '||rd=='\n'||rd=='\r'||rd=='\t');in.get(rd)){
      out<<rd;
    };
    for(;in.good()&&rd!=' '&&rd!='\t'&&rd!='\r'&&rd!='\n';in.get(rd)){
      out<<rd;
    };
    out<<rd;
    for(;in.good()&&(in.peek()==' '||in.peek()=='\n'||in.peek()=='\r'||in.peek()=='\t');in.get(rd)){
      out<<rd;
    };
    char *seq=readstring(in,"\n");
    bootstrapCodon(r,seq,out);
    out<<"\n";
    delete[] seq;
  };
  delete[] firstline;
};


int main(int argc,char *argv[]){
  if(argc<2){
    cout<<"Usage \""<<argv[0]<<" inputfile [outputfile] [randomseed]\"\n";
    exit(0);
  };
  ifstream in(argv[1]);
  if(!in.is_open()){
    cerr<<"Could not open file \""<<argv[1]<<"\".\n";
    exit(1);
  };    
  if(argc==2){
    Bootstrap(in,cout);    
  }else{
    ofstream out(argv[2]);
    if(!out.is_open()){
      int i=atoi(argv[2]);
      if(i==0){
	cerr<<"Could not open file \""<<argv[2]<<"\".\n";
      }else{
	srand(i);
      };
      Bootstrap(in,cout);          
    }else{        
      if(argc>3){
	int i=atoi(argv[3]);
	srand(i);
      };
      Bootstrap(in,out);        
      out.close();
    };
  };
};
