/*

Calculates Patristic distances from tree file.

 */
#include "Matrix.h"
#include "Miscellaneous.h"
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>

using namespace std;

strlist Names;
unsigned int ntaxa;

RealmatrixT combinePatDist(const Realmatrix &A,const Realmatrix &B,long double alen,long double blen){
  Realmatrix Ans(A.sz+B.sz);
  for(unsigned int i=0;i<(unsigned)A.sz;i++){
    for(unsigned int j=0;j<(unsigned)A.sz;j++){
      *(Ans.entries+i*Ans.sz+j)=*(A.entries+i*A.sz+j);
    };
    for(unsigned int j=0;j<(unsigned)B.sz;j++){
      *(Ans.entries+i*Ans.sz+A.sz+j)=*(A.entries+i*(A.sz+1))+*(B.entries+j*(B.sz+1))+alen+blen;
    };
    *(Ans.entries+i*(Ans.sz+1))+=alen;
  };
  for(unsigned int i=0;i<(unsigned)B.sz;i++){
    for(unsigned int j=0;j<(unsigned)A.sz;j++){
      *(Ans.entries+(A.sz+i)*Ans.sz+j)=*(A.entries+j*(A.sz+1))+*(B.entries+i*(B.sz+1))+alen+blen;
    };
    for(unsigned int j=0;j<(unsigned)B.sz;j++){
      *(Ans.entries+(A.sz+i)*Ans.sz+A.sz+j)=*(B.entries+i*B.sz+j);
    };
    *(Ans.entries+(A.sz+i)*(Ans.sz+1))+=blen;
  };
  return Ans;
};

RealmatrixT getPatDistance(const char *tree,unsigned int n){
  //  cout<<tree<<"\n"<<tree+n<<"\n";
  int level=-1;
  unsigned int a=0;
  Realmatrix A;
  A.sz=0;
  long double alen=0;
  for(unsigned int m=0;m<n;m++){
    if(*(tree+m)=='('){
      level++;
      if(level==0){
	a=m+1;
      };
    }else if(*(tree+m)==')'){
      level--;
      if(level<0){
	unsigned int s=0;
	for(;s<m-a&&*(tree+m-s)!=':';s++);
	long double blen=atof(tree+m+1-s);
	Realmatrix B=getPatDistance(tree+a,m-a);
	A=combinePatDist(A,B,alen,blen);
	alen=0;
      };
    }else if(level==0&&(*(tree+m)==','||*(tree+m)==')')){
      unsigned int s=0;
      for(;s<m-a&&*(tree+m-s)!=':';s++);
      if(A.sz==0){
	alen=atof(tree+m+1-s);
	A=getPatDistance(tree+a,m-a);
      }else{
	long double blen=atof(tree+m+1-s);
	Realmatrix B=getPatDistance(tree+a,m-a);
	A=combinePatDist(A,B,alen,blen);
	alen=0;
      };
      a=m+1;
    };
  };
  if(a==0){//Leaf
    unsigned int s=n-1;
    for(;(s>0)&&*(tree+s)!=':';s--);
    if(s==0){
      s=n;
    };
    Names.insert(tree,s);
    ntaxa++;
    A=Realmatrix(1);
    *A.entries=0;
  };
  //  cout<<ntaxa<<'\n';
  return A;
};

int main(int argc,char *argv[]){
  if(argc<2){
    cout<<"Usage: \""<<argv[0]<<" infile [outfile] [speciesfile]\" ";
    exit(0);
  };
  const char* outfile;
  if(argc<3){
    char* out=new char[strlen(argv[1])+6];
    strcpy(out,argv[1]);
    strcat(out,".dist");
    outfile=out;
  }else{
    outfile=argv[2];
  }; 
  ifstream in(argv[1]);
  ofstream out(outfile);
  if(!in.is_open()){
    cerr<<"Could not open tree file \""<<argv[1]<<"\"\n";
    exit(1);
  };
  if(!out.is_open()){
    cerr<<"Could not open output file \""<<outfile<<"\"\n";
    exit(1);
  };
  streampos st=in.tellg();
  char *tree=readstring(in,";");
  in.close();
  Realmatrix R=getPatDistance(tree,strlen(tree));
  ifstream nlist;
  if(argc>3){//Order Specified
    nlist.open(argv[3]);
  };
  if(!nlist.is_open()){
    if(argc>3){
      cerr<<"Unable to open name file \""<<argv[3]<<"\".\nOutputting in tree order";
    };
    out<<R.sz<<"\n";
    for(int i=0;i<R.sz;i++){
      out<<Names.getstr(R.sz-i-1)<<"   ";
      for(int j=0;j<R.sz;j++){
	out<<*(R.entries+i*R.sz+j)<<"  ";
      };
      out<<"\n";
    };
    out<<"\n";
  }else{//Order specified
    int *ord=new int[ntaxa];      
    for(unsigned int i=0;i<ntaxa;i++){
      char *nm=readnonemptystring(nlist," \n\t\r");
      *(ord+i)=Names.search(nm);
      if(*(ord+i)<0){
	cerr<<"Unable to find species \""<<nm<<"\".\n";
	exit(0);
      };
      delete[] nm;
      *(ord+i)=R.sz-*(ord+i)-1;
    };
    out<<R.sz<<"\n";
    for(int i=0;i<R.sz;i++){
      out<<Names.getstr(R.sz-*(ord+i)-1)<<"   ";
      for(int j=0;j<R.sz;j++){
	out<<*(R.entries+*(ord+i)*R.sz+*(ord+j))<<"  ";
      };
      out<<"\n";
    };
    out<<"\n";
  };
  out.close();  
};
