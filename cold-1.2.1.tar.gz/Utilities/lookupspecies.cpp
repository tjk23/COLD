/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>

int NumCodons=61;
int NumCodonsSq=3721;

#include "Miscellaneous.h"
#include "Tree.h"
using namespace std;

int main(int argc,char *argv[]){
  if(argc<3){
    cout<<"Usage: \""<<argv[0]<<" Treefile Datafile [Newtreefile]\"\n";
    exit(0);
  };
  const char* outfile;
  if(argc==3){
    char* out=new char[strlen(argv[1])+6];
    strcpy(out,argv[1]);
    strcat(out,".names");
    outfile=out;
  }else{
    outfile=argv[3];
  }; 
  cout<<"Data file: \""<<argv[2]<<"\"\n";
  ifstream f(argv[2]);
  ifstream in(argv[1]);
  ofstream out(outfile);
  if(!f.is_open()){
    cerr<<"Could not open data file \""<<argv[2]<<"\"\n";
    exit(1);
  };
  if(!in.is_open()){
    cerr<<"Could not open tree file \""<<argv[1]<<"\"\n";
    exit(1);
  };
  streampos st=f.tellg();
  char *firstline=readstring(f,"\n");
  unsigned int numseq=0;
  unsigned int len=0;
  try{
    readline(firstline,"uU",&numseq,-1,&len);
  }catch(char x){//firstline doesn't give general information
    f.seekg(st);
  };
  st=f.tellg();
  for(;in.good()&&!in.eof();){
    char *a=readstring(in,"\n");
    tree t(a);
    t.substitutenames(f,st);
    delete[] a;
    out<<t<<"\n";
    for(;in.good()&&!in.eof()&&(in.peek()==' '||in.peek()=='\t'||in.peek()=='\n'||in.peek()=='\r');in.get());
  };
  out.close();
};

void tree::substitutenames(ifstream& f,streampos& st){
  //More efficient to compile a list of species in advance (?)
  if(n==0){
    int i=0;
    for(;*(label+i)>='0'&&*(label+i)<='9';i++);
    if(*(label+i)){
      return;
    };
    i=atoi(label);
    for(int j=1;j<i;j++){
      for(;f.good()&&!f.eof()&&f.get()!='\n';);
    };
    if(f.eof()||!f.good()){
      f.clear();
      f.seekg(st);
    };
    for(;f.good()&&!f.eof()&&(f.peek()=='\r'||f.peek()=='\t'||f.peek()==' ');f.get());
    delete[] label;
    label=readstring(f," \t");
    f.clear();
    f.seekg(st);
    return;
  };
  for(int i=0;i<n;i++){
    (subtree+i)->substitutenames(f,st);
  };
};
