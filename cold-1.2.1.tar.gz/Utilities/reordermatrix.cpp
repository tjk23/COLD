/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "Miscellaneous.h"
#include "Matrix.h"
#include "Sequence.h"
using namespace std;
int NumCodons=61;
int NumCodonsSq=3721;


int *getperm(char *filename){
  ifstream in(filename);
  int *ans=new int[NumCodons];
  char a[3];
  for(int i=0;i<NumCodons;i++){
    in.read(a,3);
    *(ans+i)=codon(a);
    for(;in.good()&&in.peek()!='A'&&in.peek()!='C'&&in.peek()!='G'&&in.peek()!='T';in.get());
  };
  return ans;
};

int main(int argc, char *argv[]){
  if(argc!=4){
    cout<<"Usage: \""<<argv[0]<<" CodonFile InputFile OutputFile\"";
    exit(0);
  };
  int *p=getperm(argv[1]);
  for(int i=0;i<NumCodons;i++){
    cout<<*(p+i)<<" ";
  };
  cout<<"\n";
  ifstream in(argv[2]);
  ofstream out(argv[3]);
  while(in.good()&&!in.eof()){//Still need to improve matrix input.
    Realmatrix R(in);
    if(R.sz==0){
      break;
    };
    R.resortrows(p);
    R.resortcols(p);
    out.precision(15);
    R.save(out);
    out<<"\n";
  };
  out.close();
  in.close();
};
