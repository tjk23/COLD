/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include "Macros.h"
#include "Miscellaneous.h"
#include "Matrix.h"
#include <stdlib.h>
#include <iostream>
#include <fstream>
using namespace std;
int NumCodons=61;
int NumCodonsSq=3721;

/* 

   For setting up parameter matrices, converting from upper triangular
   columns to a list of matrices. 

*/


void getlinelongdouble(ifstream& in,long double *tmp,int k){
  //Reads a line of k long doubles from stream in.
  for(int i=0;i<k;i++){
    in>>*(tmp+i);
    for(char c=' ';c==' '||c=='\n'||c=='\t';in.get(c));
    in.seekg(-1,ios::cur);
  };
};

void ReadMatrices(char *inputfile,char *outputfile){
  //Reads in a series of matrices from inputfile, and outputs to
  //outputfile. Matrices are given as columns, which form the upper
  //triangular entries of a matrix.
  ifstream in(inputfile);
  if(!in.is_open()){
    cerr<<"Failed to open input file \""<<inputfile<<"\".\n";
    exit(1);
  };
  ofstream out(outputfile);
  if(!out.is_open()){
    cerr<<"Failed to open input file \""<<outputfile<<"\".\n";
    exit(1);
  };

  //Start by determining number of columns;
  int len=0;
  char c;
  for(in.get(c);c!='\n'&&in.good();){
    for(;(c==' '||c=='\t'||c=='\r')&&in.good();in.get(c));//skip over spaces
    //    cout<<"Read character:\n";
    //    cout<<"c=\'"<<c<<"\'\n";
    if(c!='\n'){
      for(len++;isdigit(c)&&in.good();in.get(c));//Need to change this to allow input of decimals.
    };
    //    cout<<"len="<<len<<"\n";
  };//Now len records the number of numbers in the row.
  cout<<"Reading in "<<len<<" matrices.\n";
  in.seekg(0,ios::beg);
  Realmatrix *outp=new Realmatrix[len];
  for(int i=0;i<len;i++){
    *(outp+i)=Realmatrix(NumCodons);
  };
  long double *tmp=new long double[len];
  for(int i=0;i<NumCodons;i++){
    for(int j=0;j<i;j++){
      getlinelongdouble(in,tmp,len);
      for(int k=0;k<len;k++){
	*((outp+k)->entries+i*NumCodons+j)=*(tmp+k);
	*((outp+k)->entries+j*NumCodons+i)=*(tmp+k);
      };
    };
  };
  //Put the correct values for diagonal elements
  for(int i=0;i<NumCodons;i++){
    for(int k=0;k<len;k++){
      *((outp+k)->entries+i*(NumCodons+1))=0;
      for(int j=0;j<NumCodons;j++){
	if(j!=i){
	  *((outp+k)->entries+i*(NumCodons+1))-=*((outp+k)->entries+i*NumCodons+j);
	};
      };
    };
  };
  for(int k=0;k<len;k++){
    (outp+k)->save(out);
    out<<"\n\n";
  };
};

int main(int argc,char *argv[]){
  if(argc!=3){
    cout<<argv[0]<<":\n\tA utility to convert symmetric matrices listed as column vectors in a matrix into a list of matrices which can be read by the program.\n\n";
    cout<<"Usage: "<<argv[0]<<" inputfilename outputfilename\n";
    exit(0);
  };
  ReadMatrices(argv[1],argv[2]);
};
