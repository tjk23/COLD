/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>

int NumCodons=61;
int NumCodonsSq=3721;

#include "Miscellaneous.h"
using namespace std;

const char* validnucleotides="AaCcGgTtUu-?n";
const char* validnucleotidesubst="AACCGGTTTT-??";

int inline validseq(char c){
  for(int i=0;*(validnucleotides+i);i++){
    if(*(validnucleotides+i)==c){
      return i;
    };
  };
  return -1;
};

char *assign(ifstream &in,int &len){
  char *a=new char[25];
  *a=' ';
  for(;in.good()&&(*a==' '||*a=='\t');in.get(*a)); //strip leading spaces.
  if (!in.good()) return NULL;
  char *seq;
  int length;
  if(isdigit(*a)){
    in.get(a+1,24,' ');
    length=atoi(a);
    seq=new char[length+2];
    *seq=' ';
  }else{
    length=len;
    seq=new char[length+2];
    *seq=*a;
  };
  if(length<len){
    len=length;
  };
  int i=0;
  for(;in.good()&&i<length;i++){
    for(;validseq(*(seq+i))==-1;in.get(*(seq+i)));
    *(seq+i)=*(validnucleotidesubst+validseq(*(seq+i)));
    *(seq+i+1)=' ';
  };
  *(seq+i)='\0';
  /*  for(;in.good()&&*seq==' ';in.get(*seq)); //strip leading spaces.
  for(int i=1;i<length;i++){
    in.get(*(seq+i));
    if(*(seq+i)==' '||*(seq+i)=='\t'||*(seq+i)=='\n'||*(seq+i)=='\r'){
      i--;
    };
    if(!in.good()){
      cerr<<"Only able to get "<<i<<" out of "<<length<<" characters.";
      throw 1;
    };
  };
  *(seq+length)='\0';*/
  if(strlen(seq)<(unsigned)length){//Short sequence
    cerr<<"Short sequence. Aborting.\n";
    exit(1);
  };
  //continue to newline;
  for(char t=' ';t!='\n'&&in.good();in.get(t));
  delete[] a;
  return seq;
};

int main(int argc,char *argv[]){
  if(argc<2){
    cout<<"Usage: \""<<argv[0]<<" sequencefile [selection] [outputfile]\"\n";
    exit(0);
  };
  int numseq=-1;
  int len=-1;
  ifstream f(argv[1]);
  streampos st=f.tellg();
  char *firstline=readstring(f,"\n");
  try{
    readline(firstline,"uU",&numseq,-1,&len);
  }catch(char x){//firstline doesn't give general information
    f.seekg(st);
    len=-1;
    numseq=-1;
  };
  int *all=NULL;
  char rd[55];
  int nsq=0;
  if(argc<3){//No selection
    char *outfilename=new char[strlen(argv[1])+10];
    strcpy(outfilename,argv[1]);
    strcat(outfilename,".noamb");
    while(f.good()){
      f.get(*rd);
      for(;f.good()&&(*rd==' '||*rd=='\n'||*rd=='\r'||*rd=='\t');f.get(*rd));
      if(!f.good()){
	break;
      };
      int i=0;
      for(;i<49&&f.good()&&*(rd+i)!=' '&&*(rd+i)!='\t'&&*(rd+i)!='\r'&&*(rd+i)!='\n';f.get(*(rd+(++i))));
      *(rd+i)='\0';
    //      f.get(rd+1,49,' ');//Species name
      char *ch=assign(f,len);
      for(;f.good()&&(*rd==' '||*rd=='\n'||*rd=='\r'||*rd=='\t');f.get(*rd));
      nsq++;
      if(all==NULL){
	all=new int[len];
	for(int i=0;i<len;i++){
	  *(all+i)=1;
	};
      };
      for(int i=0;i<len;i++){
	if(*(ch+i)!='A'&&*(ch+i)!='T'&&*(ch+i)!='C'&&*(ch+i)!='G'){//Ambiguous
	  *(all+i)=0;
	};
      };
      delete[] ch;
    };
    int nlen=0;
    for(int i=0;i*3<len;i++){
      if(!*(all+i*3)||!*(all+i*3+1)||!*(all+i*3+2)){	
	*(all+i*3)=0;
	*(all+i*3+1)=0;
	*(all+i*3+2)=0;
      }else{
	nlen+=3;
      };
    };
    ofstream out(outfilename);
    f.clear();
    f.seekg(0,ios::beg);
    out<<nsq<<"   "<<nlen<<"\n";
    char *firstline=readstring(f,"\n");
    try{
      readline(firstline,"uU",&numseq,-1,&numseq);
    }catch(char x){//firstline doesn't give general information
      f.seekg(st);
    };
    while(f.good()){
      f.get(*rd);
      for(;f.good()&&(*rd==' '||*rd=='\n'||*rd=='\r'||*rd=='\t');f.get(*rd));
      if(!f.good())break;
      int i=0;
      for(;i<49&&f.good()&&*(rd+i)!=' '&&*(rd+i)!='\t'&&*(rd+i)!='\r'&&*(rd+i)!='\n';f.get(*(rd+(++i))));
      *(rd+i)='\0';
      //      f.get(rd+1,49,' ');//Species name
      out<<rd<<"    ";
      char *ch=assign(f,len);
      for(int i=0;i<len;i++){
	if(*(all+i)){
	  out<<*(ch+i);
	};
      };
      out<<"\n";
      delete[] ch;
    };
    out.close();
  }else{
    char *outfilename;
    if(argc<4){
      outfilename=new char[strlen(argv[1])+10];
      strcpy(outfilename,argv[1]);
      strcat(outfilename,".noamb");
    }else{
      outfilename=argv[3];
    };
    int *sel=selection(argv[2]);
    sortlist(sel);
    int *next=sel;
    for(int i=1;f.good()&&*next!=-1;i++){
      f.get(*rd);
      for(;f.good()&&(*rd==' '||*rd=='\n'||*rd=='\r'||*rd=='\t');f.get(*rd));
      f.get(rd+1,49,' ');//Species name
      char *ch=assign(f,len);
      if(i==*next){
	nsq++;
	next++;
	if(all==NULL){
	  all=new int[len];
	  for(int i=0;i<len;i++){
	    *(all+i)=1;
	  };
	};
	for(int j=0;j<len;j++){
	  if(*(ch+j)!='A'&&*(ch+j)!='T'&&*(ch+j)!='C'&&*(ch+j)!='G'){//Ambiguous
	    *(all+j)=0;
	  };
	};
      };
      delete[] ch;
    };
    int nlen=0;
    for(int i=0;i*3<len;i++){
      if(!*(all+i*3)||!*(all+i*3+1)||!*(all+i*3+2)){
	*(all+i*3)=0;
	*(all+i*3+1)=0;
	*(all+i*3+2)=0;
      }else{
	nlen+=3;
      };
    };
    ofstream out(outfilename);
    f.clear();
    f.seekg(st);
    char *firstline=readstring(f,"\n");
    out<<nsq<<"   "<<nlen<<"\n";
    try{
      readline(firstline,"uU",&numseq,-1,&numseq);
    }catch(char x){//firstline doesn't give general information
      f.seekg(st);
    };
    next=sel;
    for(int i=1;f.good()&&*next!=-1;i++){
      f.get(*rd);
      for(;f.good()&&(*rd==' '||*rd=='\n'||*rd=='\r'||*rd=='\t');f.get(*rd));
      f.get(rd+1,49,' ');//Species name
      char *ch=assign(f,len);
      if(i==*next){
	out<<rd<<"   ";
	next++;
	for(int j=0;j<len;j++){
	  if(*(all+j)){
	    out<<*(ch+j);
	  };
	};
	out<<"\n";
      };
      delete[] ch;
    };
    out.close();
  };
};
