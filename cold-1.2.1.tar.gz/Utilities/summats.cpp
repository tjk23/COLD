/*

   Copyright 2011 Toby Kenney

   This file is part of Cold.

   Cold is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Cold is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Cold.  If not, see <http://www.gnu.org/licenses/>.

 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "Miscellaneous.h"
#include "Matrix.h"
using namespace std;
int NumCodons=61;
int NumCodonsSq=3721;

int main(int argc,char *argv[]){
  if(argc<3){
    cout<<"Usage: \""<<argv[0]<<" filename selection [subtracting]\"\n";
    exit(0);
  };
  int *sel=selection(argv[2]);
  sortlist(sel);
  ifstream in(argv[1]);
  int n;
  for(n=0;*(sel+n)>=0;n++);
  Realmatrix* R=new Realmatrix[n];
  int last=0;
  int i=0;
  if(*sel==0){
    i=1;
  };
  for(;*(sel+i)>=0;i++){
    for(int j=last;j<*(sel+i);j++){
      dummyreadmatrix(in);
    };
    *(R+i)=RealmatrixT(in);
    last=*(sel+i)+1;
  };
  in.close();
  if(*sel==0){
    *R=RealmatrixT((R+1)->sz);
    for(int i=0;i<R->sz;i++){
      for(int j=0;j<R->sz;j++){
	*(R->entries+i*R->sz+j)=(i==j)?(1-R->sz):1;
      };
    };
  };
  Realmatrix out(R->sz);
  int ss=R->sz*R->sz;
  for(int i=0;i<ss;i++){
    *(out.entries+i)=0;
  };
  for(int j=0;j<n;j++){
    for(int i=0;i<ss;i++){
      *(out.entries+i)+=*((R+j)->entries+i);
    };
  };
  if(argc>3){
    int *sel=selection(argv[3]);
    sortlist(sel);
    ifstream in(argv[1]);
    for(n=0;*(sel+n)>=0;n++);
    R=new Realmatrix[n];
    last=0;
    for(int i=0;*(sel+i)>=0;i++){
      for(int j=last;j<*(sel+i);j++){
	dummyreadmatrix(in);
      };
      *(R+i)=RealmatrixT(in);
      last=*(sel+i)+1;
    };
    in.close();
    for(int j=0;j<n;j++){
      for(int i=0;i<ss;i++){
	*(out.entries+i)-=*((R+j)->entries+i);
      };
    };
  };
  cout<<out<<"\n";
};
